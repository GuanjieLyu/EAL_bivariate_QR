# CJQR: Copula-Based Joint Quantile Regression

CJQR fits two paired continuous outcomes using enriched asymmetric-Laplace
(EAL) margins, additive location predictors and a copula. Each margin may
have its own covariates and spline basis. A fitted distribution provides
conditional quantiles at multiple probabilities, together with graphical
residual diagnostics and reference-assisted pointwise intervals.

## Installation

Install the runtime dependencies, then install a downloaded source archive:

```r
install.packages(c("mgcv", "qgam", "survival"))
install.packages("CJQR_0.22.0.tar.gz", repos = NULL, type = "source")
library(CJQR)
```

Supply the archive's full path if it is not in the working directory.
Alternatively, run `R CMD INSTALL .` from the package source directory.
CJQR contains no compiled code and does not require LaTeX for installation.
Dependencies installed from source may require R build tools.

## Quick start

```r
dat <- cjqr_example_data(n = 200, seed = 1)

fit <- cjqr_eal(
  list(y1 ~ z + s(x, k = 6), y2 ~ z + s(x, k = 6)),
  data = dat,
  copula = "gaussian",
  anchors = 0.5,
  seed = 1,
  progress = TRUE
)

summary(fit)
cjqr_fit_diagnostics(fit)

grid <- data.frame(x = seq(-1, 1, length.out = 101), z = 0)
q <- predict(fit, newdata = grid, probs = c(0.1, 0.5, 0.9))
q[, 1, ]                       # margin 1: rows by quantile probability
plot(fit, eq = 1, select = 1)   # smooth effect with 95% pointwise CIs
plot(fit, eq = 1, select = 1, se = FALSE)  # estimates only

diagnostics <- cjqr_residual_diagnostics(fit)
plot(diagnostics)              # two Rosenblatt histograms and a contour plot
```

The example fixes one fitting level to shorten the initial workflow. Joint
fitting uses multiple starting configurations and numerical convergence checks,
so fitting time depends on the data and model complexity. The example data
contain Student-t5 location margins with a Gaussian copula.

## Model scope

The model assumes independent subject pairs and a common-error location
structure. Marginal scales, enrichment parameters and copula dependence are
constant across observations. Within a fitted margin, quantiles share their
non-intercept covariate effects and differ by constant shifts. The EAL
polynomial degree is fixed at three.

| Copula | Dependence supported | Additional argument |
|---|---|---|
| `"gaussian"` | Positive or negative | None |
| `"clayton"` | Positive | None |
| `"frank"` | Positive or negative | None |
| `"gumbel"` | Positive | None |
| `"student_t"` | Positive or negative | Fixed `df > 0`, for example `df = 5` |

Student-t degrees of freedom specify the copula, not the EAL margins.
Observation weights, offsets, response variables used as predictors and
covariate-dependent scales or dependence are not supported. Each formula
requires an intercept. Missing values are rejected by default;
`na.action = stats::na.omit` uses the same complete subject pairs
for both margins.

### Fitting levels and prediction levels

`anchors` specifies the fitting level or a set of candidate fitting
levels. By default, the model compares `c(0.25, 0.5, 0.75)` and selects
an admissible fit using the penalized likelihood. For example,
`anchors = 0.10` fixes the fitting level at 0.10.

`probs` specifies which quantiles to report from that fitted distribution;
it does not change the likelihood or refit the model. A numeric vector
requests the same levels for both margins. A two-element list allows
different levels and different numbers of levels:

```r
q_shared <- predict(fit, newdata = grid, probs = c(0.1, 0.9))
# An observation-by-response-by-probability array.

q_margins <- predict(fit, newdata = grid,
                    probs = list(y1 = c(0.1, 0.5), y2 = 0.9))
q_margins$y1  # observation-by-two matrix
q_margins$y2  # observation-by-one matrix
```

Named lists must contain both fitted response names. Unnamed lists follow
formula order. Explicit `probs` supplied to `cjqr_eal()` are stored as
reporting defaults; later prediction calls can override them. Without stored
targets, predictions use .10, .25, .50, .75 and .90, and complete-quantile
plots use .10, .50 and .90.

### Different predictors in the margins

The formulas may use different covariates, smooths and basis dimensions.
For a dataset containing the indicated variables, a specification could be:

```r
formulas <- list(
  y1 ~ group + s(age, k = 6),
  y2 ~ exposure + s(age, k = 8) + s(easting, northing, k = 12)
)
```

A coordinate smooth models location, not residual spatial dependence.
Prediction data must include the union of covariates from both formulas.
When the marginal designs differ, `coef()` and
`predict(type = "lpmatrix")` return response-named lists. Identical designs
retain matrix outputs. Quantile prediction arrays have the same layout in
either case; list-valued probability requests always return lists of matrices.

## Confidence intervals

```r
ci <- cjqr_eal_ci(
  fit, newdata = grid, probs = c(0.1, 0.5, 0.9),
  level = 0.95, B = 500, seed = 2
)
print(ci)
head(as.data.frame(ci))
```

These are **reference-assisted pointwise confidence intervals**, not joint
model standard errors. A paired-subject bootstrap refits auxiliary
least-squares location regressions and recomputes residual quantiles. Each
reference percentile interval is enlarged if necessary to contain the
unchanged joint estimate; the joint EAL model is not refitted.

The method requires independent pairs, finite-variance common errors
independent of covariates, an adequate fixed basis and positive continuous
residual densities at the requested quantiles. It does not provide general
coverage for heteroscedastic, clustered, longitudinal or complex-survey data.
Failed resamples make intervals unavailable and are reported in the result.
See `?cjqr_eal_ci` for the full assumptions and output structure.

### Experimental effect inference

```r
inference <- summary(fit, inference = "reference", B = 500, seed = 1)
print(inference)
```

Reference-assisted intervals and tests for parametric effects, whole-smooth
tests and Kendall's tau intervals are experimental and opt-in. Coefficient
coverage was below the nominal level in some validation settings; these
procedures are not established defaults for confirmatory inference. They
require the same common-error location assumptions and do not estimate a
joint parameter covariance. Details are available in `?cjqr_eal_coef_ci`,
`?cjqr_eal_smooth_test` and `?cjqr_eal_tau_ci`.

The default `summary(fit)` performs no bootstrap. It reports coefficient
estimates and descriptive conditional effective degrees of freedom (EDF).
EDF may be unavailable at likelihood cusps, search boundaries or singular
information matrices.

### Smooth plots with confidence intervals

```r
plot(fit, eq = 1, select = 1)  # se = TRUE, level = 0.95, B = 500
smooth_data <- plot(fit, eq = 2, select = 1, B = 999, seed = 2,
                    draw = FALSE)
```

The default `se = TRUE` adds reference-assisted **pointwise** smooth intervals,
drawn as two dashed lines without shading. It does not calculate joint-model
standard errors. Auxiliary least-squares
regressions are bootstrapped using complete paired rows. Each smooth is
evaluated and centered over the same original cohort as the joint smooth,
and its percentile interval is enlarged to contain the joint estimate.
The joint model is not refitted, and a prior `summary()` call is not required.
These intervals rely on finite-variance common location errors independent
of covariates and an adequate, full-rank fixed basis. They are not simultaneous
bands and do not guarantee nominal finite-sample coverage.

Use `se = FALSE` for estimates alone. For two-dimensional smooths, `se = TRUE`
shows the fitted surface and the lower and upper pointwise confidence
surfaces on a common scale. A failed auxiliary draw stops the confidence
plot rather than silently dropping the draw. Returned plot data include
the endpoints and bootstrap diagnostics; see `?cjqr_eal_methods`.
Complete-quantile plots remain separate and request intervals through
`interval = "confidence"`.

## Diagnostics and copula comparisons

`cjqr_fit_diagnostics(fit)` reports numerical convergence checks.
`summary(fit)$convergence$status` is `"converged"`, `"not converged"` or
`"not assessed"`. Numerical convergence does not guarantee a global optimum
or an adequate statistical model.

`cjqr_residual_diagnostics(fit)` computes Rosenblatt residuals. The plot
shows the first response's marginal probability transform, the second
response's conditional transform, and empirical normal-score density
contours. Use `order = c(2, 1)` to reverse the conditioning order, or supply
`newdata` for held-out observations. Histograms and contours are descriptive
checks, not calibrated goodness-of-fit tests. Marginal residuals are also
available through `residuals(fit, type = "pit")` and
`residuals(fit, type = "quantile")`.

For compatible copula fits, `cjqr_eal_ic()`, `AIC()` and `BIC()` provide
qualified comparison criteria based on the unpenalized joint log likelihood
and conditional joint-score EDF. AIC is an OPG/expected-Fisher approximation;
EDF-based BIC is a heuristic, not marginal-likelihood evidence. Both condition
on the selected anchor, smoothing parameters, EAL degree and fixed copula
degrees of freedom. They are not comparable to native `qgam` criteria.
See `?cjqr_eal_ic` before using or reporting them.

## Documentation and contributions

Start with `help("CJQR-package", package = "CJQR")` and the
[user guide](inst/notes/user-guide.md). See [model scope](MODEL_SCOPE.md)
for the supported specifications and inferential limitations. In an installed package:

```r
file.show(system.file("notes", "user-guide.md", package = "CJQR"))
citation("CJQR")
```

Save the analysis code, fitted objects, random seeds and `sessionInfo()` for
reproducibility. See [CONTRIBUTING.md](CONTRIBUTING.md) for issue reporting,
development checks and release procedures. CJQR is distributed under the
MIT license.
