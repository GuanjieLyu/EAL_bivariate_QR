test_that("example data are reproducible finite paired data with the documented DGP", {
  a <- cjqr_example_data(n = 80L, seed = 19L)
  expect_s3_class(a, "data.frame")
  expect_identical(names(a), c("y1", "y2", "x", "z"))
  expect_identical(nrow(a), 80L)
  expect_true(all(vapply(a, is.numeric, logical(1))))
  expect_true(all(is.finite(as.matrix(a))))
  expect_true(all(a$x >= -1 & a$x <= 1))
  expect_true(all(a$z %in% 0:1))
  expect_identical(a, cjqr_example_data(n = 80L, seed = 19L))
  expect_false(identical(a, cjqr_example_data(n = 80L, seed = 20L)))
  expected <- CJQR:::.cjqr_eal_with_seed(19L, {
    x <- runif(80L, -1, 1)
    z <- rbinom(80L, 1, .5)
    g1 <- rnorm(80L)
    rho <- sin(pi / 4)
    g2 <- rho * g1 + sqrt(1 - rho^2) * rnorm(80L)
    data.frame(y1 = .3 + .6 * z + 1.1 * sin(pi * x) +
                 .8 * sqrt(3 / 5) * qt(pnorm(g1), 5),
               y2 = -.2 - .5 * z + cos(pi * x) +
                 .9 * sqrt(3 / 5) * qt(pnorm(g2), 5), x = x, z = z)
  })
  expect_equal(a, expected, tolerance = 1e-12)
  expect_identical(nrow(cjqr_example_data()), 200L)
})

test_that("example generation preserves caller RNG kind, state and seed absence", {
  old_kind <- RNGkind()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    do.call(RNGkind, as.list(old_kind))
    if (had_seed) assign(".Random.seed", old_seed, envir = .GlobalEnv) else
      if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
        rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  RNGkind("L'Ecuyer-CMRG", "Inversion", "Rejection")
  set.seed(74L)
  before <- .Random.seed
  kind <- RNGkind()
  invisible(cjqr_example_data(n = 30L, seed = 11L))
  expect_identical(.Random.seed, before)
  expect_identical(RNGkind(), kind)
  expect_error(cjqr_example_data(n = 29L), "n")
  expect_identical(.Random.seed, before)
  expect_identical(RNGkind(), kind)
  rm(".Random.seed", envir = .GlobalEnv)
  invisible(cjqr_example_data(n = 30L, seed = 11L))
  expect_false(exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
  expect_identical(RNGkind(), kind)
})

test_that("example helper rejects invalid sizes and seeds without implicit coercion", {
  for (n in list(0, 29, 30.5, NA_real_, Inf, "200", TRUE, 1000001L))
    expect_error(cjqr_example_data(n = n), "n|1000000")
  for (seed in list(-1, 1.5, NA_real_, Inf, "1", .Machine$integer.max))
    expect_error(cjqr_example_data(seed = seed), "seed")
})

.eal_ci_table_fixture <- function(m = 2L, probs = c(.9, .1),
                                    labeled = TRUE, available = TRUE) {
  dims <- c(m, 2L, length(probs))
  labels <- if (labeled) list(if (m) paste("case", seq_len(m)) else character(), c("Y left", "Y right"),
                              as.character(probs)) else NULL
  fit <- array(seq_len(prod(dims)), dims, dimnames = labels)
  lo <- fit - .2
  hi <- fit + .3
  if (!available) lo[] <- hi[] <- NA_real_
  result <- list(fit = fit, lower = lo, upper = hi,
    reference = list(fit = fit + .1, lower = lo, upper = hi),
    probs = probs, level = .95, available = available,
    method = "reference-assisted minimal-containment pointwise interval",
    error = if (available) NULL else "one bootstrap draw failed",
    bootstrap = list(requested = 500L, attempted = 500L,
      successful = if (available) 500L else 499L, failed = if (available) 0L else 1L),
    assumptions = "Independent common-error location pairs")
  class(result) <- "cjqr_eal_ci"
  result
}

test_that("CI tables preserve exact values and row-response-probability ordering", {
  ci <- .eal_ci_table_fixture()
  frozen <- serialize(ci, NULL)
  a <- as.data.frame(ci)
  expect_s3_class(a, "data.frame")
  expect_identical(names(a), c("row_index", "response", "prob", "estimate",
                               "lower", "upper", "available", "row_label"))
  expect_identical(a$row_index, rep(1:2, each = 4L))
  expect_identical(a$response, rep(c("Y left", "Y left", "Y right", "Y right"), 2L))
  expect_identical(a$prob, rep(c(.9, .1), 4L))
  expect_equal(a$estimate, c(1, 5, 3, 7, 2, 6, 4, 8), tolerance = 0)
  expect_equal(a$lower, a$estimate - .2, tolerance = 0)
  expect_equal(a$upper, a$estimate + .3, tolerance = 0)
  expect_identical(a$row_label, rep(c("case 1", "case 2"), each = 4L))
  expect_true(all(a$available))
  expect_identical(attr(a, "cjqr_interval")$level, .95)
  expect_identical(attr(a, "cjqr_interval")$method, ci$method)
  expect_false(attr(a, "cjqr_interval")$native_joint_standard_errors)
  expect_identical(serialize(ci, NULL), frozen)
  b <- as.data.frame(ci, include_reference = TRUE)
  expect_equal(b$reference_estimate, b$estimate + .1, tolerance = 0)
  expect_identical(b$reference_lower, b$lower)
  expect_identical(b$reference_upper, b$upper)
})

test_that("CI tables handle missing names, one quantile, custom names and empty rows", {
  a <- as.data.frame(.eal_ci_table_fixture(m = 1L, probs = .37, labeled = FALSE))
  expect_identical(nrow(a), 2L)
  expect_identical(a$response, c("margin1", "margin2"))
  expect_identical(a$prob, c(.37, .37))
  expect_false("row_label" %in% names(a))
  ci <- .eal_ci_table_fixture()
  rn <- paste0("interval_", seq_len(8L))
  b <- as.data.frame(ci, row.names = rn, optional = TRUE)
  expect_identical(rownames(b), rn)
  expect_identical(b$row_label, rep(c("case 1", "case 2"), each = 4L))
  dimnames(ci$fit)[[1L]] <- c("duplicate", "duplicate")
  d <- as.data.frame(ci)
  expect_identical(d$row_label, rep("duplicate", 8L))
  empty <- as.data.frame(.eal_ci_table_fixture(m = 0L), include_reference = TRUE)
  expect_identical(nrow(empty), 0L)
  expect_true(all(c("estimate", "reference_estimate", "available") %in% names(empty)))
  expect_true(attr(empty, "cjqr_interval")$available)
})

test_that("failed intervals retain points and all-NA bounds without false precision", {
  ci <- .eal_ci_table_fixture(available = FALSE)
  a <- as.data.frame(ci, include_reference = TRUE)
  expect_identical(nrow(a), 8L)
  expect_true(all(is.finite(a$estimate)))
  expect_true(all(is.na(a$lower) & is.na(a$upper)))
  expect_true(all(is.na(a$reference_lower) & is.na(a$reference_upper)))
  expect_true(all(!a$available))
  expect_identical(attr(a, "cjqr_interval")$error, ci$error)
  expect_identical(attr(a, "cjqr_interval")$bootstrap$failed, 1L)
  expect_false(any(names(a) %in% c("se", "std.error", "std_error", "standard_error")))
  empty <- as.data.frame(.eal_ci_table_fixture(m = 0L, available = FALSE))
  expect_identical(nrow(empty), 0L)
  expect_false(attr(empty, "cjqr_interval")$available)
})

test_that("CI conversion rejects malformed or misleading interval objects", {
  ci <- .eal_ci_table_fixture()
  expect_error(as.data.frame(ci, include_reference = NA), "include_reference")
  expect_error(as.data.frame(ci, optional = 1), "optional")
  expect_error(as.data.frame(ci, stringsAsFactors = FALSE), "Unsupported")
  bad <- ci
  bad$probs <- .5
  expect_error(as.data.frame(bad), "probability dimension")
  bad <- ci
  bad$lower <- matrix(0, 2, 4)
  expect_error(as.data.frame(bad), "dimensions")
  bad <- ci
  bad$lower[1L] <- Inf
  expect_error(as.data.frame(bad), "finite")
  bad <- ci
  bad$upper[1L] <- bad$fit[1L] - .1
  expect_error(as.data.frame(bad), "contain")
  bad <- ci
  bad$available <- FALSE
  expect_error(as.data.frame(bad), "all-NA")
  bad <- ci
  bad$available <- NA
  expect_error(as.data.frame(bad), "available")
  bad <- ci
  bad$level <- 1
  expect_error(as.data.frame(bad), "confidence level")
  bad <- ci
  bad$reference <- NULL
  expect_error(as.data.frame(bad, include_reference = TRUE), "no reference")
  bad <- ci
  bad$reference$upper <- bad$upper + 1
  expect_error(as.data.frame(bad, include_reference = TRUE), "Reference bounds")
})
