# Independent tau-a concordance and paired-residual bootstrap checks.
# No EAL optimizer or joint-model refit is invoked by these fixtures.
.eal_tau_oracle <- function(z) {
  n <- nrow(z)
  sign_x <- sign(outer(z[, 1L], z[, 1L], "-"))
  sign_y <- sign(outer(z[, 2L], z[, 2L], "-"))
  kernel <- sign_x * sign_y
  upper <- upper.tri(kernel)
  counts <- c(concordant = sum(kernel[upper] > 0),
    discordant = sum(kernel[upper] < 0),
    tied.x = sum(sign_x[upper] == 0 & sign_y[upper] != 0),
    tied.y = sum(sign_y[upper] == 0 & sign_x[upper] != 0),
    tied.xy = sum(sign_x[upper] == 0 & sign_y[upper] == 0))
  list(tau = sum(kernel[upper]) / choose(n, 2), counts = counts)
}

.eal_tau_opts <- function(B = 9L, level = .95, keep = TRUE) {
  CJQR:::.cjqr_eal_ci_options(.5, level, B, 24L, 1L, 256, keep)
}

test_that("fast Kendall counts reproduce the sign-kernel tau-a including ties", {
  near <- c(1, 1 + 1e-12, 1 + 2e-12, 2, 3, 4)
  cases <- list(cbind(1:6, 1:6), cbind(1:6, 6:1),
    cbind(c(1, 1, 2, 3, 4, 5), c(2, 3, 3, 1, 5, 4)),
    cbind(c(1, 1, 2, 2, 3, 3), c(4, 4, 5, 2, 1, 1)),
    cbind(rep(1, 6), 1:6), cbind(rep(1, 6), rep(2, 6)),
    cbind(near, c(near[3L], near[2L], near[1L], near[4:6])),
    cbind(c(-1e150, -1, 0, 1e-150, 1, 1e150), c(3, 6, 1, 4, 2, 5)))
  for (z in cases) {
    out <- CJQR:::.cjqr_eal_tau_a(z)
    oracle <- .eal_tau_oracle(z)
    expect_equal(out$tau, oracle$tau, tolerance = 1e-14)
    expect_equal(unname(out$counts), unname(oracle$counts), tolerance = 0)
    expect_equal(sum(out$counts), out$pairs)
    expect_equal(out$pairs, choose(nrow(z), 2))
    expect_identical(out$original_ties,
      vapply(1:2, function(j) anyDuplicated(z[, j]) > 0L, logical(1L)))
  }
  tied <- cases[[3L]]
  out <- CJQR:::.cjqr_eal_tau_a(tied)
  expect_gt(abs(out$tau - cor(tied[, 1L], tied[, 2L], method = "kendall")), .001)
  expect_error(CJQR:::.cjqr_eal_tau_a(tied, original = TRUE), "Original residual ties")
  expect_no_error(CJQR:::.cjqr_eal_tau_a(cases[[7L]], original = TRUE))
})

test_that("tau-a is permutation and monotone-coordinate invariant", {
  z <- cbind(c(2, 6, 1, 4, 7, 3, 5), c(7, 3, 6, 2, 4, 1, 5))
  tau <- CJQR:::.cjqr_eal_tau_a(z)$tau
  expect_equal(CJQR:::.cjqr_eal_tau_a(z[7:1, , drop = FALSE])$tau, tau)
  expect_equal(CJQR:::.cjqr_eal_tau_a(cbind(exp(z[, 1L]), z[, 2L]^3))$tau, tau)
  expect_equal(CJQR:::.cjqr_eal_tau_a(cbind(-z[, 1L], z[, 2L]))$tau, -tau)
  expect_equal(CJQR:::.cjqr_eal_tau_a(z[, 2:1, drop = FALSE])$tau, tau)
  for (bad in list(z[, 1L], z[1:2, , drop = FALSE], cbind(z, 1),
    matrix(NA_real_, 5, 2), matrix(Inf, 5, 2)))
    expect_error(CJQR:::.cjqr_eal_tau_a(bad), "finite paired residuals")
})

test_that("tau envelopes contain both bootstrap intervals and the unchanged joint value", {
  draws <- seq(-.4, .6, length.out = 101L)
  status <- data.frame(ok = rep(TRUE, 101L), error = "")
  opts <- .eal_tau_opts(101L)
  ends <- quantile(draws, c((1 - opts$level) / 2, (1 + opts$level) / 2), type = 8L, names = FALSE)
  for (reference in c(-.15, .1, .4)) for (point in c(-.95, -.1, .95)) {
    basic <- 2 * reference - rev(ends)
    envelope <- pmax(-1, pmin(1, c(min(ends[1L], basic[1L]), max(ends[2L], basic[2L]))))
    out <- CJQR:::.cjqr_eal_tau_interval(point, list(tau = reference), draws, status, opts)
    expect_s3_class(out, "cjqr_eal_tau_ci")
    expect_true(out$available)
    expect_identical(out$estimate, point)
    expect_equal(unname(out$percentile_interval), ends)
    expect_equal(unname(out$basic_interval), basic)
    expect_equal(unname(out$reference_interval), envelope)
    expect_equal(unname(out$interval), c(min(envelope[1L], point), max(envelope[2L], point)))
    expect_lte(out$interval[1L], point)
    expect_gte(out$interval[2L], point)
    expect_lte(out$interval[1L], out$reference_interval[1L])
    expect_gte(out$interval[2L], out$reference_interval[2L])
    expect_true(all(out$interval >= -1 & out$interval <= 1))
    for (component in list(out$percentile_interval, out$basic_interval)) {
      intersection <- c(max(-1, component[1L]), min(1, component[2L]))
      if (intersection[1L] <= intersection[2L]) {
        expect_lte(out$reference_interval[1L], intersection[1L])
        expect_gte(out$reference_interval[2L], intersection[2L])
      }
    }
    expect_identical(out$draws, draws)
    expect_false(out$interpretation$native_joint_covariance)
  }
  wide <- CJQR:::.cjqr_eal_tau_interval(.1, list(tau = .1), draws, status, .eal_tau_opts(101L, .99))
  narrow <- CJQR:::.cjqr_eal_tau_interval(.1, list(tau = .1), draws, status, .eal_tau_opts(101L, .80))
  expect_lte(wide$interval[1L], narrow$interval[1L])
  expect_gte(wide$interval[2L], narrow$interval[2L])
  expect_identical(wide$estimate, narrow$estimate)
})

test_that("tau bootstrap envelopes obey reflection sign and affine equivariance away from bounds", {
  # Deliberately skewed draws: the percentile and basic intervals differ.
  draws <- seq(-.2, .6, length.out = 101L)^3
  reference <- -.05
  point <- .1
  status <- data.frame(ok = rep(TRUE, 101L), error = "")
  opts <- .eal_tau_opts(101L)
  calculate <- function(r, b, d) CJQR:::.cjqr_eal_tau_interval(b, list(tau = r), d, status, opts)
  out <- calculate(reference, point, draws)
  expect_gt(max(abs(out$percentile_interval - out$basic_interval)), .01)
  expect_equal(mean(out$reference_interval), reference, tolerance = 1e-14)
  radius <- max(abs(out$percentile_interval - reference))
  expect_equal(unname(out$reference_interval), reference + c(-radius, radius), tolerance = 1e-14)
  reflected <- calculate(reference, point, 2 * reference - draws)
  expect_equal(reflected$reference_interval, out$reference_interval, tolerance = 1e-14)
  expect_equal(unname(reflected$percentile_interval), unname(out$basic_interval), tolerance = 1e-14)
  expect_equal(unname(reflected$basic_interval), unname(out$percentile_interval), tolerance = 1e-14)
  expect_equal(reflected$interval, out$interval, tolerance = 1e-14)
  for (transform in list(c(scale = -1, shift = 0), c(scale = 1.3, shift = .12),
                         c(scale = -.7, shift = .2))) {
    a <- unname(transform["scale"])
    c0 <- unname(transform["shift"])
    moved <- calculate(a * reference + c0, a * point + c0, a * draws + c0)
    for (field in c("percentile_interval", "basic_interval", "reference_interval", "interval"))
      expect_equal(unname(moved[[field]]), sort(a * unname(out[[field]]) + c0), tolerance = 1e-13)
  }
  expect_identical(out$draws, draws)
})

test_that("tau envelopes clip only the parameter-space bounds and preserve raw reflection diagnostics", {
  status <- data.frame(ok = rep(TRUE, 101L), error = "")
  opts <- .eal_tau_opts(101L)
  for (sign in c(-1, 1)) {
    draws <- sign * seq(.05, .4, length.out = 101L)
    reference <- sign * .9
    out <- CJQR:::.cjqr_eal_tau_interval(sign * .8, list(tau = reference), draws, status, opts)
    expect_true(out$available)
    expect_true(all(out$reference_interval >= -1 & out$reference_interval <= 1))
    expect_true(all(out$interval >= -1 & out$interval <= 1))
    expect_true(any(abs(out$basic_interval) > 1))
    expect_equal(if (sign < 0) out$reference_interval[1L] else out$reference_interval[2L],
      setNames(sign, if (sign < 0) "lower" else "upper"))
    expect_lte(out$reference_interval[1L], out$percentile_interval[1L])
    expect_gte(out$reference_interval[2L], out$percentile_interval[2L])
    expect_identical(out$draws, draws)
  }
})

test_that("tau intervals fail closed for failed draws or degenerate dependence", {
  draws <- seq(-.4, .6, length.out = 101L)
  status <- data.frame(ok = rep(TRUE, 101L), error = "")
  opts <- .eal_tau_opts(101L)
  cases <- list(list(reference = list(tau = 1), draws = draws, status = status),
    list(reference = list(tau = -1), draws = draws, status = status),
    list(reference = list(tau = .1), draws = rep(.1, 101L), status = status),
    list(reference = simpleError("Original residual ties"), draws = draws, status = status),
    list(reference = list(tau = .1), draws = replace(draws, 13L, NA_real_), status = status))
  bad_status <- status
  bad_status$ok[13L] <- FALSE
  bad_status$error[13L] <- "rank_deficient_subject_resample"
  cases[[length(cases) + 1L]] <- list(reference = list(tau = .1), draws = draws, status = bad_status)
  for (case in cases) {
    out <- do.call(CJQR:::.cjqr_eal_tau_interval, c(list(joint_tau = .25, opts = opts), case))
    expect_false(out$available)
    expect_identical(out$estimate, .25)
    expect_true(all(is.na(out$interval)))
    expect_true(all(is.na(out$reference_interval)))
    expect_true(all(is.na(out$percentile_interval)))
    expect_true(all(is.na(out$basic_interval)))
    expect_match(out$reason, "failed|Degenerate")
    expect_identical(out$bootstrap$replacement_draws, 0L)
  }
})

test_that("paired OLS residual tau draws agree with direct nuisance-adjusted refits", {
  for (distinct in c(FALSE, TRUE)) {
    fit <- .eal_coef_fixture(distinct)
    before <- serialize(fit, NULL)
    set.seed(747L)
    rng <- .Random.seed
    out <- cjqr_eal_tau_ci(fit, B = 149L, seed = 31L, keep_draws = TRUE)
    expect_identical(.Random.seed, rng)
    expect_identical(serialize(fit, NULL), before)
    expect_true(out$available)
    expect_s3_class(out, "cjqr_eal_tau_ci")
    expect_identical(out$bootstrap$successful, 149L)
    expect_identical(out$bootstrap$failed, 0L)
    expect_identical(out$bootstrap$joint_refits, 0L)
    expect_identical(out$bootstrap$replacement_draws, 0L)
    expect_true(out$bootstrap$paired_subject_rows)
    expect_true(out$bootstrap$all_draws_required)
    expect_identical(out$bootstrap$tau_statistic, "tau-a")
    expect_identical(out$bootstrap$endpoint_quantile_type, 8L)
    expect_true(out$interpretation$bootstrap_duplicate_rows_retained)
    expect_false(out$interpretation$anchor_adjustment_required)
    expect_false(out$interpretation$original_ties_supported)
    X <- if (distinct) fit$X else list(fit$X, fit$X)
    residual <- vapply(1:2, function(j) fit$Y[, j] -
      drop(X[[j]] %*% qr.coef(qr(X[[j]]), fit$Y[, j])), numeric(nrow(fit$Y)))
    expect_equal(out$reference$tau, .eal_tau_oracle(residual)$tau, tolerance = 1e-14)
    indices <- CJQR:::.cjqr_eal_ci_indices(nrow(fit$Y), 149L, 31L)
    expect_true(all(apply(indices, 2L, anyDuplicated) > 0))
    direct <- vapply(seq_len(149L), function(b) {
      ii <- indices[, b]
      errors <- vapply(1:2, function(j) {
        xb <- X[[j]][ii, , drop = FALSE]
        fit$Y[ii, j] - drop(xb %*% qr.coef(qr(xb), fit$Y[ii, j]))
      }, numeric(length(ii)))
      .eal_tau_oracle(errors)$tau
    }, numeric(1L))
    expect_equal(out$draws, direct, tolerance = 1e-14)
    expect_equal(out$estimate, CJQR:::.cjqr_kendall_tau(fit$fit$theta, fit$copula))
    expect_lte(out$interval[1L], out$estimate)
    expect_gte(out$interval[2L], out$estimate)
    expect_match(out$target, "not a pseudo-true likelihood parameter", fixed = TRUE)
  }
})

test_that("adding tau inference preserves existing coefficient and smooth calculations", {
  fit <- .eal_coef_fixture(distinct = TRUE)
  ref <- CJQR:::.cjqr_eal_coefficient_inference(fit, B = 149L, seed = 22L,
    keep_draws = TRUE, include_smooth = TRUE)
  extended <- CJQR:::.cjqr_eal_coefficient_inference(fit, B = 149L, seed = 22L,
    keep_draws = TRUE, include_smooth = TRUE, include_tau = TRUE)
  expect_identical(extended$tables, ref$tables)
  expect_identical(extended$reference, ref$reference)
  expect_identical(extended$draws, ref$draws)
  expect_identical(extended$smooth, ref$smooth)
  expect_true(extended$tau_ci$available)
  expect_true(extended$interpretation$includes_dependence_inference)
  expect_null(ref$tau_ci)
  direct <- cjqr_eal_tau_ci(fit, B = 149L, seed = 22L, keep_draws = TRUE)
  expect_identical(extended$tau_ci, direct)
})

test_that("original residual ties disable only tau inference", {
  fit <- .eal_coef_fixture()
  fit$X[2L, ] <- fit$X[1L, ]
  fit$Y[2L, ] <- fit$Y[1L, ]
  n <- nrow(fit$X)
  opts <- .eal_tau_opts(9L)
  indices <- matrix(rep(seq_len(n), opts$B), nrow = n)
  blocks <- lapply(1:2, function(j) CJQR:::.cjqr_eal_smooth_blocks(fit, j))
  base <- CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y,
    CJQR:::.cjqr_eal_betas(fit$fit$beta), list(1:2, 1:2), opts,
    resamples = indices, smooth_blocks = blocks)
  out <- CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y,
    CJQR:::.cjqr_eal_betas(fit$fit$beta), list(1:2, 1:2), opts,
    resamples = indices, smooth_blocks = blocks, joint_tau = -.2)
  expect_true(out$available)
  expect_true(out$smooth$available)
  expect_false(out$tau_ci$available)
  expect_identical(out$tables, base$tables)
  expect_identical(out$draws, base$draws)
  expect_identical(out$smooth, base$smooth)
  expect_identical(out$tau_ci$bootstrap$successful, 0L)
  expect_identical(out$tau_ci$bootstrap$failed, 9L)
  expect_true(all(grepl("Original residual ties", out$tau_ci$bootstrap$status$error)))
  expect_true(all(is.na(out$tau_ci$interval)))
})

test_that("failed OLS bootstrap rows cannot be omitted from tau inference", {
  fit <- .eal_coef_fixture()
  opts <- .eal_tau_opts(9L)
  n <- nrow(fit$X)
  indices <- matrix(rep(seq_len(n), opts$B), nrow = n)
  indices[, 4L] <- 1L
  expect_warning(out <- CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y,
    CJQR:::.cjqr_eal_betas(fit$fit$beta), list(1:2, 1:2), opts,
    resamples = indices, joint_tau = -.2), "No failed draws were discarded or replaced")
  expect_false(out$tau_ci$available)
  expect_identical(out$tau_ci$bootstrap$successful, 8L)
  expect_identical(out$tau_ci$bootstrap$failed, 1L)
  expect_identical(out$tau_ci$bootstrap$replacement_draws, 0L)
  expect_match(out$tau_ci$bootstrap$status$error[4L], "rank_deficient")
  expect_true(is.na(out$tau_ci$draws[4L]))
  expect_true(all(is.na(out$tau_ci$interval)))
})

test_that("tau inference is independent of anchor metadata and marginal constants", {
  fit <- .eal_coef_fixture()
  original <- cjqr_eal_tau_ci(fit, B = 149L, seed = 63L, keep_draws = TRUE)
  fit$anchors <- fit$anchor <- NULL
  fit$selection <- list(strict_ok = TRUE)
  fit$fit$p <- .25
  fit$fit$beta[1L, ] <- fit$fit$beta[1L, ] + c(4, -8)
  changed <- cjqr_eal_tau_ci(fit, B = 149L, seed = 63L, keep_draws = TRUE)
  expect_identical(changed, original)
  fit$Y <- sweep(fit$Y, 2L, c(2, -3), "+")
  shifted <- cjqr_eal_tau_ci(fit, B = 149L, seed = 63L, keep_draws = TRUE)
  expect_equal(shifted$draws, original$draws, tolerance = 1e-14)
  expect_equal(shifted$interval, original$interval, tolerance = 1e-14)
})

test_that("fitted tau remains the selected copula transformation and printing preserves it", {
  fit <- .eal_coef_fixture()
  cases <- list(gaussian = -.4, student_t = -.4, clayton = 2, frank = -4, gumbel = 2)
  for (family in names(cases)) {
    fit$copula <- family
    fit$df <- if (family == "student_t") 5 else NULL
    fit$fit$theta <- cases[[family]]
    out <- cjqr_eal_tau_ci(fit, B = 100L, seed = 36L)
    expect_equal(out$estimate, CJQR:::.cjqr_kendall_tau(cases[[family]], family, df = fit$df))
    expect_true(out$available)
    before <- serialize(out, NULL)
    txt <- paste(capture.output(print(out)), collapse = "\n")
    expect_match(txt, "Estimated Kendall's tau", fixed = TRUE)
    expect_match(txt, "95% CI", fixed = TRUE)
    expect_false(grepl("reference-assisted|theta =|Wald|Std. Error", txt))
    expect_identical(serialize(out, NULL), before)
    expect_null(out$draws)
  }
  expect_error(print(out, digits = 0), "digits")
  expect_error(print(out, digits = 23), "digits")
  expect_error(print(out, extra = TRUE), "Unsupported tau")
  expect_error(cjqr_eal_tau_ci(fit, B = 1L), "B")
  expect_error(cjqr_eal_tau_ci(fit, level = 1), "level")
  for (value in list(NA_real_, Inf, -1.1, c(.1, .2))) {
    expect_error(CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y,
      CJQR:::.cjqr_eal_betas(fit$fit$beta), list(1:2, 1:2), .eal_tau_opts(),
      joint_tau = value), "Invalid fitted Kendall tau")
  }
})
