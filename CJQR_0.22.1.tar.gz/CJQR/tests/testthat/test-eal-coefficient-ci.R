.eal_coef_opts <- function(B = 12L, level = .95, seed = 27L, keep = TRUE) {
  CJQR:::.cjqr_eal_ci_options(.5, level, B, seed, 1L, 256, keep)
}

test_that("coefficient hulls contain both their reference and unchanged joint estimates", {
  fit <- .eal_coef_fixture()
  frozen <- serialize(fit, NULL)
  out <- cjqr_eal_coef_ci(fit, B = 100L, seed = 72L, keep_draws = TRUE)
  expect_s3_class(out, "cjqr_eal_coef_ci")
  expect_true(out$available)
  expect_identical(names(out$tables), c("y1", "y2"))
  expect_identical(out$bootstrap$joint_refits, 0L)
  expect_identical(out$bootstrap$successful, 100L)
  expect_identical(out$bootstrap$replacement_draws, 0L)
  expect_true(out$bootstrap$paired_subject_rows)
  expect_true(out$bootstrap$all_draws_required)
  expect_false(out$interpretation$is_joint_sampling_SE)
  expect_false(out$interpretation$is_Wald_test)
  expect_identical(serialize(fit, NULL), frozen)
  for (j in 1:2) {
    tab <- out$tables[[j]]
    expect_identical(rownames(tab), c("(Intercept)", "z"))
    expect_identical(colnames(tab), c("Estimate", "Lower 95%", "Upper 95%", "p-value"))
    expect_equal(tab[, "Estimate"], setNames(fit$fit$beta[1:2, j], rownames(tab)))
    expect_true(all(is.finite(tab[1L, -1L])))
    expect_lte(tab[2L, 2L], out$reference[[j]][2L, 2L])
    expect_gte(tab[2L, 3L], out$reference[[j]][2L, 3L])
    expect_lte(tab[2L, 2L], tab[2L, 1L])
    expect_gte(tab[2L, 3L], tab[2L, 1L])
    expect_true(all(is.finite(tab[2L, ])))
    expect_gte(tab[2L, 4L], 2 / 101)
    expect_lte(tab[2L, 4L], 1)
    expect_identical(rownames(out$draws$coefficients[[j]]), c("(Intercept)", "z"))
  }
  expect_output(print(out), "joint refits: 0")
  expect_output(print(out), "no joint-model SEs")
})

test_that("paired coefficient resampling agrees with direct least squares for different bases", {
  fit <- .eal_coef_fixture(distinct = TRUE)
  out <- cjqr_eal_coef_ci(fit, B = 100L, seed = 90L, keep_draws = TRUE)
  expect_true(out$available)
  expect_identical(rownames(out$tables[[1L]]), c("(Intercept)", "z"))
  expect_identical(rownames(out$tables[[2L]]), c("(Intercept)", "w", "v"))
  for (b in c(1L, 17L, 100L)) {
    ii <- out$draws$indices[, b]
    for (j in 1:2) {
      ref <- qr.coef(qr(fit$X[[j]][ii, , drop = FALSE]), fit$Y[ii, j])
      ids <- seq_len(nrow(out$tables[[j]]))
      expect_equal(out$draws$coefficients[[j]][, b], ref[ids], tolerance = 1e-12)
    }
  }
  expect_true(all(is.finite(out$tables[[2L]][1L, -1L])))
  expect_true(all(is.finite(out$tables[[2L]][-1L, ])))
})

test_that("interval inversion agrees with an independent dense alpha grid", {
  pfun <- CJQR:::.cjqr_eal_coef_tail_p
  # Distinct, tied and skewed draws exercise strict endpoint comparisons.
  cases <- list(seq(-.4, 2, length.out = 501L),
    c(rep(-.2, 60L), rep(0, 30L), rep(.5, 411L)),
    sort(c(seq(-2, -.1, length.out = 410L), seq(0, .3, length.out = 91L))))
  alphas <- seq(0, 1, length.out = 20001L)
  for (draws in cases) for (joint in c(-.7, .7)) {
    qs <- stats::quantile(draws, probs = if (joint > 0) alphas / 2 else 1 - alphas / 2,
      type = 8L, names = FALSE)
    outside <- if (joint > 0) qs > 0 else qs < 0
    raw <- if (any(outside)) alphas[which(outside)[1L]] else 1
    oracle <- min(1, max(raw, 2 / (length(draws) + 1)))
    expect_lte(abs(pfun(draws, joint) - oracle), 5.1e-5)
  }
})

test_that("coefficient test inversion handles signs ties offsets and affine units", {
  pfun <- CJQR:::.cjqr_eal_coef_tail_p
  d <- seq(-.2, 1.8, length.out = 501L)
  p <- pfun(d, .5)
  expect_equal(pfun(d, 0), 1)
  expect_equal(pfun(d, -.5), 1)
  expect_equal(pfun(-d, -.5), p, tolerance = 1e-12)
  expect_equal(pfun(7 * d + 13, 7 * .5 + 13, null = 13), p, tolerance = 1e-12)
  expect_equal(pfun(d / 1000, .5 / 1000), p, tolerance = 1e-12)
  expect_equal(pfun(rep(0, 101L), 1), 1)
  expect_equal(pfun(rep(0, 101L), -1), 1)
  expect_equal(pfun(rep(1, 101L), 1), 2 / 102)
  expect_equal(pfun(rep(-1, 101L), -1), 2 / 102)
  expect_equal(pfun(c(rep(0, 51L), rep(1, 50L)), 1), 1)
  expect_equal(pfun(c(rep(-1, 50L), rep(0, 51L)), -1), 1)
  expect_gte(pfun(d, .5, null = .1), pfun(d, .5, null = -.1))
  # No spurious p = 0 is claimed from a finite empirical bootstrap.
  expect_gt(pfun(seq(1, 2, length.out = 100L), .5), 0)
})

test_that("hull width grows with confidence level without changing reference draws or tests", {
  fit <- .eal_coef_fixture()
  lo <- cjqr_eal_coef_ci(fit, B = 100L, seed = 33L, level = .80, keep_draws = TRUE)
  hi <- cjqr_eal_coef_ci(fit, B = 100L, seed = 33L, level = .95, keep_draws = TRUE)
  expect_identical(lo$draws, hi$draws)
  for (j in 1:2) {
    expect_lte(hi$tables[[j]][2L, 2L], lo$tables[[j]][2L, 2L])
    expect_gte(hi$tables[[j]][2L, 3L], lo$tables[[j]][2L, 3L])
    expect_identical(hi$tables[[j]][2L, 4L], lo$tables[[j]][2L, 4L])
  }
})

test_that("failed reference draws are neither discarded nor replaced", {
  fit <- .eal_coef_fixture()
  opts <- .eal_coef_opts(B = 4L)
  ids <- list(1:2, 1:2)
  idx <- matrix(rep(seq_len(nrow(fit$X)), opts$B), ncol = opts$B)
  idx[, 2L] <- 1L
  expect_warning(out <- CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y,
    CJQR:::.cjqr_eal_betas(fit$fit$beta), ids, opts, resamples = idx),
    "No failed draws were discarded or replaced", fixed = TRUE)
  expect_false(out$available)
  expect_identical(out$bootstrap$attempted, 4L)
  expect_identical(out$bootstrap$successful, 3L)
  expect_identical(out$bootstrap$failed, 1L)
  expect_identical(out$bootstrap$status$ok, c(TRUE, FALSE, TRUE, TRUE))
  expect_identical(out$bootstrap$replacement_draws, 0L)
  expect_match(out$bootstrap$status$error[2L], "rank_deficient")
  for (j in 1:2) {
    expect_true(all(is.na(out$tables[[j]][, -1L])))
    expect_true(all(is.na(out$reference[[j]][, -1L])))
    expect_true(all(is.na(out$draws$coefficients[[j]][, 2L])))
    expect_true(all(is.finite(out$tables[[j]][, 1L])))
  }
  idx[,] <- 1L
  expect_warning(all_bad <- CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y,
    CJQR:::.cjqr_eal_betas(fit$fit$beta), ids, opts, resamples = idx), "unavailable")
  expect_identical(all_bad$bootstrap$successful, 0L)
  expect_false(all_bad$available)
})

test_that("seeded coefficient inference preserves RNG state and original fit", {
  fit <- .eal_coef_fixture()
  frozen <- serialize(fit, NULL)
  set.seed(913L)
  before <- .Random.seed
  kind <- RNGkind()
  a <- cjqr_eal_coef_ci(fit, B = 100L, seed = 81L, keep_draws = TRUE)
  expect_identical(.Random.seed, before)
  expect_identical(RNGkind(), kind)
  b <- cjqr_eal_coef_ci(fit, B = 100L, seed = 81L, keep_draws = TRUE)
  expect_identical(a$draws, b$draws)
  expect_identical(a$tables, b$tables)
  expect_identical(serialize(fit, NULL), frozen)
  no_draws <- cjqr_eal_coef_ci(fit, B = 100L, seed = 81L)
  expect_null(no_draws$draws)
  expect_identical(no_draws$tables, a$tables)
})

test_that("coefficient inference does not create a previously absent global RNG seed", {
  had <- exists(".Random.seed", .GlobalEnv, inherits = FALSE)
  if (had) old <- get(".Random.seed", .GlobalEnv)
  on.exit({
    if (had) assign(".Random.seed", old, .GlobalEnv) else
      if (exists(".Random.seed", .GlobalEnv, inherits = FALSE)) rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  if (had) rm(".Random.seed", envir = .GlobalEnv)
  invisible(cjqr_eal_coef_ci(.eal_coef_fixture(), B = 100L))
  expect_false(exists(".Random.seed", .GlobalEnv, inherits = FALSE))
})

test_that("summary inference is opt-in and never borrows preparation covariance or edf", {
  fit <- .eal_coef_fixture(distinct = TRUE)
  standard <- summary(fit)
  expect_identical(standard, summary(fit, inference = "none"))
  expect_null(standard$coefficient_inference)
  expect_identical(colnames(standard$tableP1), "Estimate")
  ref <- summary(fit, inference = "reference", B = 100L, seed = 12L)
  expect_identical(ref$tableP1, ref$coefficient_inference$tables[[1L]])
  expect_identical(ref$tableP2, ref$coefficient_inference$tables[[2L]])
  expect_identical(ref$tableP3, standard$tableP3)
  expect_identical(ref$smooth_tables[[1L]][, "edf"], standard$smooth_tables[[1L]][, "edf"])
  expect_identical(ref$tableNP1, standard$tableNP1)
  expect_true(all(is.finite(ref$tableP1[1L, -1L])))
  expect_true(all(is.finite(ref$smooth_tables[[1L]][, -1L])))
  for (j in 1:2) {
    fit$basis[[j]]$Vp[,] <- 1e20
    fit$basis[[j]]$edf[] <- 1e10
  }
  polluted <- summary(fit, inference = "reference", B = 100L, seed = 12L)
  expect_identical(polluted$tableP1, ref$tableP1)
  expect_identical(polluted$tableP2, ref$tableP2)
  expect_identical(polluted$smooth_tables, ref$smooth_tables)
  txt <- paste(capture.output(print(ref)), collapse = "\n")
  expect_match(txt, "p-value", fixed = TRUE)
  expect_false(grepl("(RA)", txt, fixed = TRUE))
  expect_identical(ref$coefficient_inference$bootstrap$joint_refits, 0L)
  expect_false(grepl("Std. Error|Pr\\(>\\|z\\|\\)|z value", txt))
  expect_error(summary(fit, inference = "sandwich"), "arg")
  expect_error(summary(fit, inference = "reference", strange = TRUE), "Unsupported")
})

test_that("coefficient input validation rejects unsupported or malformed inference requests", {
  fit <- .eal_coef_fixture()
  expect_error(cjqr_eal_coef_ci(list()), "certified")
  broken <- fit
  broken$fit$strict_ok <- FALSE
  expect_error(cjqr_eal_coef_ci(broken), "certified")
  expect_error(cjqr_eal_coef_ci(fit, B = 1L), "B")
  expect_error(cjqr_eal_coef_ci(fit, B = 2.5), "B")
  expect_error(cjqr_eal_coef_ci(fit, B = NA_real_), "B")
  expect_error(cjqr_eal_coef_ci(fit, level = 1), "level")
  expect_error(cjqr_eal_coef_ci(fit, seed = -1), "seed")
  expect_error(cjqr_eal_coef_ci(fit, keep_draws = NA), "keep_draws")
  expect_error(cjqr_eal_coef_ci(fit, max_memory_mb = .0001), "workspace")
  expect_warning(cjqr_eal_coef_ci(fit, B = 99L), "B < 100")
  expect_warning(cjqr_eal_coef_ci(fit, B = 100L, level = .999), "resolution")
  broken <- fit
  broken$weights <- rep(2, nrow(fit$X))
  expect_error(cjqr_eal_coef_ci(broken), "Weighted")
  broken <- fit
  broken$X[1L, 2L] <- NA_real_
  expect_error(cjqr_eal_coef_ci(broken), "finite")
  broken <- fit
  broken$X[, 1L] <- 2
  expect_error(cjqr_eal_coef_ci(broken), "intercept")
  broken <- fit
  broken$X[, 2L] <- broken$X[, 3L]
  expect_error(cjqr_eal_coef_ci(broken), "rank_deficient")
  opts <- .eal_coef_opts()
  beta <- CJQR:::.cjqr_eal_betas(fit$fit$beta)
  expect_error(CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y, beta,
    list(c(1, 1), 1:2), opts), "indices")
  expect_error(CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y, beta,
    list(c(1, 2.5), 1:2), opts), "indices")
  expect_error(CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y, beta,
    list(c(1, 50), 1:2), opts), "indices")
  expect_error(CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y,
    list(beta[[1L]][-1L], beta[[2L]]), list(1:2, 1:2), opts), "coefficient")
  expect_error(CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y, beta,
    list(1:2, 1:2), opts, resamples = matrix(0, nrow(fit$X), opts$B)), "row indices")
})
