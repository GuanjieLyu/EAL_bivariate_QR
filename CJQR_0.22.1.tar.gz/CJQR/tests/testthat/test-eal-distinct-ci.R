.eal_distinct_ci_fixture <- function(probs = c(.1, .5, .9)) {
  n <- 48L
  x <- seq(-1, 1, length.out = n)
  z <- sin(seq_len(n) * .79)
  X <- list(first = cbind("(Intercept)" = 1, x = x),
            second = cbind("(Intercept)" = 1, z = z, z2 = z^2,
                           xz = x * z))
  e <- sin(seq_len(n) * 3.7) + cos(seq_len(n) * 1.3) / 3
  Y <- cbind(first = .3 + .4 * x + e,
             second = -.2 + .5 * z - .3 * z^2 + .1 * x * z +
               .7 * e + cos(seq_len(n) * 2.1) / 4)
  rows <- c(2L, 17L, 39L)
  Xe <- lapply(X, function(a) a[rows, , drop = FALSE])
  joint <- array(NA_real_, c(length(rows), 2L, length(probs)),
                 dimnames = list(c("a", "b", "c"), colnames(Y),
                                 as.character(probs)))
  for (j in 1:2) for (k in seq_along(probs)) {
    joint[, j, k] <- j + x[rows] + probs[k]
  }
  list(X = X, Y = Y, Xeval = Xe, joint = joint, probs = probs)
}

.eal_distinct_ci_opts <- function(probs, B = 24L, seed = 871L,
                                    chunk_size = 2L, keep_draws = TRUE) {
  CJQR:::.cjqr_eal_ci_options(probs, .95, B, seed, chunk_size,
                              max_memory_mb = 256, keep_draws = keep_draws)
}

.eal_distinct_ci_compute <- function(a, opts = .eal_distinct_ci_opts(a$probs),
                                       resamples = NULL) {
  CJQR:::.cjqr_eal_ci_compute(a$X, a$Y, a$Xeval, a$joint, opts, resamples)
}

test_that("distinct-design CIs replay both paired OLS regressions and exact hulls", {
  a <- .eal_distinct_ci_fixture()
  opts <- .eal_distinct_ci_opts(a$probs)
  ans <- .eal_distinct_ci_compute(a, opts)
  expect_true(ans$available)
  expect_identical(ans$fit, a$joint)
  expect_identical(dimnames(ans$lower), dimnames(a$joint))
  expect_identical(names(ans$draws$coefficients), colnames(a$Y))
  expect_identical(lapply(ans$draws$coefficients, dim),
                   list(first = c(2L, opts$B), second = c(4L, opts$B)))
  expect_identical(dim(ans$draws$residual_quantiles), c(3L, 2L, opts$B))
  expect_identical(ans$draws$indices,
                   CJQR:::.cjqr_eal_ci_indices(nrow(a$Y), opts$B, opts$seed))
  expect_true(all(ans$bootstrap$status$rank_margin1 == 2L))
  expect_true(all(ans$bootstrap$status$rank_margin2 == 4L))
  expect_true(ans$bootstrap$paired_subject_rows)
  expect_identical(ans$bootstrap$joint_refits, 0L)
  expect_identical(ans$bootstrap$qgam_refits, 0L)

  draws <- array(NA_real_, c(3L, 2L, length(a$probs), opts$B))
  for (j in 1:2) {
    beta <- qr.coef(qr(a$X[[j]]), a$Y[, j])
    residual <- a$Y[, j] - drop(a$X[[j]] %*% beta)
    rq <- quantile(residual, a$probs, type = 8L, names = FALSE)
    for (k in seq_along(a$probs)) {
      expect_equal(unname(ans$reference$fit[, j, k]),
                   unname(drop(a$Xeval[[j]] %*% beta) + rq[k]), tolerance = 0)
    }
    for (b in seq_len(opts$B)) {
      ii <- ans$draws$indices[, b]
      Xb <- a$X[[j]][ii, , drop = FALSE]
      beta <- qr.coef(qr(Xb), a$Y[ii, j])
      residual <- a$Y[ii, j] - drop(Xb %*% beta)
      rq <- quantile(residual, a$probs, type = 8L, names = FALSE)
      expect_equal(unname(ans$draws$coefficients[[j]][, b]),
                   unname(beta), tolerance = 0)
      expect_equal(ans$draws$residual_quantiles[, j, b], rq, tolerance = 0)
      for (k in seq_along(a$probs)) {
        draws[, j, k, b] <- drop(a$Xeval[[j]] %*% beta) + rq[k]
      }
    }
  }
  tails <- c((1 - opts$level) / 2, (1 + opts$level) / 2)
  for (i in 1:3) for (j in 1:2) for (k in seq_along(a$probs)) {
    endpoints <- quantile(draws[i, j, k, ], tails, type = 8L, names = FALSE)
    expect_equal(unname(c(ans$reference$lower[i, j, k],
                         ans$reference$upper[i, j, k])), endpoints, tolerance = 0)
  }
  expect_identical(ans$lower, pmin(ans$reference$lower, a$joint))
  expect_identical(ans$upper, pmax(ans$reference$upper, a$joint))
})

test_that("a rank failure in only margin two invalidates every CI without redraws", {
  a <- .eal_distinct_ci_fixture()
  rare <- as.numeric(seq_len(nrow(a$Y)) == 1L)
  a$X[[2L]] <- cbind(a$X[[2L]], rare = rare)
  a$Xeval[[2L]] <- cbind(a$Xeval[[2L]], rare = 0)
  opts <- .eal_distinct_ci_opts(a$probs, B = 4L)
  ii <- matrix(rep(seq_len(nrow(a$Y)), opts$B), nrow(a$Y), opts$B)
  ii[1L, 2L] <- 2L
  expect_warning(ans <- .eal_distinct_ci_compute(a, opts, ii), "No failed draws")
  expect_false(ans$available)
  expect_identical(ans$fit, a$joint)
  expect_identical(ans$draws$indices, ii)
  expect_equal(ans$bootstrap$successful, 3L)
  expect_equal(ans$bootstrap$failed, 1L)
  expect_identical(ans$bootstrap$replacement_draws, 0L)
  expect_identical(ans$bootstrap$status$rank_margin1[2L], 2L)
  expect_identical(ans$bootstrap$status$rank_margin2[2L], 4L)
  expect_identical(ans$bootstrap$status$error[2L],
                   "rank_deficient_subject_resample_margin_2")
  for (bound in list(ans$lower, ans$upper, ans$reference$lower,
                    ans$reference$upper)) expect_true(all(is.na(bound)))
  for (j in 1:2) {
    expect_true(all(is.na(ans$draws$coefficients[[j]][, 2L])))
    expect_true(all(is.finite(ans$draws$coefficients[[j]][, 4L])))
  }
  expect_true(all(is.finite(ans$reference$fit)))
})

test_that("distinct-design chunking, singleton dimensions and RNG are stable", {
  a <- .eal_distinct_ci_fixture(probs = c(.9, .1))
  before <- if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
    get(".Random.seed", envir = .GlobalEnv) else NULL
  kind <- RNGkind()
  one <- .eal_distinct_ci_compute(a, .eal_distinct_ci_opts(a$probs,
                                                          chunk_size = 1L))
  many <- .eal_distinct_ci_compute(a, .eal_distinct_ci_opts(a$probs,
                                                           chunk_size = 100L,
                                                           keep_draws = FALSE))
  after <- if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
    get(".Random.seed", envir = .GlobalEnv) else NULL
  expect_identical(after, before)
  expect_identical(RNGkind(), kind)
  expect_identical(one$lower, many$lower)
  expect_identical(one$upper, many$upper)
  expect_identical(one$reference, many$reference)
  expect_identical(one$probs, c(.9, .1))
  expect_null(many$draws)
  b <- .eal_distinct_ci_fixture(.37)
  b$Xeval <- lapply(b$Xeval, function(z) z[1L, , drop = FALSE])
  b$joint <- b$joint[1L, , , drop = FALSE]
  ans <- .eal_distinct_ci_compute(b)
  expect_true(ans$available)
  expect_identical(dim(ans$fit), c(1L, 2L, 1L))
  expect_identical(dim(ans$lower), c(1L, 2L, 1L))
  expect_identical(dim(ans$draws$residual_quantiles), c(1L, 2L, 24L))
})

test_that("both design dimensions, intercepts and ranks are checked independently", {
  a <- .eal_distinct_ci_fixture()
  for (which in 1:2) {
    b <- a
    b$X[[which]] <- b$X[[which]][-1L, , drop = FALSE]
    expect_error(.eal_distinct_ci_compute(b), "conformable")
    b <- a
    b$Xeval[[which]] <- b$Xeval[[which]][-1L, , drop = FALSE]
    expect_error(.eal_distinct_ci_compute(b), "conformable")
    b <- a
    b$Xeval[[which]] <- b$Xeval[[which]][, -2L, drop = FALSE]
    expect_error(.eal_distinct_ci_compute(b), "conformable")
    b <- a
    b$X[[which]][1L, 2L] <- NA_real_
    expect_error(.eal_distinct_ci_compute(b), "finite")
    b <- a
    b$X[[which]][, 1L] <- 2
    expect_error(.eal_distinct_ci_compute(b), "intercept")
    b <- a
    b$Xeval[[which]][, 1L] <- 2
    expect_error(.eal_distinct_ci_compute(b), "intercept")
    b <- a
    b$X[[which]][, 2L] <- 1
    expect_error(.eal_distinct_ci_compute(b), "intercept")
  }
  b <- a
  b$X[[2L]][, 4L] <- b$X[[2L]][, 3L]
  expect_error(.eal_distinct_ci_compute(b), "Original OLS reference.*margin_2")
  for (bad in list(list(a$X[[1L]]), list(a$X[[1L]], NULL),
                   c(a$X, a$X[1L]), as.data.frame(a$X[[1L]]))) {
    b <- a
    b$X <- bad
    expect_error(.eal_distinct_ci_compute(b), "conformable")
  }
})

test_that("CI workspace accounts for each distinct design and draw matrix", {
  a <- .eal_distinct_ci_fixture()
  opts <- .eal_distinct_ci_opts(a$probs)
  dims <- CJQR:::.cjqr_eal_ci_validate_design(a$X, a$Y, a$Xeval, a$joint, opts)
  expect_identical(unname(dims$d), c(2L, 4L))
  n <- nrow(a$Y)
  m <- dim(a$joint)[1L]
  ds <- sum(vapply(a$X, ncol, integer(1L)))
  np <- length(a$probs)
  expected <- 4 * as.double(n) * opts$B + 8 * opts$B * (ds + 2 * np) +
    8 * m * 2 * np * 8 + 8 * min(m, opts$chunk_size) * opts$B * 4 +
    8 * n * (ds + 2) * 4 + 8 * m * ds
  expect_identical(dims$estimated_bytes, expected)
  opts$max_memory_mb <- (expected - 1) / 1024^2
  expect_error(.eal_distinct_ci_compute(a, opts), "workspace")
})

test_that("common matrices keep legacy coefficient arrays and status columns", {
  a <- .eal_distinct_ci_fixture()
  a$X <- a$X[[2L]]
  a$Xeval <- a$Xeval[[2L]]
  ans <- .eal_distinct_ci_compute(a)
  expect_identical(dim(ans$draws$coefficients), c(4L, 2L, 24L))
  expect_identical(names(ans$bootstrap$status),
                   c("draw", "unique_subjects", "rank", "ok", "error"))
  for (b in seq_len(ans$bootstrap$attempted)) {
    ii <- ans$draws$indices[, b]
    beta <- qr.coef(qr(a$X[ii, , drop = FALSE]), a$Y[ii, , drop = FALSE])
    expect_equal(unname(ans$draws$coefficients[, , b]), unname(beta),
                   tolerance = 0)
  }
  b <- a
  b$X <- list(first = a$X, second = a$X)
  b$Xeval <- list(first = a$Xeval, second = a$Xeval)
  out <- .eal_distinct_ci_compute(b)
  expect_equal(out$reference, ans$reference, tolerance = 1e-14)
  expect_identical(out$fit, ans$fit)
})

test_that("the public CI adapter accepts distinct designs without mutating the fit", {
  a <- .eal_distinct_ci_fixture()
  fixture <- structure(list(X = a$X, Y = a$Y,
                            selection = list(strict_ok = TRUE)),
                       class = "cjqr_eal")
  local_mocked_bindings(
    .cjqr_eal_newX = function(object, newdata) a$Xeval,
    .cjqr_eal_ci_prediction = function(object, newdata, probs) a$joint,
    .package = "CJQR")
  before <- serialize(fixture, NULL)
  ans <- cjqr_eal_ci(fixture, probs = a$probs, B = 100L, keep_draws = TRUE)
  expect_true(ans$available)
  expect_identical(ans$fit, a$joint)
  expect_identical(serialize(fixture, NULL), before)
  expect_identical(names(ans$draws$coefficients), c("first", "second"))
  expect_identical(ans$bootstrap$requested, 100L)
})
