test_that("reference-assisted tables use standard R significance thresholds", {
  tab <- cbind(Estimate = rep(1, 8), `Lower 95%` = 0, `Upper 95%` = 2,
    `p-value (RA)` = c(NA, .0009, .001, .0011, .01, .05, .1, .11))
  rownames(tab) <- c("missing", "tiny", "edge001", "over001", "edge01", "edge05", "edge1", "large")
  before <- serialize(tab, NULL)
  lines <- capture.output(CJQR:::.cjqr_eal_print_parametric(tab, 4L, TRUE))
  row <- function(name) lines[grepl(paste0("^", name, "[[:space:]]"), lines)]
  expect_match(row("tiny"), "\\*\\*\\*[[:space:]]*$")
  expect_match(row("edge001"), "\\*\\*\\*[[:space:]]*$")
  expect_match(row("over001"), "[^*]\\*\\*[[:space:]]*$")
  expect_match(row("edge01"), "[^*]\\*\\*[[:space:]]*$")
  expect_match(row("edge05"), "[^*]\\*[[:space:]]*$")
  expect_match(row("edge1"), "\\.[[:space:]]*$")
  expect_false(grepl("\\*|\\.[[:space:]]*$", row("missing")))
  expect_false(grepl("\\*|\\.[[:space:]]*$", row("large")))
  expect_true(any(grepl("Signif. codes:", lines, fixed = TRUE)))
  expect_identical(serialize(tab, NULL), before)
})

test_that("stars can be disabled and unavailable tests get no legend", {
  tab <- cbind(Estimate = .2, `Lower 95%` = .1, `Upper 95%` = .3,
               `p-value (RA)` = .001)
  txt <- paste(capture.output(CJQR:::.cjqr_eal_print_parametric(tab, 4L, FALSE)), collapse = "\n")
  expect_false(grepl("\\*|Signif. codes", txt))
  tab[, 4L] <- NA_real_
  txt <- paste(capture.output(CJQR:::.cjqr_eal_print_parametric(tab, 4L, TRUE)), collapse = "\n")
  expect_false(grepl("\\*|Signif. codes", txt))
  expect_error(CJQR:::.cjqr_eal_print_parametric(tab, 4L, NA), "signif.stars")
})

test_that("both public coefficient print methods preserve experimental labels", {
  fit <- .eal_coef_fixture()
  sm <- summary(fit, inference = "reference", B = 100L)
  frozen <- serialize(sm, NULL)
  old <- options(show.signif.stars = TRUE)
  on.exit(options(old), add = TRUE)
  txt <- paste(capture.output(print(sm)), collapse = "\n")
  expect_match(txt, "Signif. codes:", fixed = TRUE)
  expect_match(txt, "EXPERIMENTAL", fixed = TRUE)
  expect_match(txt, "p-value", fixed = TRUE)
  expect_false(grepl("(RA)", txt, fixed = TRUE))
  expect_identical(serialize(sm, NULL), frozen)
  options(show.signif.stars = FALSE)
  expect_false(any(grepl("Signif. codes", capture.output(print(sm)), fixed = TRUE)))
  expect_true(any(grepl("Signif. codes", capture.output(print(sm, signif.stars = TRUE)), fixed = TRUE)))
  ci <- sm$coefficient_inference
  expect_true(any(grepl("Signif. codes", capture.output(print(ci, signif.stars = TRUE)), fixed = TRUE)))
  expect_false(any(grepl("Signif. codes", capture.output(print(ci, signif.stars = FALSE)), fixed = TRUE)))
  expect_error(print(sm, signif.stars = NA), "signif.stars")
  expect_error(print(ci, signif.stars = 1), "signif.stars")
  expect_error(print(ci, digits = 0), "digits")
})
