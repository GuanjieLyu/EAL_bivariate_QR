# Pointwise smooth intervals use coefficient draws from the unpenalized
# location reference, not complete-quantile intervals or working-GAM SEs.
.cjqr_eal_smooth_plot_ci <- function(object, panels, eq, level, B, seed,
                                       max_memory_mb = 256) {
  opts <- .cjqr_eal_ci_options(.5, level, B, seed, 128L, max_memory_mb, FALSE)
  if (!is.null(object$weights) && (!is.numeric(object$weights) ||
      any(!is.finite(object$weights)) || any(object$weights != 1)))
    stop("Weighted observations are not supported by this reference bootstrap; use se = FALSE for estimates only.",
         call. = FALSE)
  designs <- .cjqr_eal_designs(object$X)
  evaluation <- if (is.matrix(object$X)) object$X[1L, , drop = FALSE] else
    lapply(object$X, function(z) z[1L, , drop = FALSE])
  dims <- .cjqr_eal_ci_validate_design(object$X, object$Y, evaluation, NULL,
                                       opts, check_joint = FALSE)
  rows <- vapply(panels, function(z) length(z$fit), integer(1L))
  columns <- vapply(panels, function(z) length(z$coefficient_indices), integer(1L))
  # Keep only coefficient draws and project the grid in bounded chunks.
  estimated <- dims$estimated_bytes + 8 * sum(as.double(rows) * (columns + 8)) +
    8 * min(max(rows), opts$chunk_size) * opts$B * 4
  if (!is.finite(estimated) || estimated > opts$max_memory_mb * 1024^2)
    stop("Estimated smooth CI workspace exceeds max_memory_mb; reduce B or the plotting grid.",
         call. = FALSE)
  tryCatch(.cjqr_eal_coef_reference(object$X, object$Y, seq_len(dims$n)),
    error = function(e) stop("Smooth confidence intervals require full-rank auxiliary designs: ",
      conditionMessage(e), ". Use se = FALSE for estimates only.", call. = FALSE))
  if (opts$B < 100L)
    warning("B < 100 gives coarse percentile endpoints; use this only for code checks, not inferential validation.",
            call. = FALSE)

  began <- proc.time()[[3L]]
  indices <- .cjqr_eal_ci_indices(dims$n, opts$B, opts$seed)
  ids <- sort(unique(unlist(lapply(panels, `[[`, "coefficient_indices"))))
  draws <- matrix(NA_real_, length(ids), opts$B)
  for (b in seq_len(opts$B)) {
    reference <- tryCatch(.cjqr_eal_coef_reference(object$X, object$Y, indices[, b]),
                          error = function(e) e)
    if (inherits(reference, "error"))
      stop("Smooth confidence intervals unavailable: auxiliary bootstrap draw ", b,
        " of ", opts$B, " failed (", conditionMessage(reference),
        "). No failed draws are discarded or replaced. Use se = FALSE for estimates only.",
        call. = FALSE)
    draws[, b] <- reference[[eq]][ids]
  }
  rm(indices)
  probabilities <- c((1 - opts$level) / 2, (1 + opts$level) / 2)
  for (k in seq_along(panels)) {
    z <- panels[[k]]
    block <- z$coefficient_indices
    sm <- object$basis[[eq]]$smooth[[z$select]]
    projection <- mgcv::PredictMat(sm, z$grid)
    # Every draw uses the original cohort's centring, including by-smooths.
    projection <- sweep(projection, 2L,
      colMeans(designs[[eq]][, block, drop = FALSE]), "-")
    reference <- matrix(NA_real_, length(z$fit), 2L)
    supported <- which(!z$excluded)
    for (start in seq.int(1L, length(supported), by = opts$chunk_size)) {
      take <- supported[seq.int(start, min(length(supported), start + opts$chunk_size - 1L))]
      values <- projection[take, , drop = FALSE] %*% draws[match(block, ids), , drop = FALSE]
      if (any(!is.finite(values)))
        stop("Nonfinite auxiliary smooth contributions; confidence intervals are unavailable.", call. = FALSE)
      reference[take, ] <- t(vapply(seq_len(nrow(values)), function(i)
        stats::quantile(values[i, ], probabilities, type = 8L, names = FALSE), numeric(2L)))
    }
    reshape <- function(v) { dim(v) <- dim(z$fit); v }
    z$reference_lower <- reshape(reference[, 1L])
    z$reference_upper <- reshape(reference[, 2L])
    z$lower <- pmin(z$reference_lower, z$fit)
    z$upper <- pmax(z$reference_upper, z$fit)
    z$level <- opts$level
    z$interval <- "confidence"
    z$interpretation <- paste(
      "Joint EAL smooth contribution centered over the original analysis rows;",
      "reference-assisted pointwise percentile intervals enlarged to contain the unchanged joint estimate.",
      "Not simultaneous bands or estimate plus/minus a standard error.")
    panels[[k]] <- z
  }
  metadata <- list(requested = opts$B, attempted = opts$B, successful = opts$B,
    failed = 0L, seed = opts$seed, joint_refits = 0L, paired_subject_rows = TRUE,
    fixed_observed_basis = TRUE, original_cohort_centering = TRUE,
    endpoint_quantile_type = 8L, all_draws_required = TRUE,
    replacement_draws = 0L, elapsed_seconds = proc.time()[[3L]] - began)
  for (k in seq_along(panels)) panels[[k]]$bootstrap <- metadata
  panels
}
