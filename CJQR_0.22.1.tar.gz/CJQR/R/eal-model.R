# Package interface for the fixed-degree EAL estimator with margin-specific designs.

.cjqr_eal_probs <- function(probs) {
  if (!is.numeric(probs) || !is.null(dim(probs)) || !length(probs) || any(!is.finite(probs)) ||
      any(probs <= 0 | probs >= 1) || anyDuplicated(probs))
    stop("`probs` must contain distinct finite probabilities strictly inside (0, 1).", call. = FALSE)
  as.numeric(probs)
}

# Prediction targets are distinct from the common distributional anchor. A
# numeric vector requests a shared probability grid; a list requests
# different grids. Named lists are matched, never silently treated as positional.
.cjqr_eal_probability_spec <- function(probs, responses) {
  if (!is.list(probs)) {
    p <- .cjqr_eal_probs(probs)
    return(list(shared = TRUE, probs = p, union = p))
  }
  if (is.data.frame(probs) || length(probs) != 2L || !is.null(dim(probs)))
    stop("List-valued `probs` must contain exactly two numeric probability vectors, one per margin.", call. = FALSE)
  if (!is.character(responses) || length(responses) != 2L || anyNA(responses) ||
      any(!nzchar(responses)) || anyDuplicated(responses))
    stop("Two distinct response names are required for margin-specific probabilities.", call. = FALSE)
  nm <- names(probs)
  if (!is.null(nm)) {
    if (anyNA(nm) || any(!nzchar(nm)) || anyDuplicated(nm) || !setequal(nm, responses))
      stop("Named `probs` must match the two fitted response names exactly: ",
           paste(responses, collapse = ", "), ".", call. = FALSE)
    probs <- probs[responses]
  }
  p <- stats::setNames(lapply(probs, .cjqr_eal_probs), responses)
  combined <- unique(unlist(p, use.names = FALSE))
  list(shared = FALSE, probs = p, union = combined,
       index = lapply(p, match, table = combined))
}

.cjqr_eal_default_probs <- function(object, probs, fallback = c(.1, .25, .5, .75, .9)) {
  if (!is.null(probs)) return(probs)
  if (!is.null(object$probs)) object$probs else fallback
}

.cjqr_eal_slice_quantiles <- function(values, spec) {
  if (spec$shared) return(values)
  stats::setNames(lapply(1:2, function(j) {
    matrix(values[, j, spec$index[[j]], drop = FALSE],
      nrow = dim(values)[1L], ncol = length(spec$probs[[j]]),
      dimnames = list(dimnames(values)[[1L]], as.character(spec$probs[[j]])))
  }), names(spec$probs))
}

# Cache only verified numeric marginal roots, never data, fitted objects, basis
# matrices or the engine's mutable environments. At most 16 small specifications
# are retained. Every lookup verifies the installed source bytes and version.
.cjqr_eal_prediction_cache <- new.env(parent = emptyenv())

.cjqr_eal_quantile_offsets <- function(object, probs) {
  probs <- .cjqr_eal_probs(probs)
  f <- object$fit
  if (!is.numeric(f$p) || length(f$p) != 1L || !is.finite(f$p) || f$p <= 0 || f$p >= 1 ||
      !is.matrix(f$shape) || !is.numeric(f$shape) || !identical(dim(f$shape), c(5L, 2L)) ||
      any(!is.finite(f$shape)) || !is.numeric(f$sigma) || length(f$sigma) != 2L ||
      any(!is.finite(f$sigma)) || any(f$sigma <= 0))
    stop("The fitted EAL marginal anchor, shapes and positive scales must be finite and valid.", call. = FALSE)
  copula <- .cjqr_normalize_copula(object$copula)
  directory <- system.file("eal-engine", package = "CJQR")
  if (!nzchar(directory) || !dir.exists(directory))
    stop("The installed CJQR EAL engine directory is unavailable.", call. = FALSE)
  directory <- normalizePath(directory, winslash = "/", mustWork = TRUE)
  signature <- list(directory = directory,
    package_version = as.character(getNamespaceVersion("CJQR")),
    R_version = paste(R.version$major, R.version$minor, sep = "."),
    source_md5 = .cjqr_eal_engine_sources(directory))
  cache <- .cjqr_eal_prediction_cache
  if (!identical(cache$signature, signature)) {
    cache$signature <- signature
    cache$entries <- list()
  }
  # Strip arbitrary user attributes as well as names: even an annotated matrix
  # must not retain a caller environment or data object through this cache.
  key <- list(copula = copula, degree = as.integer(object$degree),
    p = as.numeric(f$p), shape = matrix(as.numeric(f$shape), 5L, 2L), probs = probs)
  # Large requests are calculated normally without retaining their vectors.
  cacheable <- length(probs) <= 256L && length(serialize(key, NULL)) <= 16384L
  if (cacheable && length(cache$entries)) {
    hit <- which(vapply(cache$entries, function(x) identical(x$key, key), logical(1)))
    if (length(hit)) return(cache$entries[[hit[1L]]]$value)
  }
  density <- .cjqr_eal_engine(copula)$density
  offsets <- matrix(NA_real_, 2L, length(probs))
  for (j in 1:2) {
    q <- density$eal_quantile(probs, p = f$p, shape = f$shape[, j], K = 3L)
    back <- density$eal_cdf(q, p = f$p, shape = f$shape[, j], K = 3L)
    if (any(!is.finite(q)) || any(!is.finite(back)) || max(abs(back - probs)) >= 1e-8 ||
        any(diff(q[order(probs)]) <= 0))
      stop("EAL inverse-CDF verification failed.", call. = FALSE)
    offsets[j, ] <- q
  }
  if (!identical(signature$source_md5, .cjqr_eal_engine_sources(directory)))
    stop("CJQR EAL engine sources changed during prediction; retry with a stable installation.", call. = FALSE)
  entry <- list(key = key, value = offsets)
  if (cacheable && length(serialize(entry, NULL)) <= 32768L) {
    cache$entries <- c(cache$entries, list(entry))
    if (length(cache$entries) > 16L) cache$entries <- utils::tail(cache$entries, 16L)
  }
  offsets
}

# Internal callers may reuse an already validated prediction design. This does
# not memoize X: newdata and its formula environments are evaluated on each call.
.cjqr_eal_predict_quantiles <- function(object, X, probs) {
  .cjqr_eal_require_fit(object)
  probs <- .cjqr_eal_probs(probs)
  location <- .cjqr_eal_location(X, object$fit$beta)
  offsets <- .cjqr_eal_quantile_offsets(object, probs)
  result <- array(NA_real_, c(nrow(location), 2L, length(probs)),
    dimnames = list(rownames(location), object$responses, as.character(probs)))
  for (j in 1:2) for (k in seq_along(probs))
    result[, j, k] <- location[, j] + object$fit$sigma[j] * offsets[j, k]
  if (any(!is.finite(result))) stop("Nonfinite EAL quantile prediction.", call. = FALSE)
  result
}

.cjqr_eal_seed <- function(seed) {
  if (!is.numeric(seed) || length(seed) != 1L || !is.finite(seed) ||
      seed < 0 || seed > .Machine$integer.max - 1000L || seed != floor(seed))
    stop("`seed` must be a nonnegative integer below .Machine$integer.max - 1000.", call. = FALSE)
  as.integer(seed)
}

.cjqr_eal_with_seed <- function(seed, expr) {
  seed <- .cjqr_eal_seed(seed)
  old_kind <- RNGkind()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  on.exit({
    do.call(RNGkind, as.list(old_kind))
    if (had_seed) assign(".Random.seed", old_seed, envir = .GlobalEnv)
    else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
      rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  set.seed(seed)
  force(expr)
}

.cjqr_eal_named_control <- function(x, allowed, label) {
  if (!is.list(x) || (length(x) && (is.null(names(x)) || anyNA(names(x)) ||
      any(!nzchar(names(x))) || anyDuplicated(names(x)))))
    stop("`", label, "` must be a uniquely named list.", call. = FALSE)
  bad <- setdiff(names(x), allowed)
  if (length(bad)) stop("Unknown or unsupported `", label, "` field(s): ",
                        paste(bad, collapse = ", "), ".", call. = FALSE)
  invisible(x)
}

.cjqr_eal_controls <- function(control, extra_control, copula = "gaussian") {
  # Public numerical controls deliberately cannot disable certification/search.
  allowed <- c("maxit", "retry_maxit", "continuation_maxit", "recovery_maxit",
    "factr", "pgtol", "strict_gradient_tolerance", "theta_init", "rho_bounds",
    "theta_bounds", "frank_bounds", "gumbel_bounds", "shape_bound", "trace")
  .cjqr_eal_named_control(control, allowed, "control")
  .cjqr_eal_named_control(extra_control, character(), "extra_control")
  for (nm in intersect(names(control), c("maxit", "retry_maxit", "continuation_maxit", "recovery_maxit"))) {
    a <- control[[nm]]
    if (!is.numeric(a) || length(a) != 1L || !is.finite(a) || a < 1 ||
        a > .Machine$integer.max || a != floor(a))
      stop("`", nm, "` must be a positive integer no larger than .Machine$integer.max.", call. = FALSE)
  }
  for (nm in intersect(names(control), c("factr", "pgtol", "shape_bound", "strict_gradient_tolerance"))) {
    a <- control[[nm]]
    if (!is.numeric(a) || length(a) != 1L || !is.finite(a) || a <= 0)
      stop("Numerical tolerance/bound controls must be positive finite scalars.", call. = FALSE)
  }
  if (!is.null(control$strict_gradient_tolerance) && control$strict_gradient_tolerance > 1e-6)
    stop("The strict gradient tolerance cannot exceed 1e-6.", call. = FALSE)
  for (nm in intersect(names(control), c("rho_bounds", "theta_bounds", "frank_bounds", "gumbel_bounds"))) {
    a <- control[[nm]]
    if (!is.numeric(a) || length(a) != 2L || any(!is.finite(a)) || a[1L] >= a[2L] ||
        (nm == "rho_bounds" && (a[1L] <= -1 || a[2L] >= 1)) ||
        (nm == "theta_bounds" && a[1L] <= 0) ||
        (nm == "gumbel_bounds" && a[1L] <= 1))
      stop("Invalid dependence search bounds.", call. = FALSE)
    supported <- switch(nm, rho_bounds = c("gaussian", "student_t"),
      theta_bounds = "clayton", frank_bounds = "frank", gumbel_bounds = "gumbel")
    if (!copula %in% supported)
      stop("`", nm, "` is not used by the ", copula, " copula.", call. = FALSE)
  }
  if (!is.null(control$theta_init) && (!is.numeric(control$theta_init) ||
      length(control$theta_init) != 1L || !is.finite(control$theta_init)))
    stop("`theta_init` must be a finite scalar.", call. = FALSE)
  if (!is.null(control$theta_init))
    .cjqr_validate_copula_theta(control$theta_init, copula)
  if (!is.null(control$trace) && (!is.numeric(control$trace) || length(control$trace) != 1L ||
      !is.finite(control$trace) || control$trace < 0 || control$trace > .Machine$integer.max ||
      control$trace != floor(control$trace)))
    stop("`trace` must be a nonnegative integer.", call. = FALSE)
  invisible(TRUE)
}

cjqr_eal_control <- function(..., copula = "gaussian") {
  copula <- .cjqr_normalize_copula(copula)
  control <- list(...)
  .cjqr_eal_controls(control, list(), copula)
  control
}

.cjqr_eal_progress <- function(enabled, ...) {
  if (enabled) message("CJQR: ", ...)
  invisible(NULL)
}

.cjqr_eal_validate_data <- function(formulas, data, na.action) {
  if (!is.data.frame(data) || anyDuplicated(names(data)) ||
      anyNA(names(data)) || any(!nzchar(names(data))))
    stop("`data` must be a data frame with unique column names.", call. = FALSE)
  if (!is.list(formulas) || !length(formulas) %in% c(2L, 3L) ||
      !all(vapply(formulas, inherits, logical(1), "formula")))
    stop("Supply two marginal formulas, optionally followed by ~ 1.", call. = FALSE)
  if (length(formulas) == 3L && !.is_intercept_only_formula(formulas[[3L]]))
    stop("EAL currently supports constant dependence only (~ 1).", call. = FALSE)
  formulas <- formulas[1:2]
  if (any(vapply(formulas, length, integer(1)) != 3L) ||
      !all(vapply(formulas, function(f) is.symbol(f[[2L]]), logical(1))))
    stop("Each response must be a bare numeric data-column name; transform it explicitly before fitting.", call. = FALSE)
  responses <- vapply(formulas, function(f) as.character(f[[2L]]), character(1))
  if (anyDuplicated(responses)) stop("The two response columns must be distinct.", call. = FALSE)
  margin_covariates <- lapply(formulas, function(f) all.vars(f[[3L]]))
  names(margin_covariates) <- responses
  covariates <- unique(unlist(margin_covariates, use.names = FALSE))
  if ("." %in% covariates || any(responses %in% covariates))
    stop("Name covariates explicitly; neither response can appear as a predictor.", call. = FALSE)
  if (any(vapply(formulas, .cjqr_formula_contains_call, logical(1), targets = c("offset"))))
    stop("Offsets are not supported by the current common-location EAL interface.", call. = FALSE)
  common_formula_environment <- identical(environment(formulas[[1L]]), environment(formulas[[2L]]))
  # Resolve smooth constructors without changing the caller's formula environment.
  formulas <- lapply(formulas, function(f) {
    env <- new.env(parent = environment(f))
    for (nm in c("s", "te", "ti", "t2")) assign(nm, getExportedValue("mgcv", nm), env)
    environment(f) <- env
    f
  })
  if (any(vapply(formulas, function(f) attr(stats::terms(f), "intercept") != 1L, logical(1))))
    stop("EAL and its reference intervals require an explicit intercept in each margin.", call. = FALSE)
  needed <- unique(c(responses, covariates))
  missing <- setdiff(needed, names(data))
  if (length(missing)) stop("Missing data column(s): ", paste(missing, collapse = ", "), call. = FALSE)
  if (!all(vapply(data[responses], function(y) is.numeric(y) && is.null(dim(y)), logical(1))))
    stop("Responses must be numeric vectors, not factors or matrices.", call. = FALSE)
  if (!identical(na.action, stats::na.fail) && !identical(na.action, stats::na.omit))
    stop("`na.action` must be stats::na.fail or stats::na.omit.", call. = FALSE)
  keep <- stats::complete.cases(data[needed])
  if (!all(keep) && identical(na.action, stats::na.fail))
    stop("Missing values in the paired analysis data; use na.action = na.omit explicitly.", call. = FALSE)
  analysis <- droplevels(data[keep, needed, drop = FALSE])
  for (nm in names(analysis)) {
    a <- analysis[[nm]]
    if (is.matrix(a) || is.list(a)) stop("Matrix/list data columns are unsupported.", call. = FALSE)
    if (is.numeric(a) && any(!is.finite(a))) stop("Analysis data must be finite.", call. = FALSE)
    if (is.character(a)) analysis[[nm]] <- factor(a)
  }
  if (nrow(analysis) < 30L) stop("At least 30 complete paired observations are required.", call. = FALSE)
  for (response in responses) if (length(unique(analysis[[response]])) < 2L)
    stop("Response `", response, "` must vary across the analysis observations.", call. = FALSE)
  list(formulas = formulas, data = analysis, responses = responses, covariates = covariates,
       margin_covariates = margin_covariates,
       common_formula_environment = common_formula_environment,
       kept_rows = which(keep), omitted_rows = which(!keep), original_n = nrow(data))
}

.cjqr_eal_restore_formula_environment <- function(model, formula) {
  # mgcv resets these slots to .GlobalEnv after fitting. Retain each margin's
  # lexical environment so transformations defined by the caller also work
  # during prediction. This changes no coefficients, penalties or term metadata.
  env <- environment(formula)
  for (nm in c("formula", "pred.formula", "terms", "pterms")) {
    if (inherits(model[[nm]], "formula")) environment(model[[nm]]) <- env
  }
  if (!is.null(attr(model$model, "terms")))
    environment(attr(model$model, "terms")) <- env
  if (!is.null(attr(model$pred.formula, "full")))
    environment(attr(model$pred.formula, "full")) <- env
  model
}

.cjqr_eal_prepare <- function(validated) {
  models <- lapply(validated$formulas, function(f) {
    g <- mgcv::gam(f, data = validated$data, method = "REML", na.action = stats::na.fail,
      control = mgcv::gam.control(nthreads = 1L))
    .cjqr_eal_restore_formula_environment(g, f)
  })
  okay <- vapply(models, function(g) isTRUE(g$converged) && is.finite(g$sig2) && g$sig2 > 0 &&
    (identical(g$outer.info$conv, "full convergence") ||
      (is.null(g$outer.info) && !length(g$sp))), logical(1))
  if (!all(okay)) stop("Gaussian REML penalty preparation did not converge.", call. = FALSE)
  designs <- lapply(models, stats::predict, type = "lpmatrix")
  for (j in 1:2) if (!is.matrix(designs[[j]]) || any(!is.finite(designs[[j]])))
    stop("Nonfinite design for margin ", j, ".", call. = FALSE)
  # Use the common matrix representation when formulas and bases agree.
  # Different formulas use separate designs even if their
  # observed values happen to coincide, since newdata can distinguish them.
  common_basis <- isTRUE(validated$common_formula_environment) &&
    identical(validated$formulas[[1L]][[3L]], validated$formulas[[2L]][[3L]]) &&
    identical(dim(designs[[1L]]), dim(designs[[2L]])) &&
    identical(colnames(designs[[1L]]), colnames(designs[[2L]])) &&
    max(abs(designs[[1L]] - designs[[2L]])) <= 1e-12
  decompositions <- if (common_basis) rep(list(qr(designs[[1L]])), 2L) else lapply(designs, qr)
  intercepts <- lapply(1:2, function(j) {
    Xj <- designs[[j]]
    if (decompositions[[j]]$rank != ncol(Xj) || nrow(Xj) <= ncol(Xj) + 1L)
      stop("The design for margin ", j, " must have full column rank and residual degrees of freedom.", call. = FALSE)
    ids <- which(vapply(seq_len(ncol(Xj)), function(k) max(abs(Xj[, k] - 1)) < 1e-12, logical(1)))
    if (length(ids) != 1L) stop("The basis for margin ", j, " must contain exactly one intercept.", call. = FALSE)
    ids
  })
  names(designs) <- names(decompositions) <- names(intercepts) <- validated$responses
  X <- if (common_basis) designs[[1L]] else designs
  qrX <- if (common_basis) decompositions[[1L]] else decompositions
  intercept <- if (common_basis) intercepts[[1L]] else intercepts
  metadata <- lapply(seq_len(2L), function(j) .cjqr_penalty_metadata(models[[j]],
    margin = paste0("margin", j), source = "Gaussian REML"))
  P <- lapply(seq_len(2L), function(j) metadata[[j]]$penalty_effective / models[[j]]$sig2)
  if (any(!is.finite(unlist(P)))) stop("Nonfinite Gaussian-dispersion-scaled penalty.", call. = FALSE)
  for (j in 1:2) {
    metadata[[j]]$penalty_gaussian_unscaled <- metadata[[j]]$penalty_effective
    metadata[[j]]$gaussian_dispersion <- models[[j]]$sig2
    metadata[[j]]$normalization_factor <- 1 / models[[j]]$sig2
    metadata[[j]]$penalty_effective <- P[[j]]
    metadata[[j]]$source <- "Gaussian REML; assembled penalty divided once by Gaussian dispersion"
  }
  list(X = X, Y = as.matrix(validated$data[validated$responses]), P = P,
       qr = qrX, basis = models, penalty_metadata = metadata, intercept = intercept,
       common_basis = common_basis)
}

# Both representations are intentional: old serialized common-basis fits and
# their public matrix-valued methods remain supported without migration.
.cjqr_eal_designs <- function(X) {
  if (is.matrix(X)) return(list(X, X))
  if (is.list(X) && length(X) == 2L && all(vapply(X, is.matrix, logical(1))) &&
      nrow(X[[1L]]) == nrow(X[[2L]])) return(X)
  stop("Expected a common design matrix or two row-aligned marginal design matrices.", call. = FALSE)
}

.cjqr_eal_betas <- function(beta) {
  if (is.matrix(beta) && ncol(beta) == 2L) return(list(beta[, 1L], beta[, 2L]))
  if (is.list(beta) && length(beta) == 2L &&
      all(vapply(beta, function(x) is.numeric(x) && is.null(dim(x)), logical(1)))) return(beta)
  stop("Expected a common-basis coefficient matrix or two marginal coefficient vectors.", call. = FALSE)
}

.cjqr_eal_location <- function(X, beta) {
  if (is.matrix(X) && is.matrix(beta)) return(X %*% beta)
  designs <- .cjqr_eal_designs(X)
  coefficients <- .cjqr_eal_betas(beta)
  out <- cbind(drop(designs[[1L]] %*% coefficients[[1L]]),
               drop(designs[[2L]] %*% coefficients[[2L]]))
  rownames(out) <- rownames(designs[[1L]])
  out
}

.cjqr_eal_select <- function(candidates) {
  finite_one <- function(x) if (is.numeric(x) && length(x) == 1L && is.finite(x)) x else Inf
  objective <- vapply(candidates, function(c) finite_one(c$fit$objective), numeric(1))
  known <- vapply(candidates, function(c) finite_one(c$fit$best_candidate_objective), numeric(1))
  strict <- vapply(candidates, function(c) isTRUE(c$fit$strict_ok), logical(1))
  initialized <- vapply(candidates, function(c) isTRUE(c$start$ok), logical(1))
  eligible <- which(strict & is.finite(objective))
  best <- if (length(eligible)) eligible[which.min(objective[eligible])] else NA_integer_
  gap <- if (is.na(best)) Inf else max(0, objective[best] - min(c(objective, known)))
  tol <- if (is.na(best)) 0 else candidates[[best]]$fit$improved_control$lower_candidate_gap_tolerance
  ok <- all(initialized) && !is.na(best) && length(tol) == 1L && is.finite(tol) && gap <= tol
  list(strict_ok = ok, index = if (ok) best else NA_integer_, unresolved_gap = gap,
    reason = if (ok) "minimum_certified_penalized_objective_K3" else "anchor_selection_not_certified",
    audit = data.frame(anchor = vapply(candidates, `[[`, numeric(1), "anchor"),
      initialized = initialized, strict = strict, objective = objective, known_minimum = known))
}

cjqr_eal <- function(formulas, data,
                       copula = c("gaussian", "clayton", "frank", "gumbel", "student_t"),
                       anchors = c(.25, .5, .75), na.action = stats::na.fail,
                       seed = 1L, control = list(), extra_control = list(), df = NULL,
                       progress = FALSE, probs = c(.1, .25, .5, .75, .9)) {
  call <- match.call()
  explicit_probs <- !missing(probs)
  if (!is.logical(progress) || length(progress) != 1L || is.na(progress))
    stop("`progress` must be TRUE or FALSE.", call. = FALSE)
  copula <- .cjqr_normalize_copula(if (missing(copula)) "gaussian" else copula)
  df <- .cjqr_validate_copula_df(copula, df)
  anchors <- .cjqr_eal_probs(anchors)
  if (length(anchors) > 100L) stop("At most 100 candidate anchors are supported.", call. = FALSE)
  seed <- .cjqr_eal_seed(seed)
  .cjqr_eal_controls(control, extra_control, copula)
  engine_control <- control
  if (!is.null(df)) engine_control$df <- df
  validated <- .cjqr_eal_validate_data(formulas, data, na.action)
  targets <- .cjqr_eal_probability_spec(probs, validated$responses)
  if (!requireNamespace("qgam", quietly = TRUE))
    stop("Install package 'qgam' (>= 2.0.0) for the EAL anchor initializers.", call. = FALSE)
  if (utils::packageVersion("qgam") < "2.0.0") stop("EAL requires qgam >= 2.0.0.", call. = FALSE)
  started <- proc.time()[3L]
  .cjqr_eal_progress(progress, "preparing marginal bases and Gaussian-REML penalties for ",
    nrow(validated$data), " paired observations.")
  prep <- .cjqr_eal_prepare(validated)
  designs <- .cjqr_eal_designs(prep$X)
  engine <- .cjqr_eal_engine(copula)
  candidates <- lapply(seq_along(anchors), function(k) {
    a <- anchors[k]
    beginning <- proc.time()[3L]
    .cjqr_eal_progress(progress, "anchor ", k, "/", length(anchors), " (", a,
      "): initializing and fitting the joint model.")
    starts <- lapply(1:2, function(j) .cjqr_eal_qgam_native(validated$formulas[[j]],
      validated$data, a, validated$data, seed + 2L * k + j))
    start <- list(ok = all(vapply(starts, function(z) isTRUE(z$ok), logical(1))),
                  qgam = lapply(starts, function(z) {z$fit <- NULL; z}))
    if (isTRUE(start$ok)) {
      start$beta <- if (prep$common_basis)
        matrix(NA_real_, ncol(prep$X), 2L, dimnames = list(colnames(prep$X), validated$responses)) else
        stats::setNames(lapply(designs, function(Xj) stats::setNames(rep(NA_real_, ncol(Xj)), colnames(Xj))), validated$responses)
      start$sigma <- start$reconstruction_error <- numeric(2L)
      for (j in 1:2) {
        q <- starts[[j]]
        Xj <- designs[[j]]
        if (!identical(names(stats::coef(q$fit)), colnames(Xj)))
          stop("Native qgam initializer coefficient basis differs from the basis for margin ", j, ".", call. = FALSE)
        beta_j <- qr.coef(if (prep$common_basis) prep$qr else prep$qr[[j]], q$prediction)
        if (prep$common_basis) start$beta[, j] <- beta_j else start$beta[[j]] <- beta_j
        start$reconstruction_error[j] <- max(abs(drop(Xj %*% beta_j) - q$prediction),
          abs(drop(Xj %*% stats::coef(q$fit)) - q$prediction))
        if (!is.finite(start$reconstruction_error[j]) || start$reconstruction_error[j] > 1e-7)
          stop("Native qgam initializer cannot be reconstructed in the basis for margin ", j, ".", call. = FALSE)
        residual <- prep$Y[, j] - drop(Xj %*% beta_j)
        start$sigma[j] <- max(1e-4, mean(residual * (a - (residual < 0))))
      }
    }
    fit <- if (isTRUE(start$ok)) tryCatch(engine$fit(prep$X, prep$Y, prep$P,
      start$beta, start$sigma, p = a, degree = 3L, copula = copula,
      control = engine_control, extra_control = extra_control), error = function(e)
        list(strict_ok = FALSE, error = conditionMessage(e),
          error_class = class(e), error_call = conditionCall(e))) else
      list(strict_ok = FALSE, error = "native_qgam_initialization_failed")
    seconds <- unname(proc.time()[3L] - beginning)
    .cjqr_eal_progress(progress, "anchor ", a, ": ",
      if (isTRUE(fit$strict_ok)) "numerical checks passed" else "not certified",
      " (", format(round(seconds, 1), trim = TRUE), " seconds).")
    list(anchor = a, start = start, fit = fit, seconds = seconds)
  })
  selection <- .cjqr_eal_select(candidates)
  if (!isTRUE(selection$strict_ok)) {
    condition <- structure(list(message = paste0("EAL anchor selection was not numerically certified; ",
      "no accepted fit was returned. Capture this error with tryCatch() and use ",
      "cjqr_fit_diagnostics() to inspect the initializer and anchor failures."),
      call = call, selection = selection, candidates = candidates,
      copula = copula, df = df, n = nrow(prep$Y), anchors = anchors, seed = seed,
      elapsed_seconds = unname(proc.time()[3L] - started)),
      class = c("cjqr_eal_convergence_error", "error", "condition"))
    stop(condition)
  }
  fit <- candidates[[selection$index]]$fit
  if (prep$common_basis) dimnames(fit$beta) <- list(colnames(prep$X), validated$responses) else {
    fit$beta <- stats::setNames(lapply(1:2, function(j) stats::setNames(fit$beta[[j]], colnames(designs[[j]]))), validated$responses)
  }
  object <- list(call = call, formulas = validated$formulas, data = validated$data,
    responses = validated$responses, covariates = validated$covariates,
    margin_covariates = validated$margin_covariates, common_basis = prep$common_basis,
    X = prep$X, Y = prep$Y, P = prep$P, basis = prep$basis,
    penalty_metadata = prep$penalty_metadata, fit = fit,
    anchor = fit$p, anchors = anchors, degree = 3L, copula = copula, df = df,
    probs = if (explicit_probs) targets$probs else NULL,
    selection = selection, candidates = candidates, seed = seed,
    control = control, extra_control = extra_control,
    kept_rows = validated$kept_rows, omitted_rows = validated$omitted_rows,
    original_n = validated$original_n, na.action = na.action,
    dependence_structure = "constant", marginal_structure = "common_error_location",
    elapsed_seconds = unname(proc.time()[3L] - started),
    runtime = list(R = R.version.string, CJQR = as.character(getNamespaceVersion("CJQR")),
      mgcv = as.character(utils::packageVersion("mgcv")),
      qgam = as.character(utils::packageVersion("qgam"))),
    engine_version = engine$version)
  class(object) <- "cjqr_eal"
  # Verify inverse-CDF accuracy before returning a fit usable for prediction.
  invisible(predict(object, probs = unique(c(.1, .25, .5, .75, .9, fit$p))))
  if (explicit_probs) invisible(predict(object))
  .cjqr_eal_progress(progress, "finished; selected anchor ", fit$p, ".")
  object
}

.cjqr_eal_require_fit <- function(object) {
  if (!inherits(object, "cjqr_eal") || !isTRUE(object$fit$strict_ok) ||
      !isTRUE(object$selection$strict_ok) || !identical(object$degree, 3L))
    stop("A certified cjqr_eal fit is required.", call. = FALSE)
  invisible(TRUE)
}

.cjqr_eal_newX <- function(object, newdata = NULL) {
  .cjqr_eal_require_fit(object)
  if (is.null(newdata)) return(object$X)
  if (!is.data.frame(newdata) || !nrow(newdata))
    stop("`newdata` must be a nonempty data frame.", call. = FALSE)
  if (anyDuplicated(names(newdata)) || anyNA(names(newdata)) || any(!nzchar(names(newdata))))
    stop("`newdata` must have unique, nonempty column names.", call. = FALSE)
  absent <- setdiff(object$covariates, names(newdata))
  if (length(absent))
    stop("Missing prediction covariate(s): ", paste(absent, collapse = ", "), ".", call. = FALSE)
  for (nm in object$covariates) {
    v <- newdata[[nm]]
    if (is.matrix(v) || is.list(v) || anyNA(v) ||
        (is.numeric(v) && any(!is.finite(v))))
      stop("Prediction covariate `", nm, "` must be a complete, finite vector.", call. = FALSE)
    fitted_column <- object$data[[nm]]
    if (is.factor(fitted_column)) {
      unknown <- setdiff(as.character(v), levels(fitted_column))
      if (length(unknown)) stop("Unknown level(s) for prediction factor `", nm,
        "`: ", paste(unknown, collapse = ", "), ". Use levels present in the analysis data.", call. = FALSE)
    } else if (is.numeric(fitted_column) && !is.numeric(v)) {
      stop("Prediction covariate `", nm, "` must be numeric, as in the analysis data.", call. = FALSE)
    }
  }
  original <- .cjqr_eal_designs(object$X)
  predict_design <- function(j) {
    Xj <- stats::predict(object$basis[[j]], newdata = newdata, type = "lpmatrix", na.action = stats::na.pass)
    if (!is.matrix(Xj) || nrow(Xj) != nrow(newdata) ||
        !identical(colnames(Xj), colnames(original[[j]])) || any(!is.finite(Xj)))
      stop("Prediction design is nonfinite or incompatible with the fitted basis for margin ", j, ".", call. = FALSE)
    Xj
  }
  if (is.matrix(object$X)) predict_design(1L) else
    stats::setNames(lapply(1:2, predict_design), object$responses)
}

predict.cjqr_eal <- function(object, newdata = NULL,
                               probs = NULL,
                               type = c("quantile", "location", "lpmatrix", "cdf"),
                               interval = c("none", "confidence"), level = .95,
                               B = 500L, seed = 1L, y = NULL, ...) {
  dots <- list(...)
  type <- match.arg(type); interval <- match.arg(interval)
  if (type == "quantile") probs <- .cjqr_eal_default_probs(object, probs)
  .cjqr_eal_named_control(dots, if (interval == "confidence")
    c("chunk_size", "max_memory_mb", "keep_draws") else character(), "prediction arguments")
  if (interval == "confidence") {
    if (type != "quantile") stop("Reference confidence intervals are available only for complete quantile predictions.", call. = FALSE)
    return(do.call(cjqr_eal_ci, c(list(object = object, newdata = newdata,
      probs = probs, level = level, B = B, seed = seed), dots)))
  }
  if (type == "quantile") spec <- .cjqr_eal_probability_spec(probs, object$responses)
  X <- .cjqr_eal_newX(object, newdata)
  if (type == "lpmatrix") return(X)
  if (type == "quantile") return(.cjqr_eal_slice_quantiles(
    .cjqr_eal_predict_quantiles(object, X, spec$union), spec))
  location <- .cjqr_eal_location(X, object$fit$beta)
  colnames(location) <- object$responses
  if (type == "location") return(location)
  f <- object$fit
  if (type == "cdf") {
    if (is.null(y)) {
      if (is.null(newdata)) y <- object$Y
      else if (all(object$responses %in% names(newdata))) y <- as.matrix(newdata[object$responses])
      else stop("Supply an n-by-2 numeric `y` matrix for CDF prediction.", call. = FALSE)
    }
    if (!is.matrix(y) || !is.numeric(y) || !identical(dim(y), dim(location)) || any(!is.finite(y)))
      stop("`y` must be a finite numeric matrix matching prediction rows and two margins.", call. = FALSE)
    density <- .cjqr_eal_engine(object$copula)$density
    out <- location
    for (j in 1:2) out[, j] <- density$eal_cdf((y[, j] - location[, j]) / f$sigma[j],
      p = f$p, shape = f$shape[, j], K = 3L)
    return(out)
  }
}

coef.cjqr_eal <- function(object, ...) { .cjqr_eal_require_fit(object); object$fit$beta }
fitted.cjqr_eal <- function(object, probs = NULL, ...) predict(object, probs = probs, ...)
nobs.cjqr_eal <- function(object, ...) { .cjqr_eal_require_fit(object); nrow(.cjqr_eal_designs(object$X)[[1L]]) }
formula.cjqr_eal <- function(x, ...) x$formulas
model.frame.cjqr_eal <- function(formula, ...) formula$data
vcov.cjqr_eal <- function(object, ...) stop("No joint sampling covariance is supplied; use cjqr_eal_ci() for complete quantile predictions.", call. = FALSE)
confint.cjqr_eal <- function(object, parm, level = .95, newdata = NULL,
                               probs = NULL, B = 500L, seed = 1L, ...) {
  if (!missing(parm)) stop("Coefficient intervals are unavailable through confint.cjqr_eal; use cjqr_eal_coef_ci() for reference-assisted marginal parametric intervals, including intercepts. confint.cjqr_eal returns complete quantile intervals.", call. = FALSE)
  cjqr_eal_ci(object, newdata = newdata, probs = probs, level = level, B = B, seed = seed, ...)
}
logLik.cjqr_eal <- function(object, ...) {
  .cjqr_eal_require_fit(object)
  # Bare logLik deliberately withholds df: dedicated AIC/BIC methods perform
  # additional numerical checks and qualify their conditional approximation.
  structure(object$fit$loglik, class = "logLik", nobs = nrow(.cjqr_eal_designs(object$X)[[1L]]), df = NA_real_)
}
