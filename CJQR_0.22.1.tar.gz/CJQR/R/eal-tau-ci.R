# Kendall's tau reference inference: paired OLS residual bootstrap, never a
# covariance approximation or refit of the fitted EAL copula parameter.
.cjqr_eal_tau_a <- function(residual, original = FALSE) {
  if (!is.matrix(residual) || !is.numeric(residual) || ncol(residual) != 2L ||
      nrow(residual) < 3L || any(!is.finite(residual)))
    stop("Kendall reference requires finite paired residuals.", call. = FALSE)
  tied <- vapply(seq_len(2L), function(j) anyDuplicated(residual[, j]) > 0L, logical(1L))
  if (original && any(tied))
    stop("Original residual ties: continuous-copula tau inference is unavailable.", call. = FALSE)
  # Public O(n log n) concordance counts. Do not use cor.test's independence
  # variance, Somers' d, or tau-b. Duplicate bootstrap subjects contribute zero
  # to the sign kernel and remain in the U-statistic's full pair denominator.
  cc <- survival::concordancefit(y = residual[, 2L], x = residual[, 1L],
    timewt = "n", timefix = FALSE, reverse = FALSE, influence = 0L,
    std.err = FALSE)$count
  n <- as.double(nrow(residual))
  pairs <- n * (n - 1) / 2
  needed <- c("concordant", "discordant", "tied.x", "tied.y", "tied.xy")
  if (!is.numeric(cc) || !all(needed %in% names(cc)) ||
      any(!is.finite(cc[needed])) || any(cc[needed] < 0) ||
      abs(sum(cc[needed]) - pairs) > 1e-8 * max(1, pairs))
    stop("Invalid Kendall concordance counts.", call. = FALSE)
  tau <- unname((cc["concordant"] - cc["discordant"]) / pairs)
  if (!is.finite(tau) || abs(tau) > 1)
    stop("Nonfinite or out-of-range Kendall reference.", call. = FALSE)
  list(tau = tau, pairs = pairs, counts = cc[needed], original_ties = tied)
}

.cjqr_eal_tau_reference <- function(X, Y, indices, beta, original = FALSE) {
  designs <- .cjqr_eal_designs(X)
  residual <- vapply(seq_len(2L), function(j)
    Y[indices, j] - drop(designs[[j]][indices, , drop = FALSE] %*% beta[[j]]),
    numeric(length(indices)))
  .cjqr_eal_tau_a(residual, original = original)
}

.cjqr_eal_tau_interval <- function(joint_tau, reference, draws, status, opts) {
  available <- all(status$ok) && !inherits(reference, "error") &&
    is.numeric(draws) && length(draws) == opts$B && all(is.finite(draws))
  reason <- if (!available) "At least one tau reference calculation failed; no draws were discarded or replaced." else NULL
  if (inherits(reference, "error")) reason <- paste("Tau reference calculation failed:", conditionMessage(reference))
  if (available && (abs(reference$tau) >= 1 || max(draws) == min(draws))) {
    available <- FALSE
    reason <- "Degenerate residual dependence or zero bootstrap variability; tau CI unavailable."
  }
  percentile <- basic <- endpoints <- interval <- c(lower = NA_real_, upper = NA_real_)
  if (available) {
    percentile[] <- stats::quantile(draws,
      probs = c((1 - opts$level) / 2, (1 + opts$level) / 2), type = 8L, names = FALSE)
    basic[] <- 2 * reference$tau - rev(percentile)
    # Use one fixed envelope rather than choose a bias direction or interval
    # type from observed performance. It contains both component intervals
    # within the universal parameter space, with no tuned inflation factor.
    endpoints[] <- c(max(-1, min(percentile[1L], basic[1L])),
      min(1, max(percentile[2L], basic[2L])))
    interval[] <- c(min(endpoints[1L], joint_tau), max(endpoints[2L], joint_tau))
  }
  out <- list(estimate = joint_tau, interval = interval, level = opts$level,
    available = available, reason = reason,
    reference = if (inherits(reference, "error")) NULL else reference,
    reference_interval = endpoints,
    percentile_interval = percentile, basic_interval = basic,
    method = "reference-assisted Kendall tau percentile/basic envelope hull from paired OLS residual bootstrap",
    target = "True constant residual-copula Kendall tau under an adequate common-error location reference; not a pseudo-true likelihood parameter.",
    validation_status = "experimental reference-assisted inference",
    bootstrap = list(requested = opts$B, successful = sum(status$ok),
      failed = sum(!status$ok), status = status, seed = opts$seed,
      joint_refits = 0L, all_draws_required = TRUE, replacement_draws = 0L,
      paired_subject_rows = TRUE, fixed_observed_basis = TRUE,
      tau_statistic = "tau-a", endpoint_quantile_type = 8L),
    interpretation = list(joint_estimate_unchanged = TRUE, native_joint_covariance = FALSE,
      anchor_adjustment_required = FALSE, original_ties_supported = FALSE,
      bootstrap_duplicate_rows_retained = TRUE,
      reference_envelope = "fixed union of percentile and basic intervals, intersected with [-1,1]"),
    assumptions = c("Independent subjects and a continuous residual copula constant across covariates.",
      "Finite-variance common errors independent of covariates, adequately represented by full-rank fixed location bases.",
      "All bootstrap OLS fits must succeed; original residual ties and degenerate dependence are not supported.",
      "Coverage is inherited from an approximate percentile/basic reference envelope, not native joint-parameter sampling inference."))
  if (opts$keep_draws) out$draws <- draws
  class(out) <- "cjqr_eal_tau_ci"
  out
}

cjqr_eal_tau_ci <- function(object, level = .95, B = 500L, seed = 1L,
                             max_memory_mb = 256, keep_draws = FALSE) {
  out <- .cjqr_eal_coefficient_inference(object, level, B, seed, max_memory_mb,
    keep_draws, include_parametric = FALSE, include_tau = TRUE)
  out$tau_ci
}

print.cjqr_eal_tau_ci <- function(x, digits = 4L, ...) {
  if (length(list(...))) stop("Unsupported tau CI printing arguments.", call. = FALSE)
  digits <- .cjqr_eal_ci_integer(digits, "digits", 1L)
  if (digits > 22L) stop("digits must not exceed 22.", call. = FALSE)
  cat("Estimated Kendall's tau = ", format(x$estimate, digits = digits),
    "  (", format(100 * x$level, trim = TRUE), "% CI: [",
    paste(format(x$interval, digits = digits), collapse = ", "), "])\n", sep = "")
  if (!isTRUE(x$available)) cat("Tau CI unavailable:", x$reason, "\n")
  invisible(x)
}
