# Reference-assisted pointwise intervals for the adaptive-anchor EAL fit.
# The unpenalized location reference is auxiliary: it never replaces the
# reported joint estimate and does not provide a joint-model covariance matrix.

.cjqr_eal_ci_integer <- function(x, name, lower = 1L) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) ||
      x != floor(x) || x < lower || x > .Machine$integer.max) {
    stop(name, " must be a single integer between ", lower, " and ",
         .Machine$integer.max, ".", call. = FALSE)
  }
  as.integer(x)
}

.cjqr_eal_ci_options <- function(probs, level, B, seed, chunk_size,
                                    max_memory_mb, keep_draws) {
  if (!is.numeric(probs) || !length(probs) || !is.null(dim(probs)) ||
      any(!is.finite(probs)) || any(probs <= 0 | probs >= 1) ||
      anyDuplicated(probs)) {
    stop("probs must be a nonempty vector of distinct numeric probabilities strictly between 0 and 1.",
         call. = FALSE)
  }
  if (!is.numeric(level) || length(level) != 1L || !is.finite(level) ||
      level <= 0 || level >= 1) {
    stop("level must be a single number strictly between 0 and 1.",
         call. = FALSE)
  }
  if (!is.numeric(max_memory_mb) || length(max_memory_mb) != 1L ||
      !is.finite(max_memory_mb) || max_memory_mb <= 0) {
    stop("max_memory_mb must be a positive finite number.", call. = FALSE)
  }
  if (!is.logical(keep_draws) || length(keep_draws) != 1L || is.na(keep_draws)) {
    stop("keep_draws must be TRUE or FALSE.", call. = FALSE)
  }
  list(probs = probs, level = level,
       B = .cjqr_eal_ci_integer(B, "B", 2L),
       seed = .cjqr_eal_ci_integer(seed, "seed", 0L),
       chunk_size = .cjqr_eal_ci_integer(chunk_size, "chunk_size"),
       max_memory_mb = max_memory_mb, keep_draws = keep_draws)
}

.cjqr_eal_ci_indices <- function(n, B, seed) {
  old_kind <- RNGkind()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv,
                                inherits = FALSE)
  on.exit({
    do.call(RNGkind, as.list(old_kind))
    if (had_seed) {
      assign(".Random.seed", old_seed, envir = .GlobalEnv)
    } else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
      rm(".Random.seed", envir = .GlobalEnv)
    }
  }, add = TRUE)
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  set.seed(seed)
  matrix(sample.int(n, size = as.double(n) * B, replace = TRUE),
         nrow = n, ncol = B)
}

.cjqr_eal_ci_refit <- function(X, Y, indices, probs, keep_qr = FALSE,
                               qr_cache = NULL) {
  if (is.list(X)) {
    # Resample subjects, not margins: both regressions use exactly the same
    # row indices, even when their coefficient dimensions differ.
    Xb <- if (is.null(qr_cache)) lapply(X, function(z) z[indices, , drop = FALSE]) else
      qr_cache$designs
    decompositions <- if (is.null(qr_cache)) lapply(Xb, qr) else qr_cache$decompositions
    ranks <- vapply(decompositions, function(z) z$rank, integer(1L))
    bad <- which(ranks != vapply(X, ncol, integer(1L)))
    if (length(bad)) {
      return(list(ok = FALSE, rank = min(ranks), ranks = ranks,
                  error = paste0("rank_deficient_subject_resample_margin_",
                                 paste(bad, collapse = "_"))))
    }
    beta <- vector("list", 2L)
    names(beta) <- names(X)
    rq <- matrix(NA_real_, nrow = length(probs), ncol = 2L)
    for (j in seq_len(2L)) {
      beta[[j]] <- qr.coef(decompositions[[j]], Y[indices, j])
      residual <- Y[indices, j] - drop(Xb[[j]] %*% beta[[j]])
      rq[, j] <- as.numeric(stats::quantile(residual, probs = probs,
                                           type = 8L, names = FALSE))
      if (any(!is.finite(beta[[j]])) || any(!is.finite(rq[, j]))) {
        return(list(ok = FALSE, rank = min(ranks), ranks = ranks,
                    error = paste0("nonfinite_OLS_or_residual_quantile_margin_", j)))
      }
    }
    out <- list(ok = TRUE, beta = beta, residual_quantiles = rq,
                rank = min(ranks), ranks = ranks, error = "")
    if (keep_qr) out$qr_cache <- list(designs = Xb, decompositions = decompositions)
    return(out)
  }
  # Share the multiple-response QR decomposition for a common design.
  Xb <- if (is.null(qr_cache)) X[indices, , drop = FALSE] else qr_cache$designs[[1L]]
  Yb <- Y[indices, , drop = FALSE]
  decomposition <- if (is.null(qr_cache)) qr(Xb) else qr_cache$decompositions[[1L]]
  if (decomposition$rank != ncol(X)) {
    return(list(ok = FALSE, rank = decomposition$rank,
                error = "rank_deficient_subject_resample"))
  }
  beta <- qr.coef(decomposition, Yb)
  residual <- Yb - Xb %*% beta
  rq <- vapply(seq_len(2L), function(j) {
    as.numeric(stats::quantile(residual[, j], probs = probs,
                               type = 8L, names = FALSE))
  }, numeric(length(probs)))
  # vapply with a scalar template simplifies to a vector; retain the p-by-2
  # layout for a single requested quantile as well as for several levels.
  rq <- matrix(rq, nrow = length(probs), ncol = 2L)
  if (any(!is.finite(beta)) || any(!is.finite(rq))) {
    return(list(ok = FALSE, rank = decomposition$rank,
                error = "nonfinite_OLS_or_residual_quantile"))
  }
  out <- list(ok = TRUE, beta = beta, residual_quantiles = rq,
       rank = decomposition$rank, error = "")
  if (keep_qr) out$qr_cache <- list(designs = list(Xb), decompositions = list(decomposition))
  out
}

.cjqr_eal_ci_validate_design <- function(X, Y, Xeval, joint, opts,
                                           check_joint = TRUE) {
  finite_matrix <- function(x) is.matrix(x) && is.numeric(x) &&
    length(x) > 0L && all(is.finite(x))
  designs <- function(x) {
    if (finite_matrix(x)) return(list(x, x))
    if (is.list(x) && !is.data.frame(x) && length(x) == 2L &&
        all(vapply(x, finite_matrix, logical(1L)))) return(x)
    NULL
  }
  train <- designs(X)
  evaluation <- designs(Xeval)
  if (is.null(train) || is.null(evaluation) || !finite_matrix(Y) ||
      ncol(Y) != 2L || any(vapply(train, nrow, integer(1L)) != nrow(Y)) ||
      nrow(evaluation[[1L]]) != nrow(evaluation[[2L]]) ||
      any(vapply(evaluation, ncol, integer(1L)) !=
          vapply(train, ncol, integer(1L)))) {
    stop("Training X and prediction X must be finite, conformable numeric matrices or lists of two matrices, with the same paired rows as finite two-column Y.",
         call. = FALSE)
  }
  n <- nrow(Y)
  ds <- vapply(train, ncol, integer(1L))
  d <- if (is.matrix(X)) ds[[1L]] else ds
  m <- nrow(evaluation[[1L]])
  np <- length(opts$probs)
  if (any(n <= ds + 1L)) {
    stop("The reference needs more than d + 1 observations for d design columns.",
         call. = FALSE)
  }
  for (j in seq_len(2L)) {
    intercept <- which(vapply(seq_len(ds[[j]]), function(k) {
      max(abs(train[[j]][, k] - 1)) < 1e-12
    }, logical(1L)))
    if (length(intercept) != 1L ||
        max(abs(evaluation[[j]][, intercept] - 1)) >= 1e-12) {
      stop("The reference requires one intercept column equal to 1 in each margin's training and prediction design.",
           call. = FALSE)
    }
  }
  if (check_joint && (!is.numeric(joint) ||
      !identical(dim(joint), c(m, 2L, np)) || any(!is.finite(joint)))) {
    stop("Joint predictions must be a finite nrow(newdata)-by-2-by-length(probs) array.",
         call. = FALSE)
  }
  # Conservative workspace estimate, not a hard process-memory limit. It
  # covers the index matrix, draws, output arrays and temporary row chunks.
  cells <- as.double(n) * opts$B
  estimate <- 4 * cells + 8 * opts$B * (sum(ds) + 2 * np) +
    8 * m * 2 * np * 8 + 8 * min(m, opts$chunk_size) * opts$B * 4 +
    8 * n * (if (is.matrix(X)) d + 2 else sum(ds) + 2) * 4
  if (is.list(X) || is.list(Xeval)) {
    estimate <- estimate + 8 * m * sum(ds)
  }
  if (cells > .Machine$integer.max || !is.finite(estimate) ||
      estimate > opts$max_memory_mb * 1024^2) {
    stop("Estimated CI workspace exceeds max_memory_mb (or index size limit); reduce B, prediction rows, or chunk_size.",
         call. = FALSE)
  }
  list(n = n, d = d, m = m, np = np, estimated_bytes = estimate,
       train = train, evaluation = evaluation)
}

.cjqr_eal_ci_compute <- function(X, Y, Xeval, joint, opts,
                                    resamples = NULL) {
  began <- proc.time()[[3L]]
  dims <- .cjqr_eal_ci_validate_design(X, Y, Xeval, joint, opts)
  n <- dims$n
  d <- dims$d
  m <- dims$m
  np <- dims$np
  B <- opts$B
  distinct <- is.list(X)
  point <- .cjqr_eal_ci_refit(X, Y, seq_len(n), opts$probs)
  if (!isTRUE(point$ok)) {
    stop("Original OLS reference is unavailable: ", point$error, call. = FALSE)
  }
  reference_fit <- array(NA_real_, dim(joint), dimnames = dimnames(joint))
  location <- if (is.matrix(Xeval) && !distinct) {
    Xeval %*% point$beta
  } else {
    matrix(vapply(seq_len(2L), function(j) {
      beta <- if (distinct) point$beta[[j]] else point$beta[, j]
      drop(dims$evaluation[[j]] %*% beta)
    }, numeric(m)), nrow = m, ncol = 2L)
  }
  for (j in seq_len(2L)) for (k in seq_len(np)) {
    reference_fit[, j, k] <- location[, j] + point$residual_quantiles[k, j]
  }
  if (any(!is.finite(reference_fit))) {
    stop("Nonfinite original reference predictions.", call. = FALSE)
  }
  indices <- if (is.null(resamples)) {
    .cjqr_eal_ci_indices(n, B, opts$seed)
  } else resamples
  if (!is.matrix(indices) || !is.numeric(indices) ||
      !identical(dim(indices), c(n, B)) || any(!is.finite(indices)) ||
      any(indices != floor(indices)) || any(indices < 1 | indices > n)) {
    stop("Internal resample indices must be an n-by-B integer-valued matrix.",
         call. = FALSE)
  }
  beta_draws <- if (distinct) {
    out <- lapply(d, function(dj) matrix(NA_real_, nrow = dj, ncol = B))
    names(out) <- if (!is.null(colnames(Y))) colnames(Y) else names(X)
    out
  } else array(NA_real_, c(d, 2L, B))
  quantile_draws <- array(NA_real_, c(np, 2L, B))
  status <- data.frame(draw = seq_len(B), unique_subjects = integer(B),
                       rank = rep(NA_integer_, B), ok = rep(FALSE, B),
                       error = rep("", B), stringsAsFactors = FALSE)
  if (distinct) {
    status$rank_margin1 <- status$rank_margin2 <- rep(NA_integer_, B)
  }
  for (b in seq_len(B)) {
    ii <- indices[, b]
    status$unique_subjects[b] <- length(unique(ii))
    draw <- tryCatch(.cjqr_eal_ci_refit(X, Y, ii, opts$probs),
                     error = function(e) list(ok = FALSE, rank = NA_integer_,
                                              error = conditionMessage(e)))
    status$rank[b] <- draw$rank
    status$ok[b] <- isTRUE(draw$ok)
    status$error[b] <- draw$error
    if (distinct && length(draw$ranks) == 2L) {
      status$rank_margin1[b] <- draw$ranks[[1L]]
      status$rank_margin2[b] <- draw$ranks[[2L]]
    }
    if (isTRUE(draw$ok)) {
      if (distinct) {
        for (j in seq_len(2L)) beta_draws[[j]][, b] <- draw$beta[[j]]
      } else beta_draws[, , b] <- draw$beta
      quantile_draws[, , b] <- draw$residual_quantiles
    }
  }
  reference_lower <- reference_upper <- lower <- upper <-
    array(NA_real_, dim(joint), dimnames = dimnames(joint))
  available <- all(status$ok)
  error <- if (available) NULL else paste0(
    "At least one bootstrap draw failed; all CI bounds are unavailable. ",
    "No failed draws were discarded or replaced.")
  if (available) {
    tails <- c((1 - opts$level) / 2, (1 + opts$level) / 2)
    endpoint_error <- tryCatch({
      # Extract each common-design coefficient block only once. Process one
      # margin at a time so this does not retain an additional pair of copies.
      for (j in seq_len(2L)) {
        coefficients <- if (distinct) beta_draws[[j]] else
          matrix(beta_draws[, j, ], nrow = d, ncol = B)
        for (start in seq.int(1L, m, by = opts$chunk_size)) {
          rows <- seq.int(start, min(m, start + opts$chunk_size - 1L))
          locdraw <- dims$evaluation[[j]][rows, , drop = FALSE] %*% coefficients
          for (k in seq_len(np)) {
            qdraw <- sweep(locdraw, 2L, quantile_draws[k, j, ], "+")
            if (any(!is.finite(qdraw))) stop("Nonfinite reference bootstrap predictions.")
            endpoints <- vapply(seq_along(rows), function(i) {
              as.numeric(stats::quantile(qdraw[i, ], probs = tails,
                                         type = 8L, names = FALSE))
            }, numeric(2L))
            reference_lower[rows, j, k] <- endpoints[1L, ]
            reference_upper[rows, j, k] <- endpoints[2L, ]
          }
        }
      }
      NULL
    }, error = function(e) conditionMessage(e))
    if (!is.null(endpoint_error)) {
      available <- FALSE
      error <- paste("Reference endpoint calculation failed:", endpoint_error)
      reference_lower[] <- reference_upper[] <- NA_real_
    } else {
      # Exact minimal containment: neither recenter nor replace joint.
      lower <- pmin(reference_lower, joint)
      upper <- pmax(reference_upper, joint)
    }
  }
  if (!available) warning(error, call. = FALSE)
  result <- list(
    fit = joint, lower = lower, upper = upper,
    reference = list(fit = reference_fit, lower = reference_lower,
                     upper = reference_upper,
                     method = "ordinary_subject_pairs_percentile"),
    level = opts$level, probs = opts$probs, available = available,
    method = "reference-assisted minimal-containment pointwise interval",
    error = error,
    bootstrap = list(
      requested = B, attempted = B, successful = sum(status$ok),
      failed = sum(!status$ok), status = status, seed = opts$seed,
      RNG = c("Mersenne-Twister", "Inversion", "Rejection"),
      all_draws_required = TRUE, replacement_draws = 0L,
      paired_subject_rows = TRUE, fixed_observed_basis = TRUE,
      residual_quantile_type = 8L, endpoint_quantile_type = 8L,
      joint_refits = 0L, qgam_refits = 0L, indices_saved = opts$keep_draws,
      estimated_workspace_bytes = dims$estimated_bytes,
      elapsed_seconds = unname(proc.time()[[3L]] - began)),
    interpretation = list(
      unchanged_joint_estimate = TRUE, is_joint_sampling_SE = FALSE,
      symmetry_enforced = FALSE, simultaneous = FALSE,
      reference_validity_established = FALSE),
    assumptions = c(
      "Independent subject pairs; outcomes within a pair may be dependent.",
      "Each margin follows a common-error additive location model with errors independent of covariates and finite variance.",
      if (distinct) "Each fixed observed marginal design includes an intercept, is full rank, and adequately represents its marginal location function." else
        "The fixed observed common design includes an intercept, is full rank, and adequately represents the marginal location functions.",
      "Target quantiles are interior with positive continuous residual density; residual quantiles and endpoints use type 8.",
      "The reference basis, anchor and smoothing selection are not reselected by this bootstrap.",
      "Pointwise coverage is inherited only when the auxiliary reference interval is valid; no universal or finite-sample guarantee is asserted.",
      "These intervals are not native joint-model standard errors, simultaneous bands, or intervals for coefficients or copula parameters."))
  if (opts$keep_draws) {
    result$draws <- list(indices = indices, coefficients = beta_draws,
                         residual_quantiles = quantile_draws)
  }
  class(result) <- "cjqr_eal_ci"
  result
}

# A separate prediction adapter permits testing without fitting an EAL model.
.cjqr_eal_ci_prediction <- function(object, newdata, probs) {
  stats::predict(object, newdata = newdata, probs = probs, type = "quantile")
}

cjqr_eal_ci <- function(object, newdata = NULL,
                           probs = NULL,
                           level = 0.95, B = 500L, seed = 1L,
                           chunk_size = 128L, max_memory_mb = 256,
                           keep_draws = FALSE) {
  if (!inherits(object, "cjqr_eal")) {
    stop("object must be a cjqr_eal fit.", call. = FALSE)
  }
  probs <- .cjqr_eal_default_probs(object, probs)
  spec <- .cjqr_eal_probability_spec(probs, object$responses)
  # Numeric requests retain their original metadata, including names.
  opts <- .cjqr_eal_ci_options(if (spec$shared) probs else spec$union, level, B, seed, chunk_size,
                                 max_memory_mb, keep_draws)
  if (!isTRUE(object$selection$strict_ok)) {
    stop("Reference-assisted intervals require a strictly accepted original EAL fit.",
         call. = FALSE)
  }
  if (!is.null(object$weights) && (!is.numeric(object$weights) ||
      any(!is.finite(object$weights)) || any(object$weights != 1))) {
    stop("Weighted observations are not supported by this reference bootstrap.",
         call. = FALSE)
  }
  if (opts$B < 100L) {
    warning("B < 100 gives coarse percentile endpoints; use this only for code checks, not inferential validation.",
            call. = FALSE)
  }
  Xeval <- .cjqr_eal_newX(object, newdata)
  # Refuse oversized requests before allocating the joint prediction array.
  .cjqr_eal_ci_validate_design(object$X, object$Y, Xeval, NULL, opts,
                                 check_joint = FALSE)
  joint <- .cjqr_eal_ci_prediction(object, newdata, opts$probs)
  result <- .cjqr_eal_ci_compute(object$X, object$Y, Xeval, joint, opts)
  if (!spec$shared) {
    for (nm in c("fit", "lower", "upper")) {
      result[[nm]] <- .cjqr_eal_slice_quantiles(result[[nm]], spec)
      result$reference[[nm]] <- .cjqr_eal_slice_quantiles(result$reference[[nm]], spec)
    }
    result$probs <- spec$probs
    if (!is.null(result$draws)) {
      draws <- result$draws$residual_quantiles
      result$draws$residual_quantiles <- stats::setNames(lapply(1:2, function(j)
        matrix(draws[spec$index[[j]], j, , drop = FALSE],
          nrow = length(spec$probs[[j]]), ncol = opts$B,
          dimnames = list(as.character(spec$probs[[j]]), NULL))), names(spec$probs))
    }
  }
  result
}

print.cjqr_eal_ci <- function(x, ...) {
  cat("Reference-assisted pointwise intervals for joint EAL quantiles\n")
  cat("Level:", format(100 * x$level), "%; probabilities:",
      if (is.list(x$probs)) paste(vapply(seq_along(x$probs), function(j)
        paste0(names(x$probs)[j], " = ", paste(format(x$probs[[j]]), collapse = ", ")),
        character(1)), collapse = "; ") else paste(format(x$probs), collapse = ", "), "\n")
  cat("Bootstrap draws:", x$bootstrap$successful, "successful of",
      x$bootstrap$attempted, "attempted; joint refits: 0\n")
  cat("Intervals:", if (isTRUE(x$available)) "available" else "UNAVAILABLE", "\n")
  cat("Joint estimates are unchanged; intervals are generally asymmetric.\n")
  cat("Validity depends on the common-error location reference; these are not native joint SEs.\n")
  invisible(x)
}
