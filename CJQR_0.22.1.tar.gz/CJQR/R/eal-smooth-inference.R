# Whole-smooth inference from an auxiliary block confidence region.
# This is not a joint EAL Wald statistic or a bootstrap of the EAL estimator.
.cjqr_eal_smooth_hull <- function(reference, joint, draws, level = .95,
                                  condition_max = 1e10, covariance = NULL, radial = NULL) {
  fail <- function(reason) list(available = FALSE, reason = reason,
    rank = NA_integer_, statistic = NA_real_, p.value = NA_real_,
    reference_statistic = NA_real_, reference_p.value = NA_real_)
  if (!is.numeric(reference) || !length(reference) || !is.numeric(joint) ||
      length(joint) != length(reference) || any(!is.finite(c(reference, joint))) ||
      !is.matrix(draws) || !is.numeric(draws) || nrow(draws) != length(reference) ||
      any(!is.finite(draws))) return(fail("Nonfinite or incompatible smooth coefficient inputs."))
  d <- length(reference); B <- ncol(draws)
  if (B <= d || B < 2L) return(fail("More bootstrap draws than smooth coefficients are required."))
  if (!is.numeric(level) || length(level) != 1L || !is.finite(level) || level <= 0 || level >= 1 ||
      !is.numeric(condition_max) || length(condition_max) != 1L || !is.finite(condition_max) || condition_max <= 1)
    stop("Invalid smooth confidence level or conditioning threshold.", call. = FALSE)
  supplied_radial <- radial
  if (xor(is.null(covariance), is.null(radial)))
    return(fail("Studentized calibration requires both reference covariance and radial draws."))
  if (!is.null(radial) && (!is.numeric(radial) || length(radial) != B ||
      any(!is.finite(radial)) || any(radial < 0))) return(fail("Invalid studentized radial draws."))
  V <- if (is.null(covariance)) stats::cov(t(draws)) else covariance
  if (!is.matrix(V) || !is.numeric(V) || !identical(dim(V), c(d, d)) ||
      any(!is.finite(V)) || max(abs(V - t(V))) > 1e-10 * max(1, max(abs(V))))
    return(fail("Invalid smooth reference covariance."))
  scales <- sqrt(diag(V))
  if (any(!is.finite(scales)) || any(scales <= 0)) return(fail("Singular smooth reference covariance."))
  correlation <- V / outer(scales, scales)
  eigenvalues <- eigen(correlation, symmetric = TRUE, only.values = TRUE)$values
  condition <- max(eigenvalues) / min(eigenvalues)
  if (any(!is.finite(eigenvalues)) || min(eigenvalues) <= 0 ||
      !is.finite(condition) || condition > condition_max)
    return(fail("Singular or ill-conditioned smooth reference covariance; no ridge or rank truncation applied."))
  ch <- chol(correlation)
  whiten <- function(v) backsolve(ch, v, transpose = TRUE)
  r <- drop(whiten(reference / scales)); b <- drop(whiten(joint / scales))
  radial <- if (is.null(supplied_radial))
    colSums(whiten(sweep(sweep(draws, 1L, reference, "-"), 1L, scales, "/"))^2) else supplied_radial
  reference_statistic <- sum(r^2)
  if (all(joint == 0)) {
    statistic <- 0; ray <- NA_real_
  } else {
    bb <- sum(b^2)
    if (!is.finite(bb) || bb <= 0) return(fail("Unstable smooth joint-vector norm."))
    ray <- max(0, -sum(r * b) / bb)
    statistic <- sum((r + ray * b)^2)
    if (statistic <= 64 * .Machine$double.eps^2 * max(1, reference_statistic)) statistic <- 0
    # Roundoff only: the feasible ray includes t=0 exactly.
    if (statistic > reference_statistic &&
        statistic - reference_statistic <= 1e-10 * max(1, reference_statistic)) statistic <- reference_statistic
  }
  if (any(!is.finite(c(radial, statistic, reference_statistic))) || statistic > reference_statistic + 1e-10)
    return(fail("Nonfinite or inconsistent smooth hull statistic."))
  # Centered-bootstrap radial calibration. The plus one limits resolution;
  # it does not make this an exact Monte Carlo or finite-sample-valid test.
  tail <- function(q) (1 + sum(radial >= q)) / (B + 1)
  p <- if (all(joint == 0)) 1 else tail(statistic)
  k <- ceiling(level * (B + 1))
  critical <- if (k > B) Inf else sort(radial, partial = k)[k]
  list(available = TRUE, reason = NA_character_, rank = as.integer(d),
    statistic = statistic, p.value = p,
    reference_statistic = reference_statistic, reference_p.value = tail(reference_statistic),
    radial = radial, covariance = V, condition_number = condition,
    ray = ray, critical = critical, level = level, p_value_floor = 1 / (B + 1))
}

.cjqr_eal_smooth_hc3 <- function(X, Y, indices, beta, qr_cache = NULL) {
  designs <- .cjqr_eal_designs(X)
  # The optional cache comes from the same subject-pairs OLS fit; it contains
  # only this draw's unchanged designs and decompositions. Common marginal
  # designs share leverage and bread, but retain separate residual products.
  out <- vector("list", 2L)
  for (j in seq_len(2L)) {
    if (j == 1L || !is.matrix(X)) {
      xb <- if (is.null(qr_cache)) designs[[j]][indices, , drop = FALSE] else
        qr_cache$designs[[j]]
      Q <- if (is.null(qr_cache)) qr(xb) else qr_cache$decompositions[[j]]
      if (Q$rank != ncol(xb)) stop("Rank-deficient smooth HC3 design.", call. = FALSE)
      h <- rowSums(qr.Q(Q)^2)
      if (any(!is.finite(h)) || any(1 - h <= 1e-8))
        stop("Unstable leverage in smooth HC3 reference.", call. = FALSE)
      bread <- chol2inv(qr.R(Q))
      bread <- bread[order(Q$pivot), order(Q$pivot), drop = FALSE]
      projection <- xb %*% bread
    }
    e <- Y[indices, j] - drop(xb %*% beta[[j]])
    influence <- projection * (e / (1 - h))
    V <- crossprod(influence)
    if (any(!is.finite(V))) stop("Nonfinite smooth HC3 covariance.", call. = FALSE)
    out[[j]] <- V
  }
  out
}

.cjqr_eal_smooth_studentized_radial <- function(reference, bootstrap, covariance) {
  scales <- sqrt(diag(covariance))
  if (any(!is.finite(scales)) || any(scales <= 0)) stop("Singular bootstrap HC3 covariance.", call. = FALSE)
  correlation <- covariance / outer(scales, scales)
  ev <- eigen(correlation, symmetric = TRUE, only.values = TRUE)$values
  if (any(!is.finite(ev)) || min(ev) <= 0 || max(ev) / min(ev) > 1e10)
    stop("Singular or ill-conditioned bootstrap HC3 covariance.", call. = FALSE)
  u <- backsolve(chol(correlation), (bootstrap - reference) / scales, transpose = TRUE)
  value <- sum(u^2)
  if (!is.finite(value)) stop("Nonfinite studentized smooth radial statistic.", call. = FALSE)
  value
}

.cjqr_eal_smooth_compute <- function(blocks, joint, reference, draws, status, opts,
                                    covariances = NULL, radials = NULL) {
  tables <- details <- vector("list", 2L)
  for (j in seq_len(2L)) {
    labels <- vapply(blocks[[j]], `[[`, character(1L), "label")
    tables[[j]] <- matrix(NA_real_, length(labels), 3L,
      dimnames = list(labels, c("Rank", "Statistic", "p-value")))
    details[[j]] <- lapply(seq_along(blocks[[j]]), function(k) {
      block <- blocks[[j]][[k]]; ids <- block$ids
      if (!all(status$ok)) return(list(available = FALSE,
        reason = paste("At least one reference draw failed; no smooth tests are available.",
          paste(unique(status$error[nzchar(status$error)]), collapse = "; "))))
      result <- .cjqr_eal_smooth_hull(reference[[j]][ids], joint[[j]][ids],
        draws[[j]][ids, , drop = FALSE], level = opts$level,
        covariance = if (is.null(covariances)) NULL else covariances[[j]][ids, ids, drop = FALSE],
        radial = if (is.null(radials)) NULL else radials[[j]][[k]])
      if (isTRUE(result$available)) tables[[j]][k, ] <<-
        c(result$rank, result$statistic, result$p.value)
      result
    })
    names(details[[j]]) <- labels
  }
  list(tables = tables, details = details,
    available = all(status$ok) && all(vapply(unlist(details, recursive = FALSE),
      function(x) isTRUE(x$available), logical(1L))),
    method = if (is.null(covariances))
      "reference-assisted whole-smooth convex-hull test with centered-bootstrap radial calibration" else
      "reference-assisted whole-smooth convex-hull test with HC3-studentized paired bootstrap",
    null = "All identifiable coefficients of the centered smooth, including its linear component, equal zero.",
    validation_status = "experimental: common-error location reference required",
    bootstrap = list(requested = opts$B, successful = sum(status$ok),
      failed = sum(!status$ok), all_draws_required = TRUE, paired_subject_rows = TRUE,
      status = status,
      joint_refits = 0L, replacement_draws = 0L, seed = opts$seed,
      p_value_floor = 1 / (opts$B + 1), studentized = !is.null(covariances)),
    interpretation = list(native_joint_Wald = FALSE, Chi_squared_calibration = FALSE,
      adjustment_across_smooths = FALSE, anchor_adjustment_required = FALSE,
      basis_and_centering_fixed = TRUE,
      rank_is_test_block_dimension_not_GAM_Ref_df = TRUE))
}

cjqr_eal_smooth_test <- function(object, level = .95, B = 500L, seed = 1L,
                                 max_memory_mb = 256, keep_draws = FALSE) {
  out <- .cjqr_eal_coefficient_inference(object, level, B, seed, max_memory_mb,
    keep_draws, include_smooth = TRUE, include_parametric = FALSE)
  result <- out$smooth
  names(result$tables) <- names(result$details) <- object$responses
  if (keep_draws) result$draws <- list(indices = out$draws$indices,
    coefficients = out$draws$full_coefficients)
  class(result) <- "cjqr_eal_smooth_test"
  result
}

print.cjqr_eal_smooth_test <- function(x, digits = 4L,
                                      signif.stars = getOption("show.signif.stars", TRUE), ...) {
  digits <- .cjqr_eal_ci_integer(digits, "digits", 1L)
  if (digits > 22L) stop("digits must not exceed 22.", call. = FALSE)
  if (!is.logical(signif.stars) || length(signif.stars) != 1L || is.na(signif.stars))
    stop("signif.stars must be TRUE or FALSE.", call. = FALSE)
  cat("EXPERIMENTAL: reference-assisted whole-smooth tests\n")
  for (j in seq_along(x$tables)) {
    cat("\nEQUATION", j, "\n")
    .cjqr_eal_print_parametric(x$tables[[j]][, "p-value", drop = FALSE], digits, signif.stars)
  }
  cat("\nPaired bootstrap calibration; null: entire centered effect is zero, not merely linear.\n")
  cat("Tests are not adjusted across smooths or margins; joint refits: 0; p-value floor:",
    format(x$bootstrap$p_value_floor, digits = digits), "\n")
  bad <- unlist(lapply(x$details, function(margin) vapply(margin, function(z)
    if (isTRUE(z$available)) "" else z$reason, character(1L))), use.names = FALSE)
  bad <- unique(bad[nzchar(bad)])
  if (length(bad)) cat("Unavailable tests:", paste(bad, collapse = "; "), "\n")
  invisible(x)
}
