# Equation-oriented presentation. Gaussian preparation objects supply only the
# fixed basis metadata, never EAL standard errors, tests or effective df.

.cjqr_eal_smooth_blocks <- function(object, eq) {
  smooths <- object$basis[[eq]]$smooth
  if (!length(smooths)) return(list())
  lapply(smooths, function(sm) {
    ids <- seq.int(sm$first.para, sm$last.para)
    if (any(ids < 1L | ids > ncol(.cjqr_eal_designs(object$X)[[eq]])))
      stop("Smooth coefficient indices are incompatible with the fitted EAL basis.", call. = FALSE)
    list(label = sm$label, ids = ids, dimension = length(ids), smooth = sm)
  })
}

.cjqr_eal_smooth_summary_table <- function(components, edf = NULL, tests = NULL) {
  out <- matrix(NA_real_, nrow = nrow(components), ncol = 2L,
    dimnames = list(components$Smooth, c("edf", "p-value")))
  if (!is.null(edf)) out[, "edf"] <- edf[components$Smooth]
  if (!is.null(tests)) out[, "p-value"] <- tests[components$Smooth, "p-value"]
  out
}

.cjqr_eal_dependence_link_name <- function(copula) {
  switch(copula, gaussian =, student_t = "atanh",
    clayton = "log", frank = "identity", gumbel = "log(theta - 1)")
}

.cjqr_eal_print_parametric <- function(table, digits, signif.stars) {
  if (!is.logical(signif.stars) || length(signif.stars) != 1L || is.na(signif.stars))
    stop("signif.stars must be TRUE or FALSE.", call. = FALSE)
  # Also clean the heading when printing summaries saved by older releases.
  colnames(table)[colnames(table) == "p-value (RA)"] <- "p-value"
  if ("p-value" %in% colnames(table) &&
      any(is.finite(table[, "p-value"]))) {
    stats::printCoefmat(table, digits = digits, cs.ind = seq_len(ncol(table) - 1L),
      tst.ind = integer(), P.values = TRUE, has.Pvalue = TRUE,
      signif.stars = signif.stars, signif.legend = signif.stars, na.print = "NA")
  } else print(table, digits = digits, na.print = "NA")
  invisible(table)
}

summary.cjqr_eal <- function(object, inference = c("none", "reference"),
                             level = 0.95, B = 500L, seed = 1L,
                             max_memory_mb = 256, ...) {
  if (length(list(...))) stop("Unsupported EAL summary arguments.", call. = FALSE)
  inference <- match.arg(inference)
  .cjqr_eal_require_fit(object)
  f <- object$fit
  df <- if (object$copula == "student_t") object$df else NULL
  if (object$copula == "student_t") .cjqr_validate_copula_df("student_t", df)
  equations <- lapply(1:2, function(j) {
    Xj <- .cjqr_eal_designs(object$X)[[j]]
    beta_j <- .cjqr_eal_betas(f$beta)[[j]]
    blocks <- .cjqr_eal_smooth_blocks(object, j)
    smooth_ids <- unlist(lapply(blocks, `[[`, "ids"), use.names = FALSE)
    parametric <- setdiff(seq_len(ncol(Xj)), smooth_ids)
    table <- matrix(beta_j[parametric], ncol = 1L,
      dimnames = list(colnames(Xj)[parametric], "Estimate"))
    components <- data.frame(Select = seq_along(blocks),
      Smooth = vapply(blocks, `[[`, character(1L), "label"),
      Coef.dim = vapply(blocks, `[[`, integer(1L), "dimension"),
      stringsAsFactors = FALSE)
    list(formula = object$formulas[[j]], response = object$responses[j],
         parametric = table, smooth = components)
  })
  delta <- .cjqr_delta_from_theta(f$theta, object$copula)
  link <- switch(object$copula,
    gaussian =, student_t = "rho = tanh(delta)",
    clayton = "theta = exp(delta)", frank = "theta = delta",
    gumbel = "theta = 1 + exp(delta)")
  dependence <- matrix(delta, 1L, 1L,
    dimnames = list("(Intercept)", "Estimate"))
  coefficient_ci <- if (inference == "reference")
    .cjqr_eal_coefficient_inference(object, level = level, B = B, seed = seed,
                    max_memory_mb = max_memory_mb, include_smooth = TRUE,
                    include_tau = TRUE) else NULL
  smooth_edf <- .cjqr_eal_smooth_edf(object)
  smooth_tests <- if (is.null(coefficient_ci)) NULL else coefficient_ci$smooth
  if (!is.null(coefficient_ci)) for (j in 1:2)
    equations[[j]]$parametric <- coefficient_ci$tables[[j]]
  out <- list(call = object$call, coefficients = f$beta, equations = equations,
    coefficient_inference = coefficient_ci,
    smooth_inference = smooth_tests, smooth_edf = smooth_edf,
    tau_ci = if (is.null(coefficient_ci)) NULL else coefficient_ci$tau_ci,
    convergence = .cjqr_eal_summary_convergence(object),
    tableP1 = equations[[1L]]$parametric, tableP2 = equations[[2L]]$parametric,
    tableP3 = dependence, tableNP1 = equations[[1L]]$smooth,
    tableNP2 = equations[[2L]]$smooth,
    smooth_tables = lapply(seq_len(2L), function(j)
      .cjqr_eal_smooth_summary_table(equations[[j]]$smooth, smooth_edf$edf[[j]],
        if (is.null(smooth_tests)) NULL else smooth_tests$tables[[j]])),
    n = nrow(.cjqr_eal_designs(object$X)[[1L]]), omitted = length(object$omitted_rows),
    copula = object$copula, df = df, anchor = f$p, degree = object$degree,
    scales = f$sigma, theta = f$theta, delta = delta, dependence_link = link,
    dependence_link_name = .cjqr_eal_dependence_link_name(object$copula),
    kendall_tau = .cjqr_kendall_tau(f$theta, object$copula, df = df),
    selection = object$selection$audit, loglik = f$loglik,
    stationarity = f$stationarity,
    boundary = list(dependence = f$improved_certificate$dependence_boundary %||% NA,
      scale = f$improved_certificate$scale_boundary %||% NA,
      shape = f$improved_certificate$shape_boundary %||% NA),
    seconds = object$elapsed_seconds,
    inference = paste("edf: descriptive conditional joint OPG trace; selected anchor, degree and smoothing treated as fixed.",
      "NA: tests and tau intervals require inference = 'reference'; native joint SEs are unavailable."))
  if (!is.null(coefficient_ci)) out$inference <- paste(
    "Reference-assisted coefficient CIs and interval-inversion p-values for H0: coefficient = 0.",
    "Validity requires a common-error location model and an adequate fixed basis; tests are not adjusted across coefficients or margins.",
    "Marginal intercept inference protects selection over the prespecified candidate anchors within each margin.",
    "Smooth tests use whole-block reference regions with HC3-studentized paired-bootstrap calibration, not native joint Wald tests.",
    "edf: descriptive conditional joint OPG trace, with anchor, degree and smoothing fixed; it is not the test reference df.",
    "Kendall tau intervals use the paired OLS residual bootstrap reference with a hull containing the unchanged fitted copula tau.",
    "NA: native joint SEs and theta-scale inference are unavailable.")
  class(out) <- "summary.cjqr_eal"
  out
}

print.summary.cjqr_eal <- function(x, digits = max(3L, getOption("digits") - 3L),
                                   signif.stars = getOption("show.signif.stars", TRUE), ...) {
  if (length(list(...))) stop("Unsupported EAL summary printing arguments.", call. = FALSE)
  digits <- .cjqr_eal_ci_integer(digits, "digits", 1L)
  if (digits > 22L) stop("digits must not exceed 22.", call. = FALSE)
  if (!is.logical(signif.stars) || length(signif.stars) != 1L || is.na(signif.stars))
    stop("signif.stars must be TRUE or FALSE.", call. = FALSE)
  cat("CJQR: Copula-based joint quantile regression\n")
  cat("Adaptive-anchor EAL margins\n")
  cat("COPULA:", x$copula)
  if (!is.null(x$df)) cat(" (fixed df = ", format(x$df, digits = digits), ")", sep = "")
  cat("\nEAL degree:", x$degree, " | Selected anchor:", format(x$anchor, digits = digits), "\n")
  if (!is.null(x$coefficient_inference))
    cat("EXPERIMENTAL: reference-assisted coefficient calibration is not established.\n")
  for (j in 1:2) {
    eq <- x$equations[[j]]
    cat("\nEQUATION ", j, "\n", sep = "")
    cat("Link function for mu.", j, ": identity\nFormula: ",
        paste(deparse(eq$formula, width.cutoff = 120L), collapse = " "), "\n", sep = "")
    cat("\nParametric coefficients:\n")
    .cjqr_eal_print_parametric(eq$parametric, digits, signif.stars)
    if (nrow(eq$smooth)) {
      cat(if (is.null(x$smooth_inference)) "\nSmooth components:\n" else
        "\nSmooth components' reference-assisted significance:\n")
      table <- if (is.null(x$smooth_tables))
        .cjqr_eal_smooth_summary_table(eq$smooth) else x$smooth_tables[[j]]
      # Keep the display compact, including for previously serialized summaries.
      table <- table[, c("edf", "p-value"), drop = FALSE]
      .cjqr_eal_print_parametric(table, digits, signif.stars)
    } else cat("Smooth components: none\n")
  }
  cat("\nEQUATION 3\n")
  link_name <- x$dependence_link_name %||% .cjqr_eal_dependence_link_name(x$copula)
  cat("Link function for theta: ", link_name, "\nFormula: ~ 1\n", sep = "")
  cat("\nParametric coefficients:\n")
  print(x$tableP3, digits = digits)
  cat("\nn = ", x$n, "\n", sep = "")
  if (is.null(x$tau_ci)) cat("Estimated Kendall's tau = ",
    format(x$kendall_tau, digits = digits), "  (CI not computed)\n", sep = "") else
      print(x$tau_ci, digits = digits)
  if (x$omitted > 0L) cat("Omitted paired rows:", x$omitted, "\n")
  scales <- format(x$scales, digits = digits, trim = TRUE)
  cat("Estimated marginal scales: sigma.1 = ", scales[1L],
    ", sigma.2 = ", scales[2L], "\n", sep = "")
  # Accept earlier saved-summary labels without asserting convergence when
  # a status is missing or unrecognized. Detailed checks remain in the object.
  status <- if (is.list(x$convergence)) x$convergence$status else NULL
  labels <- c(converged = "converged", "not converged" = "not converged",
    "not assessed" = "not assessed", passed = "converged",
    failed = "not converged", incomplete = "not assessed")
  label <- if (is.character(status) && length(status) == 1L &&
    !is.na(status) && status %in% names(labels)) unname(labels[status]) else "not assessed"
  cat("Convergence: ", label, "\n", sep = "")
  invisible(x)
}

print.cjqr_eal <- function(x, ...) {
  print(summary(x), ...)
  invisible(x)
}

.cjqr_eal_plot_equation <- function(eq, margin, eq_missing) {
  if (!is.null(margin)) {
    margin <- .cjqr_eal_ci_integer(margin, "margin")
    if (!eq_missing && !identical(as.numeric(eq), as.numeric(margin)))
      stop("eq and margin select different equations.", call. = FALSE)
    eq <- margin
  }
  eq <- .cjqr_eal_ci_integer(eq, "eq")
  if (!eq %in% 1:2) stop("eq must be 1 or 2; the constant dependence equation has no smooth terms.", call. = FALSE)
  eq
}

.cjqr_eal_smooth_plot_data <- function(object, eq, select, n, n2, too.far) {
  blocks <- .cjqr_eal_smooth_blocks(object, eq)
  if (!length(blocks))
    stop("This equation has no smooth components; use type = 'quantile' for complete predictions.", call. = FALSE)
  if (is.null(select)) select <- seq_along(blocks)
  if (!is.numeric(select) || !length(select) || any(!is.finite(select)) ||
      any(select != floor(select)) || any(select < 1L | select > length(blocks)) ||
      anyDuplicated(select)) stop("select must identify distinct smooth components in the chosen equation.", call. = FALSE)
  answer <- lapply(select, function(k) {
    b <- blocks[[k]]
    sm <- b$smooth
    terms <- sm$term
    dat <- object$basis[[eq]]$model
    if (inherits(sm, c("random.effect", "mrf.smooth", "fs.interaction", "sz.interaction")) ||
        !length(terms) %in% 1:2 || !identical(as.integer(sm$dim), as.integer(length(terms))) ||
        !all(terms %in% names(dat)) ||
        !all(vapply(dat[terms], function(z) is.numeric(z) && is.null(dim(z)) &&
                     all(is.finite(z)) && diff(range(z)) > 0, logical(1))))
      stop("Automatic smooth plots currently require one or two nonconstant numeric covariates; unsupported term: ",
           b$label, ".", call. = FALSE)
    size <- if (length(terms) == 1L) n else n2
    axes <- lapply(dat[terms], function(z) seq(min(z), max(z), length.out = size))
    grid <- do.call(expand.grid, c(axes, list(KEEP.OUT.ATTRS = FALSE,
                                            stringsAsFactors = FALSE)))
    by_note <- NULL
    if (!is.null(sm$by) && sm$by != "NA") {
      z <- dat[[sm$by]]
      if (is.factor(z)) {
        lev <- sm$by.level
        if (is.null(lev) || !lev %in% levels(z))
          stop("Cannot identify the factor-by level for smooth ", b$label, ".", call. = FALSE)
        grid[[sm$by]] <- factor(rep(lev, nrow(grid)), levels = levels(z), ordered = is.ordered(z))
        by_note <- paste(sm$by, "=", lev)
      } else if (is.numeric(z) && all(is.finite(z))) {
        grid[[sm$by]] <- rep(1, nrow(grid))
        by_note <- paste(sm$by, "= 1")
      } else stop("Unsupported by-variable for smooth ", b$label, ".", call. = FALSE)
    }
    Xterm <- mgcv::PredictMat(sm, grid)
    if (!is.matrix(Xterm) || ncol(Xterm) != length(b$ids) || any(!is.finite(Xterm)))
      stop("Invalid smooth prediction matrix for ", b$label, ".", call. = FALSE)
    if (!is.null(attr(Xterm, "offset")) && any(attr(Xterm, "offset") != 0))
      stop("Smooth-specific offsets are not supported by these EAL term plots.", call. = FALSE)
    coefficient <- .cjqr_eal_betas(object$fit$beta)[[eq]][b$ids]
    training <- drop(.cjqr_eal_designs(object$X)[[eq]][, b$ids, drop = FALSE] %*% coefficient)
    center <- mean(training)
    value <- drop(Xterm %*% coefficient) - center
    excluded <- if (length(terms) == 2L && too.far > 0)
      mgcv::exclude.too.far(grid[[terms[1L]]], grid[[terms[2L]]],
        dat[[terms[1L]]], dat[[terms[2L]]], dist = too.far) else rep(FALSE, nrow(grid))
    value[excluded] <- NA_real_
    if (!any(is.finite(value))) stop("No supported plotting locations for ", b$label, ".", call. = FALSE)
    list(equation = eq, select = as.integer(k), label = b$label,
      variables = terms, grid = grid, axes = axes,
      fit = if (length(terms) == 2L) matrix(value, n2, n2) else value,
      center = center, training_centered = training - center,
      raw = dat[terms], excluded = excluded, by_profile = by_note,
      coefficient_indices = b$ids, se = NULL, interval = "none",
      interpretation = "Joint EAL smooth contribution centered over the original analysis rows; no uncertainty band.")
  })
  names(answer) <- vapply(answer, `[[`, character(1L), "label")
  answer
}

.cjqr_eal_draw_smooths <- function(panels, pages, rug, scheme, dots) {
  panel_count <- sum(vapply(panels, function(z)
    if (length(z$variables) == 2L && !is.null(z$lower)) 3L else 1L, integer(1L)))
  if (pages > 0L) {
    per_page <- ceiling(panel_count / min(pages, panel_count))
    nr <- max(1L, floor(sqrt(per_page)))
    nc <- ceiling(per_page / nr)
    old <- graphics::par(mfrow = c(nr, nc))
    on.exit(graphics::par(old), add = TRUE)
  }
  for (z in panels) {
    if (length(z$variables) == 1L) {
      args <- utils::modifyList(list(x = z$axes[[1L]], y = z$fit, type = "l",
        xlab = z$variables[1L], ylab = z$label,
        main = paste("Equation", z$equation, if (!is.null(z$by_profile)) paste0("; ", z$by_profile) else ""),
        lwd = 2), dots)
      if (is.null(z$lower)) do.call(graphics::plot, args) else {
        if (is.null(dots$ylim)) args$ylim <- range(z$lower, z$upper, finite = TRUE)
        curve_type <- args$type
        args$type <- "n"
        do.call(graphics::plot, args)
        graphics::lines(z$axes[[1L]], z$lower,
          col = args$col %||% graphics::par("col"), lwd = args$lwd / 2, lty = 2L)
        graphics::lines(z$axes[[1L]], z$upper,
          col = args$col %||% graphics::par("col"), lwd = args$lwd / 2, lty = 2L)
        graphics::lines(z$axes[[1L]], z$fit, type = curve_type,
          col = args$col %||% graphics::par("col"), lwd = args$lwd,
          lty = args$lty %||% graphics::par("lty"), pch = args$pch %||% graphics::par("pch"))
      }
      if (rug) graphics::rug(z$raw[[1L]])
    } else {
      surfaces <- if (is.null(z$lower)) list(z$fit) else
        stats::setNames(list(z$fit, z$lower, z$upper), c("estimate",
          paste0(format(100 * z$level), "% pointwise lower"),
          paste0(format(100 * z$level), "% pointwise upper")))
      limits <- range(unlist(surfaces), finite = TRUE)
      for (k in seq_along(surfaces)) {
        args <- utils::modifyList(list(x = z$axes[[1L]], y = z$axes[[2L]], z = surfaces[[k]],
          xlab = z$variables[1L], ylab = z$variables[2L],
          main = paste("Equation", z$equation, "- centered", z$label,
            if (!is.null(z$by_profile)) paste0("; ", z$by_profile) else "")), dots)
        if (length(surfaces) > 1L) {
          args$main <- paste(args$main, names(surfaces)[k], sep = "\n")
          if (scheme != 0L && is.null(args$zlim)) args$zlim <- limits
          if (scheme != 1L && is.null(args$levels)) args$levels <- pretty(limits, n = 10L)
        }
        if (scheme == 1L) {
          if (is.null(args$zlab)) args$zlab <- z$label
          do.call(graphics::persp, args)
        } else if (scheme == 2L) {
          contour_levels <- args$levels
          args$levels <- NULL
          do.call(graphics::image, args)
          if (is.null(contour_levels))
            graphics::contour(z$axes[[1L]], z$axes[[2L]], surfaces[[k]], add = TRUE) else
              graphics::contour(z$axes[[1L]], z$axes[[2L]], surfaces[[k]], levels = contour_levels, add = TRUE)
        } else do.call(graphics::contour, args)
        if (rug && scheme != 1L) graphics::points(z$raw[[1L]], z$raw[[2L]], pch = ".")
      }
    }
  }
  invisible(panels)
}

.cjqr_eal_quantile_plot_style <- function(dots, np) {
  expand_style <- function(name, default) {
    value <- dots[[name]]
    if (is.null(value)) value <- default
    if (!is.null(dim(value)) || !length(value) %in% c(1L, np))
      stop(name, " must have length 1 or length(probs) for quantile plots.", call. = FALSE)
    rep(value, length.out = np)
  }
  colors <- expand_style("col", seq_len(np))
  if (!is.numeric(colors) && !is.character(colors))
    stop("col must contain R color names or numeric color indices.", call. = FALSE)
  tryCatch(grDevices::col2rgb(colors), error = function(e)
    stop("Invalid col specification: ", conditionMessage(e), call. = FALSE))
  widths <- expand_style("lwd", 2)
  if (!is.numeric(widths) || any(!is.finite(widths)) || any(widths <= 0))
    stop("lwd must contain positive finite line widths.", call. = FALSE)
  types <- expand_style("lty", 1L)
  named_types <- c("blank", "solid", "dashed", "dotted", "dotdash", "longdash", "twodash")
  if (is.numeric(types)) {
    valid <- all(is.finite(types)) && all(types == floor(types)) && all(types >= 0 & types <= 6)
    dashed_curve <- types == 2
  } else if (is.character(types)) {
    valid <- !anyNA(types) && all(types %in% named_types |
      grepl("^([1-9a-fA-F]{2}){1,4}$", types))
    dashed_curve <- types %in% c("dashed", "44")
  } else valid <- FALSE
  if (!valid) stop("lty must contain codes 0:6, named R line types, or valid even-length hexadecimal patterns.", call. = FALSE)
  list(col = colors, lwd = widths, lty = types,
       bound_lwd = widths / 2, bound_lty = ifelse(dashed_curve, 5L, 2L))
}

.cjqr_eal_plot_quantiles <- function(x, newdata, variable, probs, margin,
                                     interval, level, B, seed, draw, dots,
                                     max_memory_mb = 256) {
  spec <- .cjqr_eal_probability_spec(probs, x$responses)
  selected_probs <- if (spec$shared) spec$probs else spec$probs[[margin]]
  # Reject invalid style vectors before an optional, more expensive CI call.
  style <- .cjqr_eal_quantile_plot_style(dots, length(selected_probs))
  dat <- if (is.null(newdata)) x$data else newdata
  axis <- if (is.null(variable)) seq_len(nrow(dat)) else {
    if (!is.character(variable) || length(variable) != 1L || !variable %in% names(dat) ||
        !is.numeric(dat[[variable]]) || any(!is.finite(dat[[variable]])))
      stop("variable must name one finite numeric prediction covariate.", call. = FALSE)
    dat[[variable]]
  }
  ci_control <- if (interval == "confidence") list(max_memory_mb = max_memory_mb) else list()
  pr <- do.call(stats::predict, c(list(object = x, newdata = newdata, probs = probs,
    interval = interval, level = level, B = B, seed = seed), ci_control))
  values <- if (interval == "confidence") pr$fit else pr
  if (interval == "confidence" && !isTRUE(pr$available))
    stop("Confidence intervals are unavailable; inspect cjqr_eal_ci() diagnostics.", call. = FALSE)
  if (draw) {
    extract <- function(a) if (spec$shared) matrix(a[, margin, ], nrow = nrow(dat)) else a[[margin]]
    ys <- extract(values)
    if (interval == "confidence") { lower <- extract(pr$lower); upper <- extract(pr$upper) }
    ord <- order(axis)
    yrange <- if (interval == "confidence")
      range(lower, upper) else range(ys)
    frame_dots <- dots
    frame_dots$col <- frame_dots$lwd <- frame_dots$lty <- NULL
    args <- utils::modifyList(list(x = axis, y = ys[, 1L], type = "n", ylim = yrange,
      xlab = if (is.null(variable)) "Analysis row" else variable,
      ylab = paste(x$responses[margin], "conditional quantile")), frame_dots)
    do.call(graphics::plot, args)
    for (k in seq_along(selected_probs)) {
      if (interval == "confidence") {
        graphics::lines(axis[ord], if (spec$shared) pr$lower[ord, margin, k] else lower[ord, k], col = style$col[k],
          lwd = style$bound_lwd[k], lty = style$bound_lty[k])
        graphics::lines(axis[ord], if (spec$shared) pr$upper[ord, margin, k] else upper[ord, k], col = style$col[k],
          lwd = style$bound_lwd[k], lty = style$bound_lty[k])
      }
      graphics::lines(axis[ord], ys[ord, k], col = style$col[k],
        lwd = style$lwd[k], lty = style$lty[k])
    }
    graphics::legend("topleft", legend = paste("p =", selected_probs), col = style$col,
                     lty = style$lty, lwd = style$lwd, bty = "n")
  }
  invisible(pr)
}

plot.cjqr_eal <- function(x, eq = 1L, select = NULL,
                           type = c("smooth", "quantile"),
                           newdata = NULL, variable = NULL, probs = NULL,
                           margin = NULL, interval = c("none", "confidence"),
                           level = .95, B = 500L, seed = 1L, se = TRUE,
                           n = 100L, n2 = 40L, pages = 0L, rug = TRUE,
                           scheme = 0L, too.far = .1, draw = TRUE,
                           max_memory_mb = 256, ...) {
  .cjqr_eal_require_fit(x)
  eq_missing <- missing(eq)
  interval_missing <- missing(interval)
  profile_request <- !missing(newdata) || !missing(variable) || !missing(probs) || !missing(margin)
  if (missing(type) && (profile_request ||
      (!interval_missing && missing(eq) && missing(select)))) type <- "quantile"
  type <- match.arg(type)
  interval <- match.arg(interval)
  eq <- .cjqr_eal_plot_equation(eq, margin, eq_missing)
  if (!is.logical(draw) || length(draw) != 1L || is.na(draw))
    stop("draw must be TRUE or FALSE.", call. = FALSE)
  if (!is.logical(se) || length(se) != 1L || is.na(se))
    stop("se must be TRUE or FALSE; it controls pointwise confidence intervals, not an SE multiplier.", call. = FALSE)
  dots <- list(...)
  bad <- intersect(names(dots), c("seWithMean", "unconditional", "residuals", "all.terms",
    "shade", "shade.col", "by.resids", "deriv", "shift", "trans", "scale"))
  if (length(bad)) stop("Unsupported EAL plot option(s): ", paste(bad, collapse = ", "),
                        ". No Gaussian initializer uncertainty or residuals are used.", call. = FALSE)
  if (type == "quantile") {
    if (!is.null(select)) stop("select is for smooth components, not complete quantiles.", call. = FALSE)
    probs <- .cjqr_eal_probability_spec(
      .cjqr_eal_default_probs(x, probs, fallback = c(.1, .5, .9)), x$responses)$probs
    return(.cjqr_eal_plot_quantiles(x, newdata, variable, probs, eq,
                                   interval, level, B, seed, draw, dots, max_memory_mb))
  }
  if (!interval_missing) {
    requested <- interval == "confidence"
    if (!missing(se) && se != requested)
      stop("se and interval request different smooth uncertainty displays.", call. = FALSE)
    se <- requested
  }
  if (!is.null(newdata) || !is.null(variable))
    stop("Smooth plots use a grid of the original smooth covariates; use type = 'quantile' for newdata profiles.", call. = FALSE)
  n <- .cjqr_eal_ci_integer(n, "n", 2L)
  n2 <- .cjqr_eal_ci_integer(n2, "n2", 2L)
  if (n > 10000L || n2 > 250L) stop("Plot grids are limited to n <= 10000 and n2 <= 250.", call. = FALSE)
  pages <- .cjqr_eal_ci_integer(pages, "pages", 0L)
  scheme <- .cjqr_eal_ci_integer(scheme, "scheme", 0L)
  if (scheme > 2L) stop("scheme must be 0 (contour), 1 (perspective), or 2 (heatmap).", call. = FALSE)
  if (!is.logical(rug) || length(rug) != 1L || is.na(rug))
    stop("rug must be TRUE or FALSE.", call. = FALSE)
  if (!is.numeric(too.far) || length(too.far) != 1L || !is.finite(too.far) || too.far < 0)
    stop("too.far must be one nonnegative finite number.", call. = FALSE)
  panels <- .cjqr_eal_smooth_plot_data(x, eq, select, n, n2, too.far)
  if (se) panels <- .cjqr_eal_smooth_plot_ci(x, panels, eq, level, B, seed, max_memory_mb)
  if (draw) .cjqr_eal_draw_smooths(panels, pages, rug, scheme, dots)
  invisible(panels)
}
