# Run with demo("eal_joint_demo", package = "CJQR").
# The full multistart fit and convergence checks can take several minutes.
library(CJQR)

dat <- cjqr_example_data(n = 200, seed = 1)
fit <- cjqr_eal(
  list(y1 ~ z + s(x, k = 6), y2 ~ z + s(x, k = 6)),
  data = dat, copula = "gaussian", anchors = 0.5,
  seed = 1, progress = TRUE
)
print(summary(fit))
print(cjqr_fit_diagnostics(fit))

grid <- data.frame(x = seq(-1, 1, length.out = 101), z = 0)
quantiles <- predict(fit, newdata = grid, probs = c(0.1, 0.5, 0.9))
print(head(quantiles[, 1, ]))
plot(fit, eq = 1, select = 1)  # se = TRUE: 95% pointwise smooth intervals
plot(cjqr_residual_diagnostics(fit))

# Complete-quantile intervals include all effects; they do not refit EAL.
# ci <- cjqr_eal_ci(fit, newdata = grid, probs = c(0.1, 0.5, 0.9),
#                   B = 500, seed = 2)
# print(ci)
