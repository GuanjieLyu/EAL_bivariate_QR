# CJQR 0.22.2

* Renamed reference-assisted inference to auxiliary-bootstrap inference in
  package descriptions, help pages, guides and printed messages. The
  auxiliary estimator is distinct from the fitting quantile level.
* Added `summary(fit, inference = "auxiliary")` as the preferred spelling.
  The existing `inference = "reference"` option remains supported, and
  exported functions and returned field names are unchanged.
* Confidence limits, bootstrap resampling, fitting algorithms and numerical
  acceptance rules are unchanged. Existing inferential assumptions and
  experimental-calibration qualifications remain in force.
* Corrected the source-archive installation example to the current version.

# CJQR 0.22.1

* One-dimensional smooth confidence intervals are drawn as two dashed lines,
  without shading. The bounds use the estimate's colour and half its line
  width. `se = TRUE` remains the default; interval calculations and returned
  values are unchanged.

# CJQR 0.22.0

* Smooth plots now use `se = TRUE` by default to display 95% pointwise
  reference-assisted confidence intervals. Use `se = FALSE` to plot estimates
  alone; `level`, `B` and `seed` control the interval calculation.
* Smooth reference draws use paired-subject auxiliary least-squares fits,
  projected onto the selected smooth's basis and centered over the original
  analysis cohort. The joint model is not refitted, and its estimates are
  unchanged. Complete-quantile intervals are not used as smooth bands.
* Two-dimensional smooths display the estimate and its lower and upper
  pointwise confidence surfaces on a common scale. Returned plot data retain
  both reference and reported endpoints and bootstrap diagnostics.
* Added explicit failure handling for rank-deficient reference draws,
  unsupported weights and excessive memory requests. The plot bootstrap
  preserves the caller's random-number state.

# CJQR 0.21.1

* Reorganized the README and user guide around installation, fitting,
  prediction, diagnostics and inference.
* Clarified experimental effect inference and the conditional interpretation
  of information criteria.
* Consolidated numerical-engine documentation and removed obsolete
  development-checkpoint references and unverifiable historical checksums.
* Updated citation metadata to use the installed package version and added
  metadata and documentation regression tests.
* Added a full repository license, repository hygiene rules and an installed
  workflow smoke test in continuous integration.

# CJQR 0.21.0

* Consolidated the public fitting API around `cjqr_eal()`. Removed the
  retired standalone AL fitter and its controls, bootstrap, smoothing
  selectors, methods and documentation. This is a breaking change for
  scripts using the former API.
* Retained degree-three EAL enrichment, adaptive fitting-level selection,
  five copula families and margin-specific predictor bases. The AL submodel
  remains an internal initialization and validation component.
* Retained reference-assisted inference, prediction, qualified information
  criteria and Rosenblatt diagnostics. The estimation objective and
  numerical acceptance rules are unchanged.
* Removed unused shared helpers and the parallel dependency; added
  regression tests for the EAL-only interface.
* Smooth-effect y-axis labels now use the exact term name, such as `s(age)`.
