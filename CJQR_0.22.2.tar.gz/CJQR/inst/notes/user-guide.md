# CJQR user guide

This guide describes the EAL interface in CJQR 0.22.2. The examples assume
that CJQR and its declared dependencies are installed.

## 1. Model and data requirements

CJQR models two paired continuous outcomes observed on independent subjects.
Each marginal equation requires an intercept, but covariates, smooths and
basis dimensions may differ between margins. In
`y1 ~ z + s(x, k = 6)`, `k` is the spline basis dimension, not the estimated
degrees of freedom.

The model has a common-error location structure. Within a margin,
`q_p(x) = eta(x) + sigma * Q_E(p)`: slopes and smooth effects are shared
across prediction probabilities, while intercept shifts differ. Scale,
enrichment and dependence are constant across observations. This is a
distributional location model, not unrestricted quantile regression.

Observation weights, offsets, degree adaptation and covariate-dependent
dispersion or dependence are not supported. An optional third formula must
be `~ 1`. Responses must be distinct numeric columns. If a transformation
is scientifically appropriate, create transformed response columns before
fitting and interpret predictions on that scale.

At least 30 complete paired observations and an identifiable design are
required. The default `na.action = stats::na.fail` rejects missing values.
Explicit `na.action = stats::na.omit` uses one complete-case sample covering
both responses and all predictors. It does not correct missing-data bias.
Repeated observations, clustered records and survey data require sampling
assumptions beyond those implemented here.

## 2. Fit a model

```r
library(CJQR)
dat <- cjqr_example_data(n = 200, seed = 1)

formulas <- list(
  y1 ~ z + s(x, k = 6),
  y2 ~ z + s(x, k = 6)
)
fit <- cjqr_eal(
  formulas, data = dat, copula = "gaussian",
  anchors = 0.5, seed = 1, progress = TRUE
)
summary(fit)
cjqr_fit_diagnostics(fit)
```

The synthetic data have a binary covariate, a continuous covariate, two
nonlinear location functions and Student-t5 errors coupled through a Gaussian
copula. Residual standard deviations are 0.8 and 0.9, and Kendall's tau is 0.5.
The helper preserves the caller's random-number state.

The example fixes the fitting level at 0.5. Default anchors
`c(0.25, 0.5, 0.75)` are candidate fitting levels. CJQR
compares admissible candidates using the penalized likelihood. A single
value, such as `anchors = 0.10`, fixes the fitting level. Multiple starts and
numerical checks improve the search but do not prove global optimality.

The EAL polynomial degree is fixed at three. Working Gaussian additive
models fitted by restricted maximum likelihood (REML) supply smoothing
penalties, which remain fixed during joint optimization. Anchor-specific
calibrated `qgam` fits provide initial locations. These working models do not
supply the joint model's sampling covariance.

Use `cjqr_eal_control()` to validate numerical options. An empty call returns
no overrides, preserving the fitting defaults. `progress = TRUE` prints
fitting progress; the default is quiet. These reporting choices do not change
the estimator.

### Different marginal formulas

For data containing the required variables, formulas can differ:

```r
distinct_formulas <- list(
  y1 ~ group + s(age, k = 6),
  y2 ~ exposure + s(age, k = 8) + s(easting, northing, k = 12)
)
```

Specify coordinate units and an appropriate projection for spatial smooths.
A coordinate term models conditional location, not residual spatial
dependence. It does not justify independent-subject inference for spatially
correlated errors. Automatic plots support numeric one- and two-dimensional
smooths; MRF maps and factor-only random-effect displays are not implemented.

## 3. Choose a copula

| `copula` | Inverse dependence link | Scope |
|---|---|---|
| `"gaussian"` | `rho = tanh(delta)` | Positive or negative dependence |
| `"clayton"` | `theta = exp(delta)` | Positive dependence |
| `"frank"` | `theta = delta` | Both signs; zero is independence |
| `"gumbel"` | `theta = 1 + exp(delta)` | Positive dependence |
| `"student_t"` | `rho = tanh(delta)` | Both signs; fixed `df > 0` |

A Student-t copula requires, for example, `copula = "student_t", df = 5`.
The degrees of freedom concern the copula; the margins remain EAL.
For finite degrees of freedom, zero correlation gives zero Kendall's tau but
not independence. Clayton and Gumbel approach independence at their lower
parameter boundaries.

Numerical search bounds safeguard evaluation without changing the inverse
links. Controls inappropriate for the selected family are rejected. Choose
copulas using substantive considerations and diagnostic evidence.

## 4. Predictions and fitting levels

```r
grid <- data.frame(x = seq(-1, 1, length.out = 101), z = 0)
probs <- c(0.1, 0.5, 0.9)

q <- predict(fit, newdata = grid, probs = probs)
dim(q)  # observations x responses x probabilities
q[, 1, ]

location <- predict(fit, newdata = grid, type = "location")
design <- predict(fit, newdata = grid, type = "lpmatrix")

q_distinct <- predict(fit, newdata = grid,
  probs = list(y1 = c(0.1, 0.5), y2 = 0.9))
```

`anchors` determines the fitted distribution; `probs` determines reported
quantiles from that distribution. Changing `probs` does not refit the model.
A vector requests the same probabilities for both responses. A two-element
list requests different marginal grids and always returns response-named
matrices. Named lists must use both response names; unnamed lists follow
formula order. Probabilities must be distinct within each margin and lie
strictly between zero and one.

Explicit `probs` supplied to `cjqr_eal()` become the object's reporting
defaults. Without stored targets, predictions and quantile intervals use
0.10, 0.25, 0.50, 0.75 and 0.90; complete-quantile plots use 0.10, 0.50 and
0.90. A method's explicit `probs` argument overrides stored defaults.

`type = "location"` returns the conditional quantile at the selected anchor,
not generally the median. `type = "cdf"` returns marginal CDFs; see its help
for the response argument `y`. Prediction data must include all covariates
from both formulas, in the fitted units and factor coding. Unknown factor
levels are rejected.

When marginal formulas, environments and represented bases coincide,
`coef(fit)` and `predict(fit, type = "lpmatrix")` return matrices.
Otherwise they return response-named lists. Equal column counts alone do
not make different designs identical.

## 5. Summaries and numerical diagnostics

`summary(fit)` reports each marginal equation, estimated parametric effects
and descriptive smooth EDF. The third equation reports the dependence
intercept on its link scale. The footer reports Kendall's tau, marginal EAL
scales and convergence status. EAL scales are not generally residual
standard deviations.

Smooth EDF is a conditional joint-score outer-product-of-gradients (OPG)
trace, with fitting level, degree and penalties treated as fixed. It is
unavailable at detected likelihood cusps, search boundaries or unsafe
information matrices. It is not a test reference degrees of freedom.
Default summaries do not run a bootstrap; p-values and the tau interval are
not computed unless auxiliary-bootstrap inference is requested.

`summary(fit)$convergence$status` is `"converged"`, `"not converged"` or
`"not assessed"`. Detailed measures, thresholds, reasons and boundary checks
are retained in the convergence component and `cjqr_fit_diagnostics(fit)`.
These concern numerical convergence, not statistical model adequacy.

## 6. Pointwise conditional-quantile intervals

These auxiliary-bootstrap intervals use auxiliary estimators based on
ordinary least squares and residual quantiles. The term distinguishes this
construction from the reference or anchor level used to fit the EAL model.

```r
ci <- cjqr_eal_ci(
  fit, newdata = grid, probs = probs,
  level = 0.95, B = 500, seed = 2
)
print(ci)
head(as.data.frame(ci))
auxiliary_table <- as.data.frame(ci, include_reference = TRUE)
```

The equivalent `predict(..., interval = "confidence", B = 500, seed = 2)`
returns an interval object rather than a prediction array. Long-format output
contains `row_index`, `response`, `prob`, `estimate`, `lower`, `upper` and
`available`. The row index refers to the prediction grid.

Each subject-pairs bootstrap draw refits an auxiliary unpenalized
least-squares regression on each margin's fixed design. The same sampled
indices are used for both outcomes and designs. Auxiliary predictions add
the empirical residual quantile to the auxiliary fitted location.
Percentile endpoints and residual quantiles use R's type-8 convention.
The reported interval is
`[min(reference_lower, joint_prediction), max(reference_upper, joint_prediction)]`.
The `reference_*` field names and `include_reference` argument are retained
for compatibility; they refer to the auxiliary estimator and its bounds.

This enclosure retains the joint estimate and may be asymmetric around it.
It does not estimate the joint model's sampling standard error. No EAL or
`qgam` model is refitted. All requested resamples are attempted; any failed
or rank-deficient auxiliary fit makes the interval calculation unavailable.
Point estimates and resample diagnostics remain accessible.

Validity requires independent identically distributed subject pairs,
finite-variance common location errors independent of covariates, positive
continuous residual density at the target quantiles, adequate basis
approximation and a well-behaved design. Containment inherits coverage from
a valid auxiliary interval; it does not correct basis bias or guarantee
finite-sample coverage. Increasing `B` reduces bootstrap Monte Carlo error,
not model misspecification.

These are pointwise intervals for complete conditional quantiles, not
simultaneous bands or future-response prediction intervals. For different
marginal probability grids, the same paired resamples serve all requested
levels.

### Experimental effect inference

```r
inference <- summary(fit, inference = "auxiliary", B = 500, seed = 1)
print(inference)

coefficient_ci <- cjqr_eal_coef_ci(fit, B = 500, seed = 1)
smooth_tests <- cjqr_eal_smooth_test(fit, B = 1999, seed = 1)
tau_ci <- cjqr_eal_tau_ci(fit, B = 1999, seed = 1)
```

`inference = "auxiliary"` is the preferred summary option. The legacy
`inference = "reference"` remains an alias for the same procedure.

Coefficient intervals, whole-smooth tests and Kendall's tau intervals are
experimental and opt-in. Coefficient coverage was below nominal in some
validation settings; the methods are not established defaults for
confirmatory inference. They require the common-error location assumptions
above and do not supply a joint covariance matrix or native joint Wald tests.

Non-intercept coefficients use auxiliary OLS percentile intervals enlarged
to contain the joint estimate. Interval-inversion p-values have a conservative
resampling floor of `2/(B + 1)`. Auxiliary intercept estimates add the
residual quantile at the fitted anchor. With `K` prespecified candidate anchors, within-margin
Bonferroni protection uses the entire candidate grid; the intercept p-value
floor is `min(1, 2 * K / (B + 1))`. This protects the candidate-level comparison,
not other coefficients or margins, and does not repair auxiliary-bootstrap
undercoverage.

Whole-smooth tests use HC3-studentized paired-bootstrap auxiliary regions
enlarged to contain the joint coefficient block. They test the entire
centered smooth, including its linear component, not nonlinearity alone.
Their resampling p-value floor is `1/(B + 1)`. Tests are not adjusted across
effects or margins. Rank and test statistics remain in the returned inference
object; printed smooth tables show EDF and p-values.

Kendall's tau inference bootstraps paired OLS residuals, combines percentile
and basic intervals in a fixed envelope, and enlarges it to contain the
fitted copula-derived tau. The target is true residual-copula association
under the common-error model, not a misspecified likelihood's pseudo-true
parameter. Original residual ties, degenerate dependence or failed draws
make the interval unavailable. Bootstrap duplicates remain in the calculation.
The dependence-link coefficient does not receive a standard error or test.

Save computed summaries or interval objects for reuse. Reprinting them does
not repeat the bootstrap. Significance symbols can be omitted with
`print(inference, signif.stars = FALSE)`.

## 7. Plotting and residual assessment

```r
plot(fit, eq = 1, select = 1)  # default 95% pointwise smooth intervals
plot(fit, eq = 2, select = 1)
plot(fit, eq = 1, select = 1, se = FALSE)  # estimates only
plot(fit, type = "quantile", newdata = grid, variable = "x",
     margin = 1, probs = probs)

diagnostics <- cjqr_residual_diagnostics(fit)
plot(diagnostics)
reverse_diagnostics <- cjqr_residual_diagnostics(fit, order = c(2, 1))
```

Default smooth plots use `se = TRUE` for auxiliary-bootstrap 95% pointwise
intervals. `eq` selects the margin and `select` the smooth within that
margin. The x-axis uses the covariate name and the y-axis the smooth label,
such as `s(x)`. Use `se = FALSE` for estimates alone, or `draw = FALSE`
to obtain plot data without drawing. `level`, `B` and `seed` control the
interval calculation; their defaults are 0.95, 500 and 1.

The calculation resamples complete paired rows and fits auxiliary unpenalized
least-squares models in the original marginal bases. Bootstrap contributions
for the selected smooth are centered over the original analysis cohort,
then their equal-tail percentile intervals are enlarged to contain the
unchanged joint smooth. No intercept or residual quantile is added to a
smooth interval. This calculation does not refit EAL, use Gaussian-model
standard errors, or require a preceding `summary()` call. It preserves the
caller's random-number state. All bootstrap draws must be valid; a failed
or rank-deficient draw stops the confidence plot rather than being discarded.

These intervals require an adequate full-rank fixed basis and finite-variance
common location errors independent of covariates. They are pointwise, not
simultaneous bands, and do not guarantee nominal finite-sample coverage.
Returned plot data contain the joint estimates, auxiliary and reported
endpoints, confidence level and bootstrap diagnostics. The `se` field is
`NULL`, since joint-model standard errors are not computed. For a
two-dimensional smooth, three panels show the estimate and the lower and
upper pointwise confidence surfaces on a common scale; `pages = 1` arranges
them together. Unsupported grid locations remain masked throughout.

Complete-quantile plots include the intercept and all effects; hold other
predictors fixed for an interpretable profile. Adding
`interval = "confidence"` to these plots computes pointwise quantile
intervals, not smooth-component bands. For an explicit smooth plot, an
explicit `interval` value is an alias for `se`; conflicting requests are
rejected. Use `type = "smooth"` or `type = "quantile"` to make the intended
plot type unambiguous.

Rosenblatt plots contain the first response's marginal probability
transform, the second response's conditional transform and nine empirical
normal-score density contours. The transformation supports both conditioning
orders and all five copula families. Approximately uniform histograms and
circular contours are diagnostic expectations, not proof of adequate fit.
No whitening or rank transformation is applied. For held-out assessment,
supply `newdata` containing both responses, or a separate paired numeric
`y` matrix in fitted response order. Diagnostics are unweighted.

`residuals(fit)` returns observed outcomes minus fitted anchor locations.
`type = "standardized"` divides by the EAL scale, not a residual standard
deviation. `type = "pit"` and `type = "quantile"` return marginal probability
transforms and their normal scores. These marginal residuals do not remove
between-outcome dependence. Omitted fitting rows are not restored.

## 8. Comparing copulas

```r
ic <- cjqr_eal_ic(fit)
ic$effective_df
ic$diagnostics
AIC(fit)
BIC(fit)
```

The criteria use the unpenalized joint log likelihood and conditional
joint-score OPG EDF, including regression, scale, shape and dependence
parameters. AIC is an OPG/expected-Fisher approximation; EDF-based BIC is a
heuristic without an established marginal-likelihood interpretation. Warnings
identify these limitations. The sample size is the number of subject pairs.

Both criteria condition on the selected anchor, degree, penalties and fixed
copula degrees of freedom. Multi-model calls require identical paired data,
row order, marginal designs, degree, candidate-anchor sets and penalties.
Different fixed copula degrees of freedom may be compared conditionally.
Native `qgam` criteria are not comparable, and these methods should not be
used to select a fitting level.

Incomplete convergence evidence, unsafe information, fitted cusps, boundaries
or failed likelihood replay cause an error. There is no parameter-count
fallback. The ordinary `logLik()` method retains `df = NA`. See
`?cjqr_eal_ic` for the precise criterion and compatibility checks.

## 9. Failed fits and reproducibility

To retain a numerical failure for inspection:

```r
result <- tryCatch(
  cjqr_eal(formulas, data = dat, copula = "gaussian", anchors = 0.5, seed = 1),
  cjqr_eal_convergence_error = identity
)
cjqr_fit_diagnostics(result)
if (inherits(result, "cjqr_eal_convergence_error")) {
  message("No accepted EAL fit: ", conditionMessage(result))
}
```

A convergence error is not a usable fitted model. Inspect candidate failures,
bounds, data scaling and basis rank before changing the analysis. Record
changes to iteration budgets, anchors or basis dimensions. The example catches
convergence errors only; input-validation errors require correcting the inputs.

Save the fitted model, preprocessing code, formulas, copula, fixed degrees of
freedom, candidate and selected anchors, controls, seeds, inference results
and `sessionInfo()`. Retain participant data only where privacy and consent
permit. Preserve failed-fit and failed-resample counts in simulation reports.

```r
analysis <- list(
  fit = fit, intervals = ci, prediction_grid = grid,
  formulas = formulas, fit_seed = 1, interval_seed = 2,
  session = sessionInfo()
)
saveRDS(analysis, "cjqr-analysis.rds")
citation("CJQR")
```

Loading a saved object does not migrate its statistical or numerical policy.
Retain the package version used for an analysis and verify compatibility
before using saved objects with another release.
