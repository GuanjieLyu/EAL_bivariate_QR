# Bivariate copula kernels using the EAL's represented log tails. No PIT
# clipping is used. Scores are on the dependence-link scale and retain all
# marginal shape derivatives. Gaussian and Clayton kernels are in numerical.R.

.eal_logadd <- function(a,b) {
  m <- pmax(a,b)
  out <- m+log1p(exp(pmin(a,b)-m))
  out[is.infinite(m)&m<0] <- -Inf
  out
}
.eal_log1pexp <- function(x) pmax(x,0)+log1p(exp(-abs(x)))
.eal_tail <- function(t) {
  left <- t$logF<=t$logS
  list(left=left,lp=ifelse(left,t$logF,t$logS))
}
.eal_tail_chain <- function(t,g,left) {
  de <- numeric(length(g)); ds <- matrix(0,length(g),ncol(t$dlogF_dshape))
  for(lower in c(TRUE,FALSE)) {
    ii <- which(left==lower)
    if(!length(ii))next
    lp <- if(lower)t$logF[ii] else t$logS[ii]
    de[ii] <- g[ii]*exp(t$logdensity[ii]-lp)*if(lower)1 else -1
    deriv <- if(lower)t$dlogF_dshape else t$dlogS_dshape
    ds[ii,] <- g[ii]*deriv[ii,,drop=FALSE]
  }
  list(de=de,dshape=ds)
}
.eal_finish_tail <- function(ans,t1,t2,g1,g2,a,b) {
  one <- .eal_tail_chain(t1,g1,a$left)
  two <- .eal_tail_chain(t2,g2,b$left)
  ans$de <- cbind(one$de,two$de)
  ans$dshape <- list(one$dshape,two$dshape)
  ans
}

eal_student_t_terms <- function(t1,t2,rho,df,derivatives=TRUE) {
  stopifnot(length(df)==1L,is.finite(df),df>0,length(rho)==1L,
    is.finite(rho),abs(rho)<1,length(t1$logF)==length(t2$logF))
  nu <- df
  t_score <- function(t) {
    s <- .eal_tail(t)
    q <- suppressWarnings(qt(s$lp,df=nu,lower.tail=FALSE,log.p=TRUE))
    lq <- log(abs(q))
    large <- which(!is.finite(q))
    if(length(large)) {
      # qt can overflow even though log|q| and the copula remain representable.
      # At such magnitudes the omitted O(nu/q^2) tail term is below precision.
      logC <- (.5*nu-1)*log(nu)-lbeta(.5*nu,.5)
      lq[large] <- (logC-s$lp[large])/nu
    }
    stopifnot(all(!is.na(lq)),all(lq<Inf))
    s$logabs <- lq
    s$sign <- ifelse(s$left,-1,1)
    s$log1q <- .eal_log1pexp(2*lq-log(nu))
    s$logdensity <- -.5*log(nu)-lbeta(.5*nu,.5)-.5*(nu+1)*s$log1q
    s
  }
  a <- t_score(t1); b <- t_score(t2)
  lm <- pmax(.5*log(nu),a$logabs,b$logabs)
  x <- a$sign*exp(a$logabs-lm); y <- b$sign*exp(b$logabs-lm)
  sn <- exp(log(nu)-2*lm)
  D <- (1-rho)*(1+rho)
  N <- .5*((1-rho)*(x+y)^2+(1+rho)*(x-y)^2)
  T <- sn*D+N
  lq <- log(T)+2*lm-log(nu)-log(D)
  constant <- log(nu/2)+2*(lbeta(nu/2,.5)-lgamma(.5))
  ans <- list(logc=constant-.5*log(D)-.5*(nu+2)*lq+
    .5*(nu+1)*(a$log1q+b$log1q))
  if(!derivatives)return(ans)
  score <- function(s,x,y) {
    # Evaluate joint and univariate terms on separate scales so a highly
    # unequal pair of quantiles cannot create an artificial 0/0.
    joint <- -(nu+2)*(x-rho*y)/T*exp(s$lp-s$logdensity-lm)
    li <- pmax(.5*log(nu),s$logabs)
    xi <- s$sign*exp(s$logabs-li)
    ni <- exp(log(nu)-2*li)
    marginal <- (nu+1)*xi/(ni+xi^2)*exp(s$lp-s$logdensity-li)
    -s$sign*(joint+marginal)
  }
  ans$ddelta <- rho+(nu+2)*(D*x*y-rho*N)/T
  .eal_finish_tail(ans,t1,t2,score(a,x,y),score(b,y,x),a,b)
}

.eal_frank_phi <- function(x) {
  # phi(x)=(1-exp(-x))/x and its analytic derivative. The convergent
  # polynomial avoids subtracting the two singular 1/theta terms near zero.
  co <- c(1,-1/2,1/6,-1/24,1/120,-1/720,1/5040,-1/40320,1/362880)
  f <- rep(co[9],length(x)); fp <- rep(8*co[9],length(x))
  for(k in 8:1)f <- co[k]+x*f
  for(k in 7:1)fp <- k*co[k+1]+x*fp
  list(f=f,fp=fp)
}
.eal_log_one_minus_exp_product <- function(a,lp) {
  la <- log(a)+lp
  out <- numeric(length(lp)); small <- la< -36
  out[small] <- la[small]
  out[!small] <- log(-expm1(-exp(la[!small])))
  out
}
eal_frank_terms <- function(t1,t2,theta,derivatives=TRUE) {
  stopifnot(length(theta)==1L,is.finite(theta),length(t1$logF)==length(t2$logF))
  a <- .eal_tail(t1); b <- .eal_tail(t2)
  u <- exp(t1$logF); v <- exp(t2$logF)
  if(abs(theta)<.01) {
    z <- theta; f <- .eal_frank_phi(z)
    fu <- .eal_frank_phi(z*u); fv <- .eal_frank_phi(z*v)
    H <- f$f-z*u*v*fu$f*fv$f
    ans <- list(logc=log(f$f)-z*(u+v)-2*log(H))
    if(!derivatives)return(ans)
    du <- -z+2*z*exp(-z*u)*v*fv$f/H
    dv <- -z+2*z*exp(-z*v)*u*fu$f/H
    Hp <- f$fp-u*v*(fu$f*fv$f+z*(u*fu$fp*fv$f+v*fu$f*fv$fp))
    ans$ddelta <- f$fp/f$f-u-v-2*Hp/H
  } else {
    # Negative Frank is a reflection of positive Frank. Swap the stored
    # tails rather than forming 1-v, which may already have rounded to zero.
    z <- abs(theta)
    lv <- if(theta>0)t2$logF else t2$logS
    lsv <- if(theta>0)t2$logS else t2$logF
    v <- exp(lv)
    lau <- .eal_log_one_minus_exp_product(z,t1$logF)
    lav <- .eal_log_one_minus_exp_product(z,lv)
    lasv <- .eal_log_one_minus_exp_product(z,lsv)
    logA <- log(-expm1(-z))
    logD <- .eal_logadd(-z*u+lav,-z*v+lasv)
    ans <- list(logc=log(z)+logA-z*(u+v)-2*logD)
    if(!derivatives)return(ans)
    ru <- exp(-z*u+lav-logD); rv <- exp(-z*v+lau-logD)
    du <- -z+2*z*ru
    dv <- (-z+2*z*rv)*if(theta>0)1 else -1
    dD <- exp(-z-logD)-u*ru-v*rv
    ans$ddelta <- (1/z+exp(-z-logA)-u-v-2*dD)*sign(theta)
  }
  g1 <- du*exp(a$lp)*ifelse(a$left,1,-1)
  g2 <- dv*exp(b$lp)*ifelse(b$left,1,-1)
  .eal_finish_tail(ans,t1,t2,g1,g2,a,b)
}

eal_gumbel_terms <- function(t1,t2,theta,derivatives=TRUE) {
  stopifnot(length(theta)==1L,is.finite(theta),theta>=1,
    length(t1$logF)==length(t2$logF))
  log_minus_log <- function(t) {
    # -log(u) is asymptotic to 1-u; retain its logarithm when u rounds to 1.
    out <- log(-t$logF); ii <- t$logS< -36
    out[ii] <- t$logS[ii]
    out
  }
  a <- .eal_tail(t1); b <- .eal_tail(t2)
  lx <- log_minus_log(t1); ly <- log_minus_log(t2)
  logA <- .eal_logadd(theta*lx,theta*ly)
  lt <- logA/theta
  wx <- exp(theta*lx-logA); wy <- exp(theta*ly-logA)
  tt <- exp(lt); aa <- theta-1
  vv <- if(aa==0)rep(0,length(lt)) else plogis(log(aa)-lt)
  logB <- if(aa==0)rep(0,length(lt)) else .eal_log1pexp(log(aa)-lt)
  ans <- list(logc=-tt-t1$logF-t2$logF+aa*(lx+ly-2*lt)+logB)
  if(theta==1)ans$logc[] <- 0
  if(!derivatives)return(ans)
  if(theta==1) {
    ans$ddelta <- numeric(length(lt))
    ans$de <- matrix(0,length(lt),2L)
    ans$dshape <- list(matrix(0,length(lt),ncol(t1$dlogF_dshape)),
      matrix(0,length(lt),ncol(t2$dlogF_dshape)))
    return(ans)
  }
  common <- tt+2*aa+vv
  gx <- exp(lx)+aa-common*wx
  gy <- exp(ly)+aa-common*wy
  # These are derivatives with respect to the smaller represented log tail.
  chain <- function(t,s,lx,g) {
    out <- -g*exp(-lx)
    ii <- which(!s$left)
    out[ii] <- g[ii]*exp(t$logS[ii]-t$logF[ii]-lx[ii])
    out
  }
  dl <- (wx*(lx-lt)+wy*(ly-lt))/theta
  ans$ddelta <- aa*(lx+ly-2*lt-common*dl)+vv
  .eal_finish_tail(ans,t1,t2,chain(t1,a,lx,gx),chain(t2,b,ly,gy),a,b)
}

eal_additional_copula_terms <- function(t1,t2,theta,copula,df=NULL,derivatives=TRUE) {
  switch(copula,
    student_t=eal_student_t_terms(t1,t2,theta,df,derivatives),
    frank=eal_frank_terms(t1,t2,theta,derivatives),
    gumbel=eal_gumbel_terms(t1,t2,theta,derivatives),
    stop("Unsupported additional EAL copula"))
}
