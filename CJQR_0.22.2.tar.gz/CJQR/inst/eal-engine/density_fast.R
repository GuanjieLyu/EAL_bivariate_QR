# Optimized pure-R arithmetic for the finite-degree EAL density.
sweep <- function(x, MARGIN, STATS, FUN = "-", check.margin = TRUE, ...) {
  if (missing(x) || missing(MARGIN) || missing(STATS))
    return(base::sweep(x, MARGIN, STATS, FUN, check.margin, ...))
  valid <- is.matrix(x) && !is.object(x) &&
    (is.double(x) || is.integer(x)) && nrow(x) > 0L && ncol(x) > 0L &&
    !is.object(MARGIN) && is.null(dim(MARGIN)) &&
    (is.double(MARGIN) || is.integer(MARGIN)) && length(MARGIN) == 1L &&
    !is.na(MARGIN) && MARGIN == 2 &&
    !is.object(STATS) && is.null(dim(STATS)) &&
    (is.double(STATS) || is.integer(STATS)) && length(STATS) == ncol(x) &&
    is.character(FUN) && length(FUN) == 1L && !is.na(FUN) &&
    FUN %in% c("/", "-", "*") &&
    (identical(check.margin, TRUE) || identical(check.margin, FALSE)) &&
    ...length() == 0L
  if (!valid) return(base::sweep(x, MARGIN, STATS, FUN, check.margin, ...))
  # base::sweep constructs an array then permutes it. Its entries are exactly
  # the column statistic repeated nrow(x) times. This removes that permutation,
  # not any arithmetic: each cell performs the same single binary operation.
  column_values <- rep(as.vector(STATS), each = nrow(x))
  switch(FUN, "/" = x / column_values, "-" = x - column_values,
         "*" = x * column_values)
}

rowSums <- function(x, na.rm = FALSE, dims = 1L) {
  if (missing(x)) return(base::rowSums(x, na.rm, dims))
  valid <- is.matrix(x) && is.double(x) && !is.object(x) &&
    identical(names(attributes(x)), "dim") && nrow(x) > 0L && ncol(x) > 0L &&
    (identical(dims, 1L) || identical(dims, 1)) &&
    (identical(na.rm, FALSE) || identical(na.rm, TRUE))
  if (!valid) return(base::rowSums(x, na.rm, dims))
  # The same base C rowSums routine, same cell ordering and accumulation.
  base::.rowSums(x, nrow(x), ncol(x), na.rm)
}

colSums <- function(x, na.rm = FALSE, dims = 1L) {
  if (missing(x)) return(base::colSums(x, na.rm, dims))
  valid <- is.matrix(x) && is.double(x) && !is.object(x) &&
    identical(names(attributes(x)), "dim") && nrow(x) > 0L && ncol(x) > 0L &&
    (identical(dims, 1L) || identical(dims, 1)) &&
    (identical(na.rm, FALSE) || identical(na.rm, TRUE))
  if (!valid) return(base::colSums(x, na.rm, dims))
  base::.colSums(x, nrow(x), ncol(x), na.rm)
}


# Bounded immutable geometry only; no parameter/evaluation/gradient memo layers.
.eal_geometry <- local({
  make <- function(K) {
    d <- K+1L
    list(d=d,sqrt_d=sqrt(d),offset=qlogis(1/sqrt(d)),
      v0=(c(1,rep(0,K))-rep(1/d,d))/sqrt(1-1/d),
      B=rbind(0,sweep(contr.helmert(K),2L,
        sqrt(seq_len(K-1L)*(seq_len(K-1L)+1)),"/")))
  }
  values <- list(`3`=make(3L),`4`=make(4L))
  function(K) {
    value <- values[[as.character(K)]]
    if(is.null(value))stop("Optimized geometry supports degree 3 or 4")
    value
  }
})
# Finite-degree enriched asymmetric-Laplace margins.
# The squared Laguerre construction follows D'Haen et al. (arXiv:2410.05069,
# Section 3.1). Shape geometry enforces the density-continuity constraint.
# Density and tail calculations retain the finite-degree EAL specification.

eal_shape_init <- function(K = 3L) numeric(2L * as.integer(K) - 1L)

eal_shape <- function(shape = eal_shape_init(K), K = 3L) {
  K <- as.integer(K)
  if (K < 2L || length(shape) != 2L * K - 1L || any(!is.finite(shape)))
    stop("K must be >= 2 and shape must contain 2*K-1 finite values")
  geometry <- .eal_geometry(K)
  d <- geometry$d
  ns <- length(shape)
  frac <- plogis(shape[1L] + geometry$offset)
  center_sum <- geometry$sqrt_d * frac
  radius <- sqrt((1 - frac) * (1 + frac))
  dc <- geometry$sqrt_d * frac * (1 - frac)
  dr <- -frac^2 * sqrt(1 - frac) / sqrt(1 + frac)
  v0 <- geometry$v0
  B <- geometry$B
  make_side <- function(cols) {
    w <- shape[cols]
    den <- 1 + sum(w^2)
    v <- ((1 - sum(w^2)) * v0 + 2 * drop(B %*% w)) / den
    a <- rep(center_sum / d, d) + radius * v
    jac <- matrix(0, d, ns)
    jac[, 1L] <- rep(dc / d, d) + dr * v
    jac[, cols] <- radius * (2 / den) * (B - outer(v0 + v, w))
    list(a = a, jac = jac, norm2 = sum(a^2),
         dlognorm = 2 * drop(crossprod(a, jac)) / sum(a^2))
  }
  left <- make_side(seq.int(2L, K))
  right <- make_side(seq.int(K + 1L, 2L * K - 1L))
  list(K = K, left = left, right = right, center_sum = center_sum,
       shape = shape, shape_dimension = ns)
}

.eal_laguerre <- function(t, K) {
  ans <- matrix(0, length(t), K + 1L)
  ans[, 1L] <- 1
  if (K >= 1L) ans[, 2L] <- 1 - t
  if (K >= 2L) for (k in seq.int(2L, K))
    ans[, k + 1L] <- ((2 * k - 1 - t) * ans[, k] -
                       (k - 1) * ans[, k - 1L]) / k
  ans
}

.eal_log1mexp <- function(x) {
  # x <= 0; preserve tiny complements without subtracting rounded CDFs.
  out <- numeric(length(x))
  small <- x < -log(2)
  out[small] <- log1p(-exp(x[small]))
  out[!small] <- log(-expm1(x[!small]))
  out
}

.eal_half_terms <- function(t, side, K, derivatives = TRUE) {
  L <- .eal_laguerre(t, K)
  poly <- drop(L %*% side$a)
  # dL_k/dt = -sum_{j=0}^{k-1} L_j(t).
  dcoef <- -rev(cumsum(rev(side$a[-1L])))
  dpoly <- drop(L[, seq_len(K), drop = FALSE] %*% dcoef)
  shifted <- matrix(0, length(t), K + 1L)
  # L_k(t+s) = sum_j [L_{k-j}(t)-L_{k-j-1}(t)] L_j(s).
  # Therefore the tail integral is exp(-t) * sum_j shifted_j(t)^2.
  D <- L
  D[, -1L] <- L[, -1L, drop = FALSE] - L[, seq_len(K), drop = FALSE]
  dshifted <- if (derivatives) array(0, c(length(t), K + 1L,
                                        ncol(side$jac))) else NULL
  for (j in 0:K) {
    ix <- seq_len(K - j + 1L)
    coeff_ix <- seq.int(j + 1L, K + 1L)
    shifted[, j + 1L] <- drop(D[, ix, drop = FALSE] %*% side$a[coeff_ix])
    if (derivatives)
      dshifted[, j + 1L, ] <- D[, ix, drop = FALSE] %*%
        side$jac[coeff_ix, , drop = FALSE]
  }
  maxabs <- abs(shifted[, 1L])
  for (j in seq.int(2L, K + 1L)) maxabs <- pmax(maxabs, abs(shifted[, j]))
  shifted_scaled <- shifted / maxabs
  ss <- rowSums(shifted_scaled^2)
  log_tail_poly <- 2 * log(maxabs) + log(ss)
  logtail <- -t + log_tail_poly - log(side$norm2)
  # The true integral is <=1; only roundoff at t near zero is clipped.
  if (any(logtail > 1e-10)) stop("EAL half-tail normalization failure")
  logtail <- pmin(logtail, 0)
  ans <- list(logkernel = -t + 2 * log(abs(poly)) - log(side$norm2),
              logtail = logtail, dlogkernel_dt = -1 + 2 * dpoly / poly)
  if (derivatives) {
    dpoly_shape <- L %*% side$jac
    dk <- sweep(2 * dpoly_shape / poly, 2L, side$dlognorm, "-")
    dt <- matrix(0, length(t), ncol(side$jac))
    for (k in seq_len(ncol(side$jac))) {
      tmp <- if (length(t) > 1L && K >= 1L) dshifted[, , k] else
        matrix(dshifted[, , k], nrow = length(t), ncol = K + 1L)
      dt[, k] <- 2 * rowSums(shifted_scaled * (tmp / maxabs)) / ss
    }
    dt <- sweep(dt, 2L, side$dlognorm, "-")
    ans$dlogkernel_dshape <- dk
    ans$dlogtail_dshape <- dt
  }
  ans
}

eal_terms <- function(e, p, shape = eal_shape_init(K), K = 3L,
                      derivatives = TRUE) {
  if (length(p) != 1L || !is.finite(p) || p <= 0 || p >= 1)
    stop("p must be strictly between 0 and 1")
  if (any(!is.finite(e))) stop("Residuals must be finite")
  spec <- if (is.list(shape)) shape else eal_shape(shape, K)
  K <- spec$K
  n <- length(e)
  ns <- spec$shape_dimension
  logg <- logF <- logS <- hz <- rep(NA_real_, n)
  dlogg <- dlogF <- dlogS <- if (derivatives) matrix(0, n, ns) else NULL
  for (isleft in c(TRUE, FALSE)) {
    ix <- which(if (isleft) e < 0 else e >= 0)
    if (!length(ix)) next
    rate <- if (isleft) 1 - p else p
    side <- if (isleft) spec$left else spec$right
    z <- .eal_half_terms(rate * abs(e[ix]), side, K, derivatives)
    logg[ix] <- log(p) + log1p(-p) + z$logkernel
    hz[ix] <- (if (isleft) -rate else rate) * z$dlogkernel_dt
    if (isleft) {
      logF[ix] <- log(p) + z$logtail
      logS[ix] <- .eal_log1mexp(logF[ix])
      if (derivatives) {
        dlogF[ix, ] <- z$dlogtail_dshape
        dlogS[ix, ] <- -exp(logF[ix] - logS[ix]) * z$dlogtail_dshape
      }
    } else {
      logS[ix] <- log1p(-p) + z$logtail
      logF[ix] <- .eal_log1mexp(logS[ix])
      if (derivatives) {
        dlogS[ix, ] <- z$dlogtail_dshape
        dlogF[ix, ] <- -exp(logS[ix] - logF[ix]) * z$dlogtail_dshape
      }
    }
    if (derivatives) dlogg[ix, ] <- z$dlogkernel_dshape
  }
  hz_left0 <- (1 - p) * (1 + 2 * sum((0:K) * spec$left$a) / sum(spec$left$a))
  hz_right0 <- p * (-1 - 2 * sum((0:K) * spec$right$a) / sum(spec$right$a))
  kink_a <- (hz_left0 - hz_right0) / 2
  exact_dlogF_de <- exp(logg - logF)
  exact_dlogS_de <- -exp(logg - logS)
  ans <- list(logdensity = logg, logcdf = logF, logsurvival = logS,
              derivative_logdensity_e = hz,
              derivative_logcdf_e = exact_dlogF_de,
              derivative_logsurvival_e = exact_dlogS_de,
              logg = logg, logF = logF, logS = logS, hz = hz,
              dlogF_de = exact_dlogF_de, dlogS_de = exact_dlogS_de,
              hz_left0 = hz_left0, hz_right0 = hz_right0,
              kink_a = kink_a)
  if (derivatives) {
    ans$dlogg_dshape <- dlogg
    ans$dlogF_dshape <- dlogF
    ans$dlogS_dshape <- dlogS
    ratio_gradient <- function(side) {
      den <- sum(side$a)
      num <- sum((0:K) * side$a)
      (colSums(side$jac * (0:K)) * den -
         num * colSums(side$jac)) / den^2
    }
    ans$dkink_a_dshape <- (1 - p) * ratio_gradient(spec$left) +
      p * ratio_gradient(spec$right)
    ans$da_dshape <- ans$dkink_a_dshape
  }
  ans
}

eal_density <- function(e, p, shape = eal_shape_init(K), K = 3L, log = FALSE) {
  z <- eal_terms(e, p, shape, K, derivatives = FALSE)$logg
  if (log) z else exp(z)
}

eal_cdf <- function(e, p, shape = eal_shape_init(K), K = 3L,
                    lower.tail = TRUE, log.p = FALSE) {
  z <- eal_terms(e, p, shape, K, derivatives = FALSE)
  v <- if (lower.tail) z$logF else z$logS
  if (log.p) v else exp(v)
}

eal_quantile <- function(u, p, shape = eal_shape_init(K), K = 3L) {
  if (anyNA(u) || any(u < 0 | u > 1)) stop("u must be in [0,1]")
  spec <- if (is.list(shape)) shape else eal_shape(shape, K)
  vapply(u, function(prob) {
    if (prob == 0) return(-Inf)
    if (prob == 1) return(Inf)
    if (abs(prob - p) < .Machine$double.eps) return(0)
    lo <- -1
    hi <- 1
    if (prob < p) {
      target <- log(prob)
      fun <- function(x) eal_cdf(x, p, spec, K, log.p = TRUE) - target
      while (fun(lo) > 0) lo <- lo * 2
    } else {
      target <- log1p(-prob)
      fun <- function(x) eal_cdf(x, p, spec, K, lower.tail = FALSE,
                                 log.p = TRUE) - target
      while (fun(hi) > 0) hi <- hi * 2
    }
    uniroot(fun, c(lo, hi), tol = 1e-10)$root
  }, numeric(1))
}


