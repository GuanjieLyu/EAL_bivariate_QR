# Quantile-centred EAL copula optimization; requires the density module.
# Here p is a fixed fitted anchor; other quantiles are derived from its density.

eal_clayton_terms <- function(logu, logv, theta) {
  aa <- -theta * logu
  bb <- -theta * logv
  mm <- pmax(aa, bb)
  logA <- mm + log(exp(aa - mm) + exp(bb - mm) - exp(-mm))
  wu <- exp(aa - logA)
  wv <- exp(bb - logA)
  list(logc = log1p(theta) - (theta + 1) * (logu + logv) -
         (2 + 1 / theta) * logA,
       dlu = -(theta + 1) + (2 * theta + 1) * wu,
       dlv = -(theta + 1) + (2 * theta + 1) * wv,
       dlogtheta = theta * (1 / (1 + theta) - logu - logv +
         logA / theta^2 - (2 + 1 / theta) * (-logu * wu - logv * wv)))
}

eal_gaussian_terms <- function(t1, t2, rho, derivatives = TRUE) {
  # Normal scores are formed from the smaller represented log tail. Using
  # logF/logS directly avoids rounded CDFs of 0 or 1 and requires no clipping.
  stopifnot(length(rho) == 1L, is.finite(rho), abs(rho) < 1,
            length(t1$logF) == length(t2$logF))
  normal_score <- function(t) {
    left <- t$logF <= t$logS
    z <- numeric(length(left))
    z[left] <- qnorm(t$logF[left], log.p = TRUE)
    z[!left] <- qnorm(t$logS[!left], lower.tail = FALSE, log.p = TRUE)
    stopifnot(all(is.finite(z)))
    list(z = z, logphi = dnorm(z, log = TRUE), left = left)
  }
  a <- normal_score(t1); b <- normal_score(t2)
  plus <- (a$z + b$z) / sqrt(2)
  minus <- (a$z - b$z) / sqrt(2)
  den <- (1 - rho) * (1 + rho)
  # Orthogonal-coordinate expression remains stable close to either bound.
  logc <- -.5 * log(den) + .5 * rho *
    (plus^2 / (1 + rho) - minus^2 / (1 - rho))
  ans <- list(logc = logc, normal_scores = cbind(a$z, b$z))
  if (!derivatives) return(ans)
  gz1 <- rho * (b$z - rho * a$z) / den
  gz2 <- rho * (a$z - rho * b$z) / den
  # logdensity is the exact CDF derivative, even during computational
  # continuation when evaluate() temporarily smooths only the logg alias.
  residual_score <- function(t, s, gz) gz * exp(t$logdensity - s$logphi)
  shape_score <- function(t, s, gz) {
    out <- matrix(0, length(gz), ncol(t$dlogF_dshape))
    ii <- which(s$left)
    if (length(ii)) out[ii, ] <- (gz[ii] * exp(t$logF[ii] - s$logphi[ii])) *
      t$dlogF_dshape[ii, , drop = FALSE]
    ii <- which(!s$left)
    if (length(ii)) out[ii, ] <- (-gz[ii] * exp(t$logS[ii] - s$logphi[ii])) *
      t$dlogS_dshape[ii, , drop = FALSE]
    out
  }
  ans$de <- cbind(residual_score(t1, a, gz1), residual_score(t2, b, gz2))
  ans$dshape <- list(shape_score(t1, a, gz1), shape_score(t2, b, gz2))
  # Derivative with respect to delta, not rho: d rho / d delta = 1-rho^2.
  ans$ddelta <- rho + .5 * ((1 - rho) / (1 + rho) * plus^2 -
    (1 + rho) / (1 - rho) * minus^2)
  ans
}

# An explicit two-element list represents distinct marginal design matrices.
# The common-design matrix branch preserves its established arithmetic order.
eal_design_list <- function(X) is.list(X) && !is.data.frame(X)
eal_margin_design <- function(X, j) if (eal_design_list(X)) X[[j]] else X
eal_margin_beta <- function(beta, j) if (is.list(beta)) beta[[j]] else beta[, j]
eal_beta_rows <- function(d, j) {
  if (length(d) == 1L) (j - 1L) * d + seq_len(d) else
    (if (j == 1L) 0L else d[1L]) + seq_len(d[j])
}
eal_margin_dimension <- function(d, j) if (length(d) == 1L) d else d[j]
eal_beta_from_vector <- function(value, d) {
  if (length(d) == 1L) matrix(value, d, 2L) else
    lapply(seq_len(2L), function(j) value[eal_beta_rows(d, j)])
}
eal_location <- function(X, beta) {
  if (!eal_design_list(X)) X %*% beta else
    cbind(drop(X[[1L]] %*% beta[[1L]]), drop(X[[2L]] %*% beta[[2L]]))
}
eal_parameter_location <- function(problem, parameter) {
  eal_location(problem$X, eal_beta_from_vector(parameter[problem$idx_beta], problem$d))
}

eal_problem <- function(X, Y, P, beta_init, sigma_init, p, degree = 3L,
                        copula = c("clayton", "independence", "gaussian", "student_t", "frank", "gumbel"),
                        init = NULL, control = list()) {
  copula <- match.arg(copula)
  distinct <- eal_design_list(X)
  if (distinct) {
    stopifnot(length(X) == 2L,
      all(vapply(X, function(x) is.matrix(x) && is.numeric(x) &&
        nrow(x) > 0L && ncol(x) > 0L && all(is.finite(x)), logical(1L))))
    n <- nrow(X[[1L]])
    d <- unname(vapply(X, ncol, integer(1L)))
    stopifnot(nrow(X[[2L]]) == n, is.list(beta_init), length(beta_init) == 2L,
      all(vapply(seq_len(2L), function(j) is.numeric(beta_init[[j]]) &&
        is.null(dim(beta_init[[j]])) && length(beta_init[[j]]) == d[j] &&
        all(is.finite(beta_init[[j]])), logical(1L))), length(P) == 2L,
      all(vapply(seq_len(2L), function(j) is.matrix(P[[j]]) &&
        is.numeric(P[[j]]) && identical(dim(P[[j]]), c(d[j], d[j])) &&
        all(is.finite(P[[j]])), logical(1L))))
  } else {
    X <- as.matrix(X)
    n <- nrow(X)
    d <- ncol(X)
  }
  Y <- as.matrix(Y)
  degree <- as.integer(degree)
  k <- length(eal_shape_init(degree))
  stopifnot(nrow(Y) == n, ncol(Y) == 2L, length(P) == 2L,
            distinct || all(dim(beta_init) == c(d, 2L)), length(sigma_init) == 2L,
            distinct || all(is.finite(X)), all(is.finite(Y)), all(sigma_init > 0),
            length(p) == 1L, p > 0, p < 1, degree >= 1L)
  ctl <- modifyList(list(theta_init = NULL, shape_bound = 8,
                         theta_bounds = c(.005, 30), rho_bounds = c(-.995, .995)), control)
  tail_score_copula <- copula %in% c("gaussian","student_t","frank","gumbel")
  if(copula=="student_t")stopifnot(length(ctl$df)==1L,is.finite(ctl$df),ctl$df>0)
  if(copula=="frank") {
    if(is.null(ctl$frank_bounds))ctl$frank_bounds <- c(-30,30)
    stopifnot(length(ctl$frank_bounds)==2L,all(is.finite(ctl$frank_bounds)),
      ctl$frank_bounds[1L]<ctl$frank_bounds[2L])
  }
  if(copula=="gumbel") {
    if(is.null(ctl$gumbel_bounds))ctl$gumbel_bounds <- c(1+exp(-17),30)
    stopifnot(length(ctl$gumbel_bounds)==2L,all(is.finite(ctl$gumbel_bounds)),
      ctl$gumbel_bounds[1L]>1,ctl$gumbel_bounds[1L]<ctl$gumbel_bounds[2L])
  }
  if (copula == "clayton") stopifnot(length(ctl$theta_bounds) == 2L,
    all(is.finite(ctl$theta_bounds)), ctl$theta_bounds[1L] > 0,
    ctl$theta_bounds[1L] < ctl$theta_bounds[2L])
  if (copula %in% c("gaussian","student_t")) stopifnot(length(ctl$rho_bounds) == 2L,
    all(is.finite(ctl$rho_bounds)), ctl$rho_bounds[1L] > -1,
    ctl$rho_bounds[2L] < 1, ctl$rho_bounds[1L] < ctl$rho_bounds[2L])
  if (distinct) {
    R <- lapply(seq_len(2L), function(j) chol(crossprod(X[[j]]) / n + diag(1e-9, d[j])))
    Rinv <- lapply(seq_len(2L), function(j) backsolve(R[[j]], diag(d[j])))
    XX <- lapply(seq_len(2L), function(j) X[[j]] %*% Rinv[[j]])
    PP <- lapply(seq_len(2L), function(j)
      crossprod(Rinv[[j]], P[[j]] %*% Rinv[[j]]))
    beta0 <- lapply(beta_init, as.numeric)
  } else {
    R <- chol(crossprod(X) / n + diag(1e-9, d))
    Rinv <- backsolve(R, diag(d))
    XX <- X %*% Rinv
    PP <- lapply(P, function(x) crossprod(Rinv, as.matrix(x) %*% Rinv))
    beta0 <- as.matrix(beta_init)
  }
  sigma0 <- as.numeric(sigma_init)
  shape0 <- matrix(rep(eal_shape_init(degree), 2L), k, 2L)
  theta0 <- ctl$theta_init
  if (!is.null(init)) {
    stopifnot(init$degree == degree, abs(init$p - p) < 1e-12)
    beta0 <- init$beta
    sigma0 <- init$sigma
    shape0 <- init$shape
    if (copula %in% c("gaussian","student_t","frank")) {
      if (is.null(theta0) && length(init$theta) == 1L && is.finite(init$theta)) theta0 <- init$theta
    } else if (is.null(theta0) && init$theta > 0) theta0 <- init$theta
  }
  if (distinct) stopifnot(is.list(beta0), length(beta0) == 2L,
    all(vapply(seq_len(2L), function(j) is.numeric(beta0[[j]]) &&
      is.null(dim(beta0[[j]])) && length(beta0[[j]]) == d[j] &&
      all(is.finite(beta0[[j]])), logical(1L))))
  if (copula == "clayton" && (is.null(theta0) || !is.finite(theta0))) {
    residual <- Y - eal_location(X, beta0)
    kt <- suppressWarnings(cor(residual[, 1L], residual[, 2L], method = "kendall"))
    kt <- min(.88, max(.025, if (is.finite(kt)) kt else .25))
    theta0 <- 2 * kt / (1 - kt)
  }
  if (copula %in% c("gaussian","student_t") && (is.null(theta0) || !is.finite(theta0))) {
    residual <- Y - eal_location(X, beta0)
    kt <- suppressWarnings(cor(residual[, 1L], residual[, 2L], method = "kendall"))
    theta0 <- sin(pi * (if (is.finite(kt)) kt else 0) / 2)
  }
  if(copula%in%c("frank","gumbel")&&(is.null(theta0)||!is.finite(theta0))) {
    residual <- Y-eal_location(X,beta0)
    kt <- suppressWarnings(cor(residual[,1L],residual[,2L],method="kendall"))
    if(!is.finite(kt))kt <- 0
    # A deterministic empirical-dependence start, not a fitting restriction.
    theta0 <- if(copula=="frank")9*kt else 1/(1-min(.95,max(.025,kt)))
  }
  nb <- if (distinct) sum(d) else 2L * d
  ib <- seq_len(nb)
  isc <- nb + seq_len(2L)
  ish <- nb + 2L + seq_len(2L * k)
  ith <- if (copula != "independence") max(ish) + 1L else integer()
  alpha0 <- if (distinct) unlist(lapply(seq_len(2L), function(j)
    as.vector(R[[j]] %*% beta0[[j]])), use.names = FALSE) else as.vector(R %*% beta0)
  par <- c(alpha0, log(sigma0), as.vector(shape0))
  lower <- c(rep(-Inf, nb), rep(log(1e-5), 2L), rep(-ctl$shape_bound, 2L * k))
  upper <- c(rep(Inf, nb), rep(log(1e3), 2L), rep(ctl$shape_bound, 2L * k))
  if (copula == "clayton") {
    par <- c(par, log(min(ctl$theta_bounds[2L], max(ctl$theta_bounds[1L], theta0))))
    lower <- c(lower, log(ctl$theta_bounds[1L]))
    upper <- c(upper, log(ctl$theta_bounds[2L]))
  } else if (copula %in% c("gaussian","student_t")) {
    # These are explicit numerical search bounds, not a scaled-tanh link.
    par <- c(par, atanh(min(ctl$rho_bounds[2L], max(ctl$rho_bounds[1L], theta0))))
    lower <- c(lower, atanh(ctl$rho_bounds[1L]))
    upper <- c(upper, atanh(ctl$rho_bounds[2L]))
  } else if(copula=="frank") {
    par <- c(par,min(ctl$frank_bounds[2L],max(ctl$frank_bounds[1L],theta0)))
    lower <- c(lower,ctl$frank_bounds[1L]); upper <- c(upper,ctl$frank_bounds[2L])
  } else if(copula=="gumbel") {
    par <- c(par,log(min(ctl$gumbel_bounds[2L],max(ctl$gumbel_bounds[1L],theta0))-1))
    lower <- c(lower,log(ctl$gumbel_bounds[1L]-1)); upper <- c(upper,log(ctl$gumbel_bounds[2L]-1))
  }
  if(any(par<lower|par>upper))par <- pmin(upper,pmax(lower,par))
  unpack <- function(par) {
    alpha <- eal_beta_from_vector(par[ib], d)
    beta <- if (distinct) lapply(seq_len(2L), function(j)
      as.vector(Rinv[[j]] %*% alpha[[j]])) else Rinv %*% alpha
    result <- list(alpha = alpha, beta = beta, sigma = exp(par[isc]),
         shape = matrix(par[ish], k, 2L), degree = degree, p = p,
         theta = if (copula %in% c("gaussian","student_t")) tanh(par[ith]) else
           if(copula=="frank")par[ith] else if(copula=="gumbel")1+exp(par[ith]) else
           if (length(ith)) exp(par[ith]) else 0)
    if(copula=="student_t")result$df <- ctl$df
    result
  }
  cache_par <- NULL
  cache_value <- NULL
  cache_epsilon <- NULL
  evaluate <- function(par, gradient = TRUE, smooth_epsilon = 0) {
    if (!is.null(cache_par) && identical(par, cache_par) &&
        identical(smooth_epsilon, cache_epsilon) &&
        (!gradient || !is.null(cache_value$gradient))) return(cache_value)
    pp <- unpack(par)
    z <- sweep(Y - eal_location(XX, pp$alpha), 2L, pp$sigma, "/")
    tt <- lapply(seq_len(2L), function(j)
      eal_terms(z[, j], p, pp$shape[, j], degree, derivatives = gradient))
    if (smooth_epsilon > 0) for (j in seq_len(2L)) {
      # Computational continuation only: smooth the log-density cusp while
      # retaining the exact copula CDF.  All final reported likelihoods and
      # stationarity checks use smooth_epsilon=0 and the original EAL density.
      rad <- sqrt(z[, j]^2 + smooth_epsilon^2)
      # Stable evaluation avoids cancellation outside the narrow cusp region.
      correction <- smooth_epsilon^2 / (rad + abs(z[, j]))
      aa <- tt[[j]]$kink_a
      tt[[j]]$logg <- tt[[j]]$logg - aa * correction
      tt[[j]]$hz <- tt[[j]]$hz - aa *
        (z[, j] / rad - ifelse(z[, j] < 0, -1, 1))
      if (gradient) tt[[j]]$dlogg_dshape <- tt[[j]]$dlogg_dshape -
        outer(correction, tt[[j]]$da_dshape)
    }
    cp <- if (copula == "gaussian") eal_gaussian_terms(tt[[1]], tt[[2]], pp$theta, gradient) else
      if (copula == "clayton") eal_clayton_terms(tt[[1]]$logF, tt[[2]]$logF, pp$theta) else
      if(tail_score_copula)eal_additional_copula_terms(tt[[1]],tt[[2]],pp$theta,copula,ctl$df,gradient) else
      list(logc = rep(0, n), dlu = rep(0, n), dlv = rep(0, n), dlogtheta = rep(0, n))
    ll <- sum(tt[[1]]$logg + tt[[2]]$logg + cp$logc) - n * sum(log(pp$sigma))
    pen <- if (distinct) .5 * sum(vapply(seq_len(2L), function(j)
      sum(pp$alpha[[j]] * (PP[[j]] %*% pp$alpha[[j]])), numeric(1L))) else
      .5 * sum(vapply(seq_len(2L), function(j)
        sum(pp$alpha[, j] * (PP[[j]] %*% pp$alpha[, j])), numeric(1L)))
    value <- (-ll + pen) / n
    grad <- NULL
    if (gradient) {
      hz <- cbind(tt[[1]]$hz, tt[[2]]$hz)
      combined <- hz + if (tail_score_copula) cp$de else
        cbind(cp$dlu * tt[[1]]$dlogF_de, cp$dlv * tt[[2]]$dlogF_de)
      if (distinct) {
        gb <- unlist(lapply(seq_len(2L), function(j)
          as.vector(crossprod(XX[[j]], combined[, j] / pp$sigma[j]) +
            PP[[j]] %*% pp$alpha[[j]])), use.names = FALSE)
      } else {
        gb <- crossprod(XX, sweep(combined, 2L, pp$sigma, "/"))
        for (j in seq_len(2L)) gb[, j] <- gb[, j] + PP[[j]] %*% pp$alpha[, j]
      }
      gs <- colSums(1 + combined * z)
      gshape <- if (tail_score_copula)
        cbind(-colSums(tt[[1]]$dlogg_dshape + cp$dshape[[1L]]),
              -colSums(tt[[2]]$dlogg_dshape + cp$dshape[[2L]])) else
        cbind(-colSums(tt[[1]]$dlogg_dshape + cp$dlu * tt[[1]]$dlogF_dshape),
              -colSums(tt[[2]]$dlogg_dshape + cp$dlv * tt[[2]]$dlogF_dshape))
      grad <- c(as.vector(gb), gs, as.vector(gshape)) / n
      if (length(ith)) grad <- c(grad, -mean(if (tail_score_copula) cp$ddelta else cp$dlogtheta))
    }
    result <- list(value = value, gradient = grad, loglik = ll, penalty = pen,
                   residual = z, terms = tt)
    cache_par <<- par
    cache_value <<- result
    cache_epsilon <<- smooth_epsilon
    result
  }
  project_gradient <- function(par, grad) {
    grad[par <= lower + 1e-7 & grad > 0] <- 0
    grad[par >= upper - 1e-7 & grad < 0] <- 0
    grad
  }
  # At exactly fitted observations the continuous EAL log density can have a
  # cusp.  A bounded subgradient is the correct first-order criterion there.
  stationarity <- function(par, knot_tolerance = 1e-7) {
    ee <- evaluate(par, TRUE)
    pp <- unpack(par)
    gg <- project_gradient(par, ee$gradient)
    raw <- max(abs(gg))
    if (!all(is.finite(gg))) return(list(raw = Inf, kkt = Inf, knots = 0L))
    base <- gg
    cols <- list()
    knot_margin <- knot_observation <- integer()
    knots <- wrong_way_knots <- 0L
    for (j in seq_len(2L)) {
      ids <- which(abs(ee$residual[, j]) <= knot_tolerance)
      if (!length(ids)) next
      ends <- c(ee$terms[[j]]$hz_left0, ee$terms[[j]]$hz_right0)
      if (ends[1L] < ends[2L] - 1e-8) wrong_way_knots <- wrong_way_knots + length(ids)
      rows <- eal_beta_rows(d, j)
      for (ii in ids) {
        v <- numeric(length(par))
        atom <- eal_margin_design(XX, j)[ii, ] / (n * pp$sigma[j])
        base[rows] <- base[rows] + atom * (ends[1L] - ee$terms[[j]]$hz[ii])
        v[rows] <- atom * (ends[2L] - ends[1L])
        cols[[length(cols) + 1L]] <- v
        knot_margin <- c(knot_margin, j)
        knot_observation <- c(knot_observation, ii)
        knots <- knots + 1L
      }
    }
    if (!length(cols)) return(list(raw = raw, kkt = raw, knots = 0L,
                                   gradient = gg, base = gg,
                                   subgradient_matrix = matrix(0, length(par), 0L)))
    V <- do.call(cbind, cols)
    fn <- function(w) sum((base + V %*% w)^2)
    gr <- function(w) as.vector(2 * crossprod(V, base + V %*% w))
    w0 <- tryCatch(as.vector(qr.coef(qr(V), -base)), error = function(e) rep(.5, ncol(V)))
    w0[!is.finite(w0)] <- .5
    oo <- optim(pmax(0, pmin(1, w0)), fn, gr, method = "L-BFGS-B",
                 lower = 0, upper = 1,
                 control = list(maxit = 500L, factr = 1, pgtol = 1e-12))
    adjusted <- as.vector(base + V %*% oo$par)
    list(raw = raw, kkt = if (wrong_way_knots) Inf else max(abs(adjusted)), knots = knots,
         wrong_way_knots = wrong_way_knots,
         weights = oo$par, unbounded_weights = w0, knot_margin = knot_margin,
         knot_observation = knot_observation, gradient = adjusted, base = base,
         subgradient_matrix = V)
  }
  list(par = par, lower = lower, upper = upper, evaluate = evaluate,
       unpack = unpack, project_gradient = project_gradient,
       stationarity = stationarity, n = n, d = d, shape_dimension = k,
       idx_beta = ib, idx_scale = isc, idx_shape = ish, idx_theta = ith,
       X = XX, Y = Y, Rinv = Rinv, copula = copula,
       dependence_link = if (copula %in% c("gaussian","student_t")) "rho=tanh(delta)" else
         if (copula == "clayton") "theta=exp(delta)" else
         if(copula=="frank")"theta=delta" else
         if(copula=="gumbel")"theta=1+exp(delta)" else "independence",
       dependence_bounds = if (copula %in% c("gaussian","student_t")) ctl$rho_bounds else
         if (copula == "clayton") ctl$theta_bounds else
         if(copula=="frank")ctl$frank_bounds else
         if(copula=="gumbel")ctl$gumbel_bounds else c(0, 0))
}

# Exact-objective descent using the minimum-norm EAL subgradient.  Interior
# dual weights define quantile constraints that should remain active; weights
# at an endpoint allow the corresponding constraint to be released.  This
# avoids fixing an incorrect active set indefinitely after continuation.
eal_exact_subgradient_polish <- function(problem, par, control = list()) {
  ctl <- modifyList(list(maxit = 180L, strict_gradient_tolerance = 1e-5,
                         knot_tolerance = 1e-7, line_maxit = 28L,
                         armijo = 1e-4, minimum_step = 1e-12), control)
  count <- 0L
  value <- function(x) { count <<- count + 1L; problem$evaluate(x, FALSE)$value }
  current <- value(par)
  history <- list()
  for (iteration in seq_len(ctl$maxit)) {
    state <- problem$stationarity(par, ctl$knot_tolerance)
    history[[iteration]] <- c(objective = current, kkt = state$kkt, knots = state$knots)
    if (is.finite(state$kkt) && state$kkt <= ctl$strict_gradient_tolerance) break
    ee <- problem$evaluate(par, TRUE)
    pp <- problem$unpack(par)
    metric <- rep(1, length(par))
    metric[problem$idx_beta] <- if (length(problem$d) == 1L)
      rep(pmax(.0025, pmin(4, pp$sigma^2)), each = problem$d) else
      rep(pmax(.0025, pmin(4, pp$sigma^2)), times = problem$d)
    metric[problem$idx_shape] <- .5
    metric[problem$idx_theta] <- .5
    base <- state$base
    if (is.null(base)) base <- problem$project_gradient(par, ee$gradient)
    V <- state$subgradient_matrix
    weights <- numeric()
    if (!is.null(V) && ncol(V)) {
      B <- sqrt(metric) * V
      b <- sqrt(metric) * base
      w0 <- tryCatch(as.vector(qr.coef(qr(B), -b)),
                     error = function(e) rep(.5, ncol(V)))
      w0[!is.finite(w0)] <- .5
      oo <- optim(pmax(0, pmin(1, w0)),
                   function(w) sum((b + B %*% w)^2),
                   function(w) as.vector(2 * crossprod(B, b + B %*% w)),
                   method = "L-BFGS-B", lower = 0, upper = 1,
                   control = list(maxit = 600L, factr = 0, pgtol = 1e-13))
      weights <- oo$par
      gg <- as.vector(base + V %*% weights)
    } else gg <- base
    direction <- -metric * gg
    # Enforce numerical tangency to interior active constraints; otherwise
    # tiny least-squares errors can accumulate and discard correct knots.
    if (length(weights)) {
      interior <- which(weights > 1e-6 & weights < 1 - 1e-6)
      if (length(interior)) {
        qv <- qr(V[, interior, drop = FALSE], tol = 1e-9)
        if (qv$rank > 0L) {
          QQ <- qr.Q(qv)[, seq_len(qv$rank), drop = FALSE]
          direction <- direction - drop(QQ %*% crossprod(QQ, direction))
        }
      }
    }
    direction[par <= problem$lower + 1e-10 & direction < 0] <- 0
    direction[par >= problem$upper - 1e-10 & direction > 0] <- 0
    norm <- sqrt(sum(direction^2 / metric))
    candidates <- list()
    if (is.finite(norm) && norm > 1e-14) {
      direction <- direction / norm
      # The maximum directional derivative over the subgradient box is the
      # exact one-sided derivative at positive cusps, not an arbitrary score.
      slope <- sum(base * direction)
      if (!is.null(V) && ncol(V)) slope <- slope + sum(pmax(0, crossprod(V, direction)))
      if (is.finite(slope) && slope < -1e-14) {
        step <- 1
        for (back in seq_len(ctl$line_maxit)) {
          trial <- pmax(problem$lower, pmin(problem$upper, par + step * direction))
          trial_value <- value(trial)
          if (is.finite(trial_value) && trial_value <= current + ctl$armijo * step * slope) {
            candidates[[1L]] <- list(par = trial, value = trial_value)
            break
          }
          step <- step / 2
          if (step < ctl$minimum_step) break
        }
        if (length(candidates)) {
          # Inspect nearby quantile crossings exactly, so a line search can
          # land on a new active observation instead of repeatedly crossing it.
          change <- eal_parameter_location(problem, direction)
          residual_y <- sweep(ee$residual, 2L, pp$sigma, "*")
          crossings <- as.vector(residual_y / change)
          crossings <- sort(unique(crossings[is.finite(crossings) & crossings > 1e-10 &
                                               crossings <= 2 * step]))
          if (length(crossings) > 8L)
            crossings <- crossings[unique(round(seq(1, length(crossings), length.out = 8L)))]
          for (st in crossings) {
            trial <- pmax(problem$lower, pmin(problem$upper, par + st * direction))
            fv <- value(trial)
            if (is.finite(fv) && fv < candidates[[1L]]$value)
              candidates[[1L]] <- list(par = trial, value = fv)
          }
        }
      }
    }
    # A negative log-density cusp has the wrong orientation to be accepted as
    # a quantile knot.  Test both exact coefficient directions to escape it.
    if (!length(candidates) || isTRUE(state$wrong_way_knots > 0L)) {
      for (j in seq_len(2L)) {
        ids <- which(abs(ee$residual[, j]) <= ctl$knot_tolerance)
        if (!length(ids) || ee$terms[[j]]$kink_a >= 0) next
        dr <- numeric(length(par))
        rows <- eal_beta_rows(problem$d, j)
        dr[rows] <- eal_margin_design(problem$X, j)[ids[1L], ]
        dr <- dr / sqrt(sum(dr^2))
        for (st in c(1e-6, 1e-5, 1e-4, .001)) for (sgn in c(-1, 1)) {
          trial <- par + sgn * st * dr
          fv <- value(trial)
          if (is.finite(fv) && fv < current - 1e-12 &&
              (!length(candidates) || fv < candidates[[1L]]$value))
            candidates[[1L]] <- list(par = trial, value = fv)
        }
      }
    }
    if (!length(candidates)) break
    par <- candidates[[1L]]$par
    current <- candidates[[1L]]$value
  }
  final <- problem$stationarity(par, ctl$knot_tolerance)
  list(par = par, value = current, convergence = if (is.finite(final$kkt) &&
         final$kkt <= ctl$strict_gradient_tolerance) 0L else 1L,
       message = "Exact minimum-norm subgradient polishing",
       counts = c("function" = count, gradient = length(history)),
       history = do.call(rbind, history), stationarity = final$kkt)
}

eal_recovery_acceptance <- function(problem, par, control = list()) {
  ctl <- modifyList(list(strict_gradient_tolerance = 1e-5, knot_tolerance = 1e-7), control)
  ee <- problem$evaluate(par, TRUE)
  state <- problem$stationarity(par, ctl$knot_tolerance)
  strict_ok <- all(par>=problem$lower&par<=problem$upper) &&
    all(is.finite(ee$gradient)) && is.finite(ee$value) &&
    is.finite(state$kkt) && state$kkt <= ctl$strict_gradient_tolerance
  directional_check <- NA; improvement <- NA_real_; best_trial <- NULL
  if (strict_ok && state$knots > 0L) {
    # This is the unchanged production acceptance test, not a new tolerance.
    directions <- diag(length(par))[, problem$idx_beta, drop = FALSE]
    raw_direction <- problem$project_gradient(par, ee$gradient)
    if (sum(raw_direction^2) > 0)
      directions <- cbind(directions, raw_direction / sqrt(sum(raw_direction^2)))
    best_value <- Inf
    for (step in c(1e-6, 1e-5)) for (jj in seq_len(ncol(directions)))
      for (sgn in c(-1, 1)) {
        trial <- pmin(problem$upper, pmax(problem$lower,
          par + sgn * step * directions[, jj]))
        fv <- problem$evaluate(trial, FALSE)$value
        if (fv < best_value) { best_value <- fv; best_trial <- trial }
      }
    improvement <- ee$value - best_value
    directional_check <- improvement <= 1e-9
    strict_ok <- strict_ok && directional_check
  }
  list(strict_ok = strict_ok, directional_check = directional_check,
    max_directional_improvement = improvement, best_trial = best_trial,
    state = state, evaluation = ee)
}

# Failure-only active-face recovery.  Quantile hyperplanes are handled
# explicitly: a step stops at the next positive cusp, while negative cusps
# remain free to be crossed.  A smoothed Hessian is only a search metric;
# every line-search value, score, KKT test and acceptance check is exact.
recover_eal <- function(problem, par, control = list()) {
  ctl <- modifyList(list(recovery_maxit = 300L, recovery_hessian_epsilon = 1e-4,
    recovery_hessian_step = 1e-5, strict_gradient_tolerance = 1e-5,
    knot_tolerance = 1e-7, recovery_trace = FALSE), control)
  t0 <- proc.time()[3L]
  counts <- c('function' = 0L, gradient = 0L)
  ev <- function(x, grad = TRUE, eps = 0) {
    counts['function'] <<- counts['function'] + 1L
    if (grad) counts['gradient'] <<- counts['gradient'] + 1L
    problem$evaluate(x, grad, eps)
  }
  history <- list()
  candidates <- list()
  d <- problem$d; k <- length(par)
  omit_once <- matrix(FALSE, problem$n, 2L)
  for (iteration in seq_len(ctl$recovery_maxit)) {
    ee <- ev(par); pp <- problem$unpack(par)
    ss <- problem$stationarity(par, ctl$knot_tolerance)
    history[[iteration]] <- data.frame(iteration = iteration, objective = ee$value,
      kkt = ss$kkt, knots = ss$knots, step = NA_real_, slope = NA_real_,
      free = NA_integer_, message = '')
    candidates[[iteration]] <- list(par = par, value = ee$value,
      stationarity = ss$kkt, knots = ss$knots)
    if (isTRUE(ctl$recovery_trace)) cat(sprintf('recovery %d: %.12f KKT %.5g knots %d\n',
      iteration, ee$value, ss$kkt, ss$knots))
    if (is.finite(ss$kkt) && ss$kkt <= ctl$strict_gradient_tolerance) {
      accept <- eal_recovery_acceptance(problem, par, ctl)
      candidates[[iteration]]$strict_ok <- accept$strict_ok
      if (isTRUE(accept$strict_ok)) break
      if (!is.null(accept$best_trial)) {
        par <- accept$best_trial
        history[[iteration]]$message <- 'escape failed unchanged directional check'
        next
      }
    }
    if (isTRUE(ss$wrong_way_knots > 0L)) {
      # At a negative cusp the Clarke upper derivative is not the actual
      # one-sided descent derivative. Reuse the exact two-sided escape probes
      # instead of mistaking their subgradient hull for a local minimum.
      escape <- eal_exact_subgradient_polish(problem, par,
        list(maxit = 1L, strict_gradient_tolerance = ctl$strict_gradient_tolerance,
             knot_tolerance = ctl$knot_tolerance))
      counts <- counts + escape$counts
      history[[iteration]]$message <- 'exact negative-cusp escape'
      if (is.finite(escape$value) && escape$value < ee$value) {
        par <- escape$par
        next
      }
      break
    }
    # Independent active rows define a linear face in coefficient space.
    N <- matrix(0, k, 0L)
    active <- matrix(FALSE, problem$n, 2L)
    for (j in seq_len(2L)) {
      ids <- integer()
      if (ee$terms[[j]]$kink_a >= 0)
        ids <- which(abs(ee$residual[, j]) <= ctl$knot_tolerance & !omit_once[, j])
      rows <- eal_beta_rows(d, j)
      dj <- eal_margin_dimension(d, j)
      Xj <- eal_margin_design(problem$X, j)
      if (length(ids)) {
        A <- Xj[ids, , drop = FALSE]
        qa <- qr(t(A), tol = 1e-10)
        ids <- ids[qa$pivot[seq_len(qa$rank)]]
        A <- Xj[ids, , drop = FALSE]
        qa <- qr(t(A), tol = 1e-10)
        Q <- qr.Q(qa, complete = TRUE); nr <- qa$rank
        # Correct only represented knots, removing accumulated roundoff.
        rhs <- (problem$Y[ids, j] - drop(A %*% par[rows]))[qa$pivot]
        Rr <- qr.R(qa)[seq_len(nr), seq_len(nr), drop = FALSE]
        par[rows] <- par[rows] + drop(Q[, seq_len(nr), drop = FALSE] %*%
          forwardsolve(t(Rr), rhs))
        Nj <- if (nr < dj) Q[, (nr + 1L):dj, drop = FALSE] else matrix(0, dj, 0L)
        active[ids, j] <- TRUE
      } else Nj <- diag(dj)
      block <- matrix(0, k, ncol(Nj)); block[rows, ] <- Nj
      N <- cbind(N, block)
    }
    nuisance <- setdiff(seq_len(k), problem$idx_beta)
    N <- cbind(N, diag(k)[, nuisance, drop = FALSE])
    ee <- ev(par); ss <- problem$stationarity(par, ctl$knot_tolerance)
    base <- ss$base; V <- ss$subgradient_matrix
    adjusted <- if (!is.null(ss$gradient)) ss$gradient else ee$gradient
    gr <- drop(crossprod(N, adjusted))
    q <- ncol(N)
    history[[iteration]]$free <- q
    # First optimize the current face; only then release a single dual-
    # infeasible anchor. Releasing all endpoint weights before tangential
    # convergence discards good constraints and causes numerical cycling.
    had_release <- any(omit_once)
    omit_once[,] <- FALSE
    if (!had_release && length(ss$unbounded_weights) &&
        max(abs(gr)) <= max(1e-6, .05 * ss$kkt)) {
      violation <- pmax(-ss$unbounded_weights, ss$unbounded_weights - 1)
      bad <- which(is.finite(violation) & violation > 1e-6)
      if (length(bad)) {
        worst <- bad[which.max(violation[bad])]
        omit_once[ss$knot_observation[worst], ss$knot_margin[worst]] <- TRUE
        history[[iteration]]$message <- 'release one dual-infeasible anchor'
        next
      }
    }
    # Differentiate the smooth restriction to the current face without
    # crossing any other observation. This avoids spurious cusp curvature.
    # A computationally smoothed metric is a numerical fallback only when
    # a represented endpoint knot leaves no two-sided smooth neighbourhood.
    hh <- matrix(0, q, q)
    for (a in seq_len(q)) {
      h <- ctl$recovery_hessian_step
      dz <- eal_parameter_location(problem, N[, a])
      distance <- abs((problem$Y - eal_parameter_location(problem, par)) / dz)
      distance[active | !is.finite(distance) | abs(dz) < 1e-12] <- Inf
      h <- min(h, .2 * min(distance))
      eps <- 0
      if (h < 1e-9) { h <- ctl$recovery_hessian_step; eps <- ctl$recovery_hessian_epsilon }
      hh[, a] <- drop(crossprod(N,
        ev(par + h * N[, a], TRUE, eps)$gradient -
        ev(par - h * N[, a], TRUE, eps)$gradient)) / (2 * h)
    }
    hh <- (hh + t(hh)) / 2
    eh <- eigen(hh, symmetric = TRUE)
    floor <- max(1e-5, max(abs(eh$values)) * 1e-7)
    dr <- -drop(eh$vectors %*% (crossprod(eh$vectors, gr) / pmax(eh$values, floor)))
    direction <- drop(N %*% dr)
    direction[par <= problem$lower + 1e-10 & direction < 0] <- 0
    direction[par >= problem$upper - 1e-10 & direction > 0] <- 0
    exact_slope <- function(dir) sum(base * dir) +
      if (!is.null(V) && ncol(V)) sum(pmax(0, crossprod(V, dir))) else 0
    slope <- exact_slope(direction)
    if (!is.finite(slope) || slope >= -1e-15) {
      direction <- -drop(N %*% gr)
      slope <- exact_slope(direction)
    }
    norm <- sqrt(sum(direction^2))
    if (is.finite(norm) && norm > 2) { direction <- 2 * direction / norm; slope <- exact_slope(direction) }
    history[[iteration]]$slope <- slope
    if (!is.finite(slope) || slope >= -1e-15) {
      history[[iteration]]$message <- 'no exact descent direction'
      break
    }
    change <- eal_parameter_location(problem, direction)
    residual <- problem$Y - eal_parameter_location(problem, par)
    crossings <- residual / change
    for (j in seq_len(2L)) if (ee$terms[[j]]$kink_a < 0) crossings[, j] <- Inf
    crossings[active | !is.finite(crossings) | crossings <= 1e-10] <- Inf
    step <- min(1, crossings)
    # Parameter bounds remain exactly those of the original problem.
    bsteps <- c((problem$upper[direction > 0] - par[direction > 0]) / direction[direction > 0],
                (problem$lower[direction < 0] - par[direction < 0]) / direction[direction < 0])
    if (length(bsteps)) step <- min(step, bsteps[is.finite(bsteps) & bsteps >= 0])
    accepted <- FALSE
    for (back in seq_len(40L)) {
      trial <- pmax(problem$lower, pmin(problem$upper, par + step * direction))
      fv <- ev(trial, FALSE)$value
      if (is.finite(fv) && fv <= ee$value + 1e-4 * step * slope + 2e-15) {
        par <- trial; accepted <- TRUE; break
      }
      step <- step / 2
    }
    history[[iteration]]$step <- step
    history[[iteration]]$message <- if (accepted) 'exact face descent' else 'line search stopped'
    if (!accepted) break
  }
  final <- eal_recovery_acceptance(problem, par, ctl)
  candidates[[length(candidates) + 1L]] <- list(par = par,
    value = final$evaluation$value, stationarity = final$state$kkt,
    knots = final$state$knots, strict_ok = final$strict_ok)
  list(par = par, value = ev(par, FALSE)$value,
    convergence = if (isTRUE(final$strict_ok)) 0L else 1L,
    message = 'Failure-only exact active-face recovery', counts = counts,
    history = do.call(rbind, history), candidates = candidates,
    stationarity = final$state$kkt, strict_ok = final$strict_ok,
    acceptance = final, elapsed = proc.time()[3L] - t0)
}

# Recovery entry point; an already certified fit is returned unchanged.
# Responses, initial values and penalties are retained during recovery.
eal_recover_fit <- function(fit, X, Y, P, beta_init, sigma_init, p, degree = 3L,
                            copula = 'gaussian', control = list()) {
  if (isTRUE(fit$strict_ok)) return(fit)
  if (!(copula %in% c('gaussian', 'clayton','student_t','frank','gumbel')) ||
      !(fit$copula %in% c('gaussian', 'clayton','student_t','frank','gumbel'))) return(fit)
  wrapper_start <- proc.time()[3L]
  stopifnot(identical(copula, fit$copula), is.numeric(fit$parameter),
    degree == fit$degree, abs(p - fit$p) < 1e-12)
  ctl <- modifyList(list(strict_gradient_tolerance = fit$strict_gradient_tolerance,
    knot_tolerance = fit$knot_tolerance), control)
  problem <- eal_problem(X, Y, P, beta_init, sigma_init, p, degree, copula,
    control = ctl)
  recovery <- recover_eal(problem, fit$parameter, ctl)
  candidates <- recovery$candidates
  candidates <- c(list(list(par = fit$parameter, value = fit$objective,
    stationarity = fit$stationarity, strict_ok = FALSE)), candidates)
  eligible <- which(vapply(candidates, function(x) isTRUE(x$strict_ok), logical(1L)))
  values <- vapply(candidates, function(x) x$value, numeric(1L))
  idx <- if (length(eligible)) eligible[which.min(values[eligible])] else which.min(values)
  selected <- candidates[[idx]]
  check <- eal_recovery_acceptance(problem, selected$par, ctl)
  ee <- check$evaluation; ss <- check$state
  out <- fit
  pp <- problem$unpack(selected$par); pp$alpha <- NULL
  for (nm in names(pp)) out[[nm]] <- pp[[nm]]
  out$parameter <- selected$par
  out$strict_ok <- check$strict_ok
  out$stationarity <- ss$kkt
  out$quantile_knots <- ss$knots
  out$max_abs_gradient <- max(abs(ee$gradient))
  out$max_abs_projected_gradient <- ss$raw
  out$directional_check <- check$directional_check
  out$max_directional_improvement <- check$max_directional_improvement
  out$convergence <- if (isTRUE(out$strict_ok)) 0L else 1L
  out$message <- recovery$message
  out$convergence_basis <- if (out$strict_ok && ss$knots > 0L)
    'bounded_subgradient_KKT' else 'projected_gradient'
  out$objective <- ee$value; out$loglik <- ee$loglik; out$penalty <- ee$penalty
  out$best_candidate_objective <- min(fit$best_candidate_objective, values)
  out$lower_unconverged_objective_gap <- max(0, ee$value - out$best_candidate_objective)
  out$counts <- fit$counts + recovery$counts
  out$elapsed <- fit$elapsed + recovery$elapsed
  out$boundary <- which(abs(selected$par - problem$lower) < 1e-5 |
    abs(selected$par - problem$upper) < 1e-5)
  out$dependence_boundary <- any(problem$idx_theta %in% out$boundary)
  out$start_diagnostics <- rbind(fit$start_diagnostics, data.frame(
    label = 'failure_only_exact_face_recovery', objective = ee$value,
    convergence = out$convergence, projected_gradient = ss$raw,
    kkt_stationarity = ss$kkt, knots = ss$knots,
    function_evaluations = unname(recovery$counts['function']),
    message = recovery$message, stringsAsFactors = FALSE))
  out$recovery_used <- TRUE
  out$recovery_diagnostics <- recovery$history
  out$recovery_candidates <- candidates
  out$recovery_selected_candidate <- idx
  # As with the initial optimizer counts, these count search requests and exclude
  # the separate KKT and final acceptance diagnostics. Wall time includes all.
  out$recovery_counts <- recovery$counts
  out$recovery_counts_scope <- 'search requests; excludes KKT and acceptance diagnostics'
  out$recovery_elapsed <- unname(proc.time()[3L] - wrapper_start)
  out$elapsed <- fit$elapsed + out$recovery_elapsed
  out$recovery_control <- ctl
  out$legacy_stationarity <- fit$stationarity
  out$legacy_objective <- fit$objective
  out
}

fit_eal <- function(X, Y, P, beta_init, sigma_init, p, degree = 3L,
                    copula = c("clayton", "independence", "gaussian","student_t","frank","gumbel"), init = NULL,
                    control = list()) {
  copula <- match.arg(copula)
  ctl <- modifyList(list(maxit = 700L, factr = 1000, pgtol = 2e-6,
                         trace = 0L, starts = 3L, perturbation = .08,
                         al_warm_start = TRUE, al_maxit = 150L,
                         retry = TRUE, retry_maxit = 500L,
                         continuation = TRUE,
                         continuation_epsilon = c(.003, .0001, 3e-6, 1e-7, 1e-8),
                         continuation_maxit = 400L,
                         active_polish = TRUE, active_tolerance = 1e-5,
                         active_polish_iterations = 10L,
                         exact_subgradient_rescue = TRUE,
                         exact_subgradient_iterations = 40L,
                         strict_gradient_tolerance = 1e-5,
                         knot_tolerance = 1e-7), control)
  problem <- eal_problem(X, Y, P, beta_init, sigma_init, p, degree, copula,
                         init, control)
  active_epsilon <- 0
  objective <- function(par) problem$evaluate(par, TRUE, active_epsilon)$value
  gradient <- function(par) problem$evaluate(par, TRUE, active_epsilon)$gradient
  start_time <- proc.time()[[3L]]
  diagnostics <- list()
  candidates <- list()
  count_total <- c("function" = 0L, gradient = 0L)
  safe_optim <- function(start, maxit = ctl$maxit, active = seq_along(start), factr = ctl$factr) {
    if(any(start<problem$lower|start>problem$upper))
      start <- pmin(problem$upper,pmax(problem$lower,start))
    fixed <- start
    expand <- function(x) { ans <- fixed; ans[active] <- x; ans }
    oo <- tryCatch(optim(start[active], function(x) objective(expand(x)),
                         function(x) gradient(expand(x))[active],
                         method = "L-BFGS-B", lower = problem$lower[active],
                         upper = problem$upper[active],
                         control = list(maxit = maxit, factr = factr,
                                        pgtol = ctl$pgtol, trace = ctl$trace)),
                   error = function(e) list(par = start[active], value = Inf,
                                            convergence = 999L, message = conditionMessage(e),
                                            counts = c("function" = 0L, gradient = 0L)))
    oo$par <- expand(oo$par)
    count_total <<- count_total + oo$counts
    oo
  }
  add_candidate <- function(oo, label) {
    if(!is.numeric(oo$par)||length(oo$par)!=length(problem$par)||
       any(!is.finite(oo$par))||any(oo$par<problem$lower|oo$par>problem$upper))
      return(invisible(list(raw=Inf,kkt=Inf,knots=0L)))
    ee <- tryCatch(problem$evaluate(oo$par, TRUE), error = function(e) NULL)
    ss <- if (is.null(ee)) list(raw = Inf, kkt = Inf, knots = 0L) else
      problem$stationarity(oo$par, ctl$knot_tolerance)
    if (!is.null(ee)) oo$value <- ee$value
    diagnostics[[length(diagnostics) + 1L]] <<- data.frame(
      label = label, objective = oo$value, convergence = oo$convergence,
      projected_gradient = ss$raw, kkt_stationarity = ss$kkt, knots = ss$knots,
      function_evaluations = unname(oo$counts["function"]),
      message = if (is.null(oo$message)) "" else oo$message,
      stringsAsFactors = FALSE)
    if (is.finite(oo$value)) candidates[[length(candidates) + 1L]] <<- oo
    invisible(ss)
  }
  base <- problem$par
  if (isTRUE(ctl$al_warm_start) && is.null(init)) {
    active <- setdiff(seq_along(base), problem$idx_shape)
    warm <- safe_optim(base, maxit = ctl$al_maxit, active = active)
    if (is.finite(warm$value) && warm$value <= objective(base)) base <- warm$par
    add_candidate(warm, "AL_warm_start")
  }
  shape_direction <- rep(sin(seq_len(problem$shape_dimension)), 2L)
  shape_direction[(problem$shape_dimension + 1L):(2L * problem$shape_dimension)] <-
    rev(shape_direction[seq_len(problem$shape_dimension)])
  for (ss in seq_len(ctl$starts)) {
    start <- base
    if (ss > 1L) start[problem$idx_shape] <- start[problem$idx_shape] +
      ifelse(ss %% 2L == 0L, 1, -1) * ctl$perturbation * ceiling((ss - 1L) / 2L) * shape_direction
    oo <- safe_optim(start)
    state <- add_candidate(oo, paste0("EAL_start_", ss))
    if (isTRUE(ctl$retry) && is.finite(oo$value) &&
        (oo$convergence != 0L || state$kkt > ctl$strict_gradient_tolerance)) {
      retry <- safe_optim(oo$par, maxit = ctl$retry_maxit, factr = min(100, ctl$factr))
      add_candidate(retry, paste0("EAL_start_", ss, "_retry"))
    }
  }
  if (!length(candidates)) stop("All EAL optimization candidates were non-finite.")
  oo <- candidates[[which.min(vapply(candidates, function(x) x$value, numeric(1L)))]]
  state <- problem$stationarity(oo$par, ctl$knot_tolerance)
  if (isTRUE(ctl$retry) && state$kkt > ctl$strict_gradient_tolerance) {
    port <- tryCatch(nlminb(oo$par, objective, gradient,
                            lower = problem$lower, upper = problem$upper,
                            control = list(iter.max = ctl$retry_maxit,
                                           eval.max = 3L * ctl$retry_maxit,
                                           rel.tol = 1e-11, x.tol = 1e-10)),
                     error = function(e) NULL)
    if (!is.null(port)) {
      port$value <- port$objective
      port$counts <- c("function" = unname(port$evaluations["function"]),
                       gradient = unname(port$evaluations["gradient"]))
      count_total <- count_total + port$counts
      add_candidate(port, "best_start_nlminb_polish")
      oo <- candidates[[which.min(vapply(candidates, function(x) x$value, numeric(1L)))]]
    }
  }
  state <- problem$stationarity(oo$par, ctl$knot_tolerance)
  if (isTRUE(ctl$continuation) && state$kkt > ctl$strict_gradient_tolerance) {
    warm_par <- oo$par
    for (eps in ctl$continuation_epsilon) {
      active_epsilon <- eps
      port <- tryCatch(nlminb(warm_par, objective, gradient,
                              lower = problem$lower, upper = problem$upper,
                              control = list(iter.max = ctl$continuation_maxit,
                                             eval.max = 4L * ctl$continuation_maxit,
                                             rel.tol = 1e-12, x.tol = 1e-11)),
                       error = function(e) NULL)
      if (!is.null(port)) {
        warm_par <- port$par
        port$value <- port$objective
        port$counts <- c("function" = unname(port$evaluations["function"]),
                         gradient = unname(port$evaluations["gradient"]))
        count_total <- count_total + port$counts
        add_candidate(port, paste0("computational_continuation_", format(eps)))
      }
    }
    active_epsilon <- 0
    # Snap only observations numerically coincident with the target quantile,
    # then optimize the exact likelihood in the remaining coefficient space.
    # This removes the ill-conditioning introduced by vanishing continuation.
    omit_active <- vector("list", 2L)
    if (isTRUE(ctl$active_polish)) for (polish in seq_len(ctl$active_polish_iterations)) {
      pp <- problem$unpack(warm_par)
      zz <- problem$evaluate(warm_par, TRUE)$residual
      anchors <- nullspaces <- vector("list", 2L)
      nfree <- integer(2L)
      any_active <- FALSE
      for (j in seq_len(2L)) {
        ids <- setdiff(which(abs(zz[, j]) <= ctl$active_tolerance), omit_active[[j]])
        zero_terms <- eal_terms(0, p, pp$shape[, j], degree, derivatives = FALSE)
        # A concave negative-log-density cusp cannot support a local minimum
        # at an exactly fitted observation; never force such a constraint.
        if (zero_terms$kink_a < 0) ids <- integer()
        alpha <- eal_margin_beta(pp$alpha, j)
        dj <- eal_margin_dimension(problem$d, j)
        Xj <- eal_margin_design(problem$X, j)
        if (length(ids)) {
          any_active <- TRUE
          A <- Xj[ids, , drop = FALSE]
          qa <- qr(t(A), tol = 1e-9)
          ids <- ids[qa$pivot[seq_len(qa$rank)]]
          A <- Xj[ids, , drop = FALSE]
          qa <- qr(t(A), tol = 1e-9)
          Q <- qr.Q(qa, complete = TRUE)
          nr <- qa$rank
          rhs <- (problem$Y[ids, j] - drop(A %*% alpha))[qa$pivot]
          Rr <- qr.R(qa)[seq_len(nr), seq_len(nr), drop = FALSE]
          alpha <- alpha + drop(Q[, seq_len(nr), drop = FALSE] %*%
                                  forwardsolve(t(Rr), rhs))
          N <- if (nr < dj) Q[, (nr + 1L):dj, drop = FALSE] else
            matrix(0, dj, 0L)
        } else N <- diag(dj)
        anchors[[j]] <- alpha
        nullspaces[[j]] <- N
        nfree[j] <- ncol(N)
      }
      if (!any_active) break
      nuisance <- setdiff(seq_along(warm_par), problem$idx_beta)
      expand_reduced <- function(x) {
        ans <- warm_par
        offset <- 0L
        for (j in seq_len(2L)) {
          alpha <- anchors[[j]]
          if (nfree[j]) alpha <- alpha + drop(nullspaces[[j]] %*% x[offset + seq_len(nfree[j])])
          ans[eal_beta_rows(problem$d, j)] <- alpha
          offset <- offset + nfree[j]
        }
        ans[nuisance] <- x[offset + seq_along(nuisance)]
        ans
      }
      grad_reduced <- function(x) {
        gg <- gradient(expand_reduced(x))
        c(unlist(lapply(seq_len(2L), function(j)
          as.vector(crossprod(nullspaces[[j]], gg[eal_beta_rows(problem$d, j)])))),
          gg[nuisance])
      }
      xr <- c(rep(0, sum(nfree)), warm_par[nuisance])
      port <- tryCatch(nlminb(xr, function(x) objective(expand_reduced(x)), grad_reduced,
                              lower = c(rep(-Inf, sum(nfree)), problem$lower[nuisance]),
                              upper = c(rep(Inf, sum(nfree)), problem$upper[nuisance]),
                              control = list(iter.max = ctl$continuation_maxit,
                                             eval.max = 4L * ctl$continuation_maxit,
                                             rel.tol = 1e-12, x.tol = 1e-11)),
                       error = function(e) NULL)
      if (is.null(port)) break
      polish_opt <- tryCatch(optim(port$par,
        function(x) objective(expand_reduced(x)), grad_reduced,
        method = "L-BFGS-B",
        lower = c(rep(-Inf, sum(nfree)), problem$lower[nuisance]),
        upper = c(rep(Inf, sum(nfree)), problem$upper[nuisance]),
        control = list(maxit = 300L, factr = 0, pgtol = 1e-7, lmm = 30L)),
        error = function(e) NULL)
      if (!is.null(polish_opt)) {
        count_total <- count_total + polish_opt$counts
        if (is.finite(polish_opt$value) && polish_opt$value <= port$objective) {
          port$par <- polish_opt$par
          port$objective <- polish_opt$value
          port$convergence <- polish_opt$convergence
          port$message <- polish_opt$message
        }
      }
      port$par <- expand_reduced(port$par)
      warm_par <- port$par
      port$value <- port$objective
      port$counts <- c("function" = unname(port$evaluations["function"]),
                       gradient = unname(port$evaluations["gradient"]))
      count_total <- count_total + port$counts
      state <- add_candidate(port, paste0("exact_active_quantile_polish_", polish))
      if (state$kkt <= ctl$strict_gradient_tolerance) break
      if (isTRUE(ctl$exact_subgradient_rescue)) {
        rescue <- eal_exact_subgradient_polish(problem, warm_par,
          control = list(maxit = ctl$exact_subgradient_iterations,
                         strict_gradient_tolerance = ctl$strict_gradient_tolerance,
                         knot_tolerance = ctl$knot_tolerance))
        count_total <- count_total + rescue$counts
        rescue_state <- add_candidate(rescue, paste0("exact_subgradient_rescue_", polish))
        if (rescue$value <= port$value + 1e-12) {
          warm_par <- rescue$par
          omit_active <- vector("list", 2L)
          state <- rescue_state
        }
        if (state$kkt <= ctl$strict_gradient_tolerance) break
      }
      if (length(state$unbounded_weights)) {
        violation <- pmax(-state$unbounded_weights, state$unbounded_weights - 1)
        for (j in seq_len(2L)) {
          bad <- which(state$knot_margin == j & violation > 1e-4)
          if (length(bad)) {
            worst <- bad[which.max(violation[bad])]
            omit_active[[j]] <- unique(c(omit_active[[j]], state$knot_observation[worst]))
          }
        }
      }
    }
    oo <- candidates[[which.min(vapply(candidates, function(x) x$value, numeric(1L)))]]
  }
  candidate_values <- vapply(candidates, function(x) x$value, numeric(1L))
  candidate_kkt <- vapply(candidates, function(x)
    problem$stationarity(x$par, ctl$knot_tolerance)$kkt, numeric(1L))
  eligible <- which(is.finite(candidate_kkt) & candidate_kkt <= ctl$strict_gradient_tolerance)
  if (length(eligible)) oo <- candidates[[eligible[which.min(candidate_values[eligible])]]]
  ee <- problem$evaluate(oo$par, TRUE)
  state <- problem$stationarity(oo$par, ctl$knot_tolerance)
  fit <- problem$unpack(oo$par)
  fit$alpha <- NULL
  fit$family <- "EAL_squared_Laguerre_continuous"
  fit$copula <- copula
  fit$dependence_link <- problem$dependence_link
  fit$dependence_bounds <- problem$dependence_bounds
  fit$convergence <- oo$convergence
  fit$message <- oo$message
  fit$max_abs_gradient <- max(abs(ee$gradient))
  fit$max_abs_projected_gradient <- state$raw
  fit$stationarity <- state$kkt
  fit$quantile_knots <- state$knots
  fit$strict_ok <- all(oo$par>=problem$lower&oo$par<=problem$upper) &&
    all(is.finite(ee$gradient)) && is.finite(ee$value) &&
    state$kkt <= ctl$strict_gradient_tolerance
  fit$directional_check <- NA
  fit$max_directional_improvement <- NA_real_
  if (fit$strict_ok && state$knots > 0L) {
    # Clarke stationarity is insufficient at a nonconvex cusp.  Inspect the
    # exact objective in both coefficient-coordinate directions and along the
    # raw gradient, in addition to rejecting wrong-way density cusps above.
    directions <- diag(length(oo$par))[, problem$idx_beta, drop = FALSE]
    raw_direction <- problem$project_gradient(oo$par, ee$gradient)
    if (sum(raw_direction^2) > 0)
      directions <- cbind(directions, raw_direction / sqrt(sum(raw_direction^2)))
    trial_values <- numeric()
    for (step in c(1e-6, 1e-5)) for (jj in seq_len(ncol(directions)))
      for (sgn in c(-1, 1)) {
        trial <- pmin(problem$upper, pmax(problem$lower,
                                          oo$par + sgn * step * directions[, jj]))
        trial_values <- c(trial_values, problem$evaluate(trial, FALSE)$value)
      }
    fit$max_directional_improvement <- ee$value - min(trial_values)
    fit$directional_check <- fit$max_directional_improvement <= 1e-9
    fit$strict_ok <- fit$strict_ok && fit$directional_check
  }
  fit$convergence_basis <- if (fit$strict_ok && state$knots > 0L)
    "bounded_subgradient_KKT" else "projected_gradient"
  fit$objective <- ee$value
  fit$best_candidate_objective <- min(candidate_values)
  fit$lower_unconverged_objective_gap <- max(0, ee$value - min(candidate_values))
  fit$loglik <- ee$loglik
  fit$penalty <- ee$penalty
  fit$counts <- count_total
  fit$elapsed <- proc.time()[[3L]] - start_time
  fit$boundary <- which(abs(oo$par - problem$lower) < 1e-5 |
                          abs(oo$par - problem$upper) < 1e-5)
  fit$dependence_boundary <- any(problem$idx_theta %in% fit$boundary)
  fit$n <- problem$n
  fit$parameter <- oo$par
  fit$penalty_matrices <- P
  fit$start_diagnostics <- do.call(rbind, diagnostics)
  fit$continuation_used <- any(grepl("^computational_continuation_", fit$start_diagnostics$label))
  fit$continuation_epsilon <- if (fit$continuation_used) ctl$continuation_epsilon else numeric()
  fit$knot_tolerance <- ctl$knot_tolerance
  fit$strict_gradient_tolerance <- ctl$strict_gradient_tolerance
  fit$improved_internal_candidates <- lapply(seq_along(candidates), function(i)
    list(par = candidates[[i]]$par, value = candidate_values[i],
         stationarity = candidate_kkt[i]))
  class(fit) <- "eal_copula_fit"
  if (copula %in% c('gaussian', 'clayton','student_t','frank','gumbel') && !isTRUE(fit$strict_ok) &&
      !identical(control$failure_recovery, FALSE))
    fit <- eal_recover_fit(fit, X, Y, P, beta_init, sigma_init, p, degree, copula, control)
  fit
}

predict_eal <- function(fit, Xnew) {
  # EAL is anchored at H(0)=p, so beta directly predicts the target quantile.
  if (eal_design_list(Xnew)) {
    stopifnot(length(Xnew) == 2L, is.list(fit$beta), length(fit$beta) == 2L,
      all(vapply(seq_len(2L), function(j) is.matrix(Xnew[[j]]) &&
        is.numeric(Xnew[[j]]) && all(is.finite(Xnew[[j]])) &&
        ncol(Xnew[[j]]) == length(fit$beta[[j]]), logical(1L))),
      nrow(Xnew[[1L]]) == nrow(Xnew[[2L]]))
    eal_location(Xnew, fit$beta)
  } else as.matrix(Xnew) %*% fit$beta
}

eal_fitter_gradient_check <- function(seed = 98324L, verbose = TRUE) {
  set.seed(seed)
  X <- cbind(1, rnorm(51L), runif(51L))
  Y <- matrix(rnorm(102L), 51L, 2L)
  b <- matrix(c(.13, -.21, .08, -.14, .17, .12), 3L, 2L)
  problem <- eal_problem(X, Y, list(diag(c(0, .2, .5)), diag(c(0, .3, .4))),
                         b, c(.8, .9), p = .25, degree = 3L,
                         control = list(theta_init = 1.3))
  par <- problem$par
  par[problem$idx_shape] <- .035 * cos(seq_along(problem$idx_shape))
  analytic <- problem$evaluate(par, TRUE)$gradient
  numeric_grad <- vapply(seq_along(par), function(k) {
    a <- bb <- par
    a[k] <- a[k] + 1e-6
    bb[k] <- bb[k] - 1e-6
    (problem$evaluate(a, FALSE)$value - problem$evaluate(bb, FALSE)$value) / 2e-6
  }, numeric(1L))
  ans <- list(max_gradient_error = max(abs(analytic - numeric_grad)),
              component_errors = abs(analytic - numeric_grad))
  stopifnot(all(is.finite(analytic)), ans$max_gradient_error < 2e-5)
  if (verbose) print(ans)
  invisible(ans)
}
