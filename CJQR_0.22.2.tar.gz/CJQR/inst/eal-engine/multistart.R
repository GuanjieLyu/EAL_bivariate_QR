# Deterministic EAL initializations from the supplied paired observations.
# Root-free shapes are optional starting points, not restrictions on fitted shapes.
# Sourcing this file defines the search without fitting a model.

# Version 2 serializes ALTREP vectors by their ordinary values, not by mutable
# deferred/expanded representation. Raw bytes are detached and retain exact
# numeric bits, types, dimensions, names, attributes, controls, and fit contents.
.eal_serialized_snapshot <- function(x) serialize(x,NULL,version=2L)

eal_multistart_control <- function(control=list()) {
  answer <- modifyList(list(nuisance_starts=4L,nuisance_maxit=160L,
    marginal_retained=4L,joint_branches=4L,gap_challengers=2L),control)
  caps <- c(nuisance_starts=4L,nuisance_maxit=160L,marginal_retained=4L,
    joint_branches=4L,gap_challengers=2L)
  stopifnot(identical(sort(names(answer)),sort(names(caps))))
  for(nm in names(caps)) stopifnot(length(answer[[nm]])==1L,
    is.finite(answer[[nm]]),answer[[nm]]==as.integer(answer[[nm]]),
    answer[[nm]]>=if(nm%in%c("joint_branches","gap_challengers"))0L else 1L,
    answer[[nm]]<=caps[[nm]])
  answer
}

.eal_parameter_key <- function(x) paste(sprintf("%a",as.numeric(x)),collapse=",")

.eal_radical_inverse <- function(index,base) {
  answer <- 0;factor <- 1/base
  while(index>0L) {
    answer <- answer+(index%%base)*factor
    index <- index%/%base;factor <- factor/base
  }
  answer
}

.eal_shape_bank <- function(degree=3L) {
  stopifnot(degree==3L)
  side_dimension <- degree-1L
  bases <- c(2L,3L,5L,7L,11L,13L)[seq_len(2L*side_dimension)]
  angles <- t(vapply(seq_len(12L),function(i)
    vapply(bases,function(base).eal_radical_inverse(i,base),numeric(1)),numeric(2L*side_dimension)))
  angles <- .6*(2*angles-1)
  angles <- rbind(rep(0,2L*side_dimension),angles,
    angles[,c(side_dimension+seq_len(side_dimension),seq_len(side_dimension)),drop=FALSE])
  bank <- do.call(rbind,lapply(c(0,-1,-2,-3),function(center)cbind(center,angles)))
  colnames(bank) <- c("center",paste0("left",seq_len(side_dimension)),
    paste0("right",seq_len(side_dimension)))
  bank
}

.eal_polynomial_basis <- function(K=3L) {
  answer <- matrix(0,K+1L,K+1L)
  answer[1L,1L] <- 1;answer[2L,1:2] <- c(1,-1)
  for(k in 2:K) {
    previous <- answer[k,]
    answer[k+1L,] <- ((2*k-1)*previous-c(0,previous[-length(previous)])-
      (k-1)*answer[k-1L,])/k
  }
  answer
}

.eal_sector <- function(residual,p,shape,sigma,private,degree=3L) {
  spec <- private$eal_shape(shape,degree)
  # Optimized kernels use a child environment; Laguerre evaluation is inherited
  # from the verified source environment.
  laguerre <- get(".eal_laguerre",envir=private,inherits=TRUE)
  z <- residual/sigma
  amplitude <- numeric(length(z));root_counts <- integer(2L)
  basis <- .eal_polynomial_basis(degree)
  for(j in 1:2) {
    left <- j==1L;side <- if(left)spec$left else spec$right
    ids <- which(if(left)z<0 else z>=0)
    if(length(ids)) {
      t <- (if(left)1-p else p)*abs(z[ids])
      amplitude[ids] <- drop(laguerre(t,degree)%*%side$a)
    }
    roots <- polyroot(drop(crossprod(side$a,basis)))
    root_counts[j] <- sum(abs(Im(roots))<=1e-8*pmax(1,abs(Re(roots)))&Re(roots)>0)
  }
  negative <- amplitude<0
  list(signature=paste(which(negative),collapse=","),negative=negative,
    root_counts=root_counts,root_free=all(root_counts==0L),
    minimum_abs_amplitude=if(length(amplitude))min(abs(amplitude))else Inf)
}

# Prefer low objective, while retaining different observed sign sectors and
# one fully root-free initializer when available. No candidate is excluded
# from final model eligibility because it has roots.
.eal_diverse_indices <- function(candidates,count,exclude_signatures=character()) {
  available <- which(vapply(candidates,function(x)is.finite(x$value),logical(1)))
  if(!length(available))return(integer())
  available <- available[order(vapply(candidates[available],`[[`,numeric(1),"value"),available)]
  keys <- vapply(candidates[available],function(x).eal_parameter_key(x$parameter),character(1))
  available <- available[!duplicated(keys)]
  selected <- available[1L]
  rootfree <- available[vapply(candidates[available],function(x)isTRUE(x$root_free),logical(1))]
  if(length(rootfree)&&length(selected)<count)selected <- unique(c(selected,rootfree[1L]))
  signatures <- c(exclude_signatures,vapply(candidates[selected],`[[`,character(1),"signature"))
  for(i in available) {
    if(length(selected)>=count)break
    if(!i%in%selected&&!candidates[[i]]$signature%in%signatures) {
      selected <- c(selected,i);signatures <- c(signatures,candidates[[i]]$signature)
    }
  }
  for(i in available) {
    if(length(selected)>=count)break
    if(!i%in%selected)selected <- c(selected,i)
  }
  selected
}

.eal_marginal_starts <- function(residual,p,sigma_init,private,extra,refine=TRUE,
  lower=NULL,upper=NULL,degree=3L) {
  ns <- 2L*as.integer(degree)-1L
  if(is.null(lower))lower <- c(log(1e-5),rep(-8,ns))
  if(is.null(upper))upper <- c(log(1e3),rep(8,ns))
  stopifnot(degree==3L,length(lower)==ns+1L,length(upper)==ns+1L)
  # Sorting makes this nuisance stage insensitive to input-row permutation.
  residual <- sort(as.numeric(residual),method="radix")
  bank <- .eal_shape_bank(degree)
  evaluations <- 0L;cache_parameter <- cache_result <- NULL
  evaluate <- function(parameter,gradient=TRUE) {
    if(!is.null(cache_parameter)&&identical(parameter,cache_parameter)&&
      (!gradient||!is.null(cache_result$gradient)))return(cache_result)
    evaluations <<- evaluations+1L
    sigma <- exp(parameter[1L]);z <- residual/sigma
    terms <- private$eal_terms(z,p,parameter[-1L],degree,derivatives=gradient)
    value <- -mean(terms$logg)+parameter[1L]
    grad <- if(gradient)c(mean(1+terms$hz*z),-colMeans(terms$dlogg_dshape))else NULL
    result <- list(value=value,gradient=grad)
    cache_parameter <<- parameter;cache_result <<- result
    result
  }
  candidates <- list()
  add <- function(parameter,label,kind,reported=NA_real_) {
    ev <- tryCatch(evaluate(parameter,FALSE),error=function(e)list(value=Inf))
    sector <- tryCatch(.eal_sector(residual,p,parameter[-1L],exp(parameter[1L]),private,degree),
      error=function(e) {
        if(is.finite(ev$value))stop("Finite marginal candidate sector classification failed: ",conditionMessage(e))
        list(signature="invalid",root_counts=c(NA_integer_,NA_integer_),
          root_free=FALSE,minimum_abs_amplitude=NA_real_)
      })
    candidates[[length(candidates)+1L]] <<- list(parameter=parameter,value=ev$value,
      label=label,kind=kind,reported=reported,signature=sector$signature,
      root_free=sector$root_free,root_counts=sector$root_counts,
      minimum_abs_amplitude=sector$minimum_abs_amplitude)
    length(candidates)
  }
  for(k in seq_len(nrow(bank)))for(multiplier in c(.5,1,2)) {
    par <- c(log(sigma_init*multiplier),bank[k,])
    par <- pmax(lower,pmin(upper,par))
    add(par,paste0("bank_",k,"_scale_",multiplier),"raw_bank")
  }
  starts <- .eal_diverse_indices(candidates,extra$nuisance_starts)
  optimization_log <- list();counts <- c("function"=0,"gradient"=0)
  if(refine)for(i in starts) {
    start <- candidates[[i]]
    best_parameter <- start$parameter;best_value <- start$value
    value <- function(parameter) {
      ev <- evaluate(parameter,TRUE)
      if(is.finite(ev$value)&&ev$value<best_value) {
        best_value <<- ev$value;best_parameter <<- parameter
      }
      ev$value
    }
    gradient <- function(parameter)evaluate(parameter,TRUE)$gradient
    fit <- tryCatch(stats::optim(start$parameter,value,gradient,method="L-BFGS-B",
      lower=lower,upper=upper,control=list(maxit=extra$nuisance_maxit,
        factr=100,pgtol=1e-7)),error=function(e)list(par=start$parameter,
          value=start$value,convergence=999L,message=conditionMessage(e),
          counts=c("function"=0,"gradient"=0)))
    counts <- counts+fit$counts
    add(fit$par,paste0(start$label,"_terminal"),"nuisance_terminal",fit$value)
    add(best_parameter,paste0(start$label,"_best_evaluated"),"nuisance_best_evaluated",best_value)
    optimization_log[[length(optimization_log)+1L]] <- data.frame(label=start$label,
      convergence=fit$convergence,objective=fit$value,best_evaluated=best_value,
      functions=unname(fit$counts["function"]),gradients=unname(fit$counts["gradient"]),
      message=if(is.null(fit$message))""else fit$message)
  }
  retained <- .eal_diverse_indices(candidates,extra$marginal_retained)
  log <- do.call(rbind,lapply(seq_along(candidates),function(i) {
    a <- candidates[[i]]
    data.frame(index=i,label=a$label,kind=a$kind,objective=a$value,
      log_sigma=a$parameter[1L],shape_center=a$parameter[2L],
      left_roots=a$root_counts[1L],right_roots=a$root_counts[2L],
      signature=a$signature,root_free=a$root_free,retained=i%in%retained,
      minimum_abs_amplitude=a$minimum_abs_amplitude,stringsAsFactors=FALSE)
  }))
  list(retained=candidates[retained],log=log,
    parameters=do.call(cbind,lapply(candidates,`[[`,"parameter")),
    optimization_log=if(length(optimization_log))do.call(rbind,optimization_log)else data.frame(),
    optimizer_counts=counts,evaluations=evaluations,
    residual_count=length(residual),refined=refine)
}

.build_eal_multistart <- function(engine) {
  stopifnot(is.list(engine),identical(engine$engine,"R"),
    identical(engine$manifest$implementation,"degree3_bivariate_distinct_design_v2"))
  observed <- tools::md5sum(file.path(engine$directory,names(engine$manifest$source_md5)))
  names(observed) <- names(engine$manifest$source_md5)
  if(!identical(observed,engine$manifest$source_md5))stop("Released engine source integrity check failed")
  private <- environment(engine$fit)
  stopifnot(is.function(private$.engine_scope),is.function(private$improved_eal_certificate))
  version <- "degree3_bivariate_distinct_design_multistart_package_20260916"
  seal <- new.env(parent=emptyenv());registry <- new.env(parent=emptyenv());next_id <- 0L
  normalize_inputs <- function(X,Y,P,beta_init,sigma_init,p,degree,copula,control) {
    stopifnot(length(copula)==1L,copula%in%c("gaussian","clayton","student_t","frank","gumbel"),length(degree)==1L,is.finite(degree),degree==3L,length(p)==1L,is.finite(p),p>0,p<1)
    list(X=X,Y=Y,P=P,beta_init=beta_init,sigma_init=sigma_init,p=p,
      degree=degree,copula=copula,control=private$improved_eal_control(control))
  }
  input_binding <- function(arguments).eal_serialized_snapshot(list(arguments=arguments,
    engine_source_md5=engine$manifest$source_md5,version=version))
  compute_baseline <- function(arguments)tryCatch(do.call(engine$fit,arguments),
    error=function(e)list(error=conditionMessage(e),strict_ok=FALSE))
  prepare_baseline <- function(X,Y,P,beta_init,sigma_init,p,degree=3L,
    copula=engine$default_copula,control=list()) {
    arguments <- normalize_inputs(X,Y,P,beta_init,sigma_init,p,degree,copula,control)
    binding <- input_binding(arguments);base <- compute_baseline(arguments)
    next_id <<- next_id+1L;id <- as.character(next_id)
    entry <- list(input_binding=binding,fit=base,fit_binding=.eal_serialized_snapshot(base))
    assign(id,entry,registry)
    # Reuse is intentionally process-local and bounded; no arbitrary saved-fit
    # or donor-fit import route exists. The envelope's preview is also checked.
    old <- ls(registry,all.names=TRUE)
    if(length(old)>2L)rm(list=old[order(as.integer(old))][seq_len(length(old)-2L)],envir=registry)
    structure(list(id=id,seal=seal,input_binding=binding,fit=base),
      class="degree3_bivariate_baseline_envelope")
  }
  resolve_baseline <- function(baseline,arguments) {
    if(is.null(baseline))return(compute_baseline(arguments))
    if(!inherits(baseline,"degree3_bivariate_baseline_envelope")||!identical(baseline$seal,seal)||
      !is.character(baseline$id)||length(baseline$id)!=1L||
      !exists(baseline$id,registry,inherits=FALSE))stop("Baseline reuse requires this builder's unmodified factory envelope")
    entry <- get(baseline$id,registry,inherits=FALSE)
    if(!identical(input_binding(arguments),entry$input_binding)||
      !identical(baseline$input_binding,entry$input_binding)||
      !identical(.eal_serialized_snapshot(baseline$fit),entry$fit_binding))
      stop("Baseline envelope does not match the exact recipient inputs or sealed fit")
    entry$fit
  }
  propose_starts <- function(X,Y,P,beta_init,sigma_init,p,degree=3L,copula=engine$default_copula,
    control=list(),extra_control=list(),refine=TRUE) {
    arguments <- normalize_inputs(X,Y,P,beta_init,sigma_init,p,degree,copula,control)
    extra <- eal_multistart_control(extra_control)
    problem <- do.call(engine$reference_problem,arguments)
    residual <- as.matrix(Y) - if (is.list(X) && !is.data.frame(X))
      engine$predict_anchor(list(beta = beta_init), X) else
      as.matrix(X)%*%as.matrix(beta_init)
    density_private <- private$.engine_scope()$environment
    ns <- problem$shape_dimension
    marginal <- lapply(1:2,function(j).eal_marginal_starts(residual[,j],p,
      sigma_init[j],density_private,extra,refine,
      lower=c(problem$lower[problem$idx_scale[j]],problem$lower[problem$idx_shape[(j-1L)*ns+seq_len(ns)]]),
      upper=c(problem$upper[problem$idx_scale[j]],problem$upper[problem$idx_shape[(j-1L)*ns+seq_len(ns)]]),degree=degree))
    if(any(!vapply(marginal,function(x)length(x$retained)>0L,logical(1))))
      return(list(marginal=marginal,joint=list(),extra_control=extra,error="No finite marginal initializer"))
    joint <- list()
    for(i in seq_along(marginal[[1]]$retained))for(j in seq_along(marginal[[2]]$retained)) {
      a <- marginal[[1]]$retained[[i]];b <- marginal[[2]]$retained[[j]]
      par <- problem$par
      par[problem$idx_scale] <- c(a$parameter[1L],b$parameter[1L])
      par[problem$idx_shape] <- c(a$parameter[-1L],b$parameter[-1L])
      ev <- tryCatch(problem$evaluate(par,FALSE),error=function(e)list(value=Inf))
      sectors <- lapply(1:2,function(k) {
        candidate <- if(k==1L)a else b
        .eal_sector(residual[,k],p,candidate$parameter[-1L],exp(candidate$parameter[1L]),private,degree)
      })
      joint[[length(joint)+1L]] <- list(parameter=par,value=ev$value,
        label=paste0("within_data_margin_pair_",i,"_",j),marginal_indices=c(i,j),
        signature=paste(vapply(sectors,`[[`,character(1),"signature"),collapse="|"),
        root_free=all(vapply(sectors,`[[`,logical(1),"root_free")),
        root_counts=unlist(lapply(sectors,`[[`,"root_counts")),
        marginal_labels=c(a$label,b$label))
    }
    list(marginal=marginal,joint=joint,extra_control=extra,error=NULL,
      initialization_source="Recipient Y-X beta_init residuals only; no external fits, responses, or truths")
  }
  # Main fitter is defined below so all helper state stays private to builder.
  fit <- function(X,Y,P,beta_init,sigma_init,p,degree=3L,copula=engine$default_copula,
    control=list(),extra_control=list(),baseline=NULL) {
    arguments <- normalize_inputs(X,Y,P,beta_init,sigma_init,p,degree,copula,control)
    inputs_before <- input_binding(arguments)
    input_fields_before <- lapply(arguments,.eal_serialized_snapshot)
    check_input_integrity <- function() tryCatch({
      fields <- vapply(names(arguments),function(nm)
        identical(input_fields_before[[nm]],.eal_serialized_snapshot(arguments[[nm]])),logical(1))
      ok <- identical(inputs_before,input_binding(arguments))
      changed <- names(fields)[!fields]
      if(!ok&&!length(changed))changed <- "binding_metadata"
      list(ok=ok,scheme="canonical_value_serialization_v2_exact_bytes",
        changed_components=changed,error=NULL)
    },error=function(e)list(ok=FALSE,scheme="canonical_value_serialization_v2_exact_bytes",
      changed_components="unreadable_binding",error=conditionMessage(e)))
    extra <- eal_multistart_control(extra_control)
    started <- proc.time()[3L];baseline_started <- proc.time()[3L]
    base <- resolve_baseline(baseline,arguments)
    baseline_elapsed <- unname(proc.time()[3L]-baseline_started)
    # Keep baseline and every observed candidate if the extension itself fails.
    # An extension exception is never relabeled as revised-fit success.
    candidate_pool <- candidate_occurrences <- list();reported_minima <- numeric()
    problem <- NULL;total_counts <- if(is.numeric(base$counts))base$counts else c("function"=0,"gradient"=0)
    tryCatch({
    problem <- do.call(engine$reference_problem,arguments)
    candidate_pool <- list();candidate_occurrences <- list();reported_minima <- numeric()
    branch_fits <- list();branch_errors <- list();certificates <- list()
    total_counts <- if(is.numeric(base$counts))base$counts else c("function"=0,"gradient"=0)
    add_candidate <- function(par,label,kind,reported=NA_real_) {
      if(!is.numeric(par)||length(par)!=length(problem$par)||any(!is.finite(par)))return(NA_integer_)
      if(any(par<problem$lower|par>problem$upper))return(NA_integer_)
      value <- tryCatch(problem$evaluate(par,FALSE,0)$value,error=function(e)Inf)
      if(!is.finite(value))return(NA_integer_)
      key <- .eal_parameter_key(par)
      keys <- vapply(candidate_pool,`[[`,character(1),"key")
      index <- match(key,keys)
      if(is.na(index)) {
        index <- length(candidate_pool)+1L
        candidate_pool[[index]] <<- list(par=par,value=value,key=key,label=label,kind=kind)
      }
      candidate_occurrences[[length(candidate_occurrences)+1L]] <<-
        data.frame(candidate=index,label=label,kind=kind,objective=value,reported_objective=reported)
      index
    }
    add_fit <- function(f,label) {
      if(length(f$best_candidate_objective)==1L&&is.finite(f$best_candidate_objective))
        reported_minima <<- c(reported_minima,f$best_candidate_objective)
      add_candidate(f$parameter,label,"terminal",f$objective)
      if(is.matrix(f$improved_candidate_parameters))for(i in seq_len(ncol(f$improved_candidate_parameters)))
        add_candidate(f$improved_candidate_parameters[,i],label,"baseline_retained_candidate")
      if(is.matrix(f$improved_branch_parameters))for(i in seq_len(ncol(f$improved_branch_parameters)))
        add_candidate(f$improved_branch_parameters[,i],label,"baseline_branch_terminal")
      if(is.numeric(f$best_finite_fit$parameter))add_candidate(f$best_finite_fit$parameter,label,"best_finite")
      for(candidate in c(f$improved_internal_candidates,f$recovery_candidates))
        add_candidate(candidate$par,label,"internal_or_recovery",candidate$value)
    }
    if(is.null(base$error))add_fit(base,"baseline_v4")
    proposal_started <- proc.time()[3L]
    proposal <- do.call(propose_starts,c(arguments,list(extra_control=extra,refine=TRUE)))
    proposal_elapsed <- unname(proc.time()[3L]-proposal_started)
    for(candidate in proposal$joint)add_candidate(candidate$parameter,candidate$label,"screened_joint_start",candidate$value)
    if(length(proposal$marginal))for(marginal in proposal$marginal)total_counts <- total_counts+marginal$optimizer_counts
    baseline_signature <- character()
    if(is.null(base$error)) {
      residual <- as.matrix(Y) - if (is.list(X) && !is.data.frame(X))
        engine$predict_anchor(base, X) else as.matrix(X)%*%base$beta
      sectors <- lapply(1:2,function(j).eal_sector(residual[,j],p,base$shape[,j],base$sigma[j],private,degree))
      baseline_signature <- paste(vapply(sectors,`[[`,character(1),"signature"),collapse="|")
    }
    selected_starts <- if(extra$joint_branches>0L)
      .eal_diverse_indices(proposal$joint,extra$joint_branches,baseline_signature)else integer()
    run_branch <- function(par,label) {
      init <- problem$unpack(par);init$alpha <- NULL
      scope <- private$.engine_scope()
      branch_control <- modifyList(arguments$control,list(starts=1L,al_warm_start=FALSE))
      # theta_init is an initialization override, not an objective parameter.
      # A supplied candidate must carry its own fitted theta into this branch.
      branch_control$theta_init <- NULL
      branch_arguments <- arguments;branch_arguments$control <- branch_control
      branch_arguments$init <- init
      start <- proc.time()[3L]
      result <- tryCatch(do.call(scope$environment$.improved_legacy_fit,branch_arguments),error=function(e)e)
      if(inherits(result,"error")) {
        branch_errors[[label]] <<- conditionMessage(result);return(invisible(NULL))
      }
      result$tail_branch_elapsed <- unname(proc.time()[3L]-start)
      branch_fits[[label]] <<- result;total_counts <<- total_counts+result$counts
      add_fit(result,label)
      invisible(result)
    }
    for(i in selected_starts)run_branch(proposal$joint[[i]]$parameter,proposal$joint[[i]]$label)
    if(!length(candidate_pool))stop("No finite baseline or within-data joint candidate")
    known_best <- function()min(c(vapply(candidate_pool,`[[`,numeric(1),"value"),reported_minima))
    select_certified <- function() {
      order <- order(vapply(candidate_pool,`[[`,numeric(1),"value"),seq_along(candidate_pool))
      for(i in order) {
        key <- as.character(i)
        cc <- certificates[[key]]
        if(is.null(cc)) {
          candidate <- candidate_pool[[i]]
          cc <- private$improved_eal_certificate(problem,candidate$par,candidate$value,arguments$control)
          certificates[[key]] <<- cc
          if(!is.null(cc$best_probe))add_candidate(cc$best_probe,
            paste0(candidate$label,"_certificate_probe"),"certificate_probe",cc$best_probe_objective)
        }
        if(isTRUE(cc$strict_local_ok))return(list(index=i,certificate=cc))
      }
      NULL
    }
    selected <- select_certified();challenged <- character();challenger_count <- 0L
    for(k in seq_len(extra$gap_challengers)) {
      gap <- if(is.null(selected))Inf else max(0,selected$certificate$objective-known_best())
      if(is.finite(gap)&&gap<=arguments$control$lower_candidate_gap_tolerance)break
      ids <- order(vapply(candidate_pool,`[[`,numeric(1),"value"),seq_along(candidate_pool))
      ids <- ids[!vapply(candidate_pool[ids],function(x)x$key%in%challenged,logical(1))]
      if(!length(ids))break
      candidate <- candidate_pool[[ids[1L]]];challenged <- c(challenged,candidate$key)
      challenger_count <- challenger_count+1L
      run_branch(candidate$par,paste0("observed_lower_candidate_challenger_",k))
      selected <- select_certified()
    }
    best_index <- which.min(vapply(candidate_pool,`[[`,numeric(1),"value"))
    if(is.null(selected))selected <- list(index=best_index,certificate=NULL)
    selected_candidate <- candidate_pool[[selected$index]]
    final_problem <- do.call(engine$reference_problem,arguments)
    final_certificate <- private$improved_eal_certificate(final_problem,
      selected_candidate$par,selected_candidate$value,arguments$control)
    if(!is.null(final_certificate$best_probe))add_candidate(final_certificate$best_probe,
      "final_certificate_probe","certificate_probe",final_certificate$best_probe_objective)
    gap <- max(0,final_certificate$objective-known_best())
    accepted <- isTRUE(final_certificate$strict_local_ok)&&is.finite(gap)&&
      gap<=arguments$control$lower_candidate_gap_tolerance
    template <- if(is.null(base$error))base else if(length(branch_fits))branch_fits[[1L]] else list()
    output <- private$improved_eal_materialize(template,final_problem,selected_candidate$par,final_certificate)
    output$strict_ok <- accepted;output$convergence <- if(accepted)0L else 1L
    output$message <- if(accepted)"Within-data multistart numerical certificate passed" else
      paste(c(final_certificate$reason_codes,if(!is.finite(gap)||gap>arguments$control$lower_candidate_gap_tolerance)
        "unresolved_lower_candidate"),collapse="; ")
    output$convergence_basis <- "within_data_diverse_starts_original_exact_strict_certificate"
    output$strict_gradient_tolerance <- arguments$control$strict_gradient_tolerance
    output$best_candidate_objective <- known_best()
    output$lower_unconverged_objective_gap <- gap
    output$counts <- total_counts
    output$counts_scope <- "Baseline plus nuisance initialization and new joint optimizer requests; excludes screening/certificate/replay evaluations"
    output$elapsed <- unname(proc.time()[3L]-started)
    output$baseline_fit <- base
    output$fast_cache_statistics <- output$fast_cache_control <- NULL
    output$fast_version <- "explicit_pure_R_degree3_bivariate_distinct_design_package_20260916"
    output$improved_version <- version
    output$improved_selected_branch <- selected_candidate$label
    output$improved_control <- arguments$control
    output$improved_candidate_parameters <- do.call(cbind,lapply(candidate_pool,`[[`,"par"))
    output$improved_candidate_log <- do.call(rbind,candidate_occurrences)
    output$improved_branch_parameters <- cbind(if(is.null(base$error))base$improved_branch_parameters else NULL,
      if(length(branch_fits))do.call(cbind,lapply(branch_fits,`[[`,"parameter"))else NULL)
    output$improved_joint_branch_count <- (if(is.null(base$improved_joint_branch_count))0L else base$improved_joint_branch_count)+length(branch_fits)
    output$improved_challenger_count <- (if(is.null(base$improved_challenger_count))0L else base$improved_challenger_count)+challenger_count
    best_index <- which.min(vapply(candidate_pool,`[[`,numeric(1),"value"))
    best <- candidate_pool[[best_index]]
    best_state <- final_problem$unpack(best$par);best_state$alpha <- NULL
    output$best_finite_fit <- c(best_state,list(parameter=best$par,objective=best$value,
      branch=best$label,kind=best$kind))
    clean_certificate <- function(x) {x$evaluation <- x$state <- NULL;x}
    output$improved_certificate <- clean_certificate(final_certificate)
    output$improved_certificate$observed_candidate_gap <- gap
    output$improved_certificate$observed_candidate_gap_ok <- is.finite(gap)&&gap<=arguments$control$lower_candidate_gap_tolerance
    output$improved_certificate$reason_codes <- c(final_certificate$reason_codes,
      if(!output$improved_certificate$observed_candidate_gap_ok)"unresolved_lower_candidate")
    output$tail_multistart <- list(version=version,extra_control=extra,
      engine_source_md5=engine$manifest$source_md5,baseline_reused=!is.null(baseline),
      baseline_elapsed=baseline_elapsed,proposal_elapsed=proposal_elapsed,
      marginal=proposal$marginal,screened_joint=proposal$joint,
      selected_start_indices=selected_starts,additional_joint_branches=length(selected_starts),
      additional_gap_challengers=challenger_count,branch_errors=branch_errors,
      branch_fits=branch_fits,
      branch_log=if(length(branch_fits))do.call(rbind,lapply(names(branch_fits),function(label) {
        f <- branch_fits[[label]]
        data.frame(label=label,objective=f$objective,reported_minimum=f$best_candidate_objective,
          legacy_strict_ok=f$strict_ok,KKT=f$stationarity,elapsed=f$tail_branch_elapsed)
      }))else data.frame(),
      certificates=lapply(certificates,clean_certificate),reported_candidate_minima=reported_minima,
      objective_only_selection=TRUE,root_free_is_start_preference_only=TRUE,
      no_external_dataset_inputs=TRUE,global_optimum_claim=FALSE,extension_error=NULL)
    integrity <- check_input_integrity()
    if(!isTRUE(integrity$ok)) {
      error <- simpleError("Recipient input integrity check failed")
      error$integrity <- integrity
      class(error) <- c("tail_v3_input_integrity_error",class(error))
      stop(error)
    }
    output$input_integrity <- integrity
    class(output) <- "eal_copula_fit"
    output
    },error=function(error) {
      output <- base;output$baseline_fit <- base
      output$strict_ok <- FALSE;output$convergence <- 1L
      output$message <- paste0("Within-data extension failed: ",conditionMessage(error))
      output$convergence_basis <- "within_data_extension_error_baseline_retained"
      output$counts <- total_counts;output$elapsed <- unname(proc.time()[3L]-started)
      known <- c(if(length(candidate_pool))vapply(candidate_pool,`[[`,numeric(1),"value")else numeric(),
        reported_minima,if(length(base$best_candidate_objective)==1L)base$best_candidate_objective else numeric())
      known <- known[is.finite(known)]
      output$best_candidate_objective <- if(length(known))min(known)else Inf
      output$lower_unconverged_objective_gap <- if(length(base$objective)==1L&&is.finite(base$objective)&&length(known))
        max(0,base$objective-min(known))else Inf
      if(length(candidate_pool)) {
        best <- candidate_pool[[which.min(vapply(candidate_pool,`[[`,numeric(1),"value"))]]
        if(!is.null(problem)) {
          state <- problem$unpack(best$par);state$alpha <- NULL
          output$best_finite_fit <- c(state,list(parameter=best$par,objective=best$value,
            branch=best$label,kind=best$kind))
        }
        output$improved_candidate_parameters <- do.call(cbind,lapply(candidate_pool,`[[`,"par"))
      }
      if(length(candidate_occurrences))output$improved_candidate_log <- do.call(rbind,candidate_occurrences)
      output$improved_certificate <- list(strict_local_ok=FALSE,
        reason_codes="extension_error",observed_candidate_gap=output$lower_unconverged_objective_gap,
        observed_candidate_gap_ok=FALSE)
      output$tail_multistart <- list(version=version,extra_control=extra,
        engine_source_md5=engine$manifest$source_md5,baseline_reused=!is.null(baseline),
        baseline_elapsed=baseline_elapsed,extension_error=conditionMessage(error),
        reported_candidate_minima=reported_minima,objective_only_selection=TRUE,
        root_free_is_start_preference_only=TRUE,no_external_dataset_inputs=TRUE,
        global_optimum_claim=FALSE)
      integrity <- check_input_integrity()
      output$input_integrity <- integrity
      if(!isTRUE(integrity$ok)) {
        # Preserve the completed baseline and finite states for diagnosis only.
        # Neither strict nor all-finite comparison may use a fit whose recipient
        # inputs changed. Do not throw again and lose the diagnostic baseline.
        output$diagnostic_untrusted_fit <- list(objective=output$objective,
          best_finite_fit=output$best_finite_fit,parameter=output$parameter,
          beta=output$beta,improved_certificate=output$improved_certificate)
        untrusted_baseline <- base
        untrusted_baseline$diagnostic_original_fit <- base
        untrusted_baseline$strict_ok_before_integrity_failure <- base$strict_ok
        untrusted_baseline$strict_ok <- FALSE
        untrusted_baseline$convergence <- 1L
        untrusted_baseline$objective <- NA_real_
        untrusted_baseline$best_finite_fit <- NULL
        untrusted_baseline$input_integrity <- integrity
        untrusted_baseline$message <- "Baseline retained for diagnosis only: recipient input integrity failed"
        output$baseline_fit <- untrusted_baseline
        output$objective <- NA_real_
        output$best_finite_fit <- NULL
        output$integrity_error <- list(type="input_integrity_failure",
          changed_components=integrity$changed_components,
          message="Recipient inputs changed; original fits retained only as diagnostic evidence")
        output$message <- paste0("Within-data extension failed: recipient input integrity check failed; ",
          conditionMessage(error))
        output$convergence_basis <- "input_integrity_failure_diagnostic_baseline_retained"
        output$improved_certificate$reason_codes <- unique(c(
          output$improved_certificate$reason_codes,"input_integrity_failure"))
        output$tail_multistart$integrity_error <- output$integrity_error
      }
      class(output) <- "eal_copula_fit"
      output
    })
  }
  list(fit=fit,prepare_baseline=prepare_baseline,propose_starts=propose_starts,
    controls=eal_multistart_control,version=version,engine_manifest=engine$manifest,
    baseline_reuse_contract="Only an unmodified factory envelope from this builder and exact recipient inputs; no saved/donor fit import")
}
