# Package entry point for the degree-3 bivariate EAL engine.

load_cjqr_eal_engine <- function(directory, copula=c("gaussian","clayton","student_t","frank","gumbel")) {
  copula <- match.arg(copula)
  directory <- normalizePath(directory,winslash="/",mustWork=TRUE)
  files <- c("density_reference.R","numerical.R","strict.R","multistart.R",
    "density_fast.R","load_engine.R","copula_terms.R")
  hashes <- tools::md5sum(file.path(directory,files));names(hashes) <- files
  if(anyNA(hashes))stop("Degree-3 bivariate engine source is incomplete")
  # The numerical core uses stats/base functions; resolve them through their
  # namespace, never the user's search path or global environment.
  reference <- new.env(parent=asNamespace("stats"))
  for(file in c("density_reference.R","copula_terms.R","numerical.R","strict.R"))
    sys.source(file.path(directory,file),reference)
  private <- new.env(parent=asNamespace("stats"))
  for(name in ls(reference,all.names=TRUE))
    assign(name,get(name,reference,inherits=FALSE),private)
  private$.eal_default_copula <- copula
  template <- new.env(parent=asNamespace("stats"))
  for(name in ls(reference,all.names=TRUE)) {
    value <- get(name,reference,inherits=FALSE)
    if(is.function(value))environment(value) <- template
    assign(name,value,template)
  }
  sys.source(file.path(directory,"density_fast.R"),template)
  # A fresh private scope per numerical fit keeps native single-entry caches
  # independent. Function bodies are explicit source; only environments differ.
  private$.engine_scope <- function() {
    scope <- new.env(parent=asNamespace("stats"))
    for(name in ls(template,all.names=TRUE)) {
      value <- get(name,template,inherits=FALSE)
      # This one closure contains read-only degree geometry, not fit state.
      if(is.function(value)&&name!=".eal_geometry")environment(value) <- scope
      assign(name,value,scope)
    }
    list(environment=scope,problem=scope$eal_problem,fit=scope$improved_fit_eal)
  }
  baseline_fit <- function(X,Y,P,beta_init,sigma_init,p,degree=3L,
    copula=.eal_default_copula,control=list()) {
    stopifnot(length(copula)==1L,copula%in%c("gaussian","clayton","student_t","frank","gumbel"),length(degree)==1L,
      is.finite(degree),degree==3L)
    scope <- .engine_scope()
    out <- scope$fit(X,Y,P,beta_init,sigma_init,p,degree,copula,control)
    out$fast_version <- "explicit_pure_R_degree3_bivariate_baseline_package_20260916"
    out
  }
  environment(baseline_fit) <- private
  fast_problem <- function(X,Y,P,beta_init,sigma_init,p,degree=3L,
    copula=.eal_default_copula,init=NULL,control=list()) {
    stopifnot(length(copula)==1L,copula%in%c("gaussian","clayton","student_t","frank","gumbel"),length(degree)==1L,
      is.finite(degree),degree==3L)
    scope <- .engine_scope()
    scope$problem(X,Y,P,beta_init,sigma_init,p,degree,copula,init,control)
  }
  environment(fast_problem) <- private
  engine <- list(fit=baseline_fit,problem=fast_problem,
    reference_problem=reference$eal_problem,reference_fit=reference$improved_fit_eal,
    certificate=reference$improved_eal_certificate,
    predict_anchor=reference$predict_eal,
    manifest=list(implementation="degree3_bivariate_distinct_design_v2",source_md5=hashes,
      validation_status="Package integration; consult engine parity tests"),
    directory=directory,engine="R",supported_degrees=3L,default_copula=copula)
  outer <- new.env(parent=asNamespace("stats"))
  sys.source(file.path(directory,"multistart.R"),outer)
  model <- outer$.build_eal_multistart(engine)
  density <- private$.engine_scope()$environment
  log_density <- function(fit,X,Y,require_strict=TRUE) {
    stopifnot(is.list(fit),identical(require_strict,TRUE)||identical(require_strict,FALSE))
    if(require_strict&&!isTRUE(fit$strict_ok))stop("Log density requires a strict fit")
    distinct <- reference$eal_design_list(X)
    if (distinct) {
      stopifnot(length(X) == 2L, is.list(fit$beta), length(fit$beta) == 2L,
        all(vapply(seq_len(2L), function(j) is.matrix(X[[j]]) &&
          is.numeric(X[[j]]) && all(is.finite(X[[j]])) &&
          is.numeric(fit$beta[[j]]) && is.null(dim(fit$beta[[j]])) &&
          ncol(X[[j]]) == length(fit$beta[[j]]) &&
          all(is.finite(fit$beta[[j]])), logical(1L))),
        nrow(X[[1L]]) == nrow(X[[2L]]))
    } else stopifnot(is.matrix(fit$beta), ncol(fit$beta) == 2L,
      all(is.finite(fit$beta)), is.matrix(X), is.numeric(X), all(is.finite(X)),
      ncol(X) == nrow(fit$beta))
    stopifnot(length(fit$copula)==1L,fit$copula%in%c("gaussian","clayton","student_t","frank","gumbel"),length(fit$degree)==1L,
      fit$degree==3L,length(fit$p)==1L,is.finite(fit$p),fit$p>0,fit$p<1,
      is.matrix(fit$shape),identical(dim(fit$shape),c(2L*as.integer(fit$degree)-1L,2L)),
      all(is.finite(fit$shape)),length(fit$sigma)==2L,
      all(is.finite(fit$sigma)),all(fit$sigma>0),
      length(fit$theta)==1L,is.finite(fit$theta),
      if(fit$copula%in%c("gaussian","student_t"))abs(fit$theta)<1 else
        if(fit$copula=="frank")TRUE else if(fit$copula=="gumbel")fit$theta>=1 else fit$theta>0,
      is.matrix(Y),is.numeric(Y),all(is.finite(Y)),ncol(Y)==2L,
      nrow(Y)==nrow(reference$eal_margin_design(X, 1L)),nrow(Y)>0L)
    residual <- sweep(Y-reference$eal_location(X, fit$beta),2L,fit$sigma,"/")
    terms <- lapply(1:2,function(j)density$eal_terms(residual[,j],fit$p,
      fit$shape[,j],fit$degree,derivatives=FALSE))
    if(fit$copula=="student_t")stopifnot(length(fit$df)==1L,is.finite(fit$df),fit$df>0)
    dependence <- if(fit$copula=="gaussian")
      reference$eal_gaussian_terms(terms[[1]],terms[[2]],fit$theta,FALSE) else
      if(fit$copula=="clayton")reference$eal_clayton_terms(terms[[1]]$logF,terms[[2]]$logF,fit$theta) else
      reference$eal_additional_copula_terms(terms[[1]],terms[[2]],fit$theta,fit$copula,fit$df,FALSE)
    out <- terms[[1]]$logdensity+terms[[2]]$logdensity+dependence$logc-sum(log(fit$sigma))
    if(any(!is.finite(out)))stop("Nonfinite exact joint predictive log density")
    out
  }
  engine$baseline_fit <- baseline_fit
  engine$fit <- model$fit
  engine$propose_starts <- model$propose_starts
  engine$prepare_baseline <- model$prepare_baseline
  engine$controls <- reference$improved_eal_control
  engine$extra_controls <- outer$eal_multistart_control
  engine$density <- density
  engine$reference_density <- reference
  engine$ref_density <- reference
  engine$log_density <- log_density
  engine$private <- private
  engine$multistart_private <- outer
  engine$version <- "degree3_bivariate_distinct_design_eal_package_20260916"
  engine
}
