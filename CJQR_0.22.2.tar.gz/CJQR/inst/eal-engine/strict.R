# Multistart search and independent numerical certification for degree-3 EAL fits.
.improved_legacy_fit <- fit_eal

improved_eal_control <- function(control = list()) {
  ctl <- modifyList(list(maxit = 1200L, starts = 3L,
    strict_gradient_tolerance = 1e-6, knot_tolerance = 1e-7,
    factr = 100, pgtol = 1e-7, retry_maxit = 800L,
    continuation_maxit = 600L, exact_subgradient_iterations = 80L,
    recovery_maxit = 300L, failure_recovery = TRUE,
    objective_replay_tolerance = 1e-10,
    lower_candidate_gap_tolerance = 1e-7,
    directional_improvement_tolerance = 1e-9,
    directional_radii = c(1e-6, 1e-5, 1e-4),
    maximum_challengers = 2L), control)
  stopifnot(ctl$strict_gradient_tolerance > 0,
    ctl$strict_gradient_tolerance <= 1e-6,
    ctl$knot_tolerance > 0, ctl$objective_replay_tolerance > 0,
    ctl$lower_candidate_gap_tolerance > 0,
    ctl$directional_improvement_tolerance > 0,
    all(is.finite(ctl$directional_radii)), all(ctl$directional_radii > 0),
    ctl$maximum_challengers >= 0L, ctl$maximum_challengers <= 2L)
  ctl
}

improved_eal_certificate <- function(problem, par, reported_objective,
                                     control = list(), probes = TRUE) {
  ctl <- improved_eal_control(control)
  fail <- function(reason) list(strict_local_ok = FALSE, reason_codes = reason,
    objective = Inf, kkt = Inf, objective_replay_gap = Inf,
    directional_check = FALSE, max_directional_improvement = Inf,
    best_probe = NULL, probe_count = 0L, nonfinite_probe_count = 0L, boundary = integer(),
    dependence_boundary = FALSE, scale_boundary = FALSE, shape_boundary = FALSE)
  if (!is.numeric(par) || length(par) != length(problem$par) ||
      any(!is.finite(par))) return(fail("nonfinite_parameter"))
  if (any(par < problem$lower | par > problem$upper))
    return(fail("parameter_out_of_bounds"))
  ee <- tryCatch(problem$evaluate(par, TRUE, smooth_epsilon = 0), error = function(e) NULL)
  if (is.null(ee) || !is.finite(ee$value) || any(!is.finite(ee$gradient)))
    return(fail("nonfinite_exact_objective_or_gradient"))
  ss <- tryCatch(problem$stationarity(par, ctl$knot_tolerance), error = function(e) NULL)
  if (is.null(ss)) return(fail("exact_stationarity_evaluation_error"))
  gap <- abs(ee$value - reported_objective)
  replay_ok <- is.finite(gap) && gap <= ctl$objective_replay_tolerance * (1 + abs(ee$value))
  kkt_ok <- is.finite(ss$kkt) && ss$kkt <= ctl$strict_gradient_tolerance
  boundary <- which(abs(par - problem$lower) < 1e-5 | abs(par - problem$upper) < 1e-5)
  best <- ee$value; best_par <- NULL; probe_count <- nonfinite_probe_count <- 0L
  if (probes && replay_ok && kkt_ok) {
    # Unit movements are in whitened coefficient/log-scale/shape/link space,
    # relative to max(1,abs(parameter)). All axes and fixed mixed directions
    # are checked in both signs, not only coefficient directions at knots.
    q <- length(par); parameter_scale <- pmax(1, abs(par))
    mix <- cbind(sin(seq_len(q)), cos(seq_len(q)), sin(seq_len(q) * sqrt(2)))
    mix <- sweep(mix, 2L, sqrt(colSums(mix^2)), "/")
    directions <- cbind(diag(q), mix)
    adjusted <- ss$gradient
    if (is.numeric(adjusted) && length(adjusted) == q &&
        all(is.finite(adjusted)) && sum(adjusted^2) > 0)
      directions <- cbind(directions, adjusted / sqrt(sum(adjusted^2)))
    for (radius in ctl$directional_radii) for (a in seq_len(ncol(directions)))
      for (sgn in c(-1, 1)) {
        trial <- pmin(problem$upper, pmax(problem$lower,
          par + sgn * radius * parameter_scale * directions[, a]))
        fv <- tryCatch(problem$evaluate(trial, FALSE, smooth_epsilon = 0)$value,
                       error = function(e) Inf)
        probe_count <- probe_count + 1L
        if (!is.finite(fv)) nonfinite_probe_count <- nonfinite_probe_count + 1L
        if (is.finite(fv) && fv < best) { best <- fv; best_par <- trial }
      }
  }
  improvement <- ee$value - best
  directional_ok <- probes && replay_ok && kkt_ok &&
    improvement <= ctl$directional_improvement_tolerance
  reasons <- c(if (!replay_ok) "objective_replay_mismatch",
    if (!kkt_ok) "exact_KKT_above_1e_6",
    if (isTRUE(ss$wrong_way_knots > 0L)) "wrong_way_quantile_cusp",
    if (probes && replay_ok && kkt_ok && !directional_ok) "exact_directional_descent",
    if (!probes) "directional_probes_not_run")
  list(strict_local_ok = replay_ok && kkt_ok && directional_ok,
    reason_codes = reasons, objective = ee$value, kkt = ss$kkt,
    objective_replay_gap = gap, directional_check = directional_ok,
    max_directional_improvement = improvement, best_probe = best_par,
    best_probe_objective = best, probe_count = probe_count,
    nonfinite_probe_count = nonfinite_probe_count,
    boundary = boundary, dependence_boundary = any(problem$idx_theta %in% boundary),
    scale_boundary = any(problem$idx_scale %in% boundary),
    shape_boundary = any(problem$idx_shape %in% boundary),
    state = ss, evaluation = ee)
}

improved_eal_materialize <- function(template, problem, par, certificate = NULL) {
  pp <- problem$unpack(par); pp$alpha <- NULL
  out <- template
  for (nm in names(pp)) out[[nm]] <- pp[[nm]]
  # A screened candidate can be materialized after other branches fail, when
  # the template is empty. Its distribution metadata must still be complete.
  out$copula <- problem$copula
  out$dependence_link <- problem$dependence_link
  out$dependence_bounds <- problem$dependence_bounds
  out$n <- problem$n; out$d <- problem$d
  ee <- problem$evaluate(par, TRUE, smooth_epsilon = 0)
  out$parameter <- par; out$objective <- ee$value
  out$loglik <- ee$loglik; out$penalty <- ee$penalty
  out$max_abs_gradient <- max(abs(ee$gradient))
  if (!is.null(certificate)) {
    ss <- certificate$state
    out$stationarity <- certificate$kkt
    out$quantile_knots <- if (is.null(ss$knots)) 0L else ss$knots
    out$max_abs_projected_gradient <- if (is.null(ss$raw)) Inf else ss$raw
    out$boundary <- certificate$boundary
    out$dependence_boundary <- certificate$dependence_boundary
    out$directional_check <- certificate$directional_check
    out$max_directional_improvement <- certificate$max_directional_improvement
  }
  out$improved_internal_candidates <- NULL
  out$recovery_candidates <- NULL
  out
}

improved_fit_eal <- function(X, Y, P, beta_init, sigma_init, p, degree = 3L,
                             copula = "clayton", control = list()) {
  stopifnot(length(copula) == 1L, copula %in% c("gaussian", "clayton","student_t","frank","gumbel"), length(degree) == 1L,
    is.finite(degree), degree == 3L)
  ctl <- improved_eal_control(control)
  started <- proc.time()[3L]
  # This fresh problem is independent of every branch's optimizer/cache.
  problem <- eal_problem(X, Y, P, beta_init, sigma_init, p, degree, copula,
                         control = ctl)
  branches <- list(); candidate_pool <- list(); certificates <- list()
  total_counts <- c("function" = 0, gradient = 0)
  branch_errors <- list()
  append_candidate <- function(par, reported, label, kind) {
    if (!is.numeric(par) || length(par) != length(problem$par) || any(!is.finite(par))) return()
    if(any(par<problem$lower|par>problem$upper))return()
    ee <- tryCatch(problem$evaluate(par, FALSE, smooth_epsilon = 0), error = function(e) NULL)
    if (is.null(ee) || !is.finite(ee$value)) return()
    candidate_pool[[length(candidate_pool) + 1L]] <<- list(par = par,
      value = ee$value, reported = reported, branch = label, kind = kind)
  }
  run_branch <- function(label, init = NULL, starts = 1L, al_warm = FALSE) {
    branch_ctl <- modifyList(ctl, list(starts = starts, al_warm_start = al_warm))
    t0 <- proc.time()[3L]
    f <- tryCatch(.improved_legacy_fit(X, Y, P, beta_init, sigma_init, p,
      degree, copula, init = init, control = branch_ctl), error = function(e) e)
    if (inherits(f, "error")) {
      branch_errors[[label]] <<- conditionMessage(f)
      return(invisible(NULL))
    }
    f$branch_wall_seconds <- unname(proc.time()[3L] - t0)
    branches[[label]] <<- f
    total_counts <<- total_counts + f$counts
    append_candidate(f$parameter, f$objective, label, "terminal")
    for (a in f$improved_internal_candidates)
      append_candidate(a$par, a$value, label, "internal")
    for (a in f$recovery_candidates)
      append_candidate(a$par, a$value, label, "recovery")
    cc <- improved_eal_certificate(problem, f$parameter, f$objective, ctl)
    certificates[[label]] <<- cc
    if (!is.null(cc$best_probe)) append_candidate(cc$best_probe,
      cc$best_probe_objective, label, "directional_probe")
    invisible(f)
  }
  zero <- problem$unpack(problem$par); zero$alpha <- NULL
  run_branch("AL_warm_three_start", starts = 3L, al_warm = TRUE)
  run_branch("qgam_zero_shape", zero)
  ka <- nrow(zero$shape)
  shape_a <- zero; shape_b <- zero
  # Fixed non-collinear enrichment starts.
  shape_a$shape <- .5 * matrix(sin(seq_len(2L * ka)), ka, 2L)
  shape_b$shape <- .5 * matrix(cos(seq_len(2L * ka) * sqrt(2)), ka, 2L)
  shape_a$shape[] <- pmin(problem$upper[problem$idx_shape],
    pmax(problem$lower[problem$idx_shape],as.vector(shape_a$shape)))
  shape_b$shape[] <- pmin(problem$upper[problem$idx_shape],
    pmax(problem$lower[problem$idx_shape],as.vector(shape_b$shape)))
  run_branch("qgam_shape_sine_half", shape_a)
  run_branch("qgam_shape_cosine_half", shape_b)
  independence <- tryCatch(.improved_legacy_fit(X, Y, P, beta_init, sigma_init, p,
    degree, "independence", control = modifyList(ctl,
      list(starts = 3L, al_warm_start = TRUE))), error = function(e) e)
  independence_error <- NULL
  if (inherits(independence, "error")) {
    independence_error <- conditionMessage(independence)
    independence <- NULL
    branch_errors[["independence_start_joint"]] <- independence_error
  } else {
    total_counts <- total_counts + independence$counts
    run_branch("independence_start_joint", independence)
  }
  if (length(candidate_pool)) {
    best <- candidate_pool[[which.min(vapply(candidate_pool, `[[`, numeric(1), "value"))]]
    reset <- problem$unpack(best$par); reset$alpha <- NULL; reset$beta <- beta_init
    run_branch("best_nuisance_qgam_location_reset", reset)
  }
  if (!length(candidate_pool) || !length(branches))
    stop("No finite EAL branch candidate: ", paste(unlist(branch_errors), collapse = "; "))
  template <- branches[[1L]]
  best_pool <- function() candidate_pool[[which.min(vapply(candidate_pool, `[[`, numeric(1), "value"))]]
  best_observed_objective <- function() {
    reported <- vapply(branches, function(x) x$best_candidate_objective, numeric(1))
    min(best_pool()$value, reported[is.finite(reported)])
  }
  choose_terminal <- function() {
    ids <- which(vapply(certificates, function(x) isTRUE(x$strict_local_ok), logical(1)))
    if (!length(ids)) return(NULL)
    labels <- names(certificates)[ids]
    label <- labels[which.min(vapply(certificates[labels], `[[`, numeric(1), "objective"))]
    list(label = label, fit = branches[[label]], certificate = certificates[[label]])
  }
  challengers <- 0L
  for (j in seq_len(as.integer(ctl$maximum_challengers))) {
    best <- best_pool(); selected <- choose_terminal()
    selected_value <- if (is.null(selected)) Inf else selected$certificate$objective
    # A failed local probe is itself retained in the pool and challenged too.
    needed <- is.null(selected) ||
      selected_value - best_observed_objective() > ctl$lower_candidate_gap_tolerance
    if (!needed) break
    start <- problem$unpack(best$par); start$alpha <- NULL
    challengers <- challengers + 1L
    run_branch(paste0("lower_candidate_challenger_", challengers), start)
  }
  best <- best_pool(); selected <- choose_terminal()
  best_certificate <- improved_eal_certificate(problem, best$par, best$value, ctl)
  # A numerically certified internal point is also a legitimate candidate.
  if (isTRUE(best_certificate$strict_local_ok) &&
      (is.null(selected) || best$value < selected$certificate$objective))
    selected <- list(label = paste0(best$branch, ":", best$kind),
      fit = improved_eal_materialize(template, problem, best$par, best_certificate),
      certificate = best_certificate)
  if (is.null(selected)) selected <- list(label = paste0(best$branch, ":", best$kind),
    fit = improved_eal_materialize(template, problem, best$par, best_certificate),
    certificate = best_certificate)
  # Reconstruct again for the final certificate: no optimizer/evaluation cache
  # from the search or preliminary certificate can satisfy this replay.
  final_problem <- eal_problem(X, Y, P, beta_init, sigma_init, p, degree,
                               copula, control = ctl)
  cc <- improved_eal_certificate(final_problem, selected$fit$parameter,
    selected$fit$objective, ctl)
  if (!is.null(cc$best_probe)) {
    append_candidate(cc$best_probe, cc$best_probe_objective, selected$label, "final_probe")
    best <- best_pool()
  }
  best_observed <- best_observed_objective()
  gap <- max(0, cc$objective - best_observed)
  gap_ok <- is.finite(gap) && gap <= ctl$lower_candidate_gap_tolerance
  out <- improved_eal_materialize(selected$fit, final_problem, selected$fit$parameter, cc)
  old <- eal_recovery_acceptance(final_problem, out$parameter,
    modifyList(ctl, list(strict_gradient_tolerance = 1e-5)))
  out$legacy_strict_ok <- isTRUE(old$strict_ok)
  out$strict_ok <- isTRUE(cc$strict_local_ok) && gap_ok
  out$convergence <- if (out$strict_ok) 0L else 1L
  out$convergence_basis <- "independent_exact_KKT_multiradius_probe_lower_candidate_certificate"
  out$message <- if (out$strict_ok) "Improved numerical certificate passed" else
    paste(c(cc$reason_codes, if (!gap_ok) "unresolved_lower_candidate"), collapse = "; ")
  out$strict_gradient_tolerance <- ctl$strict_gradient_tolerance
  out$lower_unconverged_objective_gap <- gap
  out$best_candidate_objective <- best_observed
  out$elapsed <- unname(proc.time()[3L] - started)
  out$counts <- total_counts
  out$counts_scope <- "Optimizer search requests, including independence; excludes certificate and replay evaluations"
  clean_certificate <- function(x) { x$evaluation <- NULL; x$state <- NULL; x }
  out$improved_certificate <- clean_certificate(cc)
  # This is a gap to the observed search pool, not proof of global optimality.
  out$improved_certificate$observed_candidate_gap <- gap
  out$improved_certificate$observed_candidate_gap_ok <- gap_ok
  out$improved_certificate$reason_codes <- c(cc$reason_codes,
    if (!gap_ok) "unresolved_lower_candidate")
  out$improved_selected_branch <- selected$label
  out$improved_control <- ctl
  out$improved_branch_errors <- branch_errors
  out$improved_branch_certificates <- lapply(certificates, clean_certificate)
  out$improved_branch_log <- do.call(rbind, lapply(names(branches), function(label) {
    f <- branches[[label]]; z <- certificates[[label]]
    data.frame(label = label, objective = f$objective,
      reported_best_internal = f$best_candidate_objective,
      legacy_branch_strict = isTRUE(f$strict_ok), strict_local = isTRUE(z$strict_local_ok),
      exact_KKT = z$kkt, probe_improvement = z$max_directional_improvement,
      elapsed = f$branch_wall_seconds, dependence_boundary = z$dependence_boundary,
      shape_boundary = z$shape_boundary, scale_boundary = z$scale_boundary,
      reason_codes = paste(z$reason_codes, collapse = ";"), stringsAsFactors = FALSE)
  }))
  out$improved_candidate_log <- do.call(rbind, lapply(candidate_pool, function(a)
    data.frame(branch = a$branch, kind = a$kind, objective = a$value,
      reported_objective = a$reported, stringsAsFactors = FALSE)))
  out$improved_candidate_parameters <- do.call(cbind, lapply(candidate_pool, `[[`, "par"))
  out$improved_branch_parameters <- do.call(cbind, lapply(branches, `[[`, "parameter"))
  out$improved_joint_branch_count <- length(branches)
  out$improved_challenger_count <- challengers
  out$improved_independence <- if (is.null(independence)) list(error = independence_error) else
    list(objective = independence$objective, strict_ok = independence$strict_ok,
      stationarity = independence$stationarity, elapsed = independence$elapsed)
  best_finite <- improved_eal_materialize(template, final_problem, best$par)
  out$best_finite_fit <- list(beta = best_finite$beta, sigma = best_finite$sigma,
    shape = best_finite$shape, theta = best_finite$theta, degree = degree, p = p,
    parameter = best$par, objective = best$value, branch = best$branch, kind = best$kind)
  out$improved_version <- "scenario2_truth_blind_search_certificate_v1_20260911"
  class(out) <- "eal_copula_fit"
  out
}
