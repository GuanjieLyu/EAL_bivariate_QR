# EAL numerical engine

This directory contains CJQR's fixed-anchor EAL likelihood and optimization
engine. The package layer prepares spline bases and Gaussian-REML penalties,
obtains `qgam` initial values, compares fitting levels and constructs
predictions. The engine accepts these fixed design and penalty matrices.

## Mathematical basis

The density uses normalized squared-Laguerre enrichment of the
asymmetric-Laplace distribution, following the construction described by
D'Haen, Van Keilegom and Verhasselt in
[Quantile regression under dependent censoring with unknown association](https://arxiv.org/abs/2410.05069),
Section 3.1. CJQR uses degree three, with five free enrichment coordinates
per margin, and enforces normalization and continuity at the fitting quantile.

Fitted enrichment polynomials may have roots. Root-free configurations are
preferred among some starting candidates but are not imposed as constraints
on the fitted density. The ordinary asymmetric-Laplace density is a nested
submodel.

The modules were developed for the CJQR simulation studies and subsequently
integrated into the package. They are maintained with the package source;
no simulation directory or external checkpoint is needed at runtime.

## Modules

| File | Responsibility |
|---|---|
| `density_reference.R` | Reference density, distribution and enrichment calculations |
| `density_fast.R` | Cached density calculations and analytic marginal derivatives |
| `copula_terms.R` | Copula log densities and scores, including log-tail evaluation |
| `numerical.R` | Joint objective, parameter transformations and derivative assembly |
| `strict.R` | Exact-likelihood refinement and numerical convergence checks |
| `multistart.R` | Deterministic candidate starts and optimization search |
| `load_engine.R` | Private engine environment and source loading |

One common regression design or two distinct designs may be supplied. In
either case, each margin has its own coefficients and fixed penalty matrix.
Scales, enrichment and copula dependence are constant.

## Copula parameterization

| Copula | Inverse link | Default search range |
|---|---|---|
| Gaussian | `rho = tanh(delta)` | `[-0.995, 0.995]` |
| Student-t | `rho = tanh(delta)` | `[-0.995, 0.995]`, fixed `df > 0` |
| Clayton | `theta = exp(delta)` | `[0.005, 30]` |
| Frank | `theta = delta` | `[-30, 30]` |
| Gumbel | `theta = 1 + exp(delta)` | `[1 + exp(-17), 30]` |

Search bounds are configurable numerical limits, not modifications of the
link functions. The internal independence kernel is used for initialization.
A finite-df Student-t copula with zero correlation is not treated as
independent.

Copula calculations use log-CDF and log-survival tails where needed. Frank
uses its independence limit and reflection for negative dependence. Gumbel
retains the log-log representation in upper tails. Student-t calculations
use scaled quadratic forms and logarithmic tail asymptotics when direct
quantile evaluation overflows. Extreme ill-conditioning can still exceed
floating-point precision.

## Optimization and validation

The optimizer uses multiple starts, temporary cusp smoothing, exact-likelihood
refinement and subgradient calculations. The final acceptance checks use
the unsmoothed likelihood. They require a scaled stationarity measure at most
`1e-6`, local directional checks and no unresolved observed candidate with
an objective improvement exceeding `1e-7` on the normalized scale.
Boundary flags and candidate failures are retained.

These are local and observed-search-pool checks, not proof of a global
optimum or inferential regularity. The engine does not supply a likelihood
covariance matrix.

Regression tests under `tests/testthat/` cover density normalization, AL
nesting, quantile identities, analytic derivatives, copula tails, distinct
design dimensions and numerical failure handling. Engine instances record
hashes of their runtime source files. Validation records should identify
the package version, dependency versions and executed tests; earlier
simulation results are not guarantees for other sampling designs.
