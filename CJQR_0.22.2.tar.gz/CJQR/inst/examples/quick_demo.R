# Fit, inspect and predict from a joint EAL model.
# Sourcing this example runs the full optimizer and can take several minutes.
library(CJQR)

dat <- cjqr_example_data(n = 200, seed = 1)
fit <- cjqr_eal(
  list(y1 ~ z + s(x, k = 6), y2 ~ z + s(x, k = 6)),
  data = dat, copula = "gaussian", anchors = 0.5,
  seed = 1, progress = TRUE
)

print(summary(fit))
print(cjqr_fit_diagnostics(fit))
grid <- data.frame(x = seq(-1, 1, length.out = 101), z = 0)
quantiles <- predict(fit, newdata = grid, probs = c(0.1, 0.5, 0.9))
print(head(quantiles[, 1, ]))
if (interactive()) {
  plot(fit, eq = 1, select = 1)  # se = TRUE: 95% pointwise smooth intervals
  plot(fit, eq = 2, select = 1)
  plot(cjqr_residual_diagnostics(fit))
}

# Optional pointwise quantile intervals use auxiliary least-squares resamples.
# Check interval availability and the common-error location assumptions.
# ci <- cjqr_eal_ci(fit, newdata = grid, probs = c(0.1, 0.5, 0.9),
#                   B = 500, seed = 2)
# print(ci)
# head(as.data.frame(ci))
