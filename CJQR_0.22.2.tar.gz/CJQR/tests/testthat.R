library(testthat)
library(CJQR)

test_check("CJQR")
