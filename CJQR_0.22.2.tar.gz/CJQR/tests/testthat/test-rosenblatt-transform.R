.rosenblatt_cases <- list(
  list(family="gaussian",theta=.7,df=NULL),
  list(family="gaussian",theta=-.7,df=NULL),
  list(family="student_t",theta=.7,df=5),
  list(family="student_t",theta=-.7,df=2.5),
  list(family="clayton",theta=2,df=NULL),
  list(family="frank",theta=5,df=NULL),
  list(family="frank",theta=-5,df=NULL),
  list(family="gumbel",theta=2,df=NULL)
)

test_that("ordered Rosenblatt probabilities agree with existing interior h-functions", {
  u <- as.matrix(expand.grid(c(.02,.1,.4,.7,.98),c(.03,.2,.5,.8,.97)))
  lf <- log(u);ls <- log1p(-u)
  for(case in .rosenblatt_cases) {
    h <- CJQR:::.cjqr_copula_hfunc(u[,1],u[,2],case$theta,case$family,case$df)
    for(order in list(c(1L,2L),c(2L,1L))) {
      a <- CJQR:::.cjqr_rosenblatt_transform(lf,ls,case$theta,case$family,case$df,order)
      wanted <- if(order[1L]==1L)cbind(u[,1],h$h21)else cbind(u[,2],h$h12)
      expect_equal(unname(a$uniform),unname(wanted),tolerance=3e-12)
      expect_equal(unname(exp(a$logF)+exp(a$logS)),matrix(1,nrow(u),2L),tolerance=1e-13)
      expect_equal(unname(a$normal),unname(qnorm(wanted)),tolerance=2e-10)
      # Reordering the inputs gives exactly the other ordered transform.
      b <- CJQR:::.cjqr_rosenblatt_transform(lf[,order],ls[,order],case$theta,case$family,case$df)
      expect_identical(a,b)
    }
  }
})

test_that("elliptical transforms have the exact conditional normal and t distributions", {
  z <- matrix(c(-4,1,.5,-2,3,4,0,0,-1,-3),ncol=2,byrow=TRUE)
  lf <- pnorm(z,log.p=TRUE);ls <- pnorm(z,lower.tail=FALSE,log.p=TRUE)
  rho <- c(-.8,-.2,0,.3,.9)
  a <- CJQR:::.cjqr_rosenblatt_transform(lf,ls,rho,"gaussian")
  expect_equal(a$normal[,1],z[,1],tolerance=1e-12)
  expect_equal(a$normal[,2],(z[,2]-rho*z[,1])/sqrt(1-rho^2),tolerance=1e-12)
  for(df in c(.5,1,2.5,5,30,1000)) {
    a <- CJQR:::.cjqr_rosenblatt_transform(lf,ls,rho,"student_t",df)
    t <- qt(pnorm(z),df)
    h <- pt((t[,2]-rho*t[,1])/sqrt((df+t[,1]^2)*(1-rho^2)/(df+1)),df+1)
    expect_equal(a$uniform[,2],h,tolerance=1e-11)
  }
  # A finite-df t copula with rho=0 is NOT the independence copula.
  u <- matrix(c(.95,.8),nrow=1)
  a <- CJQR:::.cjqr_rosenblatt_transform(log(u),log1p(-u),0,"student_t",5)
  expect_gt(abs(a$uniform[1,2]-.8),.01)
})

test_that("independence boundaries preserve both complete marginal log tails", {
  z <- matrix(c(-40,-12,12,40,9,-9,.2,-.4),ncol=2,byrow=TRUE,
    dimnames=list(paste0("r",1:4),c("left","right")))
  lf <- pnorm(z,log.p=TRUE);ls <- pnorm(z,lower.tail=FALSE,log.p=TRUE)
  for(family in c("gaussian","clayton","frank","gumbel")) {
    theta <- if(family=="gumbel")1 else 0
    a <- CJQR:::.cjqr_rosenblatt_transform(lf,ls,theta,family)
    expect_identical(a$logF,lf)
    expect_identical(a$logS,ls)
    expect_equal(a$normal,z,tolerance=1e-12)
    expect_identical(dimnames(a$normal),dimnames(z))
    b <- CJQR:::.cjqr_rosenblatt_transform(lf,ls,theta,family,order=c(2,1))
    expect_identical(b$logF,lf[,2:1])
    expect_equal(b$normal,z[,2:1],tolerance=1e-12)
  }
})

test_that("tail scores are retained without fixed probability clipping", {
  z <- matrix(c(-12,-10,-8,9,10,12,11,-9,.1,.2,-40,-38,38,40),ncol=2,byrow=TRUE)
  lf <- pnorm(z,log.p=TRUE);ls <- pnorm(z,lower.tail=FALSE,log.p=TRUE)
  for(case in .rosenblatt_cases) {
    a <- CJQR:::.cjqr_rosenblatt_transform(lf,ls,case$theta,case$family,case$df)
    expect_true(all(is.finite(unlist(a))))
    expect_equal(a$normal[,1],z[,1],tolerance=1e-11)
    expect_true(any(abs(a$normal[,2])>8))
    expect_true(all(a$logF<=0 & a$logS<=0))
    expect_equal(exp(a$logF)+exp(a$logS),matrix(1,nrow(z),2),tolerance=1e-12)
    # Rounded probabilities at the representation boundary are permitted;
    # their log tails still supply finite, uncensored normal residuals.
    expect_true(any(a$uniform[,1]%in%c(0,1)))
  }
  # These t quantiles exceed sqrt(double.xmax); scaling avoids squaring them.
  z <- matrix(c(-80,-79,80,79),ncol=2,byrow=TRUE)
  a <- CJQR:::.cjqr_rosenblatt_transform(pnorm(z,log.p=TRUE),
    pnorm(z,lower.tail=FALSE,log.p=TRUE),.7,"student_t",5)
  expect_true(all(is.finite(a$normal)))
  expect_equal(a$normal[,1],z[,1],tolerance=1e-10)
})

test_that("Archimedean log-tail formulas retain underflow-sized upper tails", {
  # exp(-1000) is zero numerically, but its log tail is known exactly.
  lf <- rbind(c(log(.4),0),c(0,0),c(-1000,-1001))
  ls <- rbind(c(log(.6),-1000),c(-1000,-1001),c(0,0))
  for(case in .rosenblatt_cases[5:8]) {
    a <- CJQR:::.cjqr_rosenblatt_transform(lf,ls,case$theta,case$family)
    expect_true(all(is.finite(unlist(a))))
    expect_equal(a$normal[,1],c(qnorm(.4),qnorm(-1000,log.p=TRUE,lower.tail=FALSE),
      qnorm(-1000,log.p=TRUE)),tolerance=1e-12)
    expect_true(a$logS[1,2] < -900)
  }
})

test_that("near-independence parameters are continuous and vectorized", {
  u <- matrix(c(.1,.8,.3,.2,.7,.9,.95,.6),ncol=2,byrow=TRUE)
  lf <- log(u);ls <- log1p(-u)
  for(family in c("clayton","frank","gumbel")) {
    th <- if(family=="gumbel")1+c(0,1e-12,1e-9,1e-7)else c(0,1e-12,1e-9,1e-7)
    a <- CJQR:::.cjqr_rosenblatt_transform(lf,ls,th,family)
    expect_equal(a$uniform,u,tolerance=2e-7)
    for(i in 1:4) {
      b <- CJQR:::.cjqr_rosenblatt_transform(lf[i,,drop=FALSE],ls[i,,drop=FALSE],th[i],family)
      expect_equal(a$normal[i,],as.numeric(b$normal),tolerance=1e-12)
    }
    if(family=="frank") {
      b <- CJQR:::.cjqr_rosenblatt_transform(lf,ls,-th,family)
      expect_equal(b$uniform,u,tolerance=2e-7)
    }
  }
})

test_that("Frank sign reflection and Archimedean stable formulas match analytic probabilities", {
  u <- matrix(c(.1,.3,.3,.95,.9,.7),ncol=2,byrow=TRUE)
  for(th in c(.001,.5,5,40)) {
    positive <- CJQR:::.cjqr_rosenblatt_transform(log(cbind(u[,1],1-u[,2])),
      log1p(-cbind(u[,1],1-u[,2])),th,"frank")
    negative <- CJQR:::.cjqr_rosenblatt_transform(log(u),log1p(-u),-th,"frank")
    expect_equal(negative$logF[,2],positive$logS[,2],tolerance=1e-12)
    expect_equal(negative$logS[,2],positive$logF[,2],tolerance=1e-12)
  }
  for(th in c(.01,.5,2,15)) {
    a <- CJQR:::.cjqr_rosenblatt_transform(log(u),log1p(-u),th,"clayton")
    value <- (1+u[,1]^th*(u[,2]^(-th)-1))^(-(1+th)/th)
    expect_equal(a$uniform[,2],value,tolerance=1e-12)
  }
  for(th in c(1.01,1.5,2,10)) {
    x <- -log(u[,1]);y <- -log(u[,2]);t <- (x^th+y^th)^(1/th)
    value <- exp(x-t)*(x/t)^(th-1)
    a <- CJQR:::.cjqr_rosenblatt_transform(log(u),log1p(-u),th,"gumbel")
    expect_equal(a$uniform[,2],value,tolerance=1e-12)
  }
})

test_that("invalid tails, order, parameters and genuine numeric failures are explicit", {
  lf <- log(matrix(c(.2,.7,.4,.8),ncol=2));ls <- log1p(-exp(lf))
  transform <- CJQR:::.cjqr_rosenblatt_transform
  expect_error(transform(lf,ls,0,"student_t"),"df")
  expect_error(transform(lf,ls,0,"gaussian",5),"df")
  for(df in list(0,-1,Inf,NA_real_,c(2,5),5+0i,matrix(5,1,1)))
    expect_error(transform(lf,ls,0,"student_t",df),"df")
  for(order in list(c(1,1),c(1,3),1,c(1,NA),c("1","2")))
    expect_error(transform(lf,ls,0,"gaussian",order=order),"order")
  expect_error(transform(as.numeric(lf),ls,0,"gaussian"),"matrices")
  expect_error(transform(lf+0i,ls,0,"gaussian"),"matrices")
  expect_error(transform(lf,ls[1,,drop=FALSE],0,"gaussian"),"matrices")
  expect_error(transform(lf,ls+1,0,"gaussian"),"nonpositive|complementary")
  expect_error(transform(lf,matrix(-1,2,2),0,"gaussian"),"complementary")
  bad <- lf;bad[1]<--Inf
  expect_error(transform(bad,ls,0,"gaussian"),"finite")
  expect_error(transform(lf,ls,c(0,0,0),"gaussian"),"theta")
  expect_error(transform(lf,ls,matrix(0,1,1),"gaussian"),"theta")
  expect_error(transform(lf,ls,0+0i,"gaussian"),"theta")
  expect_error(transform(lf,ls,0,"gaussian",order=matrix(1:2,1,2)),"order")
  expect_error(transform(lf,ls,0,"gaussian",order=c(1,2)+0i),"order")
  expect_error(transform(lf,ls,1,"gaussian"),"lie in")
  expect_error(transform(lf,ls,-1,"clayton"),"lie in")
  expect_error(transform(lf,ls,.9,"gumbel"),"lie in")
  extreme <- matrix(c(-1e6,-1e6),nrow=1)
  expect_error(transform(extreme,matrix(0,1,2),.5,"student_t",.1),"representable.*range")
})

test_that("known-copula simulations yield uniform and decorrelated Rosenblatt pairs", {
  cases <- c(.rosenblatt_cases,list(list(family="student_t",theta=0,df=5)))
  n <- 5000L
  for(k in seq_along(cases)) {
    case <- cases[[k]]
    set.seed(1919200L+k)
    uv <- CJQR:::.cjqr_simulate_copula_uv(n,case$theta,case$family,case$df)
    for(order in list(c(1L,2L),c(2L,1L))) {
      a <- CJQR:::.cjqr_rosenblatt_transform(log(uv),log1p(-uv),
        case$theta,case$family,case$df,order)
      expect_lt(max(abs(colMeans(a$uniform)-.5)),.02)
      expect_lt(max(abs(apply(a$uniform,2,var)-1/12)),.012)
      expect_lt(max(abs(colMeans(a$normal))),.06)
      expect_lt(max(abs(apply(a$normal,2,sd)-1)),.06)
      expect_lt(abs(cor(a$normal[,1],a$normal[,2])),.06)
      expect_lt(abs(cor(a$normal[,1]^2,a$normal[,2]^2)),.075)
      for(j in 1:2) {
        u <- sort(a$uniform[,j])
        distance <- max(seq_len(n)/n-u,u-(seq_len(n)-1)/n)
        expect_lt(distance,.035)
      }
    }
    if(case$family=="student_t" && case$theta==0) {
      raw <- qnorm(uv)
      expect_gt(cor(raw[,1]^2,raw[,2]^2),.08)
    }
  }
})
