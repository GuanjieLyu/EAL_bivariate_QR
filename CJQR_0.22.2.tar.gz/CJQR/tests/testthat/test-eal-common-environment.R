test_that("equal observed designs do not merge distinct formula environments", {
  # h(x) agrees at observed 0/1 but not at a future .5. Syntax and columns
  # alone cannot establish that a single prediction design is appropriate.
  e1 <- new.env(parent = globalenv()); e1$h <- function(x) x
  e2 <- new.env(parent = globalenv()); e2$h <- function(x) x^2
  f1 <- stats::as.formula("y1 ~ h(x)", env = e1)
  f2 <- stats::as.formula("y2 ~ h(x)", env = e2)
  d <- data.frame(x = rep(0:1, 30),
    y1 = sin(seq_len(60)) + rep(0:1, 30),
    y2 = cos(seq_len(60)) - rep(0:1, 30))
  valid <- CJQR:::.cjqr_eal_validate_data(list(f1, f2), d, stats::na.fail)
  prep <- CJQR:::.cjqr_eal_prepare(valid)
  expect_false(prep$common_basis)
  expect_identical(unname(prep$X[[1]]), unname(prep$X[[2]]))
  fixture <- structure(list(X = prep$X, Y = prep$Y, basis = prep$basis,
    data = valid$data, covariates = valid$covariates, responses = valid$responses,
    degree = 3L, selection = list(strict_ok = TRUE),
    fit = list(strict_ok = TRUE, beta = list(c(0, 1), c(0, 1)))), class = "cjqr_eal")
  # Explicit coefficients are an engineering fixture, not fitted evidence.
  expect_equal(unname(predict(fixture, data.frame(x = .5), type = "location")),
               matrix(c(.5, .25), 1L, 2L), tolerance = 0)
  restored <- unserialize(serialize(fixture, NULL))
  expect_equal(unname(predict(restored, data.frame(x = .5), type = "location")),
               matrix(c(.5, .25), 1L, 2L), tolerance = 0)
  expect_identical(ls(e1), "h")
  expect_identical(ls(e2), "h")
  expect_equal(e1$h(.5), .5, tolerance = 0)
  expect_equal(e2$h(.5), .25, tolerance = 0)
})

test_that("shared local transformation retains common-matrix predictions after serialization", {
  env <- new.env(parent = baseenv())
  env$h <- eval(quote(function(x) x^2), baseenv())
  env$sentinel <- "caller-owned"
  before <- as.list(env, all.names = TRUE)
  formulas <- list(stats::as.formula("y1 ~ h(x)", env = env),
                   stats::as.formula("y2 ~ h(x)", env = env))
  d <- data.frame(x = rep(0:1, 30),
    y1 = sin(seq_len(60)) + rep(0:1, 30),
    y2 = cos(seq_len(60)) - rep(0:1, 30))
  valid <- CJQR:::.cjqr_eal_validate_data(formulas, d, stats::na.fail)
  prep <- CJQR:::.cjqr_eal_prepare(valid)
  expect_true(prep$common_basis)
  expect_true(is.matrix(prep$X))
  fixture <- structure(list(X = prep$X, Y = prep$Y, basis = prep$basis,
    data = valid$data, covariates = valid$covariates, responses = valid$responses,
    degree = 3L, selection = list(strict_ok = TRUE),
    fit = list(strict_ok = TRUE, beta = matrix(c(0, 1, 0, 2), 2L, 2L))),
    class = "cjqr_eal")
  target <- matrix(c(.25, .5), 1L, 2L)
  expect_equal(unname(predict(fixture, data.frame(x = .5), type = "location")),
               target, tolerance = 0)
  restored <- unserialize(serialize(fixture, NULL))
  expect_equal(unname(predict(restored, data.frame(x = .5), type = "location")),
               target, tolerance = 0)
  for (j in 1:2) {
    g <- prep$basis[[j]]
    reference <- environment(valid$formulas[[j]])
    for (nm in c("formula", "pred.formula", "terms", "pterms")) {
      if (!is.null(g[[nm]])) expect_identical(environment(g[[nm]]), reference)
    }
    if (!is.null(attr(g$model, "terms")))
      expect_identical(environment(attr(g$model, "terms")), reference)
    if (!is.null(attr(g$pred.formula, "full")))
      expect_identical(environment(attr(g$pred.formula, "full")), reference)
  }
  expect_identical(as.list(env, all.names = TRUE), before)
  expect_identical(environment(formulas[[1L]]), env)
  expect_identical(environment(formulas[[2L]]), env)
})

test_that("native qgam initialization preserves a local transformation and its caller", {
  skip_if_not_installed("qgam", minimum_version = "2.0.0")
  env <- new.env(parent = baseenv())
  env$h <- eval(quote(function(x) x + x^2 / 4), baseenv())
  env$sentinel <- "caller-owned"
  before <- as.list(env, all.names = TRUE)
  formula <- stats::as.formula("y ~ h(x)", env = env)
  x <- seq(-.95, .95, length.out = 120L)
  data <- data.frame(x = x,
    y = .2 + .7 * env$h(x) + sin(seq_along(x) * 2.31) / 3 +
      cos(seq_along(x) * .71) / 7)
  newdata <- data.frame(x = c(-.4, .2, .7))
  native <- CJQR:::.cjqr_eal_qgam_native(formula, data, .5, newdata, 614L)
  expect_true(native$ok, info = paste(vapply(native$attempts, `[[`, "", "error"),
                                     collapse = "; "))
  if (!isTRUE(native$ok)) return(invisible(NULL))
  expect_true(isTRUE(native$fit$converged))
  expect_true(all(is.finite(native$prediction)))
  Xnew <- cbind(1, env$h(newdata$x))
  expected <- drop(Xnew %*% stats::coef(native$fit))
  expect_equal(unname(native$prediction), unname(expected), tolerance = 1e-12)
  expect_true(isTRUE(tail(native$attempts, 1L)[[1L]]$ok))
  restored <- unserialize(serialize(native$fit, NULL))
  expect_equal(as.numeric(stats::predict(restored, newdata, type = "response")),
               unname(expected), tolerance = 1e-12)
  expect_identical(as.list(env, all.names = TRUE), before)
  expect_identical(environment(formula), env)
})
