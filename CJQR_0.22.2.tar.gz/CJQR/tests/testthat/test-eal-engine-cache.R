test_that("installed engine caching never shares mutable private state", {
  get_engine <- CJQR:::.cjqr_eal_engine
  first <- get_engine("gaussian"); second <- get_engine("gaussian")
  expect_false(identical(first$private, second$private))
  expect_false(identical(first$density, second$density))
  expect_false(identical(environment(first$prepare_baseline),
    environment(second$prepare_baseline)))
  first_registry <- environment(first$prepare_baseline)$registry
  second_registry <- environment(second$prepare_baseline)$registry
  expect_false(identical(first_registry, second_registry))
  first_registry$caller_mutation <- TRUE
  expect_identical(ls(second_registry, all.names = TRUE), character())
  first$private$.eal_default_copula <- "frank"
  first$density$eal_quantile <- function(...) stop("mutated caller")
  third <- get_engine("gaussian")
  expect_identical(second$private$.eal_default_copula, "gaussian")
  expect_identical(third$private$.eal_default_copula, "gaussian")
  expect_equal(third$density$eal_quantile(.5, .5, rep(0, 5L), 3L), 0)
  expect_identical(first$manifest, second$manifest)
  expect_identical(ls(environment(third$prepare_baseline)$registry, all.names = TRUE), character())
})

test_that("cached engine results are independent of family and call order", {
  get_engine <- CJQR:::.cjqr_eal_engine
  X <- cbind(1, seq(-1, 1, length.out = 11L))
  Y <- cbind(sin(seq_len(11L)), cos(seq_len(11L)))
  args <- list(X = X, Y = Y, P = rep(list(diag(c(0, .2))), 2L),
    beta_init = matrix(0, 2L, 2L), sigma_init = c(.7, .8), p = .5)
  families <- c("gaussian", "clayton", "student_t", "frank", "gumbel")
  results <- list()
  set.seed(3981)
  rng <- .Random.seed
  for (family in c(families, rev(families))) {
    engine <- get_engine(family)
    expect_identical(engine$default_copula, family)
    ctl <- if(family == "student_t") list(df = 5) else list()
    problem <- do.call(engine$problem, c(args, list(control = ctl)))
    original <- problem$evaluate(problem$par)
    moved <- problem$par; moved[1L] <- moved[1L] + .2
    problem$evaluate(moved)
    other <- do.call(engine$problem, c(args, list(control = ctl)))
    expect_false(identical(environment(problem$evaluate), environment(other$evaluate)))
    expect_identical(original, other$evaluate(other$par))
    if (is.null(results[[family]])) results[[family]] <- original else
      expect_identical(original, results[[family]])
  }
  expect_identical(.Random.seed, rng)
  # df is fixed by each problem, never retained as template state.
  engine <- get_engine("student_t")
  low <- do.call(engine$problem, c(args, list(control = list(df = .5))))
  high <- do.call(engine$problem, c(args, list(control = list(df = 30))))
  expect_identical(low$unpack(low$par)$df, .5)
  expect_identical(high$unpack(high$par)$df, 30)
  expect_false(identical(low$evaluate(low$par)$value, high$evaluate(high$par)$value))
  expect_error(do.call(engine$problem, args))
})

test_that("explicit engine directories bypass the installed cache", {
  cache <- CJQR:::.cjqr_eal_engine_cache
  before <- serialize(as.list(cache, all.names = TRUE), NULL)
  path <- system.file("eal-engine", package = "CJQR")
  first <- CJQR:::.cjqr_eal_engine("frank", directory = path)
  second <- CJQR:::.cjqr_eal_engine("frank", directory = path)
  expect_identical(serialize(as.list(cache, all.names = TRUE), NULL), before)
  expect_false(identical(first$private, second$private))
  expect_identical(first$manifest, second$manifest)
})

test_that("a stale installed-engine signature cannot return a stale template", {
  cache <- CJQR:::.cjqr_eal_engine_cache
  engine <- CJQR:::.cjqr_eal_engine("frank")
  original <- cache[["frank"]]
  on.exit(cache[["frank"]] <- original, add = TRUE)
  for (part in c("package_version", "source_md5", "directory", "R_version")) {
    stale <- original
    stale$signature[[part]] <- "invalidated-by-test"
    engine$version <- "stale-template-must-not-be-used"
    stale$template <- serialize(engine, NULL, version = 3L)
    cache[["frank"]] <- stale
    fresh <- CJQR:::.cjqr_eal_engine("frank")
    expect_false(identical(fresh$version, "stale-template-must-not-be-used"))
    expect_identical(cache[["frank"]]$signature, original$signature)
  }
})
