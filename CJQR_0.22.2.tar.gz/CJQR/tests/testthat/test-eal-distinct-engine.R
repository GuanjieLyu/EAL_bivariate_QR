# Unequal-dimensional design checks deliberately load the source explicitly.
# This permits development validation before installing the new package and
# does not exercise or weaken any numerical acceptance gate.
.cjqr_distinct_test_engine <- function(copula = "gaussian") {
  directory <- Sys.getenv("CJQR_TEST_ENGINE_DIRECTORY", unset = "")
  if (!nzchar(directory)) directory <- system.file("eal-engine", package = "CJQR")
  scope <- new.env(parent = asNamespace("stats"))
  sys.source(file.path(directory, "load_engine.R"), scope)
  scope$load_cjqr_eal_engine(directory, copula)
}

.cjqr_distinct_fixture <- function(n = 29L, intercept_only = FALSE) {
  x <- seq(-.85, .95, length.out = n)
  X <- list(first = if (intercept_only) matrix(1, n, 1L) else cbind(1, x),
    second = cbind(1, x^2, sin(2 * x), cos(3 * x)))
  beta <- list(if (intercept_only) .2 else c(.2, .4), c(-.1, .3, .2, -.12))
  mu <- cbind(drop(X[[1L]] %*% beta[[1L]]), drop(X[[2L]] %*% beta[[2L]]))
  residual <- cbind(.8 * sin(seq_len(n) * .71) + .17,
    .9 * cos(seq_len(n) * 1.11) - .23)
  P <- list(if (intercept_only) matrix(0, 1L, 1L) else diag(c(0, .4)),
    diag(c(0, .3, .8, .6)))
  list(X = X, Y = mu + residual, beta_init = beta, P = P,
    sigma_init = c(.7, .9), mu = mu)
}

test_that("distinct designs use exact represented dimensions for every copula", {
  fixture <- .cjqr_distinct_fixture()
  args <- fixture[setdiff(names(fixture), "mu")]
  cases <- list(list(family = "gaussian", theta = -.55),
    list(family = "clayton", theta = 1.7),
    list(family = "student_t", theta = -.45, df = 5),
    list(family = "frank", theta = -5), list(family = "frank", theta = 5),
    list(family = "gumbel", theta = 1.8))
  for (case in cases) {
    engine <- .cjqr_distinct_test_engine(case$family)
    control <- list(theta_init = case$theta)
    if (!is.null(case$df)) control$df <- case$df
    for (p in c(.25, .5, .75)) {
      problem <- do.call(engine$problem, c(args, list(p = p, control = control)))
      reference <- do.call(engine$reference_problem, c(args,
        list(p = p, copula = case$family, control = control)))
      expect_identical(problem$d, c(2L, 4L))
      expect_identical(problem$idx_beta, 1:6)
      expect_length(problem$par, 19L)
      state <- problem$unpack(problem$par)
      expect_type(state$beta, "list")
      expect_equal(state$beta, fixture$beta_init, tolerance = 2e-15)
      expect_equal(engine$predict_anchor(state, fixture$X), fixture$mu, tolerance = 2e-15)
      for (j in 1:2) {
        expect_equal(drop(problem$X[[j]] %*% state$alpha[[j]]),
          fixture$mu[, j], tolerance = 2e-15)
        expect_identical(dim(problem$Rinv[[j]]), rep(problem$d[j], 2L))
      }
      parameter <- problem$par
      parameter[problem$idx_shape] <- .07 * cos(seq_along(problem$idx_shape))
      state <- problem$unpack(parameter)
      for (epsilon in c(0, .003)) {
        actual <- problem$evaluate(parameter, TRUE, epsilon)
        expect_identical(actual, reference$evaluate(parameter, TRUE, epsilon))
        fd <- vapply(seq_along(parameter), function(k) {
          plus <- minus <- parameter
          plus[k] <- plus[k] + 1e-6; minus[k] <- minus[k] - 1e-6
          (problem$evaluate(plus, FALSE, epsilon)$value -
            problem$evaluate(minus, FALSE, epsilon)$value) / 2e-6
        }, numeric(1L))
        expect_lt(max(abs(fd - actual$gradient) / (1 + abs(actual$gradient))), 2e-7)
      }
      fit <- state; fit$copula <- case$family
      ll <- sum(engine$log_density(fit, fixture$X, fixture$Y, require_strict = FALSE))
      penalty <- .5 * sum(vapply(1:2, function(j)
        drop(crossprod(state$beta[[j]], fixture$P[[j]] %*% state$beta[[j]])), numeric(1L)))
      actual <- problem$evaluate(parameter)
      expect_equal(actual$loglik, ll, tolerance = 1e-12)
      expect_equal(actual$penalty, penalty, tolerance = 1e-12)
      expect_equal(actual$value, (-ll + penalty) / nrow(fixture$Y), tolerance = 1e-12)
      cert <- engine$certificate(problem, parameter, actual$value)
      expect_true(is.list(cert))
      expect_identical(isTRUE(cert$strict_local_ok), FALSE)
    }
  }
})

test_that("explicit equal designs agree with the retained common-matrix path", {
  fixture <- .cjqr_distinct_fixture()
  X <- fixture$X[[2L]]
  beta <- cbind(c(.2, .1, -.3, .2), fixture$beta_init[[2L]])
  P <- list(fixture$P[[2L]], fixture$P[[2L]] * 1.3)
  engine <- .cjqr_distinct_test_engine()
  common <- engine$problem(X, fixture$Y, P, beta, fixture$sigma_init, .5,
    control = list(theta_init = .45))
  distinct <- engine$problem(list(X, X), fixture$Y, P,
    list(beta[, 1L], beta[, 2L]), fixture$sigma_init, .5,
    control = list(theta_init = .45))
  expect_identical(common$d, 4L)
  expect_true(is.matrix(common$unpack(common$par)$beta))
  expect_identical(distinct$d, c(4L, 4L))
  expect_equal(distinct$par, common$par, tolerance = 1e-15)
  expect_equal(distinct$evaluate(distinct$par)$value,
    common$evaluate(common$par)$value, tolerance = 1e-14)
  expect_equal(distinct$evaluate(distinct$par)$gradient,
    common$evaluate(common$par)$gradient, tolerance = 1e-14)
  expect_equal(engine$predict_anchor(distinct$unpack(distinct$par), list(X, X)),
    engine$predict_anchor(common$unpack(common$par), X), tolerance = 1e-14)
})

test_that("distinct knot subgradients and active-face recovery respect each block", {
  fixture <- .cjqr_distinct_fixture(n = 17L)
  fixture$Y[1L, 1L] <- fixture$mu[1L, 1L]
  fixture$Y[2:3, 2L] <- fixture$mu[2:3, 2L]
  args <- fixture[setdiff(names(fixture), "mu")]
  engine <- .cjqr_distinct_test_engine()
  problem <- do.call(engine$problem, c(args, list(p = .5, control = list(theta_init = .35))))
  state <- problem$stationarity(problem$par)
  expect_identical(state$knots, 3L)
  expect_identical(state$knot_margin, c(1L, 2L, 2L))
  expect_identical(state$knot_observation, 1:3)
  expect_identical(dim(state$subgradient_matrix), c(19L, 3L))
  for (k in seq_len(state$knots)) {
    j <- state$knot_margin[k]; i <- state$knot_observation[k]
    rows <- if (j == 1L) 1:2 else 3:6
    expect_identical(state$subgradient_matrix[-rows, k], rep(0, 19L - length(rows)))
    expect_equal(state$subgradient_matrix[rows, k],
      -problem$X[[j]][i, ] / (problem$n * fixture$sigma_init[j]), tolerance = 1e-12)
  }
  scope <- environment(problem$evaluate)
  # A single exact-face iteration is sufficient to exercise block geometry,
  # Hessian directions, line searches and candidate rechecking without a fit.
  recovery <- get("recover_eal", envir = scope)(problem, problem$par,
    list(recovery_maxit = 1L))
  expect_length(recovery$par, 19L)
  expect_true(is.finite(recovery$value))
  expect_lte(recovery$value, problem$evaluate(problem$par)$value + 1e-12)
  polish <- get("eal_exact_subgradient_polish", envir = scope)(problem, problem$par,
    list(maxit = 2L))
  expect_length(polish$par, 19L)
  expect_true(is.finite(polish$value))
  expect_lte(polish$value, problem$evaluate(problem$par)$value + 1e-12)
  fit <- engine$private$improved_eal_materialize(list(), problem, problem$par)
  expect_identical(fit$d, c(2L, 4L))
  expect_type(fit$beta, "list")
  expect_identical(fit$copula, "gaussian")
})

test_that("distinct starts, intercept-only margins, and invalid dimensions are handled", {
  fixture <- .cjqr_distinct_fixture(n = 19L, intercept_only = TRUE)
  args <- fixture[setdiff(names(fixture), "mu")]
  engine <- .cjqr_distinct_test_engine()
  problem <- do.call(engine$problem, c(args, list(p = .5)))
  expect_identical(problem$d, c(1L, 4L))
  expect_length(problem$unpack(problem$par)$beta[[1L]], 1L)
  expect_equal(engine$predict_anchor(problem$unpack(problem$par), fixture$X), fixture$mu,
    tolerance = 1e-14)
  starts <- do.call(engine$propose_starts, c(args, list(p = .5, refine = FALSE)))
  expect_true(is.list(starts))
  expect_true(length(starts) > 0L)
  bad <- args; bad$X[[2L]] <- bad$X[[2L]][-1L, , drop = FALSE]
  expect_error(do.call(engine$problem, c(bad, list(p = .5))))
  bad <- args; bad$beta_init[[2L]] <- bad$beta_init[[2L]][-1L]
  expect_error(do.call(engine$problem, c(bad, list(p = .5))))
  bad <- args; bad$P[[2L]] <- diag(3L)
  expect_error(do.call(engine$problem, c(bad, list(p = .5))))
  bad <- args; bad$X[[2L]][1L, 1L] <- NA_real_
  expect_error(do.call(engine$problem, c(bad, list(p = .5))))
  expect_error(engine$predict_anchor(problem$unpack(problem$par),
    list(fixture$X[[1L]], fixture$X[[2L]][-1L, , drop = FALSE])))
})
