test_that("all copula simulators accept one parameter per row", {
  cases <- list(
    gaussian = list(theta = c(0.2, 0.7), df = NULL),
    student_t = list(theta = c(0.15, 0.65), df = 4),
    clayton = list(theta = c(0.5, 3), df = NULL),
    frank = list(theta = c(-5, 5), df = NULL),
    gumbel = list(theta = c(1.25, 2.2), df = NULL)
  )
  block_n <- 800L

  for (family in names(cases)) {
    case <- cases[[family]]
    theta <- rep(case$theta, each = block_n)
    set.seed(1210L + match(family, names(cases)))
    uv <- CJQR:::.cjqr_simulate_copula_uv(
      length(theta), theta, family, df = case$df
    )
    expect_equal(dim(uv), c(2L * block_n, 2L), info = family)
    expect_true(all(is.finite(uv) & uv > 0 & uv < 1), info = family)
    expect_equal(unname(colMeans(uv)), c(0.5, 0.5),
                 tolerance = 0.04, info = family)
    for (block in 1:2) {
      rows <- ((block - 1L) * block_n + 1L):(block * block_n)
      empirical <- stats::cor(
        uv[rows, 1L], uv[rows, 2L], method = "kendall"
      )
      target <- CJQR:::.cjqr_kendall_tau(
        case$theta[[block]], family, df = case$df
      )
      # Monte Carlo error is on the absolute tau scale, not relative to tau.
      expect_lt(abs(empirical - target), 0.10)
    }
  }

  expect_error(
    CJQR:::.cjqr_simulate_copula_uv(
      5L, c(0.1, 0.2), "gaussian"
    ),
    "one finite copula parameter or one finite parameter per row"
  )
})
