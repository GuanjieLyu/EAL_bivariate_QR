test_that("the EAL engine loads without attaching packages or changing state", {
  before <- search()
  globals <- ls(globalenv(), all.names = TRUE)
  rng <- if (exists(".Random.seed", globalenv(), inherits = FALSE))
    get(".Random.seed", globalenv()) else NULL
  engine <- CJQR:::.cjqr_eal_engine("gaussian")
  expect_identical(search(), before)
  expect_identical(ls(globalenv(), all.names = TRUE), globals)
  expect_identical(if (exists(".Random.seed", globalenv(), inherits = FALSE))
    get(".Random.seed", globalenv()) else NULL, rng)
  expect_identical(engine$supported_degrees, 3L)
  expect_identical(engine$default_copula, "gaussian")
  expect_identical(parent.env(engine$reference_density), asNamespace("stats"))
  expect_identical(parent.env(engine$density), asNamespace("stats"))
  for (family in c("frank", "gumbel", "student_t"))
    expect_identical(CJQR:::.cjqr_eal_engine(family)$default_copula, family)
  expect_identical(CJQR:::.cjqr_eal_engine("student")$default_copula, "student_t")
  expect_error(CJQR:::.cjqr_eal_engine("not_a_family"))
})

test_that("degree-three EAL density has the original normalization and anchor", {
  engine <- CJQR:::.cjqr_eal_engine("gaussian")
  density <- engine$density
  shape <- .15 * sin(seq_len(5L))
  spec <- density$eal_shape(shape, 3L)
  expect_equal(sum(spec$left$a^2), 1, tolerance = 1e-13)
  expect_equal(sum(spec$right$a^2), 1, tolerance = 1e-13)
  expect_equal(sum(spec$left$a), sum(spec$right$a), tolerance = 1e-13)
  points <- c(-50, -15, -3, -.2, 0, .2, 3, 15, 50)
  probs <- c(.001, .1, .25, .5, .75, .9, .999)
  laguerre <- matrix(0, 4L, 4L)
  for (k in 0:3) for (j in 0:k)
    laguerre[k + 1L, j + 1L] <- (-1)^j * choose(k, j) / factorial(j)
  tail_probability <- function(t, side) {
    coefficients <- drop(crossprod(side$a, laguerre))
    square <- numeric(7L)
    for (i in 0:3) for (j in 0:3)
      square[i + j + 1L] <- square[i + j + 1L] + coefficients[i + 1L] * coefficients[j + 1L]
    sum(square * factorial(0:6) * pgamma(t, shape = 1:7, lower.tail = FALSE)) /
      sum(side$a^2)
  }
  for (anchor in c(.25, .5, .75)) {
    expect_equal(density$eal_density(points, anchor, numeric(5L), 3L),
      anchor * (1 - anchor) * exp(-points * (anchor - (points < 0))), tolerance = 1e-13)
    expect_identical(density$eal_terms(points, anchor, shape, 3L),
      engine$reference_density$eal_terms(points, anchor, shape, 3L))
    quantiles <- density$eal_quantile(probs, anchor, shape, 3L)
    expect_true(all(diff(quantiles) > 0))
    expect_identical(density$eal_quantile(anchor, anchor, shape, 3L), 0)
    expect_equal(density$eal_cdf(quantiles, anchor, shape, 3L), probs, tolerance = 1e-8)
    independent <- vapply(quantiles, function(q) if (q < 0)
      anchor * tail_probability((1 - anchor) * abs(q), spec$left) else
      1 - (1 - anchor) * tail_probability(anchor * q, spec$right), numeric(1L))
    expect_equal(independent, probs, tolerance = 1e-8)
  }
})

test_that("both copulas preserve exact objective, analytic gradient and bounds", {
  n <- 40L
  x <- seq(-.97, .93, length.out = n)
  X <- cbind(1, rep(0:1, length.out = n), x, x^2)
  beta <- matrix(seq(-.12, .16, length.out = 8L), 4L, 2L)
  Y <- X %*% beta + cbind(sin(seq_len(n) * .73) + .17,
    cos(seq_len(n) * 1.11) - .23)
  P <- list(diag(c(0, 0, .8, 1.1)), diag(c(0, 0, 1.2, .5)))
  sigma <- c(.7, .9)
  for (copula in c("gaussian", "clayton")) {
    engine <- CJQR:::.cjqr_eal_engine(copula)
    expect_identical(engine$controls()$strict_gradient_tolerance, 1e-6)
    expect_identical(engine$controls()$lower_candidate_gap_tolerance, 1e-7)
    expect_identical(engine$extra_controls()$joint_branches, 4L)
    for (anchor in c(.25, .5, .75)) {
      arguments <- list(X = X, Y = Y, P = P, beta_init = beta,
        sigma_init = sigma, p = anchor, degree = 3L,
        control = list(theta_init = if (copula == "gaussian") -.6 else 2))
      fast <- do.call(engine$problem, arguments)
      ref <- do.call(engine$reference_problem, c(arguments, list(copula = copula)))
      expect_identical(fast$copula, copula)
      par <- ref$par
      par[ref$idx_shape] <- .15 * sin(seq_len(length(ref$idx_shape)))
      for (epsilon in c(0, .003, 1e-8))
        expect_identical(fast$evaluate(par, TRUE, epsilon), ref$evaluate(par, TRUE, epsilon))
      analytic <- ref$evaluate(par, TRUE, 0)$gradient
      h <- 1e-6
      finite_difference <- vapply(seq_along(par), function(j) {
        plus <- minus <- par
        plus[j] <- plus[j] + h
        minus[j] <- minus[j] - h
        (ref$evaluate(plus, FALSE, 0)$value - ref$evaluate(minus, FALSE, 0)$value) / (2 * h)
      }, numeric(1L))
      expect_lt(max(abs(analytic - finite_difference)), 2e-5)
      fitted_state <- ref$unpack(par)
      fitted_state$copula <- copula
      fitted_state$strict_ok <- TRUE
      expect_equal(sum(engine$log_density(fitted_state, X, Y)),
        ref$evaluate(par, FALSE, 0)$loglik, tolerance = 1e-10)
      expect_identical(ref$dependence_link,
        if (copula == "gaussian") "rho=tanh(delta)" else "theta=exp(delta)")
      expect_equal(ref$dependence_bounds,
        if (copula == "gaussian") c(-.995, .995) else c(.005, 30), tolerance = 0)
      fitted_state$strict_ok <- FALSE
      expect_error(engine$log_density(fitted_state, X, Y), "strict fit")
      expect_error(do.call(engine$fit, modifyList(arguments, list(degree = 4L))))
      expect_error(do.call(engine$problem, modifyList(arguments, list(copula = "not_a_family"))))
    }
  }
})

test_that("numerical acceptance is not inferred from finite parameters alone", {
  engine <- CJQR:::.cjqr_eal_engine("gaussian")
  X <- cbind(1, seq(-1, 1, length.out = 20L))
  beta <- matrix(0, 2L, 2L)
  Y <- cbind(sin(seq_len(20L)), cos(seq_len(20L)))
  problem <- engine$problem(X, Y, list(matrix(0, 2L, 2L), matrix(0, 2L, 2L)),
    beta, c(1, 1), .5)
  value <- problem$evaluate(problem$par, FALSE, 0)$value
  certificate <- engine$certificate(problem, problem$par, value + 1)
  expect_false(certificate$strict_local_ok)
  expect_true("objective_replay_mismatch" %in% certificate$reason_codes)
  expect_error(engine$controls(list(strict_gradient_tolerance = 1e-5)))
  expect_error(engine$extra_controls(list(joint_branches = 5L)))
})
