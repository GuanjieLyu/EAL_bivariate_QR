test_that("free smoothing parameters follow mgcv shared and tensor mappings", {
  skip_if_not_installed("mgcv")
  set.seed(914L)
  n <- 80L
  data <- data.frame(
    x = runif(n), z = runif(n), y = rnorm(n),
    .cjqr_case_weight = rep(1, n)
  )
  blueprint <- function(formula) {
    setup <- mgcv::gam(
      formula, data = data, weights = data$.cjqr_case_weight,
      family = stats::gaussian(), method = "REML", fit = FALSE
    )
    CJQR:::.cjqr_penalty_blueprint(setup)
  }

  separate <- blueprint(y ~ s(x, k = 5) + s(z, k = 5))
  shared <- blueprint(y ~ s(x, k = 5, id = 1) +
                        s(z, k = 5, id = 1))
  tensor <- blueprint(y ~ te(x, z, k = c(4, 4)))
  formula_fixed <- blueprint(y ~ s(x, k = 5, sp = 0.3) +
                               s(z, k = 5))

  expect_equal(length(separate$raw), 2L)
  expect_equal(length(separate$free_labels), 2L)
  expect_identical(shared$mapping$free_sp_index, c(1L, 1L))
  expect_identical(shared$mapping$sp_group_index, c(1L, 1L))
  expect_equal(length(shared$free_labels), 1L)
  expect_equal(length(tensor$raw), 2L)
  expect_identical(tensor$mapping$free_sp_index, c(1L, 2L))
  expect_equal(length(tensor$free_labels), 2L)
  expect_true(formula_fixed$mapping$formula_fixed[[1L]])
  expect_true(is.na(formula_fixed$mapping$free_sp_index[[1L]]))
  expect_equal(length(formula_fixed$free_labels), 1L)

  expected_columns <- c(
    "component", "smooth_index", "smooth", "penalty_index",
    "full_sp_index", "free_sp_index", "sp_group_index",
    "coefficient_first", "coefficient_last", "rank", "fixed",
    "formula_fixed"
  )
  expect_named(tensor$mapping, expected_columns, ignore.order = FALSE)

  # These are the same shared/tensor basis mappings used by EAL preparation.
  # No retired AL fitter or smoothing-control API is involved.
  for (b in list(separate, shared, tensor, formula_fixed)) {
    sp <- seq_along(b$raw) / 10
    reconstructed <- CJQR:::.cjqr_sum_penalty_components(b$raw, sp, b$p)
    direct <- Reduce("+", Map(function(S, lambda) lambda * S, b$raw, sp))
    expect_equal(reconstructed, direct, tolerance = 1e-12)
    expect_equal(reconstructed, t(reconstructed), tolerance = 1e-12)
    expect_equal(reconstructed[1L, ], rep(0, b$p))
  }
})
