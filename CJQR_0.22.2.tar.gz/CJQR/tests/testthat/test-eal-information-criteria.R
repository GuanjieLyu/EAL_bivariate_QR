# Synthetic, fully recorded fixtures exercise numerical identities and safety
# checks; their stored certificates are not empirical optimization validation.
.eal_ic_fixture <- function(copula = "gaussian") {
  n <- 180L
  x <- seq(-1, 1, length.out = n)
  z <- sin(seq_len(n) * sqrt(2))
  X <- list(cbind("(Intercept)" = 1, z = z, x = x, x2 = x^2),
    cbind("(Intercept)" = 1, z = z, x = x, x2 = x^2, x3 = x^3))
  beta <- list(c(.1, .2, -.3, .15), c(-.2, .1, .2, -.1, .08))
  residual <- cbind(2 * sin(seq_len(n) * 1.73) + .017,
    2 * cos(seq_len(n) * 2.13) - .029)
  sigma <- c(.7, .8)
  Y <- CJQR:::.cjqr_eal_location(X, beta) + sweep(residual, 2L, sigma, "*")
  colnames(Y) <- c("y1", "y2")
  rownames(Y) <- as.character(seq_len(n))
  fit <- list(beta = beta, sigma = sigma,
    shape = matrix(c(-.35, .07, .03, -.04, .02,
      -.28, .08, -.02, .03, .01), 5L, 2L),
    p = .35, degree = 3L, copula = copula,
    theta = switch(copula, gaussian = .4, student_t = -.3,
      clayton = 1.2, frank = -3, gumbel = 1.5),
    df = if (copula == "student_t") 5 else NULL,
    strict_ok = TRUE, stationarity = 2e-9,
    strict_gradient_tolerance = 1e-6, lower_unconverged_objective_gap = 0,
    improved_control = list(strict_gradient_tolerance = 1e-6,
      objective_replay_tolerance = 1e-10, lower_candidate_gap_tolerance = 1e-7,
      directional_improvement_tolerance = 1e-9),
    improved_certificate = list(strict_local_ok = TRUE, kkt = 2e-9,
      objective_replay_gap = 0, directional_check = TRUE,
      max_directional_improvement = 0, probe_count = 100L,
      nonfinite_probe_count = 0L, observed_candidate_gap = 0,
      observed_candidate_gap_ok = TRUE, boundary = integer(),
      dependence_boundary = FALSE, scale_boundary = FALSE, shape_boundary = FALSE))
  object <- structure(list(X = X, Y = Y,
    P = list(diag(c(0, 0, 2, 3)), diag(c(0, 0, 2, 3, 4))),
    fit = fit, basis = lapply(1:2, function(j) list(smooth = list(list(
      label = "s(x)", first.para = 3L, last.para = ncol(X[[j]]))))),
    data = data.frame(y1 = Y[, 1L], y2 = Y[, 2L], z = z, x = x),
    formulas = list(y1 ~ z + x, y2 ~ z + x),
    covariates = c("z", "x"), margin_covariates = list(c("z", "x"), c("z", "x")),
    kept_rows = seq_len(n), omitted_rows = integer(), original_n = n,
    responses = c("y1", "y2"), copula = copula, df = fit$df,
    degree = 3L, anchor = fit$p, anchors = fit$p,
    selection = list(strict_ok = TRUE, index = 1L, unresolved_gap = 0),
    control = list()), class = "cjqr_eal")
  .eal_ic_replay_fixture(object)
}

.eal_ic_replay_fixture <- function(object) {
  object$fit$loglik <- sum(CJQR:::.cjqr_eal_engine(object$copula)$log_density(
    object$fit, object$X, object$Y))
  object$fit$penalty <- sum(vapply(1:2, function(j) {
    b <- CJQR:::.cjqr_eal_betas(object$fit$beta)[[j]]
    drop(crossprod(b, object$P[[j]] %*% b)) / 2
  }, numeric(1L)))
  object$fit$objective <- (-object$fit$loglik + object$fit$penalty) / nrow(object$Y)
  object$fit$improved_certificate$objective <- object$fit$objective
  object$selection$audit <- data.frame(anchor = object$anchor,
    initialized = TRUE, strict = TRUE, objective = object$fit$objective,
    known_minimum = object$fit$objective)
  object
}

.eal_ic_dense_penalty <- function(object, score) {
  q <- ncol(score$score)
  P <- matrix(0, q, q)
  for (j in 1:2) P[score$beta_indices[[j]], score$beta_indices[[j]]] <- object$P[[j]]
  P
}

test_that("EAL information criteria use the full conditional OPG trace and raw likelihood", {
  for (family in c("gaussian", "student_t", "clayton", "frank", "gumbel")) {
    o <- .eal_ic_fixture(family)
    expect_identical(CJQR:::.cjqr_eal_summary_convergence(o)$status, "converged")
    ans <- cjqr_eal_ic(o, warn = FALSE)
    sc <- CJQR:::.cjqr_eal_joint_score(o)
    J <- crossprod(sc$score)
    expected_df <- sum(diag(solve(J + .eal_ic_dense_penalty(o, sc), J)))
    expected_ll <- sum(CJQR:::.cjqr_eal_engine(family)$log_density(o$fit, o$X, o$Y))
    expect_s3_class(ans, "cjqr_eal_ic")
    expect_equal(ans$effective_df, expected_df, tolerance = 1e-8)
    expect_equal(ans$logLik, expected_ll, tolerance = 1e-12)
    expect_equal(ans$parameter_dimension, 22L)
    expect_equal(ans$nobs, 180L)
    expect_identical(ans$method, "conditional-opg")
    expect_true(ans$conditional)
    expect_gt(length(ans$assumptions), 0L)
    expect_equal(ans$AIC, -2 * expected_ll + 2 * expected_df, tolerance = 1e-8)
    expect_equal(ans$BIC, -2 * expected_ll + log(180) * expected_df, tolerance = 1e-8)
    expect_equal(AIC(o, warn = FALSE), ans$AIC)
    expect_equal(BIC(o, warn = FALSE), ans$BIC)
    expect_equal(AIC(o, k = 3, warn = FALSE), -2 * expected_ll + 3 * expected_df)
    expect_true(is.na(attr(logLik(o), "df")))
  }
})

test_that("unpenalized models recover the full finite parameter count including fixed-t conventions", {
  for (family in c("gaussian", "student_t")) {
    o <- .eal_ic_fixture(family)
    o$P <- lapply(o$P, function(P) P * 0)
    # No smooth metadata must not accidentally set total model EDF to zero.
    o$basis <- list(list(smooth = list()), list(smooth = list()))
    o <- .eal_ic_replay_fixture(o)
    ans <- cjqr_eal_ic(o, warn = FALSE)
    expect_equal(ans$effective_df, 22, tolerance = 1e-9)
    expect_equal(ans$parameter_dimension, 22)
    expect_equal(ans$AIC, -2 * o$fit$loglik + 44, tolerance = 1e-9)
    expect_equal(ans$BIC, -2 * o$fit$loglik + log(nrow(o$Y)) * 22, tolerance = 1e-9)
  }
  o <- .eal_ic_fixture("student_t")
  first <- cjqr_eal_ic(o, warn = FALSE)
  o$df <- o$fit$df <- 8
  o <- .eal_ic_replay_fixture(o)
  expect_equal(cjqr_eal_ic(o, warn = FALSE)$parameter_dimension, first$parameter_dimension)
})

test_that("the IC OPG scores agree with independent finite differences for all five copulas", {
  for (family in c("gaussian", "student_t", "clayton", "frank", "gumbel")) {
    o <- .eal_ic_fixture(family)
    engine <- CJQR:::.cjqr_eal_engine(family)
    score <- CJQR:::.cjqr_eal_joint_score(o)$score
    par <- c(unlist(o$fit$beta), log(o$fit$sigma), as.vector(o$fit$shape),
      CJQR:::.cjqr_delta_from_theta(o$fit$theta, family))
    ld <- function(p) {
      fit <- o$fit
      fit$beta <- list(p[1:4], p[5:9])
      fit$sigma <- exp(p[10:11]); fit$shape <- matrix(p[12:21], 5L, 2L)
      fit$theta <- switch(family, gaussian =, student_t = tanh(p[22]),
        clayton = exp(p[22]), frank = p[22], gumbel = 1 + exp(p[22]))
      engine$log_density(fit, o$X, o$Y)
    }
    fd <- vapply(seq_along(par), function(k) {
      h <- 1e-6 * max(1, abs(par[k])); a <- b <- par
      a[k] <- a[k] + h; b[k] <- b[k] - h
      (ld(a) - ld(b)) / (2 * h)
    }, numeric(nrow(o$Y)))
    expect_identical(dim(score), dim(fd))
    expect_true(max(abs(unname(score) - fd)) < 2e-6, info = family)
  }
})

test_that("conditional OPG complexity agrees with a Gaussian linear-smoother limit", {
  x <- seq(-1, 1, length.out = 80L)
  X <- cbind(1, x, sin(3 * x), cos(3 * x))
  P <- diag(c(0, 0, 2, 3))
  # Gaussian known-scale expected information is X'X. The conditional OPG
  # operator reduces to the ordinary penalized least-squares hat-matrix trace.
  opg <- CJQR:::.cjqr_eal_opg_trace(X, P, list(seq_len(ncol(X))))
  hat <- X %*% solve(crossprod(X) + P, t(X))
  expect_true(opg$available)
  expect_equal(opg$diagnostics$total_edf, sum(diag(hat)), tolerance = 1e-12)
  zero <- CJQR:::.cjqr_eal_opg_trace(X, 0 * P, list(seq_len(ncol(X))))
  expect_equal(zero$diagnostics$total_edf, ncol(X), tolerance = 1e-12)
})

test_that("unsafe or inconsistent fitted models cannot receive finite EAL criteria", {
  o <- .eal_ic_fixture()
  cases <- list(
    function(x) { x$fit$strict_ok <- FALSE; x },
    function(x) { x$fit$improved_certificate <- NULL; x },
    function(x) { x$fit$improved_certificate$kkt <- .01; x },
    function(x) { x$fit$improved_certificate$shape_boundary <- TRUE; x },
    function(x) { x$fit$degree <- 2L; x },
    function(x) { x$fit$copula <- "clayton"; x },
    function(x) { x$fit$loglik <- x$fit$loglik + 1; x },
    function(x) { x$fit$penalty <- x$fit$penalty + 1; x },
    function(x) { x$fit$sigma[1] <- x$fit$sigma[1] * 1.1; x },
    function(x) { x$fit$loglik <- NA_real_; x },
    function(x) { x$P[[1]][3, 3] <- -2; .eal_ic_replay_fixture(x) },
    function(x) { x$P[[1]][1, 2] <- 1; .eal_ic_replay_fixture(x) },
    function(x) {
      x$Y[1, 1] <- drop(x$X[[1]][1, ] %*% x$fit$beta[[1]])
      .eal_ic_replay_fixture(x)
    })
  for (mutate in cases) {
    bad <- mutate(o)
    expect_error(cjqr_eal_ic(bad, warn = FALSE))
    expect_error(AIC(bad, warn = FALSE))
    expect_error(BIC(bad, warn = FALSE))
  }
  singular <- o
  singular$X[[1]][, 2] <- singular$X[[1]][, 1]
  singular <- .eal_ic_replay_fixture(singular)
  expect_error(cjqr_eal_ic(singular, warn = FALSE))
  expect_error(cjqr_eal_ic(structure(list(), class = "qgam"), warn = FALSE))
})

test_that("public criteria prominently qualify their approximation and reject malformed options", {
  o <- .eal_ic_fixture()
  expect_warning(cjqr_eal_ic(o), "[Cc]onditional|[Aa]pproxim")
  expect_warning(AIC(o), "[Cc]onditional|[Aa]pproxim")
  expect_warning(BIC(o), "[Cc]onditional|[Aa]pproxim")
  expect_silent(cjqr_eal_ic(o, warn = FALSE))
  expect_error(cjqr_eal_ic(o, warn = NA))
  expect_error(cjqr_eal_ic(o, warn = 1))
  expect_error(AIC(o, k = NA_real_, warn = FALSE))
  expect_error(AIC(o, k = c(2, 3), warn = FALSE))
  expect_error(AIC(o, k = "2", warn = FALSE))
})

test_that("different copulas compare only on the same paired data and marginal design", {
  a <- .eal_ic_fixture("gaussian")
  b <- .eal_ic_fixture("clayton")
  aa <- cjqr_eal_ic(a, warn = FALSE)
  bb <- cjqr_eal_ic(b, warn = FALSE)
  tab <- AIC(a, b, warn = FALSE)
  expect_s3_class(tab, "data.frame")
  expect_identical(names(tab), c("df", "AIC"))
  expect_equal(unname(tab$df), c(aa$effective_df, bb$effective_df))
  expect_equal(unname(tab$AIC), c(aa$AIC, bb$AIC))
  bic <- BIC(a, b, warn = FALSE)
  expect_identical(names(bic), c("df", "BIC"))
  expect_equal(unname(bic$BIC), c(aa$BIC, bb$BIC))
  bads <- list(
    function(x) { x$Y[1, 1] <- x$Y[1, 1] + .1; x },
    function(x) { x$Y <- x$Y[rev(seq_len(nrow(x$Y))), ]; x },
    function(x) { x$responses <- rev(x$responses); x },
    function(x) { x$kept_rows[1] <- 1000L; x },
    function(x) { x$anchors <- c(.25, .35, .75); x },
    function(x) { x$data$x[1] <- 2; x },
    function(x) { x$X[[1]][, 3] <- 2 * x$X[[1]][, 3]; x },
    function(x) { x$P[[1]] <- 2 * x$P[[1]]; x })
  for (change in bads) {
    expect_error(AIC(a, change(b), warn = FALSE))
    expect_error(BIC(a, change(b), warn = FALSE))
  }
  smaller <- b
  rows <- 1:170
  smaller$Y <- smaller$Y[rows, , drop = FALSE]
  smaller$X <- lapply(smaller$X, function(X) X[rows, , drop = FALSE])
  smaller$data <- smaller$data[rows, , drop = FALSE]
  smaller$kept_rows <- smaller$kept_rows[rows]
  smaller <- .eal_ic_replay_fixture(smaller)
  expect_equal(cjqr_eal_ic(smaller, warn = FALSE)$nobs, 170L)
  expect_error(AIC(a, smaller, warn = FALSE))
  expect_error(BIC(a, smaller, warn = FALSE))
  expect_error(AIC(a, structure(list(), class = "qgam"), warn = FALSE))
  expect_error(BIC(a, structure(list(), class = "qgam"), warn = FALSE))
  a$anchors <- c(.25, .35, .75)
  b$anchors <- c(.75, .35, .25)
  expect_s3_class(AIC(a, b, warn = FALSE), "data.frame")
})

test_that("named distinct marginal bases retain identical total conditional complexity", {
  o <- .eal_ic_fixture()
  baseline <- cjqr_eal_ic(o, warn = FALSE)
  names(o$X) <- names(o$fit$beta) <- names(o$P) <- o$responses
  named <- cjqr_eal_ic(o, warn = FALSE)
  expect_identical(named$logLik, baseline$logLik)
  expect_equal(named$effective_df, baseline$effective_df, tolerance = 1e-12)
  expect_equal(named$AIC, baseline$AIC, tolerance = 1e-12)
  expect_equal(named$BIC, baseline$BIC, tolerance = 1e-12)
  expect_true(CJQR:::.cjqr_eal_smooth_edf(o)$available)
})

test_that("EAL criteria are invariant to quantile reporting defaults and preserve fit and RNG", {
  o <- .eal_ic_fixture()
  original <- serialize(o, NULL)
  set.seed(9981)
  rng <- .Random.seed
  result <- cjqr_eal_ic(o, warn = FALSE)
  invisible(AIC(o, warn = FALSE))
  invisible(BIC(o, warn = FALSE))
  expect_identical(serialize(o, NULL), original)
  expect_identical(.Random.seed, rng)
  for (targets in list(c(.1, .5, .9), list(y1 = .1, y2 = .9))) {
    other <- o
    other$probs <- targets
    changed <- cjqr_eal_ic(other, warn = FALSE)
    expect_identical(changed$logLik, result$logLik)
    expect_identical(changed$effective_df, result$effective_df)
    expect_identical(changed$AIC, result$AIC)
    expect_identical(changed$BIC, result$BIC)
  }
})
