# Deterministic API fixtures: no EAL model is fitted by these tests.
.prediction_eal_fixture <- function(distinct = FALSE, copula = "gaussian") {
  x <- seq(-.8, .8, length.out = 40L)
  X <- cbind("(Intercept)" = 1, x = x)
  rownames(X) <- paste0("row", seq_along(x))
  beta <- matrix(c(.1, .7, -.2, -.4), 2L, 2L)
  if (distinct) {
    X <- list(first = X, second = cbind(X, z = x^2))
    beta <- list(c(.1, .7), c(-.2, -.4, .3))
  }
  location <- CJQR:::.cjqr_eal_location(X, beta)
  structure(list(X = X, Y = location + cbind(sin(seq_along(x)), cos(seq_along(x))),
    responses = c("first", "second"), degree = 3L, copula = copula,
    selection = list(strict_ok = TRUE), fit = list(strict_ok = TRUE,
      p = .35, beta = beta, sigma = c(.7, 1.2),
      shape = matrix(c(.05, -.03, .02, .04, -.01, -.02, .04, .01, -.03, .02), 5L, 2L))),
    class = "cjqr_eal")
}

.prediction_eal_uncached <- function(object, probs) {
  density <- CJQR:::.cjqr_eal_engine(object$copula)$density
  location <- CJQR:::.cjqr_eal_location(object$X, object$fit$beta)
  out <- array(NA_real_, c(nrow(location), 2L, length(probs)),
    dimnames = list(rownames(location), object$responses, as.character(probs)))
  for (j in 1:2) {
    q <- density$eal_quantile(probs, object$fit$p, object$fit$shape[, j], 3L)
    for (k in seq_along(probs)) out[, j, k] <- location[, j] + object$fit$sigma[j] * q[k]
  }
  out
}

test_that("cached EAL predictions exactly preserve both design representations and families", {
  set.seed(81713L)
  rng <- .Random.seed
  for (family in c("gaussian", "clayton", "student_t", "frank", "gumbel")) {
    for (distinct in c(FALSE, TRUE)) {
      object <- .prediction_eal_fixture(distinct, family)
      original <- serialize(object, NULL)
      for (probs in list(c(.9, .25, .1, .35), .5)) {
        target <- .prediction_eal_uncached(object, probs)
        expect_identical(predict(object, probs = probs), target)
        expect_identical(predict(object, probs = probs), target)
        expect_identical(fitted(object, probs = probs), target)
        restored <- unserialize(serialize(object, NULL))
        expect_identical(predict(restored, probs = probs), target)
        expect_identical(CJQR:::.cjqr_eal_predict_quantiles(object, object$X, probs), target)
      }
      expect_identical(serialize(object, NULL), original)
    }
  }
  expect_identical(.Random.seed, rng)
})

test_that("quantile cache keys include all marginal numerical specifications", {
  object <- .prediction_eal_fixture()
  cache <- CJQR:::.cjqr_eal_prediction_cache
  cache$entries <- list()
  original <- CJQR:::.cjqr_eal_engine
  calls <- 0L
  local_mocked_bindings(.cjqr_eal_engine = function(...) {
    calls <<- calls + 1L
    original(...)
  }, .package = "CJQR")
  target <- predict(object, probs = c(.1, .9))
  expect_identical(calls, 1L)
  expect_identical(predict(object, probs = c(.1, .9)), target)
  expect_identical(calls, 1L)
  object$fit$shape[1, 2] <- .12
  expect_identical(predict(object, probs = c(.1, .9)), .prediction_eal_uncached(object, c(.1, .9)))
  # The independent reference itself also loads an engine.
  expect_identical(calls, 3L)
  object$fit$p <- .45
  predict(object, probs = c(.1, .9))
  predict(object, probs = c(.9, .1))
  object$copula <- "clayton"
  predict(object, probs = c(.9, .1))
  expect_identical(calls, 6L)
  object$fit$sigma <- c(.3, 2)
  object$fit$beta[1, 1] <- 2
  predicted <- predict(object, probs = c(.9, .1))
  expect_identical(calls, 6L) # Only standardized roots are cached.
  expect_identical(predicted, .prediction_eal_uncached(object, c(.9, .1)))
})

test_that("numeric cache results cannot be mutated by the caller", {
  object <- .prediction_eal_fixture()
  cache <- CJQR:::.cjqr_eal_prediction_cache
  probs <- c(.1, .9)
  original <- CJQR:::.cjqr_eal_quantile_offsets(object, probs)
  changed <- CJQR:::.cjqr_eal_quantile_offsets(object, probs)
  changed[1, 1] <- 999
  expect_identical(CJQR:::.cjqr_eal_quantile_offsets(object, probs), original)
  for (part in c("directory", "package_version", "R_version", "source_md5")) {
    cache$signature[[part]] <- "stale"
    expect_identical(CJQR:::.cjqr_eal_quantile_offsets(object, probs), original)
    expect_false(identical(cache$signature[[part]], "stale"))
  }
})

test_that("numeric root cache has entry and per-entry memory bounds", {
  object <- .prediction_eal_fixture()
  cache <- CJQR:::.cjqr_eal_prediction_cache
  cache$entries <- list()
  calls <- 0L
  local_mocked_bindings(.cjqr_eal_engine = function(...) {
    calls <<- calls + 1L
    list(density = list(eal_quantile = function(u, ...) u, eal_cdf = function(e, ...) e))
  }, .package = "CJQR")
  for (anchor in seq(.2, .36, .01)) {
    object$fit$p <- anchor
    CJQR:::.cjqr_eal_quantile_offsets(object, .1)
  }
  expect_length(cache$entries, 16L)
  expect_identical(calls, 17L)
  expect_true(all(vapply(cache$entries, function(x) length(serialize(x, NULL)) <= 32768L, logical(1))))
  object$fit$p <- .2
  CJQR:::.cjqr_eal_quantile_offsets(object, .1)
  expect_identical(calls, 18L) # Oldest specification was evicted.
  before <- serialize(cache$entries, NULL)
  large <- seq(.01, .99, length.out = 257L)
  CJQR:::.cjqr_eal_quantile_offsets(object, large)
  CJQR:::.cjqr_eal_quantile_offsets(object, large)
  expect_identical(calls, 20L)
  expect_identical(serialize(cache$entries, NULL), before)
  attr(object$fit$shape, "large_annotation") <- rep("annotation", 4000L)
  attr(object$fit$shape, "caller_environment") <- new.env(parent = emptyenv())
  CJQR:::.cjqr_eal_quantile_offsets(object, .1)
  expect_identical(calls, 20L) # Irrelevant attributes are never retained.
  expect_identical(serialize(cache$entries, NULL), before)
})

test_that("new numerical specifications still require inverse-CDF verification", {
  object <- .prediction_eal_fixture()
  cache <- CJQR:::.cjqr_eal_prediction_cache
  cache$entries <- list()
  local_mocked_bindings(.cjqr_eal_engine = function(...) {
    list(density = list(eal_quantile = function(u, ...) u, eal_cdf = function(e, ...) e + .01))
  }, .package = "CJQR")
  expect_error(predict(object, probs = .2), "inverse-CDF verification")
  expect_length(cache$entries, 0L)
})

test_that("source replacement during root construction cannot publish a cache entry", {
  object <- .prediction_eal_fixture()
  cache <- CJQR:::.cjqr_eal_prediction_cache
  cache$entries <- list()
  reads <- 0L
  local_mocked_bindings(
    .cjqr_eal_engine_sources = function(...) {
      reads <<- reads + 1L
      if (reads == 1L) "original-source" else "replaced-source"
    },
    .cjqr_eal_engine = function(...) list(density = list(
      eal_quantile = function(u, ...) u, eal_cdf = function(e, ...) e)),
    .package = "CJQR")
  expect_error(predict(object, probs = .2), "sources changed during prediction")
  expect_length(cache$entries, 0L)
})

test_that("invalid inputs are rejected before engine work or cached lookup", {
  object <- .prediction_eal_fixture()
  predict(object, probs = .2)
  local_mocked_bindings(.cjqr_eal_engine = function(...) stop("must not load engine"),
    .package = "CJQR")
  expect_error(predict(object, probs = c(.2, .2)), "distinct finite probabilities")
  expect_error(predict(object, type = "cdf", y = matrix(NA_real_, 40L, 2L)), "finite numeric matrix")
  for (field in c("p", "shape", "sigma")) {
    bad <- object
    bad$fit[[field]][1L] <- NA_real_
    expect_error(predict(bad, probs = .2), "anchor, shapes and positive scales")
  }
  object$fit$sigma[1] <- 0
  expect_error(predict(object, probs = .2), "anchor, shapes and positive scales")
})

test_that("newdata lexical environments remain live when marginal roots are cached", {
  e1 <- new.env(parent = globalenv()); e1$h <- function(x) x
  e2 <- new.env(parent = globalenv()); e2$h <- function(x) x^2
  d <- data.frame(x = rep(0:1, 30), y1 = sin(seq_len(60)) + rep(0:1, 30),
    y2 = cos(seq_len(60)) - rep(0:1, 30))
  val <- CJQR:::.cjqr_eal_validate_data(list(
    stats::as.formula("y1 ~ h(x)", env = e1), stats::as.formula("y2 ~ h(x)", env = e2)),
    d, stats::na.fail)
  prep <- CJQR:::.cjqr_eal_prepare(val)
  object <- .prediction_eal_fixture()
  object$X <- prep$X; object$Y <- prep$Y; object$basis <- prep$basis
  object$data <- val$data; object$covariates <- val$covariates; object$responses <- val$responses
  object$fit$beta <- list(c(0, 1), c(0, 1))
  object$fit$p <- .5; object$fit$shape[] <- 0
  nd <- data.frame(x = .5)
  expect_equal(unname(predict(object, nd, probs = .5)), array(c(.5, .25), c(1L, 2L, 1L)))
  e2$h <- function(x) x^3
  expect_equal(unname(predict(object, nd, probs = .5)), array(c(.5, .125), c(1L, 2L, 1L)))
  expect_equal(unname(predict(object, nd, type = "cdf", y = matrix(c(.5, .125), 1L, 2L))),
    matrix(.5, 1L, 2L), tolerance = 1e-12)
})

test_that("coefficient interval guidance includes the supported intercept", {
  expect_error(confint(.prediction_eal_fixture(), parm = "(Intercept)"),
    "marginal parametric intervals, including intercepts", fixed = TRUE)
})
