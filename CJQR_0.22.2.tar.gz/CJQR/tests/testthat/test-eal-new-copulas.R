# Independent central-domain formulas are deliberately not the implementation
# used in the log-tail fitter. Full-objective differences also check every
# marginal, scale, shape and dependence chain-rule component.
.cjqr_test_logcopula <- function(u, v, theta, family, df = NULL) {
  if (family == "frank") {
    if (theta == 0) return(rep(0, length(u)))
    numerator <- theta * (-expm1(-theta)) * exp(-theta * (u + v))
    denominator <- -expm1(-theta) - expm1(-theta * u) * expm1(-theta * v)
    return(log(numerator / denominator^2))
  }
  if (family == "gumbel") {
    x <- -log(u); y <- -log(v)
    total <- x^theta + y^theta
    a <- total^(1 / theta)
    return(-a + (theta - 1) * (log(x) + log(y)) - log(u) - log(v) +
      (2 / theta - 2) * log(total) + log1p((theta - 1) / a))
  }
  x <- qt(u, df); y <- qt(v, df)
  quadratic <- (x^2 - 2 * theta * x * y + y^2) / (1 - theta^2)
  lgamma((df + 2) / 2) - lgamma(df / 2) - log(df * pi) -
    .5 * log1p(-theta^2) - (df + 2) / 2 * log1p(quadratic / df) -
    dt(x, df, log = TRUE) - dt(y, df, log = TRUE)
}

test_that("new EAL families agree with independent copula densities and derivatives", {
  n <- 31L
  x <- seq(-.8, .9, length.out = n)
  X <- cbind(1, x, x^2)
  beta <- matrix(seq(-.1, .1, length.out = 6L), 3L, 2L)
  Y <- X %*% beta + cbind(.8 * sin(seq_len(n) * .71) + .17,
    .9 * cos(seq_len(n) * 1.11) - .23)
  P <- list(diag(c(0, .4, .5)), diag(c(0, .3, .7)))
  cases <- list(list(family = "frank", theta = -6),
    list(family = "frank", theta = 6), list(family = "frank", theta = 0),
    list(family = "gumbel", theta = 2),
    list(family = "student_t", theta = -.6, df = 5),
    list(family = "student_t", theta = .4, df = .5),
    list(family = "student_t", theta = 0, df = 30))
  for (case in cases) {
    engine <- CJQR:::.cjqr_eal_engine(case$family)
    controls <- list(theta_init = case$theta)
    if (!is.null(case$df)) controls$df <- case$df
    for (anchor in c(.25, .5, .75)) {
      args <- list(X = X, Y = Y, P = P, beta_init = beta,
        sigma_init = c(.7, .9), p = anchor, degree = 3L,
        copula = case$family, control = controls)
      problem <- do.call(engine$problem, args)
      ref <- do.call(engine$reference_problem, args)
      parameter <- problem$par
      parameter[problem$idx_shape] <- .08 * cos(seq_along(problem$idx_shape))
      for (epsilon in c(0, .003, 1e-8))
        expect_identical(problem$evaluate(parameter, TRUE, epsilon),
          ref$evaluate(parameter, TRUE, epsilon))
      exact <- problem$evaluate(parameter, TRUE, 0)
      state <- problem$unpack(parameter)
      state$copula <- case$family; state$strict_ok <- TRUE
      state$df <- case$df
      t1 <- exact$terms[[1L]]; t2 <- exact$terms[[2L]]
      independent <- t1$logdensity + t2$logdensity - sum(log(state$sigma)) +
        .cjqr_test_logcopula(exp(t1$logF), exp(t2$logF), state$theta, case$family, case$df)
      expect_equal(engine$log_density(state, X, Y), independent, tolerance = 1e-10)
      expect_equal(sum(independent), exact$loglik, tolerance = 1e-10)
      h <- 1e-6
      difference <- vapply(seq_along(parameter), function(k) {
        plus <- minus <- parameter
        plus[k] <- plus[k] + h; minus[k] <- minus[k] - h
        (problem$evaluate(plus, FALSE, 0)$value - problem$evaluate(minus, FALSE, 0)$value) / (2 * h)
      }, numeric(1L))
      expect_true(max(abs(difference - exact$gradient)) < 2e-5,
        info = paste(case$family, case$theta, case$df, anchor))
      expect_identical(engine$controls()$strict_gradient_tolerance, 1e-6)
      expect_identical(engine$extra_controls()$joint_branches, 4L)
    }
  }
})

test_that("Student-t copula is not silently replaced by independence at zero rho", {
  u <- c(.05, .15, .85, .95)
  logc <- .cjqr_test_logcopula(u, u, 0, "student_t", 5)
  expect_gt(max(abs(logc)), .01)
  expect_equal(CJQR:::.cjqr_kendall_tau(0, "student_t", df = 5), 0)
})
