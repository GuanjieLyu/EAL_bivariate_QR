# Algebraic fixtures only: no EAL optimization or costly refits are performed.
# The basis metadata marks columns, rather than importing any GAM covariance.
.eal_coef_fixture <- function(distinct = FALSE) {
  n <- 80L
  i <- seq_len(n)
  x <- seq(-1, 1, length.out = n)
  z <- as.numeric(i %% 2L)
  X1 <- cbind("(Intercept)" = 1, z = z, "s(x).1" = x,
              "s(x).2" = x^2 - mean(x^2))
  X2 <- if (distinct) cbind("(Intercept)" = 1, w = sin(i * 1.71),
    v = cos(i * .83), "s(x).1" = x, "s(x).2" = x^2 - mean(x^2)) else X1
  b1 <- c(.3, .4, .7, -.2)
  b2 <- if (distinct) c(-.2, -.5, .15, -.6, .3) else c(-.2, -.3, -.6, .3)
  Y <- cbind(y1 = drop(X1 %*% b1) + sin(i * 2.17) / 4,
             y2 = drop(X2 %*% b2) + cos(i * 1.93) / 3)
  basis <- list(list(smooth = list(list(first.para = 3L, last.para = 4L,
    label = "s(x)")), Vp = diag(4), edf = rep(1, 4)),
    list(smooth = list(list(first.para = if (distinct) 4L else 3L,
      last.para = ncol(X2), label = "s(x)")), Vp = diag(ncol(X2)),
      edf = rep(1, ncol(X2))))
  out <- list(X = if (distinct) list(y1 = X1, y2 = X2) else X1, Y = Y,
    responses = c("y1", "y2"), basis = basis,
    formulas = list(y1 ~ z + s(x), if (distinct) y2 ~ w + v + s(x) else y2 ~ z + s(x)),
    degree = 3L, copula = "gaussian", omitted_rows = integer(), anchors = .5, anchor = .5,
    elapsed_seconds = 0, call = quote(cjqr_eal(formulas, data)),
    selection = list(strict_ok = TRUE, index = 1L, audit = data.frame(anchor = .5, strict = TRUE)),
    fit = list(strict_ok = TRUE, beta = if (distinct) list(b1, b2) else cbind(b1, b2),
      theta = -.4, sigma = c(.7, .8), p = .5, degree = 3L, loglik = -100,
      stationarity = 1e-9, improved_certificate = list()))
  class(out) <- "cjqr_eal"
  out
}
