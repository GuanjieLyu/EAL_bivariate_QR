.eal_residual_fixture <- function(distinct = FALSE, anchor = .25) {
  x <- seq(-1, 1, length.out = 6L)
  X <- cbind('(Intercept)' = 1, x = x)
  b1 <- c(.3, .4); b2 <- c(-.2, -.5)
  if (distinct) {
    X <- list(y1 = X, y2 = cbind(X, x2 = x^2))
    b2 <- c(b2, .2)
  }
  beta <- if (distinct) list(y1 = b1, y2 = b2) else cbind(b1, b2)
  location <- CJQR:::.cjqr_eal_location(X, beta)
  z <- cbind(c(-1000, -8, 0, 2, 8, 1000), c(1000, 8, 2, 0, -8, -1000))
  sigma <- c(.7, .9)
  Y <- location + sweep(z, 2, sigma, '*')
  dimnames(Y) <- list(paste0('subject', c(2, 3, 7, 9, 12, 15)), c('y1', 'y2'))
  structure(list(X = X, Y = Y, degree = 3L, responses = c('y1', 'y2'),
    copula = 'gaussian', omitted_rows = c(1L, 4L),
    selection = list(strict_ok = TRUE),
    fit = list(strict_ok = TRUE, beta = beta, sigma = sigma,
      shape = matrix(0, 5L, 2L), p = anchor, theta = .3)), class = 'cjqr_eal')
}

test_that('EAL residuals are explicit, margin-specific and preserve analysis rows', {
  for (distinct in c(FALSE, TRUE)) {
    fit <- .eal_residual_fixture(distinct)
    frozen <- serialize(fit, NULL)
    set.seed(612L); rng <- .Random.seed
    loc <- CJQR:::.cjqr_eal_location(fit$X, fit$fit$beta)
    response <- fit$Y - loc
    dimnames(response) <- dimnames(fit$Y)
    expect_identical(residuals(fit), response)
    expect_identical(residuals(fit, type = 'standardized'), sweep(response, 2, fit$fit$sigma, '/'))
    expect_identical(dimnames(residuals(fit)), dimnames(fit$Y))
    expect_identical(nrow(residuals(fit)), 6L)
    expect_identical(serialize(fit, NULL), frozen)
    expect_identical(.Random.seed, rng)
  }
})

test_that('PIT and log-tail normal residuals agree with the AL submodel', {
  for (anchor in c(.25, .5, .75)) for (distinct in c(FALSE, TRUE)) {
    fit <- .eal_residual_fixture(distinct, anchor)
    z <- residuals(fit, 'standardized')
    lf <- ifelse(z < 0, log(anchor) + (1-anchor)*z,
      log1p(-(1-anchor)*exp(-anchor*pmax(z, 0))))
    ls <- ifelse(z < 0, log1p(-anchor*exp((1-anchor)*pmin(z, 0))),
      log1p(-anchor)-anchor*z)
    expected <- z
    left <- lf <= -log(2)
    expected[left] <- qnorm(lf[left], log.p = TRUE)
    expected[!left] <- qnorm(ls[!left], log.p = TRUE, lower.tail = FALSE)
    expect_equal(unname(residuals(fit, 'pit')), unname(exp(lf)), tolerance = 1e-12)
    expect_equal(unname(residuals(fit, 'quantile')), unname(expected), tolerance = 1e-9)
    expect_true(all(is.finite(residuals(fit, 'quantile'))))
    expect_identical(unname(residuals(fit, 'pit')), unname(predict(fit, type = 'cdf')))
  }
})

test_that('residual requests reject unsupported inputs without fitting', {
  fit <- .eal_residual_fixture()
  expect_error(residuals(fit, type = 'pearson'), 'arg')
  expect_error(residuals(fit, newdata = data.frame(x = 0)), 'Unsupported')
  fit$fit$sigma <- c(0, .9)
  expect_error(residuals(fit, 'standardized'), 'positive finite')
  fit <- .eal_residual_fixture(); fit$fit$shape <- NULL
  expect_error(residuals(fit, 'pit'), 'shape')
  fit <- .eal_residual_fixture(); fit$Y[1, 1] <- NA_real_
  expect_error(residuals(fit), 'finite paired')
  fit <- .eal_residual_fixture(); fit$fit$strict_ok <- FALSE
  expect_error(residuals(fit), 'certified')
})
