.eal_ci_toy <- function(n = 36L, probs = c(.1, .25, .5, .75, .9)) {
  x <- seq(-1, 1, length.out = n)
  X <- cbind("(Intercept)" = 1, x = x, x2 = x^2)
  e <- sin(seq_len(n) * 3.7) + cos(seq_len(n) * 1.3) / 3
  y <- 0.3 + 0.4 * x - 0.1 * x^2 + e
  Y <- cbind(y, 2 * y + 3)
  Xe <- X[c(2L, 10L, 24L), , drop = FALSE]
  joint <- array(0, c(nrow(Xe), 2L, length(probs)),
                 dimnames = list(c("a", "b", "c"), c("first", "second"),
                                 as.character(probs)))
  for (j in 1:2) for (k in seq_along(probs)) {
    joint[, j, k] <- 4 * j + probs[k] + Xe[, "x"]
  }
  list(X = X, Y = Y, Xeval = Xe, joint = joint, probs = probs)
}

.eal_ci_opts <- function(probs, B = 120L, seed = 345L, level = .95,
                          chunk_size = 2L, keep_draws = TRUE) {
  CJQR:::.cjqr_eal_ci_options(probs, level, B, seed, chunk_size,
                                 max_memory_mb = 256, keep_draws = keep_draws)
}

.eal_ci_compute <- function(a, opts = .eal_ci_opts(a$probs), resamples = NULL) {
  CJQR:::.cjqr_eal_ci_compute(a$X, a$Y, a$Xeval, a$joint,
                                 opts, resamples = resamples)
}

test_that("auxiliary bootstrap reproduces direct paired OLS percentile bounds", {
  a <- .eal_ci_toy()
  opts <- .eal_ci_opts(a$probs)
  ans <- .eal_ci_compute(a, opts)
  expect_s3_class(ans, "cjqr_eal_ci")
  expect_true(ans$available)
  expect_identical(ans$fit, a$joint)
  expect_identical(dimnames(ans$lower), dimnames(a$joint))
  expect_identical(ans$bootstrap$attempted, 120L)
  expect_equal(ans$bootstrap$successful, 120L)
  expect_equal(ans$bootstrap$failed, 0L)
  expect_identical(ans$bootstrap$joint_refits, 0L)
  expect_identical(ans$bootstrap$qgam_refits, 0L)
  expect_identical(ans$bootstrap$replacement_draws, 0L)
  expect_true(ans$bootstrap$all_draws_required)
  expect_false(ans$interpretation$is_joint_sampling_SE)

  draws <- array(NA_real_, c(nrow(a$Xeval), 2L, length(a$probs), opts$B))
  for (b in seq_len(opts$B)) {
    ii <- ans$draws$indices[, b]
    Xb <- a$X[ii, , drop = FALSE]
    Yb <- a$Y[ii, , drop = FALSE]
    beta <- qr.coef(qr(Xb), Yb)
    residual <- Yb - Xb %*% beta
    expect_equal(unname(ans$draws$coefficients[, , b]), unname(beta),
                 tolerance = 0)
    for (j in 1:2) {
      rq <- quantile(residual[, j], a$probs, type = 8, names = FALSE)
      expect_equal(ans$draws$residual_quantiles[, j, b], rq, tolerance = 0)
      for (k in seq_along(a$probs)) {
        draws[, j, k, b] <- drop(a$Xeval %*% beta[, j]) + rq[k]
      }
    }
  }
  for (i in seq_len(nrow(a$Xeval))) for (j in 1:2) {
    for (k in seq_along(a$probs)) {
      endpoints <- quantile(draws[i, j, k, ], c(.025, .975),
                             type = 8, names = FALSE)
      expect_equal(unname(c(ans$reference$lower[i, j, k], ans$reference$upper[i, j, k])),
                   unname(endpoints), tolerance = 1e-14)
    }
  }
  expect_equal(ans$reference$lower[, 2, ],
               2 * ans$reference$lower[, 1, ] + 3, tolerance = 1e-12)
  expect_equal(ans$reference$upper[, 2, ],
               2 * ans$reference$upper[, 1, ] + 3, tolerance = 1e-12)
  expect_equal(ans$lower, pmin(ans$reference$lower, a$joint), tolerance = 0)
  expect_equal(ans$upper, pmax(ans$reference$upper, a$joint), tolerance = 0)
  expect_true(all(ans$lower <= a$joint & ans$upper >= a$joint))
  expect_true(all(ans$lower <= ans$reference$lower &
                    ans$upper >= ans$reference$upper))
})

test_that("chunking, probability order and one-row one-quantile arrays are safe", {
  a <- .eal_ci_toy(probs = c(.9, .1, .75))
  one <- .eal_ci_compute(a, .eal_ci_opts(a$probs, chunk_size = 1L))
  many <- .eal_ci_compute(a, .eal_ci_opts(a$probs, chunk_size = 100L,
                                         keep_draws = FALSE))
  expect_identical(one$lower, many$lower)
  expect_identical(one$upper, many$upper)
  expect_null(many$draws)
  expect_identical(one$probs, c(.9, .1, .75))
  b <- .eal_ci_toy(probs = .37)
  b$Xeval <- b$Xeval[1L, , drop = FALSE]
  b$joint <- b$joint[1L, , , drop = FALSE]
  ans <- .eal_ci_compute(b, .eal_ci_opts(b$probs, level = .9))
  expect_true(ans$available)
  expect_identical(dim(ans$fit), c(1L, 2L, 1L))
  expect_identical(dim(ans$lower), c(1L, 2L, 1L))
  expect_identical(ans$fit, b$joint)
})

test_that("the index generator restores kind, seed and seed nonexistence", {
  old_kind <- RNGkind()
  had <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had) saved <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    do.call(RNGkind, as.list(old_kind))
    if (had) assign(".Random.seed", saved, envir = .GlobalEnv) else
      if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
        rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  RNGkind("L'Ecuyer-CMRG", "Inversion", "Rejection")
  set.seed(87)
  before <- .Random.seed
  kind <- RNGkind()
  first <- CJQR:::.cjqr_eal_ci_indices(25L, 500L, 32L)
  expect_identical(.Random.seed, before)
  expect_identical(RNGkind(), kind)
  prefix <- CJQR:::.cjqr_eal_ci_indices(25L, 399L, 32L)
  expect_identical(first[, seq_len(399L)], prefix)
  expect_identical(first, CJQR:::.cjqr_eal_ci_indices(25L, 500L, 32L))
  expect_error(CJQR:::.cjqr_eal_ci_indices(-2L, 1L, 32L))
  expect_identical(.Random.seed, before)
  expect_identical(RNGkind(), kind)
  rm(".Random.seed", envir = .GlobalEnv)
  invisible(CJQR:::.cjqr_eal_ci_indices(25L, 10L, 32L))
  expect_false(exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
  expect_identical(RNGkind(), kind)
})

test_that("one bad draw invalidates all bounds without changing the point or redraws", {
  a <- .eal_ci_toy()
  opts <- .eal_ci_opts(a$probs, B = 8L)
  ii <- matrix(rep(seq_len(nrow(a$X)), opts$B), nrow = nrow(a$X))
  ii[, 3L] <- 1L
  expect_warning(ans <- .eal_ci_compute(a, opts, ii), "No failed draws")
  expect_false(ans$available)
  expect_identical(ans$fit, a$joint)
  expect_true(all(is.na(ans$lower)))
  expect_true(all(is.na(ans$reference$lower)))
  expect_equal(ans$bootstrap$successful, 7L)
  expect_equal(ans$bootstrap$failed, 1L)
  expect_identical(ans$bootstrap$attempted, 8L)
  expect_identical(ans$draws$indices, ii)
  expect_identical(which(!ans$bootstrap$status$ok), 3L)
  expect_identical(ans$bootstrap$status$error[3L], "rank_deficient_subject_resample")
  expect_true(all(is.finite(ans$draws$coefficients[, , 8L])))
})

test_that("design, probabilities, strict acceptance and memory checks fail explicitly", {
  a <- .eal_ci_toy()
  for (p in list(numeric(), 0, 1, NA_real_, Inf, "0.5", matrix(.5), c(.5, .5))) {
    expect_error(.eal_ci_opts(p), "probs")
  }
  for (b in list(1, 1.5, NA_real_, Inf, "500")) {
    expect_error(.eal_ci_opts(.5, B = b), "B")
  }
  for (seed in list(-1, 1.5, NA_real_, .Machine$integer.max + 1)) {
    expect_error(.eal_ci_opts(.5, seed = seed), "seed")
  }
  expect_error(.eal_ci_opts(.5, level = 1), "level")
  opts <- .eal_ci_opts(a$probs)
  opts$max_memory_mb <- 1e-6
  expect_error(.eal_ci_compute(a, opts), "workspace")
  b <- a
  b$X[, 3L] <- b$X[, 2L]
  expect_error(.eal_ci_compute(b), "Original auxiliary OLS fit.*rank_deficient")
  b <- a
  b$X[, 1L] <- 2
  expect_error(.eal_ci_compute(b), "intercept")
  b <- a
  b$Y[1L, 1L] <- NA_real_
  expect_error(.eal_ci_compute(b), "finite")
  b <- a
  b$joint[1L] <- Inf
  expect_error(.eal_ci_compute(b), "Joint predictions")
  expect_error(cjqr_eal_ci(structure(list(), class = "unsupported_model")), "must be a cjqr_eal fit")
  expect_error(cjqr_eal_ci(structure(list(selection = list(strict_ok = FALSE)),
                                       class = "cjqr_eal")), "strictly accepted")
})

test_that("the public interface preserves the prediction adapter exactly", {
  a <- .eal_ci_toy()
  fixture <- structure(list(X = a$X, Y = a$Y,
                            selection = list(strict_ok = TRUE)),
                       class = "cjqr_eal")
  local_mocked_bindings(
    .cjqr_eal_newX = function(object, newdata) a$Xeval,
    .cjqr_eal_ci_prediction = function(object, newdata, probs) a$joint,
    .package = "CJQR")
  before <- serialize(fixture, NULL)
  ans <- cjqr_eal_ci(fixture, probs = a$probs, B = 100L, seed = 345L)
  expect_true(ans$available)
  expect_identical(ans$fit, a$joint)
  expect_identical(serialize(fixture, NULL), before)
  expect_output(print(ans), "not native joint SEs")
  expect_warning(cjqr_eal_ci(fixture, probs = a$probs, B = 5L), "B < 100")
})

test_that("auxiliary intervals are basis invariant and intercept-only quantiles agree", {
  a <- .eal_ci_toy()
  base <- .eal_ci_compute(a)
  transformed <- a
  A <- diag(c(1, 2, .5))
  A[2, 3] <- .2
  transformed$X <- a$X %*% A
  transformed$Xeval <- a$Xeval %*% A
  out <- .eal_ci_compute(transformed)
  expect_equal(out$reference$lower, base$reference$lower, tolerance = 1e-12)
  expect_equal(out$reference$upper, base$reference$upper, tolerance = 1e-12)
  expect_identical(out$fit, a$joint)
  a$X <- matrix(1, nrow(a$X), 1L)
  a$Xeval <- matrix(1, nrow(a$Xeval), 1L)
  ans <- .eal_ci_compute(a)
  for (j in 1:2) for (k in seq_along(a$probs)) {
    qdraw <- vapply(seq_len(ans$bootstrap$attempted), function(b) {
      as.numeric(quantile(a$Y[ans$draws$indices[, b], j], a$probs[k],
                           type = 8, names = FALSE))
    }, numeric(1))
    target <- quantile(qdraw, c(.025, .975), type = 8, names = FALSE)
    expect_equal(unname(c(ans$reference$lower[1, j, k], ans$reference$upper[1, j, k])),
                 unname(target), tolerance = 1e-12)
  }
})
