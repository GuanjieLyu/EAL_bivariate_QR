# Only Gaussian preparation fits are used here. EAL coefficient fixtures are
# deterministic API fixtures, not fitted EAL estimates or coverage evidence.
.eal_distinct_data <- function(n = 96L) {
  i <- seq_len(n)
  d <- data.frame(x = seq(-.95, .95, length.out = n),
    z = as.numeric(i %% 2L), w = sin(i * 1.37),
    u = (i * .61803398875) %% 1, v = (i * .41421356237) %% 1,
    g = factor(rep(c("a", "b"), length.out = n)))
  d$y1 <- .3 + .4 * d$z + sin(pi * d$x) + cos(i * 2.3) / 4
  d$y2 <- -.2 + .2 * (d$g == "b") + cos(d$w) +
    .5 * sin(2 * pi * d$u) * cos(2 * pi * d$v) + sin(i * 2.1) / 4
  d
}

.eal_distinct_formulas <- function() list(
  y1 ~ z + s(x, k = 5),
  y2 ~ g + s(w, k = 7) + s(u, v, k = 10)
)

.eal_distinct_fixture <- function(common = FALSE) {
  dat <- .eal_distinct_data()
  formulas <- if (common) list(y1 ~ z + s(x, k = 5),
    y2 ~ z + s(x, k = 5)) else .eal_distinct_formulas()
  val <- CJQR:::.cjqr_eal_validate_data(formulas, dat, stats::na.fail)
  prep <- CJQR:::.cjqr_eal_prepare(val)
  beta <- lapply(1:2, function(j) stats::coef(prep$basis[[j]]) * c(.7, 1.2)[j])
  if (common) {
    beta <- do.call(cbind, beta)
    colnames(beta) <- val$responses
  } else names(beta) <- val$responses
  obj <- list(call = quote(cjqr_eal(formulas, data = dat)),
    formulas = val$formulas, data = val$data, responses = val$responses,
    covariates = val$covariates, margin_covariates = val$margin_covariates,
    common_basis = prep$common_basis, X = prep$X, Y = prep$Y, P = prep$P,
    basis = prep$basis, degree = 3L, copula = "gaussian", df = NULL,
    anchor = .5, anchors = .5, elapsed_seconds = 0, omitted_rows = integer(),
    selection = list(strict_ok = TRUE, audit = data.frame(anchor = .5, strict = TRUE)),
    fit = list(strict_ok = TRUE, beta = beta, p = .5, degree = 3L,
      theta = -.4, sigma = c(.7, .8), shape = matrix(0, 5L, 2L),
      loglik = -100, stationarity = 1e-9, improved_certificate = list()))
  class(obj) <- "cjqr_eal"
  list(object = obj, prepared = prep, validated = val)
}

test_that("distinct-RHS validation checks both formulas before preparation", {
  local_mocked_bindings(
    .cjqr_eal_prepare = function(...) stop("DISTINCT_TEST_FORBIDS_PREPARATION"),
    .package = "CJQR"
  )
  dat <- .eal_distinct_data()
  bad <- list(
    list(y1 ~ x),
    list(y1 ~ x, y2 ~ absent_only_in_margin_two),
    list(y1 ~ x, y2 ~ w + y1),
    list(y1 ~ x + y2, y2 ~ w),
    list(y1 ~ x, y2 ~ 0 + w),
    list(y1 ~ x, y2 ~ w + offset(z)),
    list(y1 ~ x, y2 ~ w, ~ z)
  )
  for (formulas in bad) {
    err <- tryCatch(cjqr_eal(formulas, data = dat), error = identity)
    expect_s3_class(err, "error")
    expect_false(grepl("DISTINCT_TEST_FORBIDS_PREPARATION",
                      conditionMessage(err), fixed = TRUE))
  }
  expect_error(cjqr_eal(list(y1 ~ x, y2 ~ w), data = dat),
               "DISTINCT_TEST_FORBIDS_PREPARATION")
})

test_that("one paired analysis sample uses the union of marginal covariates", {
  dat <- .eal_distinct_data()
  dat$w[3L] <- NA_real_ # Used in margin two only.
  dat$y1[5L] <- NA_real_
  formulas <- .eal_distinct_formulas()
  expect_error(CJQR:::.cjqr_eal_validate_data(formulas, dat, stats::na.fail))
  val <- CJQR:::.cjqr_eal_validate_data(formulas, dat, stats::na.omit)
  expect_setequal(val$covariates, c("x", "z", "g", "w", "u", "v"))
  expect_setequal(val$margin_covariates[[1L]], c("x", "z"))
  expect_setequal(val$margin_covariates[[2L]], c("g", "w", "u", "v"))
  expect_identical(val$omitted_rows, c(3L, 5L))
  expect_identical(val$kept_rows, setdiff(seq_len(nrow(dat)), c(3L, 5L)))
  expect_identical(nrow(val$data), 94L)
  expect_false(anyNA(val$data))
})

test_that("distinct preparation retains each design and penalty block", {
  fixture <- .eal_distinct_fixture()
  prep <- fixture$prepared
  expect_false(prep$common_basis)
  expect_type(prep$X, "list")
  expect_identical(names(prep$X), c("y1", "y2"))
  expect_identical(vapply(prep$X, ncol, integer(1)), c(y1 = 6L, y2 = 17L))
  for (j in 1:2) {
    Xj <- prep$X[[j]]
    gam <- prep$basis[[j]]
    expect_equal(Xj, stats::predict(gam, type = "lpmatrix"), tolerance = 0)
    expect_identical(dim(prep$P[[j]]), rep(ncol(Xj), 2L))
    expect_identical(prep$qr[[j]]$rank, ncol(Xj))
    expect_equal(unname(Xj[, prep$intercept[[j]]]), rep(1, nrow(Xj)))
    penalty <- matrix(0, ncol(Xj), ncol(Xj))
    for (sm in gam$smooth) for (k in seq_along(sm$S)) {
      ids <- sm$first.para:sm$last.para
      penalty[ids, ids] <- penalty[ids, ids] + gam$sp[sm$first.sp + k - 1L] * sm$S[[k]]
    }
    expect_equal(prep$P[[j]], penalty / gam$sig2, tolerance = 1e-12)
  }
})

test_that("identical formulas preserve common-basis matrix interfaces", {
  fixture <- .eal_distinct_fixture(common = TRUE)
  obj <- fixture$object
  expect_true(fixture$prepared$common_basis)
  expect_true(is.matrix(obj$X))
  expect_true(is.matrix(coef(obj)))
  expect_identical(predict(obj, type = "lpmatrix"), obj$X)
  expect_equal(predict(obj, type = "location"), obj$X %*% coef(obj), tolerance = 0)
  expect_identical(dim(predict(obj, probs = c(.1, .5, .9))), c(96L, 2L, 3L))
})

test_that("distinct prediction and coefficient extraction preserve response order", {
  obj <- .eal_distinct_fixture()$object
  frozen <- serialize(obj, NULL)
  nd <- obj$data[c(2L, 11L, 29L, 70L), obj$covariates, drop = FALSE]
  Xnew <- predict(obj, newdata = nd, type = "lpmatrix")
  beta <- coef(obj)
  expect_identical(names(Xnew), obj$responses)
  expect_identical(names(beta), obj$responses)
  expect_identical(vapply(beta, length, integer(1)), c(y1 = 6L, y2 = 17L))
  target <- do.call(cbind, lapply(1:2, function(j) {
    expect_equal(Xnew[[j]], stats::predict(obj$basis[[j]], nd, type = "lpmatrix"),
                 tolerance = 0)
    drop(Xnew[[j]] %*% beta[[j]])
  }))
  colnames(target) <- obj$responses
  location <- predict(obj, nd, type = "location")
  expect_equal(unname(location), unname(target), tolerance = 0)
  q <- predict(obj, nd, probs = c(.1, .5, .9))
  expect_identical(dim(q), c(4L, 2L, 3L))
  expect_identical(dimnames(q)[[2L]], obj$responses)
  expect_equal(unname(q[, , 2L]), unname(location), tolerance = 1e-12)
  expect_equal(unname(predict(obj, nd, type = "cdf", y = location)),
               matrix(.5, 4L, 2L), tolerance = 1e-12)
  expect_identical(nobs(obj), 96L)
  expect_identical(serialize(obj, NULL), frozen)

  expect_error(predict(obj, nd[, setdiff(names(nd), "w"), drop = FALSE]), "w")
  unknown <- nd
  unknown$g <- rep("unknown_second_margin_level", nrow(nd))
  expect_error(predict(obj, unknown), "Unknown level")
})

test_that("summary and spatial smooth plots use the selected margin basis", {
  obj <- .eal_distinct_fixture()$object
  frozen <- serialize(obj, NULL)
  sm <- summary(obj)
  expect_identical(rownames(sm$tableP1), c("(Intercept)", "z"))
  expect_identical(rownames(sm$tableP2), c("(Intercept)", "gb"))
  expect_identical(sm$tableNP1$Smooth, "s(x)")
  expect_identical(sm$tableNP2$Smooth, c("s(w)", "s(u,v)"))
  expect_equal(sm$tableNP1$Coef.dim, 4)
  expect_equal(sm$tableNP2$Coef.dim, c(6, 9))
  expect_identical(rownames(sm$smooth_tables[[1L]]), "s(x)")
  expect_identical(rownames(sm$smooth_tables[[2L]]), c("s(w)", "s(u,v)"))
  expect_true(all(is.na(sm$smooth_tables[[1L]])))
  expect_true(all(is.na(sm$smooth_tables[[2L]])))
  expect_identical(colnames(sm$tableP1), "Estimate")
  expect_identical(colnames(sm$tableP2), "Estimate")
  panel <- plot(obj, eq = 2, select = 2, n2 = 12, too.far = 0, draw = FALSE)[[1L]]
  term <- obj$basis[[2L]]$smooth[[2L]]
  ids <- term$first.para:term$last.para
  coefficients <- obj$fit$beta[[2L]][ids]
  training <- drop(obj$X[[2L]][, ids, drop = FALSE] %*% coefficients)
  direct <- drop(mgcv::PredictMat(term, panel$grid) %*% coefficients) - mean(training)
  expect_identical(panel$equation, 2L)
  expect_identical(panel$variables, c("u", "v"))
  expect_identical(dim(panel$fit), c(12L, 12L))
  expect_equal(as.numeric(panel$fit), direct, tolerance = 1e-12)
  expect_equal(panel$center, mean(training), tolerance = 1e-12)
  expect_null(panel$se)
  expect_error(plot(obj, eq = 1, select = 2, draw = FALSE), "select")
  expect_identical(serialize(obj, NULL), frozen)
})
