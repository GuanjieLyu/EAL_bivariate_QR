test_that("Gaussian preparation uses one correctly scaled common penalty", {
  x <- seq(-.95, .95, length.out = 60L)
  d <- data.frame(x = x, z = rep(0:1, 30),
    y1 = sin(4 * x) + .15 * cos(seq_along(x)),
    y2 = cos(3 * x) + .12 * sin(seq_along(x)))
  v <- CJQR:::.cjqr_eal_validate_data(
    list(y1 ~ z + s(x, k = 5), y2 ~ z + s(x, k = 5)), d, stats::na.fail)
  prep <- CJQR:::.cjqr_eal_prepare(v)
  for (j in 1:2) {
    gam <- prep$basis[[j]]
    P <- matrix(0, ncol(prep$X), ncol(prep$X))
    for (sm in gam$smooth) for (k in seq_along(sm$S)) {
      ids <- sm$first.para:sm$last.para
      P[ids, ids] <- P[ids, ids] + gam$sp[sm$first.sp + k - 1L] * sm$S[[k]]
    }
    expect_equal(prep$P[[j]], P / gam$sig2, tolerance = 1e-12)
    expect_identical(prep$penalty_metadata[[j]]$penalty_effective, prep$P[[j]])
    expect_equal(prep$penalty_metadata[[j]]$normalization_factor, 1 / gam$sig2)
  }
})

test_that("native parametric qgam initializer needs no outer optimization", {
  skip_if_not_installed("qgam", minimum_version = "2.0.0")
  d <- data.frame(x = seq(-1, 1, length.out = 60))
  d$y <- .4 + .6 * d$x + sin(seq_len(60) * 3.7)
  set.seed(461L)
  before <- .Random.seed
  out <- CJQR:::.cjqr_eal_qgam_native(y ~ x, d, .5, d, 12L)
  expect_true(out$ok)
  expect_true(out$fit$converged)
  expect_length(out$fit$sp, 0L)
  expect_null(out$fit$outer.info)
  expect_identical(out$convergence_basis, "native_mgcv_converged_no_free_outer_parameters")
  expect_identical(.Random.seed, before)
})

test_that("anchor selection never hides a known lower unresolved candidate", {
  candidate <- function(a, objective, strict, known = objective, init = TRUE)
    list(anchor = a, start = list(ok = init), fit = list(strict_ok = strict,
      objective = objective, best_candidate_objective = known,
      improved_control = list(lower_candidate_gap_tolerance = 1e-7)))
  cs <- list(candidate(.25, 2, TRUE), candidate(.5, 3, TRUE), candidate(.75, 4, TRUE))
  expect_true(CJQR:::.cjqr_eal_select(cs)$strict_ok)
  expect_identical(CJQR:::.cjqr_eal_select(cs)$index, 1L)
  cs[[2]] <- candidate(.5, 1, FALSE)
  expect_false(CJQR:::.cjqr_eal_select(cs)$strict_ok)
  cs[[2]] <- candidate(.5, 3, TRUE, known = 1)
  expect_false(CJQR:::.cjqr_eal_select(cs)$strict_ok)
  cs[[2]] <- candidate(.5, 3, TRUE, init = FALSE)
  expect_false(CJQR:::.cjqr_eal_select(cs)$strict_ok)
})
