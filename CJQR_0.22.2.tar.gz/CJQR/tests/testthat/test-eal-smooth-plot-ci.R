.smooth_plot_ci_fixture <- function(kind = "common") {
  n <- 120L
  i <- seq_len(n)
  dat <- data.frame(x = seq(-1, 1, length.out = n),
    w = cos(i * 1.43), z = as.numeric(i %% 2L),
    g = factor(rep(c("a", "b"), length.out = n)))
  dat$y1 <- .3 + .4 * dat$z + sin(pi * dat$x) + cos(i * 2.3) / 5
  dat$y2 <- -.2 - .3 * dat$z + cos(pi * dat$x) + sin(i * 2.1) / 5
  rhs <- switch(kind, factor_by = "g + s(x, by = g, k = 5)",
    numeric_by = "z + s(x, by = w, k = 6)",
    spatial = "z + s(x, w, k = 12)", "z + s(x, k = 6)")
  rhs2 <- if (kind == "distinct") "w + s(x, k = 5)" else rhs
  formulas <- Map(function(y, r) as.formula(paste(y, "~", r),
    env = asNamespace("mgcv")), c("y1", "y2"), c(rhs, rhs2))
  basis <- lapply(formulas, function(f) mgcv::gam(f, data = dat, method = "REML"))
  designs <- lapply(basis, predict, type = "lpmatrix")
  beta <- list(coef(basis[[1L]]) * .7, coef(basis[[2L]]) * 1.2)
  distinct <- kind == "distinct"
  structure(list(X = if (distinct) designs else designs[[1L]],
    Y = as.matrix(dat[c("y1", "y2")]), data = dat, formulas = formulas,
    responses = c("y1", "y2"), basis = basis, degree = 3L, copula = "gaussian",
    selection = list(strict_ok = TRUE, audit = data.frame(anchor = .5, strict = TRUE)),
    fit = list(strict_ok = TRUE, beta = if (distinct) beta else do.call(cbind, beta),
      p = .5, degree = 3L, theta = -.4, sigma = c(.7, .8),
      shape = matrix(0, 5L, 2L))), class = "cjqr_eal")
}

.smooth_plot_manual_reference <- function(object, panel, B, seed, level = .95) {
  saved_kind <- RNGkind()
  existed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (existed) saved_seed <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    do.call(RNGkind, as.list(saved_kind))
    if (existed) assign(".Random.seed", saved_seed, envir = .GlobalEnv)
    else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
      rm(".Random.seed", envir = .GlobalEnv)
  })
  set.seed(seed, kind = "Mersenne-Twister", normal.kind = "Inversion",
           sample.kind = "Rejection")
  j <- panel$equation
  X <- if (is.matrix(object$X)) object$X else object$X[[j]]
  ids <- panel$coefficient_indices
  sm <- object$basis[[j]]$smooth[[panel$select]]
  A <- sweep(mgcv::PredictMat(sm, panel$grid), 2L,
             colMeans(X[, ids, drop = FALSE]), "-")
  draws <- replicate(B, {
    rows <- sample.int(nrow(X), nrow(X), replace = TRUE)
    beta <- stats::lm.fit(X[rows, , drop = FALSE], object$Y[rows, j])$coefficients
    drop(A %*% beta[ids])
  })
  endpoints <- t(apply(draws, 1L, stats::quantile,
    probs = c((1 - level) / 2, (1 + level) / 2), type = 8, names = FALSE))
  endpoints[panel$excluded, ] <- NA_real_
  list(lower = endpoints[, 1L], upper = endpoints[, 2L], draws = draws)
}

test_that("smooth plot defaults produce auxiliary-bootstrap pointwise intervals", {
  fit <- .smooth_plot_ci_fixture()
  frozen <- serialize(fit, NULL)
  set.seed(141)
  rng <- .Random.seed
  device <- grDevices::dev.cur()
  panel <- plot(fit, eq = 1, select = 1, n = 23, draw = FALSE)[[1L]]
  expect_true(formals(CJQR:::plot.cjqr_eal)$se)
  expect_identical(panel$interval, "confidence")
  expect_identical(panel$level, .95)
  expect_null(panel$se)
  expect_identical(panel$label, "s(x)")
  expect_identical(panel$variables, "x")
  expect_equal(panel$bootstrap$requested, 500)
  expect_equal(panel$bootstrap$successful, 500)
  expect_equal(panel$bootstrap$failed, 0)
  expect_equal(panel$bootstrap$joint_refits, 0)
  expect_true(panel$bootstrap$paired_subject_rows)
  expect_true(panel$bootstrap$fixed_observed_basis)
  expect_true(all(panel$lower <= panel$fit & panel$fit <= panel$upper))
  reference <- .smooth_plot_manual_reference(fit, panel, B = 500, seed = 1)
  expect_equal(panel$reference_lower, reference$lower, tolerance = 1e-11)
  expect_equal(panel$reference_upper, reference$upper, tolerance = 1e-11)
  expect_equal(panel$lower, pmin(reference$lower, panel$fit), tolerance = 1e-11)
  expect_equal(panel$upper, pmax(reference$upper, panel$fit), tolerance = 1e-11)
  plain <- plot(fit, eq = 1, select = 1, n = 23, se = FALSE, draw = FALSE)[[1L]]
  expect_identical(panel$fit, plain$fit)
  expect_null(plain$lower)
  expect_null(plain$upper)
  expect_identical(serialize(fit, NULL), frozen)
  expect_identical(.Random.seed, rng)
  expect_identical(grDevices::dev.cur(), device)
})

test_that("smooth auxiliary intervals preserve each basis and original centring", {
  for (kind in c("distinct", "factor_by", "numeric_by")) {
    fit <- .smooth_plot_ci_fixture(kind)
    frozen <- serialize(fit, NULL)
    for (j in 1:2) {
      panels <- plot(fit, eq = j, B = 100, seed = 792, n = 17,
                     level = .9, draw = FALSE)
      for (panel in panels) {
        reference <- .smooth_plot_manual_reference(fit, panel, 100, 792, .9)
        expect_equal(panel$reference_lower, reference$lower, tolerance = 1e-11)
        expect_equal(panel$reference_upper, reference$upper, tolerance = 1e-11)
        expect_equal(panel$lower, pmin(reference$lower, panel$fit), tolerance = 1e-11)
        expect_equal(panel$upper, pmax(reference$upper, panel$fit), tolerance = 1e-11)
        expect_identical(panel$level, .9)
        expect_equal(mean(panel$training_centered), 0, tolerance = 1e-14)
        if (kind == "factor_by") expect_identical(unique(as.character(panel$grid$g)),
          fit$basis[[j]]$smooth[[panel$select]]$by.level)
        if (kind == "numeric_by") expect_true(all(panel$grid$w == 1))
      }
    }
    expect_identical(serialize(fit, NULL), frozen)
  }
})

test_that("spatial interval surfaces retain unsupported-grid masks", {
  fit <- .smooth_plot_ci_fixture("spatial")
  panel <- plot(fit, eq = 2, n2 = 17, too.far = .035,
                B = 100, seed = 93, draw = FALSE)[[1L]]
  expect_identical(dim(panel$fit), c(17L, 17L))
  expect_true(any(panel$excluded))
  expect_true(any(!panel$excluded))
  reference <- .smooth_plot_manual_reference(fit, panel, 100, 93)
  for (field in c("lower", "upper", "reference_lower", "reference_upper")) {
    expect_identical(dim(panel[[field]]), dim(panel$fit))
    expect_identical(is.na(panel[[field]]), is.na(panel$fit))
  }
  expect_equal(as.vector(panel$reference_lower), reference$lower, tolerance = 1e-11)
  expect_equal(as.vector(panel$reference_upper), reference$upper, tolerance = 1e-11)
  expect_true(all(panel$lower <= panel$fit & panel$fit <= panel$upper, na.rm = TRUE))
})

test_that("smooth intervals ignore distributional offsets and initializer covariance", {
  fit <- .smooth_plot_ci_fixture()
  baseline <- plot(fit, n = 19, B = 100, seed = 53, draw = FALSE)[[1L]]
  changed <- fit
  changed$fit$p <- .9
  changed$fit$sigma <- c(12, 23)
  changed$fit$shape[,] <- .1
  for (j in 1:2) changed$basis[[j]]$Vp[,] <- 1e8
  actual <- plot(changed, n = 19, B = 100, seed = 53, draw = FALSE)[[1L]]
  for (field in c("fit", "lower", "upper", "reference_lower", "reference_upper"))
    expect_identical(actual[[field]], baseline[[field]])
})

test_that("smooth interval controls and estimate-only mode are explicit", {
  fit <- .smooth_plot_ci_fixture()
  a <- plot(fit, B = 100, n = 13, draw = FALSE)
  b <- plot(fit, se = TRUE, B = 100, n = 13, draw = FALSE)
  c <- plot(fit, type = "smooth", interval = "confidence",
            B = 100, n = 13, draw = FALSE)
  for (field in c("fit", "lower", "upper", "reference_lower", "reference_upper")) {
    expect_identical(a[[1L]][[field]], b[[1L]][[field]])
    expect_identical(a[[1L]][[field]], c[[1L]][[field]])
  }
  expect_null(plot(fit, type = "smooth", interval = "none", draw = FALSE)[[1L]]$lower)
  expect_error(plot(fit, type = "smooth", se = FALSE, interval = "confidence", draw = FALSE),
               "se|conflict|inconsistent")
  expect_error(plot(fit, type = "smooth", se = TRUE, interval = "none", draw = FALSE),
               "se|conflict|inconsistent")
  for (bad in list(NA, 2, "TRUE", c(TRUE, FALSE)))
    expect_error(plot(fit, se = bad, draw = FALSE), "se")
  expect_error(plot(fit, level = 1, draw = FALSE), "level")
  expect_error(plot(fit, B = 1, draw = FALSE), "B")
  expect_error(plot(fit, seed = -1, draw = FALSE), "seed")
  expect_error(plot(fit, max_memory_mb = .0001, draw = FALSE), "workspace|memory")
  local_mocked_bindings(.cjqr_eal_smooth_plot_ci = function(...)
    stop("Auxiliary bootstrap was called."), .package = "CJQR")
  expect_no_error(plot(fit, se = FALSE, draw = FALSE))
})

test_that("failed or ineligible auxiliary fits never yield silent smooth bands", {
  fit <- .smooth_plot_ci_fixture()
  weighted <- fit
  weighted$weights <- rep(2, nrow(fit$Y))
  expect_error(plot(weighted, B = 100, draw = FALSE), "[Ww]eight")
  expect_no_error(plot(weighted, se = FALSE, draw = FALSE))
  local_mocked_bindings(.cjqr_eal_ci_indices = function(n, B, seed) {
    rows <- matrix(rep(seq_len(n), B), nrow = n)
    rows[, 1L] <- 1L
    rows
  }, .package = "CJQR")
  frozen <- serialize(fit, NULL)
  expect_error(plot(fit, B = 100, draw = FALSE), "failed|rank|unavailable")
  expect_identical(serialize(fit, NULL), frozen)
})

test_that("smooth interval plotting leaves an absent random seed absent", {
  fit <- .smooth_plot_ci_fixture()
  existed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (existed) saved <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    if (existed) assign(".Random.seed", saved, envir = .GlobalEnv)
    else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
      rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
    rm(".Random.seed", envir = .GlobalEnv)
  plot(fit, B = 100, draw = FALSE)
  expect_false(exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
})

test_that("default smooth bands render and restore graphics layout", {
  fit <- .smooth_plot_ci_fixture()
  spatial <- .smooth_plot_ci_fixture("spatial")
  grDevices::pdf(NULL)
  on.exit(grDevices::dev.off(), add = TRUE)
  graphics::par(mfrow = c(2, 2))
  initial <- graphics::par("mfrow")
  expect_invisible(plot(fit, B = 100, pages = 1, col = "navy", lwd = 3,
                        xlab = "Covariate", ylab = "s(x)"))
  expect_identical(graphics::par("mfrow"), initial)
  for (scheme in 0:2) {
    expect_invisible(plot(spatial, B = 100, n2 = 12, pages = 1,
                          scheme = scheme, rug = FALSE))
    expect_identical(graphics::par("mfrow"), initial)
  }
})

test_that("smooth intervals render as two dashed lines without shading or clipping", {
  fit <- .smooth_plot_ci_fixture()
  calls <- new.env(parent = emptyenv())
  calls$polygons <- calls$lines <- list()
  grDevices::pdf(NULL)
  on.exit(grDevices::dev.off(), add = TRUE)
  local_mocked_bindings(
    polygon = function(...) {
      calls$polygons[[length(calls$polygons) + 1L]] <- list(...)
      invisible(NULL)
    },
    lines = function(...) {
      calls$lines[[length(calls$lines) + 1L]] <- list(...)
      invisible(NULL)
    }, .package = "graphics")
  panel <- CJQR:::plot.cjqr_eal(fit, B = 100, rug = FALSE)[[1L]]
  expect_length(calls$polygons, 0L)
  expect_length(calls$lines, 3L)
  expect_lte(graphics::par("usr")[3L], min(panel$lower))
  expect_gte(graphics::par("usr")[4L], max(panel$upper))
  for (k in 1:3) expect_equal(calls$lines[[k]][[1L]], panel$axes[[1L]])
  expect_equal(calls$lines[[1L]][[2L]], panel$lower)
  expect_equal(calls$lines[[2L]][[2L]], panel$upper)
  expect_equal(calls$lines[[3L]][[2L]], panel$fit)
  for (k in 1:2) {
    expect_identical(calls$lines[[k]]$lty, 2L)
    expect_identical(calls$lines[[k]]$col, calls$lines[[3L]]$col)
    expect_equal(calls$lines[[k]]$lwd, calls$lines[[3L]]$lwd / 2)
  }
  expect_true(calls$lines[[3L]]$lty %in% c(1, "solid"))
  CJQR:::plot.cjqr_eal(fit, se = FALSE, rug = FALSE)
  expect_length(calls$polygons, 0L)
  expect_length(calls$lines, 3L)

  styled <- CJQR:::plot.cjqr_eal(fit, type = "smooth", interval = "confidence",
    B = 100, rug = FALSE, col = "navy", lwd = 4, lty = 3)[[1L]]
  expect_length(calls$polygons, 0L)
  expect_length(calls$lines, 6L)
  expect_equal(calls$lines[[4L]][[2L]], styled$lower)
  expect_equal(calls$lines[[5L]][[2L]], styled$upper)
  expect_equal(calls$lines[[6L]][[2L]], styled$fit)
  for (k in 4:6) expect_identical(calls$lines[[k]]$col, "navy")
  for (k in 4:5) {
    expect_identical(calls$lines[[k]]$lty, 2L)
    expect_equal(calls$lines[[k]]$lwd, 2)
  }
  expect_equal(calls$lines[[6L]]$lwd, 4)
  expect_equal(calls$lines[[6L]]$lty, 3)
})

test_that("spatial rendering displays all three interval surfaces on a common scale", {
  fit <- .smooth_plot_ci_fixture("spatial")
  calls <- list()
  local_mocked_bindings(contour = function(...) {
    calls[[length(calls) + 1L]] <<- list(...)
    invisible(NULL)
  }, .package = "graphics")
  panel <- plot(fit, B = 100, n2 = 12, scheme = 0, rug = FALSE)[[1L]]
  expect_length(calls, 3L)
  expect_identical(calls[[1L]]$z, panel$fit)
  expect_identical(calls[[2L]]$z, panel$lower)
  expect_identical(calls[[3L]]$z, panel$upper)
  expect_identical(calls[[1L]]$levels, calls[[2L]]$levels)
  expect_identical(calls[[1L]]$levels, calls[[3L]]$levels)
  expect_match(calls[[1L]]$main, "estimate")
  expect_match(calls[[2L]]$main, "95% pointwise lower", fixed = TRUE)
  expect_match(calls[[3L]]$main, "95% pointwise upper", fixed = TRUE)
})
