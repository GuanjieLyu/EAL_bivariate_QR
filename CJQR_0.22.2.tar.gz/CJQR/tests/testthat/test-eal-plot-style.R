.eal_plot_style_fixture <- function() {
  # Fixed plot payload only: no estimator or bootstrap is run by these tests.
  fit <- array(as.numeric(seq_len(12L)), c(3L, 2L, 2L),
    dimnames = list(c("a", "b", "c"), c("y1", "y2"), c("0.1", "0.9")))
  ci <- structure(list(fit = fit, lower = fit - .2, upper = fit + .3,
                        available = TRUE), class = "cjqr_eal_ci")
  object <- structure(list(data = data.frame(x = c(.3, -.1, .2)),
    responses = c("y1", "y2"), degree = 3L, fit = list(strict_ok = TRUE),
    selection = list(strict_ok = TRUE)), class = "cjqr_eal")
  list(object = object, fit = fit, ci = ci)
}

test_that("quantile styles retain defaults and expand only scalar or per-quantile vectors", {
  style <- CJQR:::.cjqr_eal_quantile_plot_style
  before <- grDevices::dev.cur()
  a <- style(list(), 3L)
  expect_identical(a$col, 1:3)
  expect_identical(a$lwd, rep(2, 3L))
  expect_identical(a$lty, rep(1L, 3L))
  expect_identical(a$bound_lwd, rep(1, 3L))
  expect_identical(a$bound_lty, rep(2L, 3L))
  b <- style(list(col = "navy", lwd = 3, lty = "dashed"), 2L)
  expect_identical(b$col, rep("navy", 2L))
  expect_identical(b$lwd, c(3, 3))
  expect_identical(b$lty, rep("dashed", 2L))
  expect_identical(b$bound_lwd, c(1.5, 1.5))
  expect_identical(b$bound_lty, c(5L, 5L))
  expect_identical(style(list(lty = c("44", "1212")), 2L)$bound_lty, c(5L, 2L))
  expect_identical(grDevices::dev.cur(), before)
  for (bad in list(list(col = c("red", "blue")), list(lwd = c(1, 2)),
                   list(lty = c(1, 2)), list(lwd = numeric()), list(col = matrix("red")))) {
    expect_error(style(bad, 3L), "length 1 or length\\(probs\\)")
  }
  expect_error(style(list(col = "not_a_color"), 2L), "Invalid col")
  for (bad in list(0, -1, NA_real_, Inf, "2"))
    expect_error(style(list(lwd = bad), 2L), "positive finite")
  for (bad in list(7, 1.5, NA_real_, "invalid", "123", "00", TRUE))
    expect_error(style(list(lty = bad), 2L), "lty")
})

test_that("actual quantile curves and legends share styles while bounds stay distinct", {
  fixture <- .eal_plot_style_fixture()
  frozen <- serialize(fixture, NULL)
  calls <- new.env(parent = emptyenv())
  calls$lines <- list()
  calls$legend <- NULL
  calls$payload <- fixture$fit
  previous_device <- grDevices::dev.cur()
  grDevices::pdf(NULL)
  plot_device <- grDevices::dev.cur()
  on.exit({
    if (plot_device %in% grDevices::dev.list()) grDevices::dev.off(plot_device)
  }, add = TRUE)
  local_mocked_bindings(
    predict = function(object, ...) calls$payload,
    .package = "stats")
  local_mocked_bindings(
    lines = function(x, y, ...) {
      calls$lines[[length(calls$lines) + 1L]] <- c(list(x = x, y = y), list(...))
      invisible(NULL)
    },
    legend = function(...) { calls$legend <- list(...); invisible(NULL) },
    .package = "graphics")
  values <- CJQR:::plot.cjqr_eal(fixture$object, type = "quantile", eq = 2L,
    variable = "x", probs = c(.1, .9), col = c("navy", "darkorange"),
    lwd = c(3, 1), lty = c(2L, 3L), main = "Profile")
  expect_identical(values, fixture$fit)
  expect_length(calls$lines, 2L)
  expect_identical(vapply(calls$lines, `[[`, character(1L), "col"), c("navy", "darkorange"))
  expect_identical(vapply(calls$lines, `[[`, numeric(1L), "lwd"), c(3, 1))
  expect_identical(vapply(calls$lines, `[[`, integer(1L), "lty"), c(2L, 3L))
  expect_identical(calls$legend$col, c("navy", "darkorange"))
  expect_identical(calls$legend$lwd, c(3, 1))
  expect_identical(calls$legend$lty, c(2L, 3L))
  ord <- order(fixture$object$data$x)
  expect_identical(calls$lines[[1L]]$x, fixture$object$data$x[ord])
  expect_identical(unname(calls$lines[[1L]]$y), unname(fixture$fit[ord, 2L, 1L]))

  calls$lines <- list()
  calls$payload <- fixture$ci
  intervals <- CJQR:::plot.cjqr_eal(fixture$object, type = "quantile", eq = 2L,
    variable = "x", probs = c(.1, .9), interval = "confidence",
    col = c("navy", "darkorange"), lwd = c(3, 1), lty = c(2L, 3L))
  expect_identical(intervals, fixture$ci)
  expect_length(calls$lines, 6L)
  expect_identical(vapply(calls$lines, `[[`, character(1L), "col"),
                   c("navy", "navy", "navy", "darkorange", "darkorange", "darkorange"))
  expect_identical(vapply(calls$lines, `[[`, numeric(1L), "lwd"),
                   c(1.5, 1.5, 3, .5, .5, 1))
  expect_identical(vapply(calls$lines, `[[`, integer(1L), "lty"),
                   c(5L, 5L, 2L, 2L, 2L, 3L))
  expect_identical(calls$lines[[1L]]$y, fixture$ci$lower[ord, 2L, 1L])
  expect_identical(calls$lines[[2L]]$y, fixture$ci$upper[ord, 2L, 1L])
  expect_identical(unname(calls$lines[[3L]]$y), unname(fixture$ci$fit[ord, 2L, 1L]))
  expect_identical(calls$legend$col, c("navy", "darkorange"))
  expect_identical(calls$legend$lwd, c(3, 1))
  expect_identical(calls$legend$lty, c(2L, 3L))
  expect_identical(serialize(fixture, NULL), frozen)
  grDevices::dev.off(plot_device)
  expect_identical(grDevices::dev.cur(), previous_device)
})

test_that("invalid styles fail before prediction and draw FALSE does not change the payload", {
  fixture <- .eal_plot_style_fixture()
  calls <- 0L
  local_mocked_bindings(predict = function(object, ...) {
    calls <<- calls + 1L
    fixture$fit
  }, .package = "stats")
  before <- grDevices::dev.cur()
  expect_error(CJQR:::plot.cjqr_eal(fixture$object, type = "quantile", probs = c(.1, .9),
    interval = "confidence", col = c("red", "blue", "black"), draw = FALSE), "length")
  expect_identical(calls, 0L)
  a <- CJQR:::plot.cjqr_eal(fixture$object, type = "quantile", probs = c(.1, .9),
                           col = "navy", lwd = 3, lty = "dotdash", draw = FALSE)
  expect_identical(calls, 1L)
  expect_identical(a, fixture$fit)
  expect_identical(grDevices::dev.cur(), before)
  expect_error(CJQR:::plot.cjqr_eal(fixture$object, type = "quantile", eq = 1,
                                  margin = 2, draw = FALSE), "different equations")
  expect_error(CJQR:::plot.cjqr_eal(fixture$object, type = "quantile", select = 1,
                                  draw = FALSE), "select is for smooth")
})
