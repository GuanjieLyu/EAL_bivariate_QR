# Gaussian GAMs below provide basis metadata only. The deterministic EAL
# coefficient arrays are test fixtures, not claims of fitted EAL estimates.
.eal_presentation_fixture <- function(two_dim = FALSE, factor_by = FALSE,
                                       parametric_only = FALSE) {
  n <- 90L
  d <- data.frame(x = seq(-1, 1, length.out = n),
    w = sin(seq_len(n) * 1.37), z = as.numeric(seq_len(n) %% 2L),
    g = factor(rep(c("a", "b"), length.out = n)))
  d$y1 <- .3 + .4 * d$z + sin(pi * d$x) + cos(seq_len(n) * 2.3) / 5
  d$y2 <- -.2 - .3 * d$z + cos(pi * d$x) + sin(seq_len(n) * 2.1) / 5
  rhs <- if (parametric_only) "z + x" else if (factor_by)
    "g + s(x, by = g, k = 5)" else if (two_dim)
    "z + s(x, w, k = 12)" else "z + s(x, k = 6)"
  formulas <- lapply(c("y1", "y2"), function(y)
    as.formula(paste(y, "~", rhs), env = asNamespace("mgcv")))
  basis <- lapply(formulas, function(f) mgcv::gam(f, data = d, method = "REML"))
  X <- predict(basis[[1L]], type = "lpmatrix")
  beta <- cbind(coef(basis[[1L]]) * .7, coef(basis[[2L]]) * 1.2)
  dimnames(beta) <- list(colnames(X), c("y1", "y2"))
  object <- list(call = quote(cjqr_eal(list(y1 ~ z + s(x), y2 ~ z + s(x)), data)),
    X = X, Y = as.matrix(d[c("y1", "y2")]), data = d,
    formulas = formulas, responses = c("y1", "y2"), basis = basis,
    covariates = all.vars(formulas[[1L]][[3L]]), degree = 3L, copula = "gaussian",
    selection = list(strict_ok = TRUE, audit = data.frame(anchor = .5, strict = TRUE)),
    omitted_rows = integer(), elapsed_seconds = 0,
    fit = list(strict_ok = TRUE, beta = beta, p = .5, degree = 3L,
      theta = -.4, sigma = c(.7, .8), shape = matrix(0, 5L, 2L),
      loglik = -100, stationarity = 1e-9, improved_certificate = list()))
  class(object) <- "cjqr_eal"
  object
}

test_that("equation summaries separate parametric and smooth coefficients honestly", {
  x <- .eal_presentation_fixture()
  frozen <- serialize(x, NULL)
  sm <- summary(x)
  expect_s3_class(sm, "summary.cjqr_eal")
  expect_identical(colnames(sm$tableP1), "Estimate")
  expect_identical(rownames(sm$tableP1), c("(Intercept)", "z"))
  expect_equal(unname(sm$tableP1[, 1L]), unname(x$fit$beta[1:2, 1L]), tolerance = 0)
  expect_identical(names(sm$tableNP1), c("Select", "Smooth", "Coef.dim"))
  expect_identical(sm$tableNP1$Select, 1L)
  expect_identical(sm$tableNP1$Smooth, "s(x)")
  expect_equal(sm$tableNP1$Coef.dim, ncol(x$X) - 2L)
  expect_equal(unname(sm$tableP3[1L, 1L]), atanh(-.4), tolerance = 1e-14)
  txt <- paste(capture.output(print(sm)), collapse = "\n")
  expect_match(txt, "EQUATION 1")
  expect_match(txt, "EQUATION 3")
  expect_false(grepl("theta = -0.4", txt, fixed = TRUE))
  expect_match(txt, "tau = ", fixed = TRUE)
  expect_match(sm$inference, "conditional joint OPG trace", fixed = TRUE)
  expect_match(txt, "Convergence:", fixed = TRUE)
  expect_false(grepl("Std. Error|Pr\\(>|Signif. codes|s\\(x\\)\\.1", txt))
  expect_identical(serialize(x, NULL), frozen)
  expect_identical(withVisible(print(x))$value, x)
})

test_that("EAL summary has clean GJRM headings and honest smooth display matrices", {
  x <- .eal_presentation_fixture()
  set.seed(917L)
  rng <- .Random.seed
  frozen <- serialize(x, NULL)
  sm <- summary(x)
  lines <- capture.output(print(sm))
  expect_identical(lines[grepl("^EQUATION", lines)],
                   c("EQUATION 1", "EQUATION 2", "EQUATION 3"))
  txt <- paste(lines, collapse = "\n")
  expect_false(grepl("EQUATION [123] -|constant dependence|delta", txt))
  expect_match(txt, "Link function for mu.1: identity", fixed = TRUE)
  expect_match(txt, "Link function for theta: atanh", fixed = TRUE)
  expect_match(txt, "Smooth components:", fixed = TRUE)
  expect_false(grepl("Coef.dim|Signif. codes|\\*\\*", txt))
  for (j in 1:2) {
    tab <- sm$smooth_tables[[j]]
    expect_identical(colnames(tab), c("edf", "p-value"))
    expect_identical(rownames(tab), sm$equations[[j]]$smooth$Smooth)
    expect_true(is.double(tab))
    expect_true(all(is.na(tab)))
  }
  expect_identical(serialize(x, NULL), frozen)
  expect_identical(.Random.seed, rng)
  # Basis preparation uncertainty must never leak into EAL inference slots.
  for (j in 1:2) {
    x$basis[[j]]$edf[] <- 999
    x$basis[[j]]$Vp[] <- 999
  }
  expect_identical(summary(x)$smooth_tables, sm$smooth_tables)
})

test_that("old serialized EAL summaries print without changing their saved fields", {
  old <- summary(.eal_presentation_fixture())
  old$smooth_tables <- NULL
  old$dependence_link_name <- NULL
  frozen <- serialize(old, NULL)
  txt <- paste(capture.output(print(old)), collapse = "\n")
  expect_match(txt, "edf", fixed = TRUE)
  expect_match(txt, "p-value", fixed = TRUE)
  expect_false(grepl("Rank|Statistic|Ref.df|Chi.sq", txt))
  expect_match(txt, "Link function for theta: atanh", fixed = TRUE)
  expect_identical(serialize(old, NULL), frozen)
})

test_that("empty, factor-by and spatial smooth displays preserve equation metadata", {
  cases <- list(.eal_presentation_fixture(parametric_only = TRUE),
    .eal_presentation_fixture(factor_by = TRUE),
    .eal_presentation_fixture(two_dim = TRUE))
  for (x in cases) {
    sm <- summary(x)
    for (j in 1:2) {
      expect_equal(nrow(sm$smooth_tables[[j]]), nrow(sm$equations[[j]]$smooth))
      expect_true(all(is.na(sm$smooth_tables[[j]])))
    }
    expect_output(print(sm), "EQUATION 3")
  }
  expect_identical(dim(summary(cases[[1L]])$smooth_tables[[1L]]), c(0L, 2L))
})

test_that("smooth summaries show only EDF and p-values while retaining inferential internals", {
  fit <- .eal_coef_fixture()
  frozen_fit <- serialize(fit, NULL)
  sm <- summary(fit, inference = "reference", B = 199L, seed = 136L)
  before <- serialize(sm, NULL)
  lines <- capture.output(print(sm, signif.stars = TRUE))
  txt <- paste(lines, collapse = "\n")
  expect_false(grepl("Rank|Statistic|Ref.df|Chi.sq", txt))
  expect_match(txt, "edf", fixed = TRUE)
  expect_match(txt, "p-value", fixed = TRUE)
  smooth_rows <- lines[grepl("^s\\(x\\)[[:space:]]", lines)]
  expect_length(smooth_rows, 2L)
  expect_true(all(grepl("\\*", smooth_rows)))
  expect_equal(sum(grepl("Signif. codes:", lines, fixed = TRUE)), 4L)
  for (j in 1:2) {
    expect_identical(colnames(sm$smooth_tables[[j]]), c("edf", "p-value"))
    expect_identical(colnames(sm$smooth_inference$tables[[j]]), c("Rank", "Statistic", "p-value"))
    expect_equal(sm$smooth_tables[[j]][, "p-value"], sm$smooth_inference$tables[[j]][, "p-value"])
    expect_true(is.finite(sm$smooth_inference$details[[j]][[1L]]$statistic))
    expect_identical(sm$smooth_inference$details[[j]][[1L]]$rank, 2L)
  }
  expect_identical(serialize(sm, NULL), before)
  expect_identical(serialize(fit, NULL), frozen_fit)
  quiet <- capture.output(print(sm, signif.stars = FALSE))
  expect_false(any(grepl("Signif. codes:|\\*", quiet)))
})

test_that("legacy four-column smooth summaries are simplified at print time only", {
  sm <- summary(.eal_coef_fixture(), inference = "reference", B = 199L, seed = 18L)
  for (j in 1:2) sm$smooth_tables[[j]] <- cbind(
    edf = sm$smooth_tables[[j]][, "edf"], sm$smooth_inference$tables[[j]])
  sm$inference <- paste(sm$inference,
    "Rank: tested block dimension; Statistic: convex-hull radial statistic, not Chi.sq.")
  before <- serialize(sm, NULL)
  txt <- paste(capture.output(print(sm)), collapse = "\n")
  expect_false(grepl("Rank|Statistic|Ref.df|Chi.sq", txt))
  expect_match(sm$inference, "whole-block auxiliary regions", fixed = TRUE)
  expect_match(txt, "p-value", fixed = TRUE)
  expect_identical(serialize(sm, NULL), before)
  for (j in 1:2) expect_identical(colnames(sm$smooth_tables[[j]]),
    c("edf", "Rank", "Statistic", "p-value"))
  # Summaries from before smooth tests existed used different unavailable
  # column names. Printing must hide those without inventing EDF or tests.
  for (j in 1:2) sm$smooth_tables[[j]] <- matrix(NA_real_, 1L, 4L,
    dimnames = list("s(x)", c("edf", "Ref.df", "Chi.sq", "p-value")))
  sm$smooth_inference <- NULL
  sm$coefficient_inference <- NULL
  sm$inference <- "Legacy inference unavailable."
  before <- serialize(sm, NULL)
  txt <- paste(capture.output(print(sm)), collapse = "\n")
  expect_false(grepl("Rank|Statistic|Ref.df|Chi.sq", txt))
  expect_false(grepl("Legacy inference unavailable.", txt, fixed = TRUE))
  expect_identical(serialize(sm, NULL), before)
})

test_that("compact footer retains tau interval and checked convergence without verbose notes", {
  fit <- .eal_coef_fixture()
  sm <- summary(fit, inference = "reference", B = 149L, seed = 27L)
  txt <- paste(capture.output(print(sm)), collapse = "\n")
  expect_match(txt, "95% CI", fixed = TRUE)
  expect_false(grepl("95% auxiliary-bootstrap CI", txt, fixed = TRUE))
  expect_match(txt, "Estimated Kendall's tau", fixed = TRUE)
  expect_match(txt, "Convergence:", fixed = TRUE)
  expect_false(grepl("theta =|Equation 3 coefficients|tau denotes|Auxiliary bootstrap:|Smooth-test p-value floor:|Intercepts: Bonferroni|Numerical certification passed", txt))
  expect_false(grepl("Auxiliary-bootstrap coefficient CIs and interval-inversion", txt, fixed = TRUE))
  expect_true(sm$tau_ci$available)
  expect_identical(sm$tau_ci$estimate, sm$kendall_tau)
  expect_identical(sm$convergence$status, "not assessed")
  expect_true(length(sm$convergence$checks) > 0L)
  expect_match(sm$inference, "Kendall tau intervals", fixed = TRUE)
  old <- sm
  old$tau_ci <- old$convergence <- NULL
  frozen <- serialize(old, NULL)
  oldtxt <- paste(capture.output(print(old)), collapse = "\n")
  expect_match(oldtxt, "CI not computed", fixed = TRUE)
  expect_match(oldtxt, "Convergence: not assessed", fixed = TRUE)
  expect_identical(serialize(old, NULL), frozen)
})

test_that("estimated scales identify each margin in order and honor print digits", {
  sm <- summary(.eal_presentation_fixture())
  sm$scales <- c(.4723, .2892)
  frozen <- serialize(sm, NULL)
  lines <- capture.output(print(sm, digits = 4L))
  expect_identical(lines[grepl("^Estimated marginal scales:", lines)],
    "Estimated marginal scales: sigma.1 = 0.4723, sigma.2 = 0.2892")
  expect_false(any(grepl("Constant marginal scales", lines, fixed = TRUE)))
  expect_identical(serialize(sm, NULL), frozen)
  coarse <- capture.output(print(sm, digits = 2L))
  expect_identical(coarse[grepl("^Estimated marginal scales:", coarse)],
    "Estimated marginal scales: sigma.1 = 0.47, sigma.2 = 0.29")
  expect_identical(serialize(sm, NULL), frozen)
})

test_that("convergence printing uses only concise new and legacy status labels", {
  template <- summary(.eal_presentation_fixture())
  cases <- c("converged" = "converged", "not converged" = "not converged",
    "not assessed" = "not assessed", "passed" = "converged",
    "failed" = "not converged", "incomplete" = "not assessed")
  for (status in names(cases)) {
    sm <- template
    sm$convergence <- list(status = status, stationarity = 1.234e-8,
      tolerance = 1e-6, message = "Detailed convergence message must remain metadata.",
      checks = c(first = TRUE, second = FALSE), reasons = "Diagnostic reason remains stored.")
    frozen <- serialize(sm, NULL)
    lines <- capture.output(print(sm))
    expect_identical(lines[grepl("^Convergence:", lines)],
      paste0("Convergence: ", unname(cases[status])))
    expect_false(any(grepl("stationarity|1.234|Detailed convergence message|Diagnostic reason", lines)))
    expect_identical(sm$convergence$stationarity, 1.234e-8)
    expect_identical(sm$convergence$tolerance, 1e-6)
    expect_identical(sm$convergence$checks, c(first = TRUE, second = FALSE))
    expect_identical(serialize(sm, NULL), frozen)
  }
})

test_that("missing or malformed saved convergence statuses print not assessed", {
  template <- summary(.eal_presentation_fixture())
  records <- list(NULL, list(), list(status = NULL), list(status = "unknown"),
    list(status = NA_character_), list(status = character()),
    list(status = c("converged", "not converged")), list(status = TRUE),
    list(status = 0), list(status = list("converged")))
  for (record in records) {
    sm <- template
    sm$convergence <- record
    frozen <- serialize(sm, NULL)
    lines <- capture.output(print(sm))
    expect_identical(lines[grepl("^Convergence:", lines)], "Convergence: not assessed")
    expect_false(any(grepl("scaled stationarity|unavailable in this saved summary|regenerate summary", lines)))
    expect_identical(serialize(sm, NULL), frozen)
  }
  expect_identical(template$convergence$status, "not assessed")
  expect_true(is.finite(template$convergence$stationarity))
  expect_true(length(template$convergence$checks) > 0L)
})

test_that("summary transforms every supported dependence family correctly", {
  x <- .eal_presentation_fixture()
  cases <- list(gaussian = -.4, student_t = -.4, clayton = 2, frank = -4, gumbel = 2)
  links <- c(gaussian = "atanh", student_t = "atanh", clayton = "log",
             frank = "identity", gumbel = "log(theta - 1)")
  for (family in names(cases)) {
    x$copula <- family
    x$fit$theta <- cases[[family]]
    x$df <- if (family == "student_t") 5 else NULL
    sm <- summary(x)
    expect_identical(sm$dependence_link_name, unname(links[family]))
    expect_equal(sm$theta, cases[[family]])
    txt <- paste(capture.output(print(sm)), collapse = "\n")
    expect_match(txt, paste0("Link function for theta: ", links[family]), fixed = TRUE)
    expect_false(grepl(paste0("theta = ", format(cases[[family]], digits = 4)), txt, fixed = TRUE))
    expect_false(grepl("delta|rho =", txt))
    expect_equal(sm$delta, CJQR:::.cjqr_delta_from_theta(x$fit$theta, family))
    expect_equal(sm$kendall_tau, CJQR:::.cjqr_kendall_tau(x$fit$theta, family,
                                                         df = x$df))
    if (family == "student_t") {
      expect_identical(sm$df, 5)
      expect_match(paste(capture.output(print(sm)), collapse = " "), "fixed df = 5")
    }
    if (family == "frank") expect_lt(sm$kendall_tau, 0)
    if (family == "gumbel") expect_equal(sm$kendall_tau, .5)
  }
  x$copula <- "frank"
  x$fit$theta <- 4
  x$df <- NULL
  expect_equal(summary(x)$tableP3[1, 1], 4)
  expect_gt(summary(x)$kendall_tau, 0)
})

test_that("one-dimensional panels use the joint coefficient block and training center", {
  x <- .eal_presentation_fixture()
  frozen <- serialize(x, NULL)
  panels <- plot(x, eq = 2, select = 1, n = 27, se = FALSE, draw = FALSE)
  p <- panels[[1L]]
  sm <- x$basis[[2L]]$smooth[[1L]]
  idx <- seq.int(sm$first.para, sm$last.para)
  raw <- drop(x$X[, idx, drop = FALSE] %*% x$fit$beta[idx, 2L])
  target <- drop(mgcv::PredictMat(sm, p$grid) %*% x$fit$beta[idx, 2L]) - mean(raw)
  expect_identical(p$select, 1L)
  expect_identical(p$equation, 2L)
  expect_length(p$fit, 27L)
  expect_equal(p$fit, target, tolerance = 0)
  expect_equal(p$center, mean(raw), tolerance = 0)
  expect_equal(mean(p$training_centered), 0, tolerance = 1e-14)
  expect_null(p$se)
  expect_identical(serialize(x, NULL), frozen)
  expect_error(plot(x, eq = 3, draw = FALSE), "constant dependence")
  expect_true(all(is.finite(plot(x, eq = 1, se = TRUE, B = 100,
                                draw = FALSE)[[1L]]$lower)))
  expect_true(all(is.finite(plot(x, eq = 1, type = "smooth",
    interval = "confidence", B = 100, draw = FALSE)[[1L]]$upper)))
  expect_error(plot(x, eq = 1, unconditional = TRUE, draw = FALSE), "Unsupported EAL plot")
  expect_error(plot(x, eq = 1, select = 9, draw = FALSE), "select")
})

test_that("two-dimensional and factor-by effects preserve their intended bases", {
  x <- .eal_presentation_fixture(two_dim = TRUE)
  p <- plot(x, eq = 1, n2 = 12, too.far = 0, se = FALSE, draw = FALSE)[[1L]]
  expect_identical(dim(p$fit), c(12L, 12L))
  expect_identical(p$variables, c("x", "w"))
  expect_true(all(is.finite(p$fit)))
  expect_equal(mean(p$training_centered), 0, tolerance = 1e-14)
  by <- .eal_presentation_fixture(factor_by = TRUE)
  panels <- plot(by, eq = 1, n = 21, se = FALSE, draw = FALSE)
  expect_length(panels, 2L)
  for (k in 1:2) {
    sm <- by$basis[[1L]]$smooth[[k]]
    expect_identical(unique(as.character(panels[[k]]$grid$g)), sm$by.level)
    ids <- panels[[k]]$coefficient_indices
    direct <- drop(mgcv::PredictMat(sm, panels[[k]]$grid) %*% by$fit$beta[ids, 1L]) -
      mean(drop(by$X[, ids, drop = FALSE] %*% by$fit$beta[ids, 1L]))
    expect_equal(panels[[k]]$fit, direct, tolerance = 0)
  }
})

test_that("complete quantile plotting remains available explicitly and compatibly", {
  x <- .eal_presentation_fixture()
  d <- data.frame(x = seq(-.8, .8, length.out = 11L), z = 0)
  expected <- predict(x, newdata = d, probs = c(.1, .9))
  pr <- plot(x, type = "quantile", newdata = d, variable = "x",
             probs = c(.1, .9), margin = 2L, draw = FALSE)
  old <- plot(x, newdata = d, variable = "x", probs = c(.1, .9),
              margin = 2L, draw = FALSE)
  expect_identical(pr, expected)
  expect_identical(old, expected)
  expect_error(plot(x, type = "quantile", eq = 1, margin = 2, draw = FALSE), "different equations")
  expect_error(plot(x, type = "quantile", select = 1, draw = FALSE), "select is for smooth")
  plain <- .eal_presentation_fixture(parametric_only = TRUE)
  expect_equal(nrow(summary(plain)$tableNP1), 0L)
  expect_error(plot(plain, draw = FALSE), "no smooth components")
  expect_true(is.array(plot(plain, type = "quantile", draw = FALSE)))
})

test_that("drawing supports one and two dimensions and restores panel layout", {
  x <- .eal_presentation_fixture()
  grDevices::pdf(NULL)
  on.exit(grDevices::dev.off(), add = TRUE)
  layout <- graphics::par("mfrow")
  expect_invisible(plot(x, eq = 1, pages = 1, B = 100,
                        main = "Joint smooth", col = "blue"))
  expect_identical(graphics::par("mfrow"), layout)
  spatial <- .eal_presentation_fixture(two_dim = TRUE)
  for (scheme in 0:2)
    expect_invisible(plot(spatial, eq = 2, n2 = 12, B = 100,
                          scheme = scheme, rug = FALSE))
})
