test_that("EAL smooth effect axes use exact term labels and honour overrides", {
  # Rendering fixtures only: no likelihood fit or uncertainty calculation.
  panel <- list(label = "s(age)", equation = 1L, variables = "age",
    axes = list(c(20, 40, 60)), fit = c(-.1, .2, -.1),
    raw = data.frame(age = c(20, 40, 60)), by_profile = NULL)
  frozen <- serialize(panel, NULL)
  calls <- list()
  local_mocked_s3_method("plot", "default", function(...) {
    calls[[length(calls) + 1L]] <<- list(...)
    invisible(NULL)
  })
  draw <- CJQR:::.cjqr_eal_draw_smooths
  for (label in c("s(age)", "s(bmi)", "s(age):sexFemale")) {
    current <- panel
    current$label <- label
    result <- draw(list(current), 0L, FALSE, 0L, list())
    expect_identical(tail(calls, 1L)[[1L]]$ylab, label)
    expect_identical(tail(calls, 1L)[[1L]]$y, panel$fit)
    expect_identical(result, list(current))
  }
  for (label in c("Custom effect", "")) {
    draw(list(panel), 0L, FALSE, 0L, list(ylab = label))
    expect_identical(tail(calls, 1L)[[1L]]$ylab, label)
  }
  expect_identical(serialize(panel, NULL), frozen)
})

test_that("two-dimensional EAL smooths retain covariate axes", {
  panel <- list(label = "te(age,bmi)", equation = 2L,
    variables = c("age", "bmi"), axes = list(1:3, 4:6),
    fit = matrix(seq_len(9L), 3L), by_profile = NULL)
  calls <- list()
  capture <- function(...) {
    calls[[length(calls) + 1L]] <<- list(...)
    invisible(NULL)
  }
  local_mocked_bindings(contour = capture, persp = capture,
                        .package = "graphics")
  draw <- CJQR:::.cjqr_eal_draw_smooths
  draw(list(panel), 0L, FALSE, 0L, list())
  expect_identical(calls[[1L]]$xlab, "age")
  expect_identical(calls[[1L]]$ylab, "bmi")
  draw(list(panel), 0L, FALSE, 1L, list())
  expect_identical(calls[[2L]]$zlab, "te(age,bmi)")
  expect_identical(calls[[2L]]$z, panel$fit)
  draw(list(panel), 0L, FALSE, 1L, list(zlab = "Custom surface"))
  expect_identical(calls[[3L]]$zlab, "Custom surface")
})
