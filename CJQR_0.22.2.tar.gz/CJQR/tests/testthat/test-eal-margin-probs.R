# These fixtures are deliberately independent of the other test files. They
# exercise prediction and the auxiliary pairs bootstrap, never an EAL fit.

.margin_probs_fixture <- function(distinct = FALSE) {
  x <- seq(-.8, .8, length.out = 40L)
  X <- cbind("(Intercept)" = 1, x = x)
  rownames(X) <- paste0("subject", seq_along(x))
  beta <- matrix(c(.1, .7, -.2, -.4), 2L, 2L)
  if (distinct) {
    X <- list(first = X, second = cbind(X, z = x^2))
    beta <- list(first = c(.1, .7), second = c(-.2, -.4, .3))
  }
  location <- CJQR:::.cjqr_eal_location(X, beta)
  Y <- location + cbind(sin(seq_along(x)), cos(seq_along(x)))
  colnames(Y) <- c("first", "second")
  data <- data.frame(x = x, first = Y[, 1L], second = Y[, 2L],
                     row.names = rownames(Y))
  structure(list(X = X, Y = Y, data = data, covariates = "x",
    responses = c("first", "second"), degree = 3L, copula = "gaussian",
    selection = list(strict_ok = TRUE),
    fit = list(strict_ok = TRUE, p = .35, beta = beta, sigma = c(.7, 1.2),
      shape = matrix(c(.05, -.03, .02, .04, -.01,
                       -.02, .04, .01, -.03, .02), 5L, 2L))),
    class = "cjqr_eal")
}

test_that("legacy ignored targets and named numeric CI metadata are preserved", {
  object <- .margin_probs_fixture()
  expect_identical(predict(object, type = "location", probs = stop("must remain unused")),
                   predict(object, type = "location"))
  expect_identical(predict(object, type = "lpmatrix", probs = stop("must remain unused")),
                   object$X)
  p <- c(low = .1, high = .9)
  ans <- cjqr_eal_ci(object, probs = p, B = 100, seed = 73)
  expect_identical(ans$probs, p)
  expect_identical(ans$fit, predict(object, probs = unname(p)))
})

.margin_probs_slice <- function(values, j, requested, union) {
  matrix(values[, j, match(requested, union), drop = FALSE],
    nrow = dim(values)[1L], ncol = length(requested),
    dimnames = list(dimnames(values)[[1L]], as.character(requested)))
}

.margin_probs_expect_ci_equal <- function(actual, expected) {
  expect_identical(actual$probs, expected$probs)
  for (field in c("fit", "lower", "upper")) {
    expect_equal(actual[[field]], expected[[field]], tolerance = 1e-12)
    expect_equal(actual$reference[[field]], expected$reference[[field]],
                 tolerance = 1e-12)
  }
  expect_identical(actual$available, expected$available)
  expect_identical(actual$bootstrap$status, expected$bootstrap$status)
}

test_that("unequal probability lists preserve response and probability order", {
  for (distinct in c(FALSE, TRUE)) {
    object <- .margin_probs_fixture(distinct)
    requested <- list(first = c(.9, .1), second = .75)
    union <- c(.9, .1, .75)
    numeric_prediction <- predict(object, probs = union)
    answer <- predict(object, probs = requested)
    expect_type(answer, "list")
    expect_identical(names(answer), object$responses)
    expect_identical(dim(answer$first), c(40L, 2L))
    expect_identical(dim(answer$second), c(40L, 1L))
    for (j in 1:2) {
      expect_equal(answer[[j]], .margin_probs_slice(numeric_prediction, j,
        requested[[j]], union), tolerance = 1e-12)
      expect_identical(colnames(answer[[j]]), as.character(requested[[j]]))
      expect_identical(rownames(answer[[j]]), rownames(object$Y))
    }
    expect_identical(predict(object, probs = rev(requested)), answer)
    expect_identical(predict(object, probs = unname(requested)), answer)
    expect_identical(dim(numeric_prediction), c(40L, 2L, 3L))
  }
})

test_that("scalar margins and one observation retain matrices and invert the CDF", {
  object <- .margin_probs_fixture()
  object$X <- object$X[7L, , drop = FALSE]
  object$Y <- object$Y[7L, , drop = FALSE]
  object$data <- object$data[7L, , drop = FALSE]
  requested <- list(first = .2, second = .8)
  answer <- predict(object, probs = requested)
  expect_identical(dim(answer$first), c(1L, 1L))
  expect_identical(dim(answer$second), c(1L, 1L))
  y <- cbind(first = answer$first[, 1L], second = answer$second[, 1L])
  back <- predict(object, type = "cdf", y = y)
  expect_equal(unname(back), matrix(c(.2, .8), 1L, 2L), tolerance = 1e-8)
  same <- predict(object, probs = list(first = .5, second = .5))
  shared <- predict(object, probs = .5)
  expect_equal(same$first, .margin_probs_slice(shared, 1L, .5, .5))
  expect_equal(same$second, .margin_probs_slice(shared, 2L, .5, .5))
})

test_that("malformed per-margin probabilities fail before prediction or bootstrap", {
  object <- .margin_probs_fixture()
  bad <- list(list(), list(.2), list(.2, .5, .8),
    list(first = .2, third = .8), list(first = .2, first = .8),
    setNames(list(.2, .8), c("first", "")),
    setNames(list(.2, .8), c("first", NA_character_)),
    list(first = numeric(), second = .8),
    list(first = c(.2, .2), second = .8),
    list(first = .2, second = c(.8, .8)),
    list(first = 0, second = .8), list(first = .2, second = 1),
    list(first = -.2, second = .8), list(first = .2, second = 1.2),
    list(first = NA_real_, second = .8),
    list(first = NaN, second = .8), list(first = .2, second = Inf),
    list(first = ".2", second = .8), list(first = TRUE, second = .8),
    list(first = list(.2), second = .8),
    list(first = matrix(.2), second = .8),
    data.frame(first = .2, second = .8),
    structure(list(.2, .8), dim = c(1L, 2L)))
  for (p in bad) {
    expect_error(predict(object, probs = p), "probs|probabilit")
    expect_error(cjqr_eal_ci(object, probs = p, B = 100L), "probs|probabilit")
  }
  expect_error(predict(object, probs = c(.2, .2)), "probs|probabilit")
  object$probs <- list(first = .2, wrong = .8)
  expect_error(predict(object), "probs|probabilit")
  expect_error(cjqr_eal_ci(object, B = 100L), "probs|probabilit")
})

test_that("constructor validates targets before fitting and stores explicit defaults", {
  object <- .margin_probs_fixture()
  formulas <- list(first ~ x, second ~ x)
  expect_error(cjqr_eal(formulas, object$data,
    probs = list(first = .2, wrong = .8)), "probs|probabilit")
  expect_error(cjqr_eal(formulas, object$data,
    probs = list(first = c(.2, .2), second = .8)), "probs|probabilit")
  skip_if_not_installed("qgam", minimum_version = "2.0.0")
  original_engine <- CJQR:::.cjqr_eal_engine
  testthat::local_mocked_bindings(
    .cjqr_eal_prepare = function(validated) list(X = object$X,
      Y = object$Y, P = matrix(0, 2L, 2L), common_basis = TRUE,
      qr = qr(object$X), basis = list(NULL, NULL), penalty_metadata = list()),
    .cjqr_eal_qgam_native = function(formula, ...) {
      j <- match(as.character(formula[[2L]]), object$responses)
      beta <- setNames(object$fit$beta[, j], colnames(object$X))
      list(ok = TRUE, fit = list(coefficients = beta),
           prediction = drop(object$X %*% beta))
    },
    .cjqr_eal_engine = function(copula) {
      engine <- original_engine(copula)
      engine$fit <- function(...) object$fit
      engine
    },
    .cjqr_eal_select = function(candidates) list(strict_ok = TRUE, index = 1L),
    .package = "CJQR")
  targets <- list(first = c(.9, .1), second = .75)
  fitted_list <- cjqr_eal(formulas, object$data, anchors = .35,
                         probs = rev(targets))
  expect_identical(fitted_list$probs, targets)
  expect_identical(predict(fitted_list), predict(fitted_list, probs = targets))
  fitted_numeric <- cjqr_eal(formulas, object$data, anchors = .35,
                            probs = c(.8, .2))
  expect_identical(fitted_numeric$probs, c(.8, .2))
  expect_identical(predict(fitted_numeric),
                   predict(fitted_numeric, probs = c(.8, .2)))
  expect_identical(fitted_list$anchors, .35)
  expect_identical(fitted_numeric$fit$p, .35)
})

test_that("stored defaults, overrides, serialization and legacy grids agree", {
  object <- .margin_probs_fixture()
  oldfive <- c(.1, .25, .5, .75, .9)
  expect_identical(predict(object), predict(object, probs = oldfive))
  expect_identical(fitted(object), predict(object, probs = oldfive))
  expect_identical(dim(predict(object)), c(40L, 2L, 5L))
  for (p in list(c(.8, .2), list(first = c(.9, .1), second = .75))) {
    object$probs <- p
    snapshot <- serialize(object, NULL)
    expected <- predict(object, probs = p)
    expect_identical(predict(object), expected)
    expect_identical(predict(object, probs = NULL), expected)
    expect_identical(fitted(object), expected)
    expect_identical(predict(object, probs = oldfive),
                     predict(.margin_probs_fixture(), probs = oldfive))
    restored <- unserialize(snapshot)
    expect_identical(restored$probs, p)
    expect_identical(predict(restored), expected)
    expect_identical(serialize(object, NULL), snapshot)
  }
})

test_that("list intervals slice one shared union bootstrap without changing RNG or fit", {
  for (distinct in c(FALSE, TRUE)) {
    object <- .margin_probs_fixture(distinct)
    requested <- list(first = c(.9, .1), second = .75)
    union <- c(.9, .1, .75)
    snapshot <- serialize(object, NULL)
    withr::local_seed(981L)
    rng <- .Random.seed
    kind <- RNGkind()
    joint <- cjqr_eal_ci(object, probs = union, B = 100L,
                        seed = 73L, keep_draws = TRUE)
    answer <- cjqr_eal_ci(object, probs = rev(requested), B = 100L,
                         seed = 73L, keep_draws = TRUE)
    expect_s3_class(answer, "cjqr_eal_ci")
    expect_true(answer$available)
    expect_identical(answer$probs, requested)
    expect_identical(.Random.seed, rng)
    expect_identical(RNGkind(), kind)
    expect_identical(serialize(object, NULL), snapshot)
    expect_identical(answer$bootstrap$status, joint$bootstrap$status)
    expect_identical(answer$draws$indices, joint$draws$indices)
    expect_identical(answer$draws$coefficients, joint$draws$coefficients)
    expect_identical(answer$bootstrap$joint_refits, 0L)
    expect_identical(answer$bootstrap$qgam_refits, 0L)
    expect_true(answer$bootstrap$paired_subject_rows)
    expect_identical(names(answer$draws$residual_quantiles), object$responses)
    for (field in c("fit", "lower", "upper")) {
      expect_identical(names(answer[[field]]), object$responses)
      expect_identical(names(answer$reference[[field]]), object$responses)
      for (j in 1:2) {
        expect_equal(answer[[field]][[j]], .margin_probs_slice(joint[[field]],
          j, requested[[j]], union), tolerance = 1e-12)
        expect_equal(answer$reference[[field]][[j]], .margin_probs_slice(
          joint$reference[[field]], j, requested[[j]], union), tolerance = 1e-12)
      }
    }
    for (j in 1:2) {
      expect_identical(dim(answer$draws$residual_quantiles[[j]]),
                       c(length(requested[[j]]), 100L))
      expected <- matrix(joint$draws$residual_quantiles[
        match(requested[[j]], union), j, , drop = FALSE],
        nrow = length(requested[[j]]), ncol = 100L)
      expect_equal(unname(answer$draws$residual_quantiles[[j]]), expected,
                   tolerance = 1e-12)
    }
    restored <- unserialize(serialize(answer, NULL))
    expect_identical(restored, answer)
  }
})

test_that("both margins use the same saved subject indices and one bootstrap call", {
  object <- .margin_probs_fixture(TRUE)
  requested <- list(first = c(.9, .1), second = .75)
  original_indices <- CJQR:::.cjqr_eal_ci_indices
  calls <- 0L
  testthat::local_mocked_bindings(.cjqr_eal_ci_indices = function(n, B, seed) {
    calls <<- calls + 1L
    original_indices(n, B, seed)
  }, .package = "CJQR")
  answer <- cjqr_eal_ci(object, probs = requested, B = 100L,
                       seed = 39L, keep_draws = TRUE)
  expect_identical(calls, 1L)
  for (b in c(1L, 37L, 100L)) {
    ids <- answer$draws$indices[, b]
    for (j in 1:2) {
      Xb <- object$X[[j]][ids, , drop = FALSE]
      beta <- qr.coef(qr(Xb), object$Y[ids, j])
      residual <- object$Y[ids, j] - drop(Xb %*% beta)
      expected <- quantile(residual, requested[[j]], type = 8L, names = FALSE)
      expect_equal(unname(answer$draws$coefficients[[j]][, b]),
                   unname(beta), tolerance = 1e-12)
      expect_equal(unname(answer$draws$residual_quantiles[[j]][, b]),
                   expected, tolerance = 1e-12)
    }
  }
})

test_that("all interval entry points resolve list defaults and legacy fallback", {
  object <- .margin_probs_fixture()
  object$probs <- list(first = c(.9, .1), second = .75)
  answer <- cjqr_eal_ci(object, B = 100L, seed = 31L)
  for (candidate in list(
    predict(object, interval = "confidence", B = 100L, seed = 31L),
    fitted(object, interval = "confidence", B = 100L, seed = 31L),
    confint(object, B = 100L, seed = 31L),
    cjqr_eal_ci(object, probs = unname(object$probs), B = 100L, seed = 31L))) {
    .margin_probs_expect_ci_equal(candidate, answer)
  }
  oldfive <- c(.1, .25, .5, .75, .9)
  legacy <- .margin_probs_fixture()
  numeric_default <- cjqr_eal_ci(legacy, B = 100L, seed = 31L)
  expect_identical(numeric_default$probs, oldfive)
  expect_identical(dim(numeric_default$fit), c(40L, 2L, 5L))
  .margin_probs_expect_ci_equal(numeric_default,
    confint(legacy, probs = oldfive, B = 100L, seed = 31L))
  .margin_probs_expect_ci_equal(
    predict(object, probs = oldfive, interval = "confidence", B = 100L, seed = 31L),
    numeric_default)
})

test_that("long interval data contain actual per-response probabilities", {
  object <- .margin_probs_fixture()
  requested <- list(first = c(.9, .1), second = .75)
  answer <- cjqr_eal_ci(object, probs = requested, B = 100L, seed = 84L)
  long <- as.data.frame(answer, include_reference = TRUE)
  expect_equal(nrow(long), 40L * 3L)
  expect_identical(long$row_index, rep(seq_len(40L), each = 3L))
  expect_identical(as.character(long$response), rep(c("first", "first", "second"), 40L))
  expect_equal(long$prob, rep(c(.9, .1, .75), 40L))
  expect_true(all(long$available))
  for (i in seq_len(nrow(long))) {
    j <- match(as.character(long$response[i]), object$responses)
    k <- match(long$prob[i], requested[[j]])
    row <- long$row_index[i]
    expect_equal(long$estimate[i], unname(answer$fit[[j]][row, k]))
    expect_equal(long$lower[i], unname(answer$lower[[j]][row, k]))
    expect_equal(long$upper[i], unname(answer$upper[[j]][row, k]))
    expect_equal(long$reference_estimate[i], unname(answer$reference$fit[[j]][row, k]))
    expect_equal(long$reference_lower[i], unname(answer$reference$lower[[j]][row, k]))
    expect_equal(long$reference_upper[i], unname(answer$reference$upper[[j]][row, k]))
  }
  expect_identical(as.data.frame(unserialize(serialize(answer, NULL)),
    include_reference = TRUE), long)
})

test_that("quantile plot draw FALSE returns all unequal margins without graphics", {
  object <- .margin_probs_fixture()
  requested <- list(first = c(.9, .1), second = .75)
  object$probs <- requested
  snapshot <- serialize(object, NULL)
  device <- grDevices::dev.cur()
  expected <- predict(object)
  for (eq in 1:2) {
    answer <- plot(object, type = "quantile", eq = eq, variable = "x", draw = FALSE)
    expect_identical(answer, expected)
    expect_identical(plot(object, type = "quantile", eq = eq,
      probs = rev(requested), draw = FALSE), expected)
  }
  ci <- plot(object, type = "quantile", eq = 2L, probs = requested,
    interval = "confidence", B = 100L, seed = 72L, draw = FALSE)
  expect_s3_class(ci, "cjqr_eal_ci")
  .margin_probs_expect_ci_equal(ci,
    cjqr_eal_ci(object, probs = requested, B = 100L, seed = 72L))
  expect_identical(grDevices::dev.cur(), device)
  expect_identical(serialize(object, NULL), snapshot)
})

test_that("quantile drawing uses only the selected response grid", {
  object <- .margin_probs_fixture()
  requested <- list(first = c(.9, .1), second = .75)
  calls <- new.env(parent = emptyenv())
  calls$lines <- list()
  calls$legend <- NULL
  testthat::local_mocked_bindings(
    lines = function(x, y, ...) {
      calls$lines[[length(calls$lines) + 1L]] <- list(x = x, y = y)
      invisible(NULL)
    },
    legend = function(...) { calls$legend <- list(...); invisible(NULL) },
    .package = "graphics")
  grDevices::pdf(NULL)
  device <- grDevices::dev.cur()
  on.exit(if (device %in% grDevices::dev.list()) grDevices::dev.off(device), add = TRUE)
  answer <- plot(object, type = "quantile", eq = 2L, variable = "x", probs = requested)
  expect_identical(answer, predict(object, probs = requested))
  expect_length(calls$lines, 1L)
  expect_equal(unname(calls$lines[[1L]]$y), unname(answer$second[, 1L]))
  expect_identical(calls$legend$legend, "p = 0.75")
  calls$lines <- list()
  answer <- plot(object, type = "quantile", eq = 1L, variable = "x", probs = requested)
  expect_length(calls$lines, 2L)
  expect_equal(unname(calls$lines[[1L]]$y), unname(answer$first[, 1L]))
  expect_equal(unname(calls$lines[[2L]]$y), unname(answer$first[, 2L]))
  expect_identical(calls$legend$legend, c("p = 0.9", "p = 0.1"))
})
