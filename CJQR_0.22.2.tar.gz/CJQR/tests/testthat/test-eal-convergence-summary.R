.eal_convergence_fixture <- function() {
  cert <- list(strict_local_ok = TRUE, objective = 2.5, kkt = 2e-9,
    objective_replay_gap = 0, directional_check = TRUE,
    max_directional_improvement = 0, probe_count = 100L,
    nonfinite_probe_count = 0L, observed_candidate_gap = 0,
    observed_candidate_gap_ok = TRUE, boundary = integer(),
    dependence_boundary = FALSE, scale_boundary = FALSE, shape_boundary = FALSE)
  control <- list(strict_gradient_tolerance = 1e-6,
    objective_replay_tolerance = 1e-10, lower_candidate_gap_tolerance = 1e-7,
    directional_improvement_tolerance = 1e-9)
  structure(list(anchor = .5,
    fit = list(strict_ok = TRUE, p = .5, stationarity = 2e-9,
      strict_gradient_tolerance = 1e-6, objective = 2.5,
      lower_unconverged_objective_gap = 0, improved_certificate = cert,
      improved_control = control),
    selection = list(strict_ok = TRUE, index = 2L, unresolved_gap = 0,
      audit = data.frame(anchor = c(.25, .5, .75), initialized = TRUE,
        strict = TRUE, objective = c(2.6, 2.5, 2.7),
        known_minimum = c(2.6, 2.5, 2.7)))), class = "cjqr_eal")
}

test_that("complete stored numerical certificates produce a conditional converged status", {
  o <- .eal_convergence_fixture()
  frozen <- serialize(o, NULL)
  set.seed(8801)
  rng <- .Random.seed
  z <- CJQR:::.cjqr_eal_summary_convergence(o)
  expect_identical(z$status, "converged")
  expect_true(all(z$checks))
  expect_length(z$reasons, 0L)
  expect_equal(z$stationarity, 2e-9)
  expect_equal(z$tolerance, 1e-6)
  expect_match(z$message, "stored numerical")
  expect_false(z$proves_global_optimum)
  expect_false(z$establishes_statistical_validity)
  expect_false(z$recomputed_model_fit)
  expect_identical(serialize(o, NULL), frozen)
  expect_identical(.Random.seed, rng)
})

test_that("unavailable legacy details do not become converged checks", {
  o <- .eal_convergence_fixture()
  o$fit$improved_certificate <- NULL
  z <- CJQR:::.cjqr_eal_summary_convergence(o)
  expect_identical(z$status, "not assessed")
  expect_true(anyNA(z$checks))
  expect_match(z$message, "incomplete or unavailable")
  expect_equal(z$stationarity, 2e-9)
  o <- .eal_convergence_fixture()
  o$selection$audit <- NULL
  expect_identical(CJQR:::.cjqr_eal_summary_convergence(o)$status, "not assessed")
  o <- .eal_convergence_fixture()
  o$fit$improved_control <- NULL
  expect_identical(CJQR:::.cjqr_eal_summary_convergence(o)$status, "not assessed")
  o <- .eal_convergence_fixture()
  o$selection$index <- NULL
  expect_identical(CJQR:::.cjqr_eal_summary_convergence(o)$status, "not assessed")
  o <- structure(list(fit = list(strict_ok = TRUE),
    selection = list(strict_ok = TRUE)), class = "cjqr_eal")
  expect_identical(CJQR:::.cjqr_eal_summary_convergence(o)$status, "not assessed")
})

test_that("explicit failed and inconsistent certificate checks are never called converged", {
  f <- CJQR:::.cjqr_eal_summary_convergence
  o <- .eal_convergence_fixture(); o$fit$strict_ok <- FALSE
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$selection$strict_ok <- FALSE
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$improved_certificate$strict_local_ok <- FALSE
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$improved_certificate$kkt <- 1e-3
  z <- f(o)
  expect_identical(z$status, "not converged")
  expect_equal(z$stationarity, 1e-3)
  expect_equal(z$tolerance, 1e-6)
  expect_false(z$checks[["stationarity"]])
  expect_true(any(grepl("stationarity", z$reasons, fixed = TRUE)))
  o <- .eal_convergence_fixture(); o$fit$improved_certificate$kkt <- Inf
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$improved_certificate$objective_replay_gap <- 1e-3
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$objective <- 2.4
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$improved_certificate$directional_check <- FALSE
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$improved_certificate$max_directional_improvement <- 1e-5
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$improved_certificate$probe_count <- 0L
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$improved_certificate$observed_candidate_gap_ok <- FALSE
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$lower_unconverged_objective_gap <- 1e-4
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$selection$unresolved_gap <- 1e-4
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$anchor <- .25
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$selection$index <- 9L
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$selection$audit$initialized[1L] <- FALSE
  expect_identical(f(o)$status, "not converged")
  o <- .eal_convergence_fixture(); o$fit$improved_certificate$reason_codes <- "unresolved_lower_candidate"
  expect_identical(f(o)$status, "not converged")
  o$fit$improved_certificate$kkt <- NULL
  expect_identical(f(o)$status, "not converged")
})

test_that("unsuccessful alternatives and active numerical boundaries are reported accurately", {
  o <- .eal_convergence_fixture()
  o$selection$audit$strict[3L] <- FALSE
  o$selection$audit$objective[3L] <- Inf
  o$selection$audit$known_minimum[3L] <- 2.8
  expect_identical(CJQR:::.cjqr_eal_summary_convergence(o)$status, "converged")
  o$selection$audit$known_minimum[3L] <- 2.4
  z <- CJQR:::.cjqr_eal_summary_convergence(o)
  expect_identical(z$status, "not converged")
  expect_false(z$checks[["recomputed_anchor_gap"]])
  o <- .eal_convergence_fixture()
  o$fit$improved_certificate$shape_boundary <- TRUE
  o$fit$improved_certificate$boundary <- 7L
  z <- CJQR:::.cjqr_eal_summary_convergence(o)
  expect_identical(z$status, "converged")
  expect_true(z$boundary$shape)
  expect_match(z$message, "search boundary was reached")
})
