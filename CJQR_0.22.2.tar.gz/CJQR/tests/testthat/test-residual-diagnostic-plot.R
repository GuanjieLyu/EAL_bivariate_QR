.cjqr_residual_plot_fixture <- function() {
  axis <- stats::qnorm(stats::ppoints(13L))
  z <- as.matrix(expand.grid(axis, axis))
  z[, 2L] <- .35 * z[, 1L] + sqrt(1 - .35^2) * z[, 2L]
  structure(list(uniform = stats::pnorm(z), normal = z,
                 labels = c("Outcome 1", "Outcome 2 | Outcome 1"), n = nrow(z)),
            class = "cjqr_residual_diagnostics")
}

.cjqr_residual_plot_pdf <- function(code) {
  path <- tempfile(fileext = ".pdf")
  grDevices::pdf(path, width = 12, height = 4.5)
  on.exit({ grDevices::dev.off(); unlink(path) }, add = TRUE)
  force(code)
}

test_that("residual diagnostics plot retains rows, histograms and probability HDRs", {
  x <- .cjqr_residual_plot_fixture()
  before <- x
  .cjqr_residual_plot_pdf({
    visible <- withVisible(plot(x, grid_size = 81L))
    p <- visible$value
    expect_false(visible$visible)
    expect_identical(x, before)
    expect_identical(p$n, x$n)
    expect_identical(p$normal, x$normal)
    expect_identical(p$uniform, x$uniform)
    expect_equal(p$histogram_totals, rep(x$n, 2L))
    expect_equal(unname(p$finite_counts$uniform), rep(x$n, 2L))
    expect_equal(unname(p$finite_counts$normal), rep(x$n, 2L))
    expect_equal(p$finite_counts$complete_pairs, x$n)
    expect_identical(p$points_drawn, x$n)
    expect_identical(p$contours$probability, seq(.1, .9, .1))
    expect_true(all(diff(p$contours$threshold) < 0))
    expect_true(all(p$contours$enclosed_grid_mass >= p$contours$probability))
    expect_lt(max(p$contours$enclosed_grid_mass - p$contours$probability), .015)
    expect_lt(abs(p$kde$integrated_mass - 1), .001)
    expect_equal(p$kde$bandwidth, stats::cov(x$normal) * x$n^(-1 / 3))
    expect_true(all(x$normal > p$normal_limits[1L] & x$normal < p$normal_limits[2L]))
    expect_identical(p$kde$grid_chunk_size, 128L)
    expect_identical(p$kde$observation_chunk_size, 2048L)
    expect_true(all(vapply(p$histograms, function(h)
      abs(sum(h$density * diff(h$breaks)) - 1) < 1e-12, logical(1L))))
  })
})

test_that("full covariance KDE matches direct Mahalanobis evaluation", {
  x <- .cjqr_residual_plot_fixture()
  .cjqr_residual_plot_pdf({
    p <- plot(x, grid_size = 61L, contour_probs = c(.5, .9), points = FALSE)
    h <- p$kde$bandwidth
    for (ij in list(c(31L, 31L), c(37L, 24L), c(20L, 40L))) {
      query <- c(p$kde$x[ij[1L]], p$kde$y[ij[2L]])
      differences <- sweep(x$normal, 2L, query, "-")
      d2 <- rowSums((differences %*% solve(h)) * differences)
      exact <- mean(exp(-d2 / 2)) / (2 * pi * sqrt(det(h)))
      expect_equal(p$kde$density[ij[1L], ij[2L]], exact, tolerance = 1e-12)
    }
    expect_identical(p$points_drawn, 0L)
    expect_identical(p$normal, x$normal)
  })
})

test_that("plot restores graphics state and does not consume random numbers", {
  x <- .cjqr_residual_plot_fixture()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) previous_seed <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    if (had_seed) assign(".Random.seed", previous_seed, envir = .GlobalEnv)
    else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
      rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  set.seed(452L)
  seed <- .Random.seed
  .cjqr_residual_plot_pdf({
    graphics::par(mfrow = c(2, 1), mar = c(3, 4, 2, 1), oma = c(1, 0, 0, 0),
                  cex = .9, las = 0, pty = "m", mgp = c(3, 1, 0))
    before <- graphics::par(no.readonly = TRUE)
    p <- plot(x, breaks = 12L, grid_size = 41L, labels = c("A", "B | A"),
              col = "navy", point_col = "#55555544", reference_col = "gray50",
              cex = .8, cex.axis = .9, cex.lab = 1, cex.main = .9, lwd = 1.1)
    after <- graphics::par(no.readonly = TRUE)
    check <- c("mfrow", "mfcol", "mar", "oma", "cex", "las", "pty", "mgp", "xpd")
    expect_equal(after[check], before[check])
    expect_identical(p$labels, c("A", "B | A"))
    expect_identical(length(p$histograms[[1L]]$counts), 12L)
    expect_identical(.Random.seed, seed)
  })
})

test_that("histograms preserve representable boundary probabilities", {
  x <- .cjqr_residual_plot_fixture()
  x$uniform[1L, ] <- 0
  x$uniform[2L, ] <- 1
  .cjqr_residual_plot_pdf({
    p <- plot(x, grid_size = 41L)
    expect_equal(p$histogram_totals, rep(x$n, 2L))
    expect_true(all(vapply(p$histograms, function(h)
      h$counts[1L] >= 1L && tail(h$counts, 1L) >= 1L, logical(1L))))
  })
})

test_that("plot rejects malformed residuals without silently dropping observations", {
  x <- .cjqr_residual_plot_fixture()
  bad <- x
  bad$normal[1L, 1L] <- Inf
  expect_error(plot(bad), "nonfinite rows are not silently dropped")
  bad <- x
  bad$uniform[2L, 2L] <- NA_real_
  expect_error(plot(bad), "nonfinite rows are not silently dropped")
  bad <- x
  bad$uniform[1L, 1L] <- 1.1
  expect_error(plot(bad), "must lie in")
  bad <- x
  bad$normal <- bad$normal[, 1L, drop = FALSE]
  expect_error(plot(bad), "matching numeric two-column")
  bad <- x
  bad$n <- x$n + 1L
  expect_error(plot(bad), "number of paired residual rows")
  bad <- x
  bad$normal <- bad$normal[1:2, ]
  bad$uniform <- bad$uniform[1:2, ]
  bad$n <- 2L
  expect_error(plot(bad), "At least three")
  bad <- x
  bad$normal[, 2L] <- bad$normal[, 1L]
  expect_error(plot(bad), "singular|near-collinear")
  bad <- x
  bad$normal[,] <- 0
  expect_error(plot(bad), "singular|near-collinear")
})

test_that("plot arguments are bounded and unsupported changes are rejected", {
  x <- .cjqr_residual_plot_fixture()
  for (v in list(NA_real_, Inf, 0, 1, 2.5, 201L, c(10L, 20L), "FD"))
    expect_error(plot(x, breaks = v), "`breaks`")
  for (v in list(NA_real_, 40L, 302L, 55.5, "121", c(81L, 121L)))
    expect_error(plot(x, grid_size = v), "`grid_size`")
  for (v in list(numeric(), NA_real_, 0, 1, c(.9, .5), c(.5, .5), seq(.01, .99, length.out = 26L)))
    expect_error(plot(x, contour_probs = v), "`contour_probs`")
  expect_error(plot(x, points = 1), "`points`")
  expect_error(plot(x, points = NA), "`points`")
  expect_error(plot(x, labels = "one"), "`labels`")
  expect_error(plot(x, labels = c("", "two")), "`labels`")
  expect_error(plot(x, labels = c("one", NA_character_)), "`labels`")
  expect_error(plot(x, xlim = c(-1, 1)), "Unsupported.*allowed style")
  expect_error(plot(x, "unused", grid_size = 41L), "`breaks`")
  expect_error(plot(x, col = "not-a-colour"), "valid colour")
  expect_error(plot(x, cex.axis = 0), "`cex.axis`")
  expect_error(plot(x, lwd = Inf), "`lwd`")
})
