.ci_legacy_tail <- function(draws, joint, null = 0) {
  if (joint == null) return(1)
  positive <- joint > null
  outside <- function(alpha) {
    endpoint <- stats::quantile(draws,
      if (positive) alpha / 2 else 1 - alpha / 2, type = 8L, names = FALSE)
    if (positive) endpoint > null else endpoint < null
  }
  if (!outside(1)) return(1)
  lo <- 0; hi <- 1
  for (i in seq_len(48L)) {
    mid <- (lo + hi) / 2
    if (outside(mid)) hi <- mid else lo <- mid
  }
  min(1, max(hi, 2 / (length(draws) + 1)))
}

test_that("prepared coefficient quantiles preserve type-8 rounding and ties", {
  set.seed(9069)
  for (n in c(2L, 3L, 7L, 49L, 499L, 1999L)) {
    positions <- (seq.int(0L, n) - 1 / 3) / (n + 1 - 1 / 3 - 1 / 3)
    probs <- pmax(0, pmin(1, c(0, 1, seq(0, 1, length.out = 101L),
      positions, positions * (1 - 4 * .Machine$double.eps),
      positions * (1 + 4 * .Machine$double.eps))))
    samples <- list(rnorm(n), round(rnorm(n)), rep(0, n),
      rep(c(-1, 0, 0, 1), length.out = n),
      rep(c(-1e300, -1e-300, 1e-300, 1e300), length.out = n),
      rep(c(-Inf, 0, Inf), length.out = n))
    for (draws in samples) {
      names(draws) <- paste0("b", seq_along(draws))
      f <- CJQR:::.cjqr_eal_coef_quantiles(draws)
      expect_identical(f(probs), stats::quantile(draws, probs, type = 8L, names = FALSE))
    }
  }
  expect_identical(CJQR:::.cjqr_eal_coef_quantiles(numeric())(.5),
    stats::quantile(numeric(), .5, type = 8L, names = FALSE))
  expect_error(CJQR:::.cjqr_eal_coef_quantiles(c(NA, 1))(.5), "missing values")
})

test_that("prepared inversion preserves the original 48-step p-value exactly", {
  set.seed(76013)
  for (n in c(2L, 10L, 49L, 499L)) {
    samples <- list(rnorm(n), rnorm(n) + 1, rnorm(n) - 1,
      rep(c(-1, 0, 0, 1), length.out = n), rep(0, n), rep(2, n))
    for (draws in samples) for (null in c(-.5, 0, .7)) {
      prepared <- CJQR:::.cjqr_eal_coef_quantiles(draws)
      for (joint in c(null - 1, null, null + 1)) {
        expected <- .ci_legacy_tail(draws, joint, null)
        expect_identical(CJQR:::.cjqr_eal_coef_tail_p(draws, joint, null), expected)
        expect_identical(CJQR:::.cjqr_eal_coef_tail_p(draws, joint, null,
          quantiles = prepared), expected)
      }
    }
  }
})

test_that("optional within-draw QR caches preserve coefficients and HC3", {
  for (distinct in c(FALSE, TRUE)) {
    fit <- .eal_coef_fixture(distinct)
    n <- nrow(fit$Y)
    indices <- CJQR:::.cjqr_eal_ci_indices(n, 17L, 729L)
    for (b in c(0L, seq_len(ncol(indices)))) {
      ii <- if (b == 0L) seq_len(n) else indices[, b]
      reference <- CJQR:::.cjqr_eal_coef_reference(fit$X, fit$Y, ii)
      cached <- CJQR:::.cjqr_eal_coef_reference(fit$X, fit$Y, ii, keep_qr = TRUE)
      expect_identical(cached$beta, reference)
      plain <- CJQR:::.cjqr_eal_ci_refit(fit$X, fit$Y, ii, c(.25,.5,.75))
      reuse <- CJQR:::.cjqr_eal_ci_refit(fit$X, fit$Y, ii, c(.25,.5,.75),
        keep_qr = TRUE, qr_cache = cached$qr_cache)
      reused_cache <- reuse$qr_cache
      reuse$qr_cache <- NULL
      expect_identical(reuse, plain)
      expect_identical(CJQR:::.cjqr_eal_smooth_hc3(fit$X, fit$Y, ii, reference,
        qr_cache = reused_cache),
        CJQR:::.cjqr_eal_smooth_hc3(fit$X, fit$Y, ii, reference))
    }
    ii <- rep(1L, n)
    expect_error(CJQR:::.cjqr_eal_coef_reference(fit$X, fit$Y, ii, keep_qr = TRUE),
      "rank_deficient")
    failed <- CJQR:::.cjqr_eal_ci_refit(fit$X, fit$Y, ii, .5, keep_qr = TRUE)
    expect_false(failed$ok)
    expect_null(failed$qr_cache)
  }
})

test_that("shared cached inference leaves coefficient streams and RNG unchanged", {
  set.seed(6754)
  rng <- .Random.seed
  for (distinct in c(FALSE, TRUE)) {
    fit <- .eal_coef_fixture(distinct)
    before <- serialize(fit, NULL)
    plain <- CJQR:::.cjqr_eal_coefficient_inference(fit, B = 109L, seed = 727L,
      keep_draws = TRUE)
    shared <- CJQR:::.cjqr_eal_coefficient_inference(fit, B = 109L, seed = 727L,
      keep_draws = TRUE, include_smooth = TRUE, include_tau = TRUE)
    expect_identical(shared$tables, plain$tables)
    expect_identical(shared$reference, plain$reference)
    expect_identical(shared$draws$indices, plain$draws$indices)
    expect_identical(shared$draws$coefficients, plain$draws$coefficients)
    expect_identical(shared$draws$intercepts, plain$draws$intercepts)
    expect_identical(shared$bootstrap$status, plain$bootstrap$status)
    expect_identical(serialize(fit, NULL), before)
    expect_identical(.Random.seed, rng)
    expect_null(shared$qr_cache)
    expect_null(shared$draws$qr_cache)
  }
})

test_that("pointwise CI chunk traversal preserves all numerical results", {
  for (distinct in c(FALSE, TRUE)) {
    fit <- .eal_coef_fixture(distinct)
    opts <- CJQR:::.cjqr_eal_ci_options(c(.1,.5,.9), .95, 29L, 19L, 7L, 256, TRUE)
    predictions <- array(0, c(nrow(fit$Y), 2L, 3L))
    first <- CJQR:::.cjqr_eal_ci_compute(fit$X, fit$Y, fit$X, predictions, opts)
    opts$chunk_size <- 80L
    second <- CJQR:::.cjqr_eal_ci_compute(fit$X, fit$Y, fit$X, predictions, opts)
    first$bootstrap$elapsed_seconds <- second$bootstrap$elapsed_seconds <- NULL
    first$bootstrap$estimated_workspace_bytes <- second$bootstrap$estimated_workspace_bytes <- NULL
    expect_identical(first, second)
  }
})

test_that("within-draw caches respect the smooth workspace budget", {
  fit <- .eal_coef_fixture(TRUE)
  opts <- CJQR:::.cjqr_eal_ci_options(.5, .95, 109L, 2L, 128L, 256, FALSE)
  Xe <- lapply(fit$X, function(x) x[1L, , drop = FALSE])
  base <- CJQR:::.cjqr_eal_ci_validate_design(fit$X, fit$Y, Xe, NULL, opts,
    check_joint = FALSE)$estimated_bytes
  d <- vapply(fit$X, ncol, integer(1L))
  required <- base + 16 * opts$B * sum(d) + 8 * sum(d^2) +
    16 * nrow(fit$Y) * sum(d)
  expect_error(CJQR:::.cjqr_eal_coefficient_inference(fit, B = 109L,
    include_smooth = TRUE, max_memory_mb = (required - 1) / 1024^2),
    "smooth auxiliary workspace")
})
