test_that("software citation tracks the installed package metadata", {
  metadata <- utils::packageDescription("CJQR")
  citation <- utils::citation("CJQR")
  text <- gsub("[[:space:]]+", " ",
    paste(capture.output(print(citation, style = "text")), collapse = " "))

  expect_match(text, paste("R package version", metadata$Version), fixed = TRUE)
  expect_match(text, metadata$Title, fixed = TRUE)
  expect_false(grepl("joint_gfs_opg|caqreg", text, ignore.case = TRUE))
  expect_match(metadata$Maintainer, "guanjielyu@gmail.com", fixed = TRUE)
  expect_identical(metadata$License, "MIT + file LICENSE")
})

test_that("all exported functions have installed help aliases", {
  topics <- tools::Rd_db("CJQR")
  aliases <- unlist(lapply(topics, function(topic) {
    entries <- topic[vapply(topic, function(node)
      identical(attr(node, "Rd_tag"), "\\alias"), logical(1L))]
    vapply(entries, function(node) paste(unlist(node), collapse = ""), character(1L))
  }), use.names = FALSE)

  exports <- getNamespaceExports("CJQR")
  expect_length(setdiff(exports, aliases), 0L)
})
