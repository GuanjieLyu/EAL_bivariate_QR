# These tests construct no fitted models. Invalid requests must be rejected
# before an initializer can fit a model.
.eal_guard_data <- function() {
  x <- seq(-0.9, 0.9, length.out = 40L)
  data.frame(y1 = sin(x) + x^2, y2 = cos(x) - x,
             x = x, z = rep(c(0, 1), 20L))
}

.eal_expect_validation_error <- function(args) {
  ans <- tryCatch(do.call(cjqr_eal, args), error = identity)
  expect_s3_class(ans, "error")
  if (inherits(ans, "error")) {
    expect_false(grepl("TEST_FORBIDS_FITTING", conditionMessage(ans),
                       fixed = TRUE), info = conditionMessage(ans))
  }
  invisible(ans)
}

.eal_replace_guard_args <- function(base, changed) {
  # Replace data frames as whole arguments: modifyList() would restore a
  # deliberately omitted response column from the original data frame.
  base[names(changed)] <- changed
  base
}

test_that("EAL malformed formulas are rejected before fitting", {
  local_mocked_bindings(
    gam = function(...) stop("TEST_FORBIDS_FITTING"), .package = "mgcv"
  )
  dat <- .eal_guard_data()
  bad <- list(
    list(y1 ~ x),
    list(y1 ~ x, y2 ~ x, ~ x),
    list(log(y1) ~ x, y2 ~ x),
    list(y1 ~ 0 + x, y2 ~ 0 + x),
    list(y1 ~ x + offset(z), y2 ~ x + offset(z)),
    list(y1 ~ x, y1 ~ x),
    list(~ x, y2 ~ x)
  )
  for (f in bad) {
    .eal_expect_validation_error(list(formulas = f, data = dat))
  }
})

test_that("EAL invalid data and probability settings fail before fitting", {
  local_mocked_bindings(
    gam = function(...) stop("TEST_FORBIDS_FITTING"), .package = "mgcv"
  )
  dat <- .eal_guard_data()
  base <- list(formulas = list(y1 ~ x, y2 ~ x), data = dat)
  invalid <- list(
    transform(dat, y1 = as.character(y1)),
    transform(dat, y2 = factor(seq_len(nrow(dat)))),
    within(dat, y1[3L] <- NA_real_),
    within(dat, y2[3L] <- Inf),
    within(dat, x[3L] <- NA_real_),
    dat[, setdiff(names(dat), "y2"), drop = FALSE],
    dat[FALSE, , drop = FALSE]
  )
  for (d in invalid) {
    .eal_expect_validation_error(.eal_replace_guard_args(base, list(data = d)))
  }
  for (a in list(numeric(), 0, 1, -0.2, 1.1, c(0.25, NA), c(0.25, Inf))) {
    .eal_expect_validation_error(.eal_replace_guard_args(base, list(anchors = a)))
  }
  for (s in list(NA_real_, Inf, -1, 1.2, c(1, 2))) {
    .eal_expect_validation_error(.eal_replace_guard_args(base, list(seed = s)))
  }
})

test_that("EAL does not silently accept unsupported model settings", {
  local_mocked_bindings(
    gam = function(...) stop("TEST_FORBIDS_FITTING"), .package = "mgcv"
  )
  base <- list(formulas = list(y1 ~ x, y2 ~ x), data = .eal_guard_data())
  for (family in c("student_t", "rotated_clayton", "unknown")) {
    .eal_expect_validation_error(.eal_replace_guard_args(base, list(copula = family)))
  }
  for (extra in list(list(weights = rep(1, 40)), list(degree = 4L),
                     list(df = 5), list(tau = 0.5),
                     list(control = list(unknown_eal_option = TRUE)),
                     list(extra_control = list(degree = 4L)))) {
    .eal_expect_validation_error(.eal_replace_guard_args(base, extra))
  }
})

test_that("Student-t degrees of freedom are explicit, fixed and validated early", {
  # Load qgam before mocking mgcv: otherwise its imports environment can retain
  # the temporary gam binding after this test and contaminate later tests.
  skip_if_not_installed("qgam", minimum_version = "2.0.0")
  requireNamespace("qgam", quietly = TRUE)
  local_mocked_bindings(
    gam = function(...) stop("TEST_FORBIDS_FITTING"), .package = "mgcv"
  )
  base <- list(formulas = list(y1 ~ x, y2 ~ x), data = .eal_guard_data(),
               copula = "student_t")
  for (df in list(NULL, NA_real_, Inf, 0, -1, c(4, 5), "5")) {
    .eal_expect_validation_error(.eal_replace_guard_args(base, list(df = df)))
  }
  for (family in c("gaussian", "clayton", "frank", "gumbel")) {
    .eal_expect_validation_error(.eal_replace_guard_args(base, list(copula = family, df = 5)))
  }
  for (family in c("frank", "gumbel", "student_t", "t", "student")) {
    args <- .eal_replace_guard_args(base, list(copula = family,
      df = if (family %in% c("student_t", "t", "student")) 5 else NULL))
    expect_error(do.call(cjqr_eal, args), "TEST_FORBIDS_FITTING")
  }
  .eal_expect_validation_error(.eal_replace_guard_args(base,
    list(df = 5, control = list(df = 7))))
  .eal_expect_validation_error(.eal_replace_guard_args(base,
    list(copula = "gumbel", control = list(theta_bounds = c(.5, 4)))))
})

test_that("the public API exposes the current EAL workflow only", {
  exports <- getNamespaceExports("CJQR")
  retained <- c("cjqr_eal", "cjqr_eal_control", "cjqr_eal_ci",
    "cjqr_eal_coef_ci", "cjqr_eal_smooth_test", "cjqr_eal_tau_ci",
    "cjqr_eal_ic", "cjqr_fit_diagnostics", "cjqr_residual_diagnostics",
    "cjqr_example_data", "s", "te", "ti", "t2")
  removed <- c("cjqr", "cjqr_control", "cjqr_inference_control",
    "cjqr_diagnostics", "joint_probability", "boot_cjqr", "smooth_test",
    "al_cdf", "al_density", "al_quantile", "cjqr_k_check", "cjqr_ic",
    "joint_cv", "joint_gfs_opg")
  expect_true(all(retained %in% exports))
  expect_length(intersect(exports, removed), 0L)
  for (name in retained)
    expect_true(is.function(getExportedValue("CJQR", name)), info = name)

  methods <- getNamespaceInfo("CJQR", "S3methods")
  retired_classes <- c("cjqr", "summary.cjqr", "boot_cjqr",
    "cjqr_smooth_test", "cjqr_k_check", "cjqr_smoothing_selection", "cjqr_ic")
  expect_false(any(methods[, 2L] %in% retired_classes))
  expect_true(all(c("predict", "coef", "summary", "plot", "AIC", "BIC") %in%
    methods[methods[, 2L] == "cjqr_eal", 1L]))
})
