# Engineering fixtures use explicitly constructed coefficients; they are not
# fitted-data evidence for numerical convergence or statistical performance.
.cjqr_ux_fixture <- function() {
  x <- seq(-.9, .9, length.out = 60L)
  d <- data.frame(x = x, group = factor(rep(c("a", "b"), 30L)),
    y1 = sin(3 * x) + .1 * cos(seq_along(x)),
    y2 = cos(2 * x) + .1 * sin(seq_along(x)))
  g <- mgcv::gam(y1 ~ group + s(x, k = 5), data = d, method = "REML")
  X <- predict(g, type = "lpmatrix")
  beta <- cbind(coef(g), .8 * coef(g))
  colnames(beta) <- c("y1", "y2")
  f <- list(strict_ok = TRUE, beta = beta, sigma = c(.7, .9),
    shape = matrix(0, 5L, 2L), p = .5, degree = 3L, theta = .3,
    copula = "gaussian", objective = 2, best_candidate_objective = 2,
    stationarity = 1e-8, improved_certificate = list(dependence_boundary = FALSE,
      scale_boundary = FALSE, shape_boundary = FALSE))
  start <- list(ok = TRUE, qgam = rep(list(list(ok = TRUE, strategy = "native_newton",
    retries = 0L, warnings = character(), attempts = list(list(error = "")))), 2L))
  structure(list(data = d, X = X, Y = as.matrix(d[c("y1", "y2")]),
    basis = list(g, g), fit = f, degree = 3L, anchor = .5,
    copula = "gaussian", covariates = c("group", "x"), responses = c("y1", "y2"),
    selection = list(strict_ok = TRUE, unresolved_gap = 0), seed = 1L,
    candidates = list(list(anchor = .5, start = start, fit = f, seconds = 1))),
    class = "cjqr_eal")
}

test_that("EAL control construction is explicit and does not weaken checks", {
  expect_identical(cjqr_eal_control(), list())
  expect_identical(cjqr_eal_control(maxit = 1500L), list(maxit = 1500L))
  expect_identical(cjqr_eal_control(frank_bounds = c(-10, 10), copula = "frank"),
    list(frank_bounds = c(-10, 10)))
  expect_error(cjqr_eal_control(1500L), "named list")
  expect_error(cjqr_eal_control(maxit = 2^32), "maxit")
  expect_error(cjqr_eal_control(trace = 2^32), "trace")
  expect_error(cjqr_eal_control(strict_gradient_tolerance = .01), "1e-6")
  expect_error(cjqr_eal_control(frnak_bounds = c(-10, 10)), "frnak_bounds")
})

test_that("natural dependence starts and family-specific bounds are validated", {
  expect_error(cjqr_eal_control(theta_init = 2), "copula parameter")
  expect_error(cjqr_eal_control(theta_init = 0, copula = "gumbel"), "copula parameter")
  expect_error(cjqr_eal_control(theta_init = -1, copula = "clayton"), "copula parameter")
  expect_error(cjqr_eal_control(gumbel_bounds = c(1.1, 5)), "not used")
  expect_error(cjqr_eal_control(df = 5, copula = "student_t"), "df")
  expect_identical(cjqr_eal_control(theta_init = -4, copula = "frank"),
    list(theta_init = -4))
})

test_that("prediction input problems identify the offending column", {
  f <- .cjqr_ux_fixture()
  nd <- f$data[1:3, c("group", "x")]
  expect_identical(dim(predict(f, nd)), c(3L, 2L, 5L))
  expect_error(predict(f, nd["x"]), "group")
  expect_error(predict(f, transform(nd, group = "unknown")), "Unknown level.*group")
  expect_error(predict(f, transform(nd, x = "bad")), "x.*numeric")
  expect_error(predict(f, transform(nd, x = NA_real_)), "x.*complete")
  expect_error(predict(f, transform(nd, x = Inf)), "x.*finite")
  names(nd) <- c("x", "x")
  expect_error(predict(f, nd), "unique")
  expect_error(predict(f, se.fit = TRUE), "se.fit")
})

test_that("prediction forwards only documented confidence-interval controls", {
  f <- .cjqr_ux_fixture()
  local_mocked_bindings(cjqr_eal_ci = function(object, newdata, probs, level,
    B, seed, chunk_size = 128L, max_memory_mb = 256, keep_draws = FALSE)
      list(chunk_size = chunk_size, max_memory_mb = max_memory_mb, keep_draws = keep_draws),
    .package = "CJQR")
  expected <- list(chunk_size = 8L, max_memory_mb = 32, keep_draws = TRUE)
  expect_identical(predict(f, interval = "confidence", chunk_size = 8L,
    max_memory_mb = 32, keep_draws = TRUE), expected)
  expect_error(predict(f, interval = "confidence", chunks = 8), "chunks")
  expect_error(predict(f, chunk_size = 8), "chunk_size")
})

test_that("fit diagnostics inspect successes and failures without refitting", {
  f <- .cjqr_ux_fixture()
  local_mocked_bindings(.cjqr_eal_engine = function(...) stop("NO_ENGINE"), .package = "CJQR")
  set.seed(731L); before <- .Random.seed
  answer <- cjqr_fit_diagnostics(f)
  expect_s3_class(answer, "cjqr_fit_diagnostics")
  expect_true(answer$accepted)
  expect_equal(answer$anchors$kkt, 1e-8)
  expect_identical(nrow(answer$initializers), 2L)
  expect_output(print(answer), "certified")
  failure <- structure(list(candidates = f$candidates,
    selection = list(strict_ok = FALSE, unresolved_gap = .2), copula = "gaussian", n = 60),
    class = c("cjqr_eal_convergence_error", "error", "condition"))
  failure$candidates[[1]]$start$ok <- FALSE
  failure$candidates[[1]]$start$qgam[[1]]$ok <- FALSE
  failure$candidates[[1]]$start$qgam[[1]]$attempts <- list(list(error = "native start failed"))
  failure$candidates[[1]]$fit$strict_ok <- FALSE
  failure$candidates[[1]]$fit$error <- "initialization failed"
  bad <- cjqr_fit_diagnostics(failure)
  expect_false(bad$accepted)
  expect_true(is.na(bad$selected_anchor))
  expect_match(bad$initializers$error[1], "native start failed")
  expect_output(print(bad), "Do not use")
  expect_identical(.Random.seed, before)
  expect_error(cjqr_fit_diagnostics(list()), "cjqr_eal")
})

test_that("progress output is optional and malformed input fails before fitting", {
  expect_silent(CJQR:::.cjqr_eal_progress(FALSE, "message"))
  expect_message(CJQR:::.cjqr_eal_progress(TRUE, "message"), "CJQR: message")
  d <- data.frame(x = seq(-1, 1, length.out = 40), y1 = 0, y2 = sin(1:40))
  f <- list(y1 ~ x, y2 ~ x)
  expect_error(cjqr_eal(f, d, progress = "yes"), "progress")
  expect_error(cjqr_eal(f, d), "Response.*y1.*vary")
})

test_that("diagnostics retain extension failures and successful silent retries", {
  f <- .cjqr_ux_fixture()
  f$candidates[[1]]$start$qgam[[1]]$retries <- 1L
  f$candidates[[1]]$start$qgam[[1]]$strategy <- "cautious_newton"
  a <- cjqr_fit_diagnostics(f)
  expect_true(a$accepted)
  expect_output(print(a), "cautious_newton")
  # An old object may not record retry counts; this is not a missing table row.
  f$candidates[[1]]$start$qgam[[2]]$retries <- NULL
  expect_output(print(cjqr_fit_diagnostics(f)), "cautious_newton")
  f$candidates[[1]]$fit$strict_ok <- FALSE
  f$candidates[[1]]$fit$message <- "Within-data extension failed: example failure cause"
  f$candidates[[1]]$fit$tail_multistart <- list(extension_error = "example failure cause")
  f$candidates[[1]]$fit$improved_certificate$reason_codes <- "extension_error"
  failure <- structure(list(candidates = f$candidates,
    selection = list(strict_ok = FALSE, unresolved_gap = .1), copula = "gaussian", n = 60),
    class = c("cjqr_eal_convergence_error", "error", "condition"))
  b <- cjqr_fit_diagnostics(failure)
  expect_false(b$accepted)
  expect_match(b$anchors$issue, "example failure cause")
  expect_match(b$anchors$issue, "extension_error")
  expect_output(print(b), "example failure cause")
})
