# Algebraic model fixtures: these tests never optimize or refit a model.
.residual_api_eal_fixture <- function(distinct = FALSE) {
  x <- seq(-1, 1, length.out = 9L)
  X1 <- cbind('(Intercept)' = 1, x = x)
  X2 <- if (distinct) cbind(X1, x2 = x^2) else X1
  b1 <- c(.2, -.3)
  b2 <- if (distinct) c(-.4, .2, .1) else c(-.4, .2)
  sigma <- c(.7, 1.1)
  location <- cbind(drop(X1 %*% b1), drop(X2 %*% b2))
  standardized <- cbind(seq(-12, 12, length.out = 9L),
                        c(5, -8, 2, 1, -3, 4, -1, 7, -6))
  Y <- location + sweep(standardized, 2L, sigma, '*')
  dimnames(Y) <- list(paste0('pair', c(2, 3, 5, 6, 7, 9, 10, 11, 12)),
                      c('A', 'B'))
  structure(list(X = if (distinct) list(A = X1, B = X2) else X1,
    Y = Y, degree = 3L, responses = c('A', 'B'), copula = 'gaussian',
    kept_rows = c(2L, 3L, 5L, 6L, 7L, 9L, 10L, 11L, 12L),
    omitted_rows = c(1L, 4L, 8L), selection = list(strict_ok = TRUE),
    fit = list(strict_ok = TRUE,
      beta = if (distinct) list(A = b1, B = b2) else cbind(b1, b2),
      sigma = sigma, shape = matrix(0, 5L, 2L), p = .35, theta = -.4)),
    class = 'cjqr_eal')
}

test_that('EAL diagnostics preserve retained pairs and implement both Gaussian orders', {
  original_engine <- CJQR:::.cjqr_eal_engine
  local_mocked_bindings(cjqr_eal = function(...) stop('Unexpected joint refit'),
    .cjqr_eal_qgam_native = function(...) stop('Unexpected initializer refit'),
    .cjqr_eal_engine = function(...) {
      engine <- original_engine(...)
      engine$fit <- function(...) stop('Unexpected EAL engine refit')
      engine
    }, .package = 'CJQR')
  for (distinct in c(FALSE, TRUE)) {
    fit <- .residual_api_eal_fixture(distinct)
    serialized <- serialize(fit, NULL)
    set.seed(917L); rng <- .Random.seed
    marginal <- residuals(fit, type = 'quantile')
    for (order in list(c(1L, 2L), c(2L, 1L))) {
      answer <- cjqr_residual_diagnostics(fit, order = order)
      expected <- cbind(marginal[, order[1L]],
        (marginal[, order[2L]] - fit$fit$theta * marginal[, order[1L]]) /
          sqrt(1 - fit$fit$theta^2))
      expect_s3_class(answer, 'cjqr_residual_diagnostics')
      expect_equal(unname(answer$normal), unname(expected), tolerance = 1e-10)
      expect_equal(unname(answer$uniform), unname(pnorm(expected)), tolerance = 1e-12)
      expect_equal(answer$marginal_pit, residuals(fit, 'pit'), tolerance = 1e-12)
      expect_equal(answer$marginal_normal, marginal, tolerance = 1e-10)
      expect_identical(answer$n, 9L)
      expect_identical(answer$row_names, rownames(fit$Y))
      expect_identical(answer$row_index, fit$kept_rows)
      expect_identical(answer$omitted_rows, fit$omitted_rows)
      expect_identical(answer$labels, c(fit$responses[order[1L]],
        paste(fit$responses[order[2L]], '|', fit$responses[order[1L]])))
      expect_identical(answer$joint_refits, 0L)
      expect_identical(serialize(fit, NULL), serialized)
      expect_identical(.Random.seed, rng)
    }
  }
})

test_that('diagnostics use observed outcomes explicitly and retain a one-pair result', {
  fit <- .residual_api_eal_fixture()
  y <- fit$Y + .1
  changed <- cjqr_residual_diagnostics(fit, y = y)
  fit$Y <- y
  expect_identical(changed$normal, cjqr_residual_diagnostics(fit)$normal)
  one <- fit
  one$X <- fit$X[1L, , drop = FALSE]
  one$Y <- fit$Y[1L, , drop = FALSE]
  one$kept_rows <- fit$kept_rows[1L]
  answer <- cjqr_residual_diagnostics(one)
  expect_identical(dim(answer$normal), c(1L, 2L))
  expect_identical(answer$n, 1L)
  expect_true(is.na(answer$correlation))
  expect_true(all(is.na(answer$summary$sd_normal)))
})

test_that('diagnostics reject malformed orders and paired outcomes', {
  fit <- .residual_api_eal_fixture()
  for (order in list(1L, c(1L, 1L), c(2L, 2L), c(0, 2), c(1, 3),
      c(1, NA_real_), c('1', '2'), c(1, 2, 3)))
    expect_error(cjqr_residual_diagnostics(fit, order = order), 'order')
  for (y in list(as.data.frame(fit$Y), fit$Y[-1L, , drop = FALSE],
      fit$Y[, 1L, drop = FALSE], replace(fit$Y, 1L, NA_real_),
      replace(fit$Y, 1L, Inf), fit$Y[, 2:1, drop = FALSE], fit$Y + 1i))
    expect_error(cjqr_residual_diagnostics(fit, y = y), 'y')
  expect_error(cjqr_residual_diagnostics(list()), 'fitted')
  expect_error(cjqr_residual_diagnostics(fit, newdata = list(x = 1)), 'data frame')
  expect_error(cjqr_residual_diagnostics(fit, newdata = data.frame(x = numeric())), 'data frame')
  bad <- fit; bad$fit$strict_ok <- FALSE
  expect_error(cjqr_residual_diagnostics(bad), 'certified')
  bad <- fit; bad$fit$sigma[1L] <- 0
  expect_error(cjqr_residual_diagnostics(bad), 'scales')
  bad <- fit; bad$fit$shape <- matrix(0, 4L, 2L)
  expect_error(cjqr_residual_diagnostics(bad), 'shape')
})

test_that('EAL new data requires observed responses and uses supplied row identities', {
  fit <- .residual_api_eal_fixture()
  data <- data.frame(x = seq(-1, 1, length.out = 9L), A = fit$Y[, 1L],
                     B = fit$Y[, 2L], row.names = paste0('evaluation', 1:9))
  local_mocked_bindings(.cjqr_eal_newX = function(object, newdata = NULL) {
    if (is.null(newdata)) object$X else cbind('(Intercept)' = 1, x = newdata$x)
  }, .package = 'CJQR')
  implicit <- cjqr_residual_diagnostics(fit, newdata = data)
  explicit <- cjqr_residual_diagnostics(fit, newdata = data['x'], y = fit$Y)
  expect_identical(implicit$normal, explicit$normal)
  expect_equal(unname(implicit$normal), unname(cjqr_residual_diagnostics(fit)$normal))
  expect_identical(implicit$row_names, rownames(data))
  expect_identical(implicit$row_index, 1:9)
  expect_identical(implicit$omitted_rows, integer())
  expect_identical(implicit$evaluation, 'new data')
  expect_error(cjqr_residual_diagnostics(fit, newdata = data['x']), 'responses')
})

test_that('printing residual diagnostics is descriptive and does not change results', {
  diagnostics <- cjqr_residual_diagnostics(.residual_api_eal_fixture())
  expect_output(answer <- print(diagnostics), 'joint refits: 0')
  expect_identical(answer, diagnostics)
  expect_error(print(diagnostics, digits = 0), 'digits')
  expect_error(print(diagnostics, surprise = 1), 'Unsupported')
})
