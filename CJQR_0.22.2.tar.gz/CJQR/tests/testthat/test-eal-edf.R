.eal_edf_fixture <- function(copula = "gaussian") {
  n <- 180L
  x <- seq(-1, 1, length.out = n)
  z <- sin(seq_len(n) * sqrt(2))
  X <- list(cbind("(Intercept)" = 1, z = z, x = x, x2 = x^2),
    cbind("(Intercept)" = 1, z = z, x = x, x2 = x^2, x3 = x^3))
  beta <- list(c(.1, .2, -.3, .15), c(-.2, .1, .2, -.1, .08))
  r <- cbind(2 * sin(seq_len(n) * 1.73) + .017,
    2 * cos(seq_len(n) * 2.13) - .029)
  sigma <- c(.7, .8)
  fit <- list(beta = beta, sigma = sigma,
    shape = matrix(c(-.35, .07, .03, -.04, .02,
                     -.28, .08, -.02, .03, .01), 5L, 2L),
    p = .35, degree = 3L, copula = copula,
    theta = switch(copula, gaussian = .4, student_t = -.3,
      clayton = 1.2, frank = -3, gumbel = 1.5),
    df = if (copula == "student_t") 5 else NULL,
    strict_ok = TRUE, improved_certificate = list(boundary = integer(),
      dependence_boundary = FALSE, scale_boundary = FALSE, shape_boundary = FALSE))
  sm <- lapply(1:2, function(j) list(smooth = list(list(
    label = "s(x)", first.para = 3L, last.para = ncol(X[[j]])))))
  structure(list(X = X, Y = CJQR:::.cjqr_eal_location(X, beta) +
    sweep(r, 2L, sigma, "*"), P = list(diag(c(0, 0, 2, 3)),
      diag(c(0, 0, 2, 3, 4))), fit = fit, basis = sm,
    responses = c("y1", "y2"), copula = copula, df = fit$df,
    degree = 3L, selection = list(strict_ok = TRUE), control = list()),
    class = "cjqr_eal")
}

test_that("full EAL joint scores match numerical likelihood derivatives in all copulas", {
  for (family in c("gaussian", "clayton", "student_t", "frank", "gumbel")) {
    o <- .eal_edf_fixture(family)
    eng <- CJQR:::.cjqr_eal_engine(family)
    sc <- CJQR:::.cjqr_eal_joint_score(o, eng)
    expect_identical(ncol(sc$score), 22L)
    expect_identical(length(sc$nuisance_indices), 13L)
    d <- lengths(o$fit$beta)
    par <- c(unlist(o$fit$beta), log(o$fit$sigma), as.vector(o$fit$shape),
      CJQR:::.cjqr_delta_from_theta(o$fit$theta, family))
    logdensity <- function(p) {
      f <- o$fit
      f$beta <- list(p[1:4], p[5:9])
      f$sigma <- exp(p[10:11]); f$shape <- matrix(p[12:21], 5L, 2L)
      f$theta <- switch(family, gaussian =, student_t = tanh(p[22L]),
        clayton = exp(p[22L]), frank = p[22L], gumbel = 1 + exp(p[22L]))
      eng$log_density(f, o$X, o$Y)
    }
    fd <- vapply(seq_along(par), function(k) {
      h <- 1e-6 * max(1, abs(par[k])); a <- b <- par
      a[k] <- a[k] + h; b[k] <- b[k] - h
      (logdensity(a) - logdensity(b)) / (2 * h)
    }, numeric(nrow(o$Y)))
    expect_identical(dim(sc$score), dim(fd))
    expect_true(max(abs(unname(sc$score) - fd)) < 2e-6, info = family)
    # The score recovers the engine objective gradient after penalty addition.
    prob <- eng$problem(o$X, o$Y, o$P, o$fit$beta, o$fit$sigma,
      p = o$fit$p, init = o$fit, copula = family,
      control = if (family == "student_t") list(df = 5) else list())
    g <- -colMeans(sc$score)
    for (j in 1:2) {
      ii <- sc$beta_indices[[j]]
      g[ii] <- g[ii] + drop(o$P[[j]] %*% o$fit$beta[[j]]) / nrow(o$Y)
      g[ii] <- drop(crossprod(prob$Rinv[[j]], g[ii]))
    }
    expect_equal(unname(g), unname(prob$evaluate(prob$par)$gradient), tolerance = 2e-9)
    edf <- CJQR:::.cjqr_eal_smooth_edf(o)
    expect_true(edf$available)
    expect_true(all(is.finite(unlist(edf$edf))))
  }
})

test_that("OPG EDF agrees with the linear smoother trace and includes nuisance parameters", {
  n <- 100L
  S <- cbind(1, seq(-1, 1, length.out = n), sin(seq_len(n)), cos(seq_len(n)))
  P <- diag(c(0, 2, 3, 0))
  fun <- CJQR:::.cjqr_eal_opg_trace
  ans <- fun(S, P, list(2:3))
  expect_true(ans$available)
  exact <- solve(crossprod(S) + P, crossprod(S))
  expect_equal(ans$edf, sum(diag(exact)[2:3]), tolerance = 1e-12)
  expect_equal(ans$diagnostics$total_edf, sum(diag(exact)), tolerance = 1e-12)
  expect_equal(ans$diagnostics$information_rank, 4L)
  zero <- fun(S, matrix(0, 4L, 4L), list(1:2, 3:4))
  expect_equal(zero$edf, c(2, 2), tolerance = 1e-12)
  expect_equal(zero$diagnostics$total_edf, 4, tolerance = 1e-12)
  monotone <- vapply(c(0, .1, 1, 10, 100), function(a)
    fun(S, a * P, list(2:3))$edf, numeric(1L))
  expect_true(all(diff(monotone) < 0))
  S[, 4L] <- S[, 4L] + 3 * S[, 2L]
  full <- fun(S, P, list(2:3))$edf
  omit <- fun(S[, 1:3], P[1:3, 1:3], list(2:3))$edf
  expect_gt(abs(full - omit), .05)
})

test_that("OPG block EDF is invariant to within-block coordinates and observation scaling", {
  o <- .eal_edf_fixture()
  s <- CJQR:::.cjqr_eal_joint_score(o)
  q <- ncol(s$score)
  P <- matrix(0, q, q)
  for (j in 1:2) P[s$beta_indices[[j]], s$beta_indices[[j]]] <- o$P[[j]]
  blocks <- list(3:4, 7:9)
  fun <- CJQR:::.cjqr_eal_opg_trace
  original <- fun(s$score, P, blocks)
  expect_true(original$available)
  T <- diag(q)
  T[3:4, 3:4] <- matrix(c(2, .2, -.3, .7), 2L)
  T[7:9, 7:9] <- matrix(c(1, .1, 0, -.2, 2, .1, 0, -.1, .5), 3L)
  T[10:22, 10:22] <- diag(seq(.4, 2, length.out = 13L))
  T[10, 12] <- .2; T[14, 20] <- -.3
  transformed <- fun(s$score %*% T, crossprod(T, P %*% T), blocks)
  expect_true(transformed$available)
  expect_equal(original$edf, transformed$edf, tolerance = 1e-9)
  expect_equal(original$diagnostics$total_edf,
    transformed$diagnostics$total_edf, tolerance = 1e-9)
  rescaled <- fun(s$score / sqrt(nrow(o$Y)), P / nrow(o$Y), blocks)
  expect_equal(original$edf, rescaled$edf, tolerance = 1e-9)
})

test_that("common and distinct representations give identical scores and EDF", {
  o <- .eal_edf_fixture()
  o$X[[2L]] <- o$X[[1L]]
  o$fit$beta[[2L]] <- o$fit$beta[[2L]][1:4]
  o$P[[2L]] <- o$P[[1L]]
  o$basis[[2L]] <- o$basis[[1L]]
  before <- CJQR:::.cjqr_eal_joint_score(o)$score
  edf <- CJQR:::.cjqr_eal_smooth_edf(o)
  o$X <- o$X[[1L]]
  o$fit$beta <- do.call(cbind, o$fit$beta)
  expect_equal(CJQR:::.cjqr_eal_joint_score(o)$score, before, tolerance = 1e-12)
  expect_equal(CJQR:::.cjqr_eal_smooth_edf(o)$edf, edf$edf, tolerance = 1e-10)
})

test_that("unsafe information is not silently regularized", {
  fun <- CJQR:::.cjqr_eal_opg_trace
  S <- cbind(1, seq(-1, 1, length.out = 40L))
  expect_false(fun(cbind(S, S[, 2L]), matrix(0, 3L, 3L), list(2:3))$available)
  expect_match(fun(S, diag(c(0, -1)), list(2L))$reason, "not_PSD")
  P <- matrix(c(0, 1, 0, 0), 2L)
  expect_match(fun(S, P, list(2L))$reason, "nonsymmetric")
  S[1L, 1L] <- Inf
  expect_false(fun(S, diag(2L), list(2L))$available)
})

test_that("joint smooth EDF has honest boundary and cusp gates without mutating fits", {
  o <- .eal_edf_fixture()
  frozen <- serialize(o, NULL)
  ans <- CJQR:::.cjqr_eal_smooth_edf(o)
  expect_true(ans$available)
  expect_identical(names(ans$edf), c("y1", "y2"))
  expect_identical(names(ans$edf[[1L]]), "s(x)")
  expect_true(all(unlist(ans$edf) > 0))
  expect_true(all(unlist(ans$edf) <= c(2, 3)))
  expect_identical(ans$diagnostics$nuisance_dimension, 13L)
  expect_false(ans$diagnostics$is_sampling_covariance)
  expect_identical(serialize(o, NULL), frozen)
  o$fit$improved_certificate$shape_boundary <- TRUE
  expect_match(CJQR:::.cjqr_eal_smooth_edf(o)$reason, "boundary")
  o$fit$improved_certificate$shape_boundary <- FALSE
  o$fit$theta <- .995
  expect_match(CJQR:::.cjqr_eal_smooth_edf(o)$reason, "boundary")
  o <- .eal_edf_fixture()
  o$Y[1L, 1L] <- drop(o$X[[1L]][1L, ] %*% o$fit$beta[[1L]])
  knot <- CJQR:::.cjqr_eal_smooth_edf(o)
  expect_false(knot$available)
  expect_match(knot$reason, "nondifferentiable")
  expect_true(all(is.na(unlist(knot$edf))))
  o$basis <- list(list(smooth = list()), list(smooth = list()))
  expect_identical(CJQR:::.cjqr_eal_smooth_edf(o)$reason, "no_smooth_components")
})

test_that("incomplete legacy density parameters yield unavailable EDF rather than errors", {
  invalid <- list(
    list("shape", NULL), list("shape", "missing"), list("shape", list(1)),
    list("shape", matrix(0, 3L, 2L)), list("shape", matrix(NA_real_, 5L, 2L)),
    list("sigma", NULL), list("sigma", c("1", "2")),
    list("sigma", c(1, NA_real_)), list("sigma", c(1, -1)),
    list("theta", NULL), list("theta", "missing"), list("theta", NaN),
    list("theta", c(.1, .2)), list("theta", 2),
    list("p", NULL), list("p", NA_real_), list("p", 1))
  for (case in invalid) {
    o <- .eal_edf_fixture()
    o$fit[[case[[1L]]]] <- case[[2L]]
    frozen <- serialize(o, NULL)
    ans <- CJQR:::.cjqr_eal_smooth_edf(o)
    expect_false(ans$available)
    expect_identical(ans$reason, "incomplete_or_invalid_density_parameters")
    expect_true(all(is.na(unlist(ans$edf))))
    expect_identical(serialize(o, NULL), frozen)
  }
})
