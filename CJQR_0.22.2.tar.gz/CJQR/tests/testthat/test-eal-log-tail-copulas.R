test_that("additional EAL copulas retain finite represented extreme-tail scores", {
  env <- CJQR:::.cjqr_eal_engine("student_t")$reference_density
  z <- expand.grid(one=c(-10000,-40,.2,40,10000),
    two=c(-10000,-40,.2,40,10000))
  terms <- lapply(z,function(x)env$eal_terms(x,.25,rep(0,5L),3L,TRUE))
  cases <- list(list("student_t",-.995,.1),list("student_t",0,.5),
    list("student_t",.995,5),list("student_t",-.7,1000),
    list("frank",-30,NULL),list("frank",-.01,NULL),list("frank",0,NULL),
    list("frank",.01,NULL),list("frank",30,NULL),
    list("gumbel",1+exp(-17),NULL),list("gumbel",2,NULL),list("gumbel",30,NULL))
  for(z in cases) {
    out <- env$eal_additional_copula_terms(terms[[1]],terms[[2]],z[[2]],z[[1]],z[[3]],TRUE)
    expect_true(all(is.finite(unlist(out))),info=paste(z[[1]],z[[2]],z[[3]]))
  }
  frank <- env$eal_frank_terms(terms[[1]],terms[[2]],0,TRUE)
  expect_true(all(frank$logc==0))
  expect_true(all(frank$de==0))
  expect_true(all(unlist(frank$dshape)==0))
  gumbel <- env$eal_gumbel_terms(terms[[1]],terms[[2]],1,TRUE)
  expect_true(all(unlist(gumbel)==0))
  student <- env$eal_student_t_terms(terms[[1]],terms[[2]],0,5,TRUE)
  expect_gt(max(abs(student$logc)),1)
})

test_that("signed Frank has a continuous analytic independence score", {
  env <- CJQR:::.cjqr_eal_engine("frank")$reference_density
  t1 <- env$eal_terms(c(-.9,.2,1.3),.5,rep(0,5),3,TRUE)
  t2 <- env$eal_terms(c(.6,-.7,1.1),.5,rep(0,5),3,TRUE)
  for(theta in c(-.01,-.009,0,.009,.01)) {
    a <- env$eal_frank_terms(t1,t2,theta,TRUE)
    h <- 1e-6
    fd <- (env$eal_frank_terms(t1,t2,theta+h,FALSE)$logc-
      env$eal_frank_terms(t1,t2,theta-h,FALSE)$logc)/(2*h)
    expect_equal(a$ddelta,fd,tolerance=2e-7)
  }
})

test_that("small shape bounds cannot create infeasible starts or certificates", {
  en <- CJQR:::.cjqr_eal_engine("student_t")
  X <- cbind(1,seq(-1,1,length.out=15)); Y <- cbind(sin(1:15),cos(1:15))
  P <- rep(list(diag(c(0,.2))),2)
  beta <- matrix(0,2,2)
  init <- list(beta=beta,sigma=c(.7,.8),shape=matrix(.5,5,2),degree=3L,p=.5,theta=.3)
  pr <- en$problem(X,Y,P,beta,c(.7,.8),.5,init=init,
    control=list(df=5,shape_bound=.01))
  expect_true(all(pr$par>=pr$lower&pr$par<=pr$upper))
  expect_equal(pr$unpack(pr$par)$shape,matrix(.01,5,2))
  bad <- pr$par; bad[pr$idx_shape[1]] <- pr$upper[pr$idx_shape[1]]+1e-11
  cc <- en$certificate(pr,bad,pr$evaluate(bad,FALSE)$value)
  expect_false(cc$strict_local_ok)
  expect_identical(cc$reason_codes,"parameter_out_of_bounds")
  state <- en$reference_density$improved_eal_materialize(list(),pr,pr$par)
  expect_identical(state$copula,"student_t")
  expect_identical(state$df,5)
  expect_identical(state$dependence_link,"rho=tanh(delta)")
  expect_identical(state$n,15L)
})
