.copula_cases <- list(
  gaussian = list(theta = 0.50, delta = atanh(0.50), df = NULL),
  clayton = list(theta = 2, delta = log(2), df = NULL),
  frank = list(theta = 5, delta = 5, df = NULL),
  gumbel = list(theta = 2, delta = log(2 - 1), df = NULL),
  student_t = list(theta = 0.50, delta = atanh(0.50), df = 4)
)

test_that("copula names and Student-t degrees of freedom are validated", {
  expect_identical(CJQR:::.cjqr_normalize_copula("normal"), "gaussian")
  expect_identical(CJQR:::.cjqr_normalize_copula("Student-t"), "student_t")
  expect_identical(CJQR:::.cjqr_normalize_copula("t"), "student_t")
  expect_error(CJQR:::.cjqr_normalize_copula("joe"), "Unsupported")

  for (nu in c(0.5, 2, 4.5)) {
    expect_identical(CJQR:::.cjqr_validate_copula_df("student_t", nu), nu)
  }
  for (nu in list(NULL, 0, -1, Inf, NA_real_, c(3, 4), "4")) {
    expect_error(
      CJQR:::.cjqr_validate_copula_df("student_t", nu),
      "require one finite `df > 0`"
    )
  }
  for (family in c("gaussian", "clayton", "frank", "gumbel")) {
    expect_error(
      CJQR:::.cjqr_validate_copula_df(family, 4),
      "only defined"
    )
    expect_null(CJQR:::.cjqr_validate_copula_df(family))
  }
})

test_that("family links exactly follow GJRM and invert on interior domains", {
  for (family in names(.copula_cases)) {
    case <- .copula_cases[[family]]
    theta <- CJQR:::.cjqr_theta_from_delta(
      case$delta, family
    )
    expect_equal(theta, case$theta, tolerance = 2e-12)
    recovered <- CJQR:::.cjqr_delta_from_theta(
      theta, family
    )
    expect_equal(recovered, case$delta, tolerance = 2e-12)
  }

  expect_equal(CJQR:::.cjqr_theta_from_delta(0, "gaussian"), 0)
  expect_equal(CJQR:::.cjqr_theta_from_delta(0, "student_t"), 0)
  expect_equal(CJQR:::.cjqr_theta_from_delta(0, "clayton"), 1)
  expect_equal(CJQR:::.cjqr_theta_from_delta(0, "gumbel"), 2)
  expect_equal(CJQR:::.cjqr_theta_from_delta(0, "frank"), 0)
  expect_equal(CJQR:::.cjqr_theta_from_delta(-log(2), "clayton"), 0.5)
  expect_equal(CJQR:::.cjqr_theta_from_delta(-log(2), "gumbel"), 1.5)
  expect_error(CJQR:::.cjqr_delta_from_theta(-0.01, "clayton"),
               "lie in|[Cc]layton")
  expect_error(CJQR:::.cjqr_delta_from_theta(0.99, "gumbel"),
               "lie in|[Gg]umbel")


})

test_that("GJRM predictor clipping protects open parameter limits", {
  delta <- c(-100, 100)
  gaussian_limits <- c(-8.75, 8.75)
  archimedean_limits <- c(-17, 20)
  gaussian <- CJQR:::.cjqr_theta_from_delta(delta, "gaussian")
  student_t <- CJQR:::.cjqr_theta_from_delta(delta, "student_t")
  expect_true(all(abs(gaussian) < 1))
  expect_equal(student_t, gaussian, tolerance = 0)
  expect_equal(gaussian, tanh(gaussian_limits), tolerance = 0)

  clayton <- CJQR:::.cjqr_theta_from_delta(delta, "clayton")
  gumbel <- CJQR:::.cjqr_theta_from_delta(delta, "gumbel")
  expect_true(all(clayton > 0))
  expect_true(all(gumbel > 1))
  expect_equal(clayton, exp(archimedean_limits), tolerance = 0)
  expect_equal(gumbel, 1 + exp(archimedean_limits), tolerance = 0)

  expect_equal(CJQR:::.cjqr_delta_from_theta(0, "clayton"), -Inf)
  expect_equal(CJQR:::.cjqr_delta_from_theta(1, "gumbel"), -Inf)
  expect_equal(
    CJQR:::.cjqr_dtheta_ddelta(
      delta, gaussian, "gaussian"
    ),
    c(0, 0), tolerance = 0
  )
})

test_that("Kendall transformations agree with standard family identities", {
  expect_equal(CJQR:::.cjqr_kendall_tau(0.5, "gaussian"), 1 / 3,
               tolerance = 1e-12)
  expect_equal(CJQR:::.cjqr_kendall_tau(0.5, "student_t", df = 0.5),
               1 / 3, tolerance = 1e-12)
  expect_equal(CJQR:::.cjqr_kendall_tau(2, "clayton"), 0.5,
               tolerance = 1e-12)
  expect_equal(CJQR:::.cjqr_kendall_tau(2, "gumbel"), 0.5,
               tolerance = 1e-12)
  expect_equal(CJQR:::.cjqr_kendall_tau(0, "frank"), 0,
               tolerance = 0)
  expect_equal(CJQR:::.cjqr_kendall_tau(5, "frank"),
               0.4567009582, tolerance = 2e-8)
  expect_equal(CJQR:::.cjqr_kendall_tau(-5, "frank"),
               -0.4567009582, tolerance = 2e-8)
})

test_that("copula CDFs satisfy boundaries, symmetry, and known values", {
  u <- c(0.2, 0.61, 0.87)
  v <- c(0.73, 0.44, 0.35)
  for (family in names(.copula_cases)) {
    case <- .copula_cases[[family]]
    c_uv <- CJQR:::.cjqr_copula_cdf(
      u, v, case$theta, family, df = case$df
    )
    c_vu <- CJQR:::.cjqr_copula_cdf(
      v, u, case$theta, family, df = case$df
    )
    expect_true(all(is.finite(c_uv)))
    expect_true(all(c_uv >= 0 & c_uv <= pmin(u, v) + 1e-10))
    expect_equal(c_uv, c_vu, tolerance = 2e-7)
    expect_equal(
      CJQR:::.cjqr_copula_cdf(rep(0, 3), v, case$theta,
                                  family, df = case$df),
      rep(0, 3), tolerance = 1e-12
    )
    expect_equal(
      CJQR:::.cjqr_copula_cdf(rep(1, 3), v, case$theta,
                                  family, df = case$df),
      v, tolerance = 2e-8
    )
  }

  expect_equal(
    CJQR:::.cjqr_copula_cdf(0.5, 0.5, 0.5, "gaussian"),
    0.25 + asin(0.5) / (2 * pi), tolerance = 2e-7
  )
  expect_equal(
    CJQR:::.cjqr_copula_cdf(0.5, 0.5, 0.5, "student_t", df = 0.5),
    0.25 + asin(0.5) / (2 * pi), tolerance = 5e-6
  )
  expect_equal(
    CJQR:::.cjqr_copula_cdf(0.5, 0.5, 2, "clayton"),
    1 / sqrt(7), tolerance = 1e-12
  )
  expect_equal(
    CJQR:::.cjqr_copula_cdf(0.5, 0.5, 2, "gumbel"),
    2^(-sqrt(2)), tolerance = 1e-12
  )
  frank_expected <- -log1p(
    expm1(-5 * 0.5)^2 / expm1(-5)
  ) / 5
  expect_equal(
    CJQR:::.cjqr_copula_cdf(0.5, 0.5, 5, "frank"),
    frank_expected, tolerance = 1e-12
  )

  # A finite-df t copula with zero correlation has tau zero, but it is not
  # the independence copula because both components share the random scale.
  t_zero <- CJQR:::.cjqr_copula_cdf(0.8, 0.8, 0, "student_t", df = 4)
  expect_gt(abs(t_zero - 0.64), 1e-4)
})

test_that("copula h-functions and log-density derivatives are finite", {
  z1 <- qnorm(c(0.17, 0.43, 0.81))
  z2 <- qnorm(c(0.68, 0.29, 0.76))
  h <- 2e-6
  for (family in names(.copula_cases)) {
    case <- .copula_cases[[family]]
    terms <- CJQR:::.cjqr_copula_terms(
      z1, z2, case$delta, family, df = case$df
    )
    expect_true(all(is.finite(terms$logc)))
    expect_true(all(is.finite(terms$ddelta)))
    expect_true(all(is.finite(terms$dz1)))
    expect_true(all(is.finite(terms$dz2)))
    plus <- CJQR:::.cjqr_copula_terms(
      z1, z2, case$delta + h, family, df = case$df
    )$logc
    minus <- CJQR:::.cjqr_copula_terms(
      z1, z2, case$delta - h, family, df = case$df
    )$logc
    expect_equal(terms$ddelta, (plus - minus) / (2 * h),
                 tolerance = 4e-4)

    hh <- CJQR:::.cjqr_copula_hfunc(
      pnorm(z1), pnorm(z2), case$theta, family, df = case$df
    )
    expect_named(hh, c("h21", "h12"))
    expect_true(all(is.finite(unlist(hh))))
    expect_true(all(unlist(hh) >= 0 & unlist(hh) <= 1))
  }
})

test_that("copula simulation has uniform margins and target Kendall tau", {
  set.seed(2901)
  for (family in names(.copula_cases)) {
    case <- .copula_cases[[family]]
    uv <- CJQR:::.cjqr_copula_simulate(
      1400L, case$theta, family, df = case$df
    )
    expect_equal(dim(uv), c(1400L, 2L))
    expect_true(all(is.finite(uv) & uv > 0 & uv < 1))
    expect_equal(unname(colMeans(uv)), c(0.5, 0.5), tolerance = 0.035)
    empirical <- cor(uv[, 1L], uv[, 2L], method = "kendall")
    target <- CJQR:::.cjqr_kendall_tau(
      case$theta, family, df = case$df
    )
    expect_equal(empirical, target, tolerance = 0.065)
  }
})

test_that("strong Clayton simulation remains finite and open", {
  set.seed(2903)
  for (theta in c(1e4, 1e6)) {
    uv <- CJQR:::.cjqr_copula_simulate(1400L, theta, "clayton")
    expect_equal(dim(uv), c(1400L, 2L))
    expect_true(all(is.finite(uv) & uv > 0 & uv < 1),
                info = paste("theta", theta))
    expect_equal(
      unname(colMeans(uv)), c(0.5, 0.5), tolerance = 0.035,
      info = paste("theta", theta)
    )
    empirical <- cor(uv[, 1L], uv[, 2L], method = "kendall")
    target <- theta / (theta + 2)
    expect_equal(empirical, target, tolerance = 0.01,
                 info = paste("theta", theta))
  }
})

test_that("Frank copula supports negative dependence", {
  theta <- -5
  delta <- -5
  u <- c(0.14, 0.47, 0.82)
  v <- c(0.76, 0.31, 0.66)
  cdf <- CJQR:::.cjqr_copula_cdf(u, v, theta, "frank")
  expect_true(all(is.finite(cdf)))
  expect_true(all(cdf >= pmax(0, u + v - 1) - 1e-12))
  expect_true(all(cdf <= pmin(u, v) + 1e-12))
  terms <- CJQR:::.cjqr_copula_terms(
    qnorm(u), qnorm(v), delta, "frank"
  )
  expect_true(all(is.finite(terms$logc)))
  expect_true(all(is.finite(terms$ddelta)))

  set.seed(2902)
  uv <- CJQR:::.cjqr_copula_simulate(1800L, theta, "frank")
  empirical <- cor(uv[, 1L], uv[, 2L], method = "kendall")
  expect_equal(
    empirical,
    CJQR:::.cjqr_kendall_tau(theta, "frank"),
    tolerance = 0.06
  )
  expect_lt(empirical, -0.35)
})
