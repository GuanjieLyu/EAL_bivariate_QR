# Independent whole-block geometry and bootstrap regression checks.
# These deterministic fixtures never optimize or refit an EAL likelihood.
.eal_smooth_draw_fixture <- function(reference = c(1, 1)) {
  errors <- sqrt(1.5) * rbind(c(1, -1, 0, 0), c(0, 0, 1, -1))
  sweep(errors, 1L, reference, "+")
}

.eal_smooth_hc3_oracle <- function(X, y) {
  inverse <- solve(crossprod(X))
  beta <- drop(inverse %*% crossprod(X, y))
  residual <- drop(y - X %*% beta)
  leverage <- rowSums((X %*% inverse) * X)
  meat <- crossprod(X, X * (residual / (1 - leverage))^2)
  list(beta = beta, covariance = inverse %*% meat %*% inverse)
}

test_that("whole-smooth hull statistics match analytic negative-ray geometry", {
  hull <- CJQR:::.cjqr_eal_smooth_hull
  r <- c(1, 1)
  draws <- .eal_smooth_draw_fixture(r)
  cases <- list(list(b = c(-2, 0), t = .5, statistic = 1, p = 1),
    list(b = c(1, 1), t = 0, statistic = 2, p = .2),
    list(b = c(-1, -1), t = 1, statistic = 0, p = 1),
    list(b = c(1, -1), t = 0, statistic = 2, p = .2))
  for (case in cases) {
    out <- hull(r, case$b, draws, level = .8)
    expect_true(out$available)
    expect_identical(out$rank, 2L)
    expect_equal(out$covariance, diag(2), tolerance = 1e-14)
    expect_equal(out$reference_statistic, 2, tolerance = 1e-14)
    expect_equal(out$reference_p.value, .2)
    expect_equal(out$ray, case$t, tolerance = 1e-14)
    expect_equal(out$statistic, case$statistic, tolerance = 1e-14)
    expect_equal(out$p.value, case$p)
    expect_equal(out$radial, rep(1.5, 4), tolerance = 1e-14)
    expect_equal(out$critical, 1.5, tolerance = 1e-14)
    expect_equal(out$p_value_floor, .2)
  }
  zero <- hull(r, c(0, 0), draws)
  expect_true(zero$available)
  expect_equal(zero$statistic, 0)
  expect_equal(zero$p.value, 1)
  expect_true(is.na(zero$ray))
  expect_true(is.infinite(zero$critical))
})

test_that("hull statistics agree with independent constrained minimization", {
  hull <- CJQR:::.cjqr_eal_smooth_hull
  i <- seq_len(80L)
  errors <- rbind(sin(i * 1.13), cos(i * .77), sin(i * .37) + cos(i * .23))
  r <- c(.6, -.4, .3)
  draws <- sweep(errors, 1L, r, "+")
  W <- solve(stats::cov(t(draws)))
  radial <- colSums(errors * (W %*% errors))
  for (b in list(c(-1, 0, .1), c(.3, -.7, .2), c(-.2, .9, -.3))) {
    objective <- function(t) drop(crossprod(r + t * b, W %*% (r + t * b)))
    optimum <- optimize(objective, c(0, 100), tol = 1e-12)
    oracle <- min(objective(0), optimum$objective)
    out <- hull(r, b, draws)
    expect_true(out$available)
    expect_equal(out$statistic, oracle, tolerance = 1e-10)
    expect_equal(out$radial, radial, tolerance = 1e-10)
    expect_equal(out$p.value, (1 + sum(radial >= oracle)) / (length(i) + 1))
    expect_lte(out$statistic, out$reference_statistic + 1e-12)
    expect_gte(out$p.value, out$reference_p.value)
    expect_gte(out$p.value, 1 / (length(i) + 1))
  }
})

test_that("smooth block inference is invariant to nonsingular reparameterization", {
  hull <- CJQR:::.cjqr_eal_smooth_hull
  r <- c(.8, -.3)
  i <- seq_len(91L)
  draws <- sweep(rbind(sin(i * 1.7), cos(i * 1.3) + .3 * sin(i * 1.7)), 1L, r, "+")
  b <- c(-.9, -.5)
  original <- hull(r, b, draws)
  for (A in list(matrix(c(2, -.4, .3, 1.1), 2), diag(c(.001, 1000)),
                 matrix(c(0, 1, 1, 0), 2))) {
    transformed <- hull(drop(A %*% r), drop(A %*% b), A %*% draws)
    expect_true(transformed$available)
    expect_equal(transformed$statistic, original$statistic, tolerance = 1e-10)
    expect_equal(transformed$reference_statistic, original$reference_statistic, tolerance = 1e-10)
    expect_equal(transformed$radial, original$radial, tolerance = 1e-10)
    expect_equal(transformed$p.value, original$p.value)
  }
  # Hull containment uses the joint estimate's ray: its magnitude does not
  # create native joint-estimator sampling information.
  for (scale in c(.001, .5, 10, 1000)) {
    changed <- hull(r, scale * b, draws)
    expect_equal(changed$statistic, original$statistic, tolerance = 1e-10)
    expect_equal(changed$p.value, original$p.value)
  }
})

test_that("singular inadequate and nonfinite smooth draws fail without regularization", {
  hull <- CJQR:::.cjqr_eal_smooth_hull
  r <- b <- c(1, 1)
  singular <- rbind(seq_len(12), 2 * seq_len(12))
  for (draws in list(singular, matrix(1, 2, 12), matrix(1, 2, 2),
                     matrix(NA_real_, 2, 12), matrix(Inf, 2, 12), matrix(1, 3, 12))) {
    out <- hull(r, b, draws)
    expect_false(out$available)
    expect_true(is.na(out$statistic))
    expect_true(is.na(out$p.value))
    expect_match(out$reason, ".+")
  }
  i <- seq_len(30L)
  near <- rbind(sin(i), sin(i) + .001 * cos(i))
  out <- hull(r, b, near, condition_max = 1000)
  expect_false(out$available)
  expect_match(out$reason, "no ridge or rank truncation")
  expect_false(hull(c(NA_real_, 1), b, .eal_smooth_draw_fixture())$available)
  expect_false(hull(r, 1, .eal_smooth_draw_fixture())$available)
  for (level in list(0, 1, NA_real_, c(.5, .95), "95%"))
    expect_error(hull(r, b, .eal_smooth_draw_fixture(), level = level), "Invalid smooth")
  expect_error(hull(r, b, .eal_smooth_draw_fixture(), condition_max = 1), "Invalid smooth")
})

test_that("one-dimensional smooth block covariance remains a matrix", {
  r <- .5
  draws <- matrix(seq(-.5, 1.5, length.out = 101L), nrow = 1L)
  out <- CJQR:::.cjqr_eal_smooth_hull(r, .2, draws)
  expect_true(out$available)
  expect_identical(dim(out$covariance), c(1L, 1L))
  expect_identical(out$rank, 1L)
  expect_equal(out$statistic, r^2 / var(as.vector(draws)), tolerance = 1e-12)
  opposite <- CJQR:::.cjqr_eal_smooth_hull(r, -.2, draws)
  expect_equal(opposite$p.value, 1)
  expect_equal(opposite$statistic, 0, tolerance = 1e-12)
})

test_that("supplied studentized metrics determine geometry and radial calibration separately", {
  hull <- CJQR:::.cjqr_eal_smooth_hull
  r <- c(.4, -.2)
  b <- c(-.3, -.1)
  draws <- .eal_smooth_draw_fixture(r)
  V <- matrix(c(2, .3, .3, .6), 2L)
  radial <- c(.01, .08, .3, 1.2)
  W <- solve(V)
  ray <- max(0, -drop(crossprod(b, W %*% r)) / drop(crossprod(b, W %*% b)))
  statistic <- drop(crossprod(r + ray * b, W %*% (r + ray * b)))
  out <- hull(r, b, draws, level = .8, covariance = V, radial = radial)
  expect_true(out$available)
  expect_equal(out$covariance, V)
  expect_identical(out$radial, radial)
  expect_equal(out$statistic, statistic, tolerance = 1e-12)
  expect_equal(out$ray, ray, tolerance = 1e-12)
  expect_equal(out$p.value, (1 + sum(radial >= statistic)) / 5)
  expect_equal(out$critical, 1.2)
  changed_draws <- hull(r, b, 100 * draws, covariance = V, radial = radial)
  expect_identical(changed_draws$statistic, out$statistic)
  expect_identical(changed_draws$p.value, out$p.value)
  for (input in list(list(covariance = V), list(radial = radial),
    list(covariance = diag(3), radial = radial),
    list(covariance = V, radial = c(0, 1)),
    list(covariance = V, radial = c(-1, 0, 1, 2)),
    list(covariance = V, radial = c(NA_real_, 0, 1, 2)),
    list(covariance = matrix(c(1, 0, .3, 1), 2), radial = radial))) {
    bad <- do.call(hull, c(list(reference = r, joint = b, draws = draws), input))
    expect_false(bad$available)
    expect_true(is.na(bad$p.value))
  }
})

test_that("public smooth tests retain all nuisance columns and paired subject rows", {
  for (distinct in c(FALSE, TRUE)) {
    fit <- .eal_coef_fixture(distinct)
    frozen <- serialize(fit, NULL)
    set.seed(812L)
    rng <- .Random.seed
    out <- cjqr_eal_smooth_test(fit, B = 199L, seed = 29L, keep_draws = TRUE)
    expect_identical(.Random.seed, rng)
    expect_identical(serialize(fit, NULL), frozen)
    expect_s3_class(out, "cjqr_eal_smooth_test")
    expect_true(out$available)
    expect_identical(names(out$tables), c("y1", "y2"))
    expect_identical(out$bootstrap$joint_refits, 0L)
    expect_true(out$bootstrap$paired_subject_rows)
    expect_true(out$bootstrap$all_draws_required)
    expect_true(out$bootstrap$studentized)
    expect_identical(out$bootstrap$replacement_draws, 0L)
    expect_equal(out$bootstrap$p_value_floor, .005)
    expect_false(out$interpretation$native_joint_Wald)
    expect_false(out$interpretation$Chi_squared_calibration)
    expect_false(out$interpretation$adjustment_across_smooths)
    expect_false(out$interpretation$anchor_adjustment_required)
    expect_true(out$interpretation$basis_and_centering_fixed)
    X <- if (distinct) fit$X else list(fit$X, fit$X)
    for (j in 1:2) {
      expect_identical(colnames(out$tables[[j]]), c("Rank", "Statistic", "p-value"))
      expect_identical(rownames(out$tables[[j]]), "s(x)")
      expect_equal(unname(out$tables[[j]][1, "Rank"]), 2)
      for (b in c(1L, 67L, 199L)) {
        ii <- out$draws$indices[, b]
        oracle <- qr.coef(qr(X[[j]][ii, , drop = FALSE]), fit$Y[ii, j])
        expect_equal(as.numeric(out$draws$coefficients[[j]][, b]), as.numeric(oracle), tolerance = 1e-12)
      }
      block <- fit$basis[[j]]$smooth[[1L]]
      ids <- seq.int(block$first.para, block$last.para)
      ref <- qr.coef(qr(X[[j]]), fit$Y[, j])[ids]
      joint <- if (distinct) fit$fit$beta[[j]][ids] else fit$fit$beta[ids, j]
      point <- .eal_smooth_hc3_oracle(X[[j]], fit$Y[, j])
      covariance <- point$covariance[ids, ids, drop = FALSE]
      radial <- vapply(seq_len(199L), function(b) {
        ii <- out$draws$indices[, b]
        boot <- .eal_smooth_hc3_oracle(X[[j]][ii, , drop = FALSE], fit$Y[ii, j])
        error <- boot$beta[ids] - point$beta[ids]
        drop(crossprod(error, solve(boot$covariance[ids, ids, drop = FALSE], error)))
      }, numeric(1L))
      expect_equal(unname(out$details[[j]][[1L]]$covariance), unname(covariance), tolerance = 1e-10)
      expect_equal(out$details[[j]][[1L]]$radial, radial, tolerance = 1e-9)
      oracle <- CJQR:::.cjqr_eal_smooth_hull(ref, joint,
        out$draws$coefficients[[j]][ids, , drop = FALSE], covariance = covariance, radial = radial)
      expect_equal(unname(out$tables[[j]][1, ]), c(oracle$rank, oracle$statistic, oracle$p.value))
    }
    expect_output(print(out), "whole-smooth tests", fixed = TRUE)
    expect_output(print(out), "joint refits: 0", fixed = TRUE)
  }
})

test_that("dedicated smooth print shows p-values and stars without removing raw diagnostics", {
  out <- cjqr_eal_smooth_test(.eal_coef_fixture(), B = 199L, seed = 138L)
  before <- serialize(out, NULL)
  lines <- capture.output(print(out, signif.stars = TRUE))
  txt <- paste(lines, collapse = "\n")
  expect_false(grepl("Rank|Statistic|Ref.df|Chi.sq", txt))
  expect_match(txt, "p-value", fixed = TRUE)
  expect_match(txt, "auxiliary-bootstrap", fixed = TRUE)
  expect_equal(sum(grepl("Signif. codes:", lines, fixed = TRUE)), 2L)
  smooth_rows <- lines[grepl("^s\\(x\\)[[:space:]]", lines)]
  expect_length(smooth_rows, 2L)
  expect_true(all(grepl("\\*", smooth_rows)))
  for (j in 1:2) {
    expect_identical(colnames(out$tables[[j]]), c("Rank", "Statistic", "p-value"))
    expect_true(is.finite(out$details[[j]][[1L]]$statistic))
    expect_identical(out$details[[j]][[1L]]$rank, 2L)
  }
  expect_identical(serialize(out, NULL), before)
  quiet <- capture.output(print(out, signif.stars = FALSE))
  expect_false(any(grepl("Signif. codes:|\\*", quiet)))
  expect_identical(withVisible(print(out, signif.stars = FALSE))$value, out)
  for (j in 1:2) out$tables[[j]][, "p-value"] <- NA_real_
  unavailable <- capture.output(print(out, signif.stars = TRUE))
  expect_false(any(grepl("Signif. codes:|\\*|Rank|Statistic", unavailable)))
})

test_that("whole-smooth tests target the full effect including its linear component", {
  fit <- .eal_coef_fixture()
  fit$fit$beta[3:4, ] <- 0
  zero <- cjqr_eal_smooth_test(fit, B = 100L, seed = 7L)
  expect_equal(unname(zero$tables[[1L]][, "p-value"]), 1)
  expect_equal(unname(zero$tables[[2L]][, "p-value"]), 1)
  fit$fit$beta[3L, ] <- c(.5, -.5)
  linear <- cjqr_eal_smooth_test(fit, B = 100L, seed = 7L)
  expect_equal(unname(linear$tables[[1L]][, "Rank"]), 2)
  expect_lt(unname(linear$tables[[1L]][, "p-value"]), .05)
  expect_lt(unname(linear$tables[[2L]][, "p-value"]), .05)
  expect_match(linear$null, "including its linear component", fixed = TRUE)
})

test_that("selected anchors do not alter the common-error smooth reference target", {
  fit <- .eal_coef_fixture()
  fixed <- cjqr_eal_smooth_test(fit, B = 199L, seed = 23L, keep_draws = TRUE)
  fit$anchor <- fit$fit$p <- .25
  fit$anchors <- c(.25, .5, .75)
  fit$selection$index <- 1L
  fit$selection$audit <- data.frame(anchor = fit$anchors, strict = TRUE)
  fit$fit$beta[1L, ] <- fit$fit$beta[1L, ] + c(-.7, .8)
  adaptive <- cjqr_eal_smooth_test(fit, B = 199L, seed = 23L, keep_draws = TRUE)
  expect_identical(adaptive$draws, fixed$draws)
  expect_identical(adaptive$tables, fixed$tables)
  expect_identical(adaptive$bootstrap$p_value_floor, fixed$bootstrap$p_value_floor)
  fit$anchor <- fit$anchors <- fit$selection <- NULL
  fit$selection <- list(strict_ok = TRUE)
  without_anchor_audit <- cjqr_eal_smooth_test(fit, B = 199L, seed = 23L, keep_draws = TRUE)
  expect_identical(without_anchor_audit$draws, fixed$draws)
  expect_identical(without_anchor_audit$tables, fixed$tables)
})

test_that("a failed draw disables all whole-smooth tests without dropping pairs", {
  blocks <- rep(list(list(list(label = "s(x)", ids = 1:2))), 2L)
  reference <- joint <- rep(list(c(1, 1)), 2L)
  draws <- rep(list(.eal_smooth_draw_fixture()), 2L)
  status <- data.frame(ok = c(TRUE, FALSE, TRUE, TRUE))
  opts <- list(B = 4L, seed = 11L, level = .95)
  out <- CJQR:::.cjqr_eal_smooth_compute(blocks, joint, reference, draws, status, opts)
  expect_false(out$available)
  expect_identical(out$bootstrap$successful, 3L)
  expect_identical(out$bootstrap$failed, 1L)
  expect_identical(out$bootstrap$replacement_draws, 0L)
  for (j in 1:2) {
    expect_true(all(is.na(out$tables[[j]])))
    expect_false(out$details[[j]][[1L]]$available)
    expect_match(out$details[[j]][[1L]]$reason, "At least one auxiliary draw failed")
  }
})

test_that("models without smooths return empty inferential tables", {
  fit <- .eal_coef_fixture()
  for (j in 1:2) fit$basis[[j]]$smooth <- list()
  out <- cjqr_eal_smooth_test(fit, B = 100L, seed = 12L)
  expect_true(out$available)
  for (j in 1:2) expect_identical(dim(out$tables[[j]]), c(0L, 3L))
  expect_output(print(out), "whole-smooth tests", fixed = TRUE)
})

test_that("HC3 detects singular resamples and unit leverage without a ridge", {
  fit <- .eal_coef_fixture()
  n <- nrow(fit$X)
  reference <- CJQR:::.cjqr_eal_coef_reference(fit$X, fit$Y, seq_len(n))
  expect_error(CJQR:::.cjqr_eal_smooth_hc3(fit$X, fit$Y, rep(1L, n), reference),
    "Rank-deficient smooth HC3")
  fit$X[, 2L] <- c(1, rep(0, n - 1L))
  reference <- CJQR:::.cjqr_eal_coef_reference(fit$X, fit$Y, seq_len(n))
  expect_error(CJQR:::.cjqr_eal_smooth_hc3(fit$X, fit$Y, seq_len(n), reference),
    "Unstable leverage")
  opts <- CJQR:::.cjqr_eal_ci_options(.5, .95, 4L, 27L, 1L, 256, TRUE)
  indices <- matrix(rep(seq_len(n), 4L), nrow = n)
  blocks <- lapply(1:2, function(j) CJQR:::.cjqr_eal_smooth_blocks(fit, j))
  out <- CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y,
    CJQR:::.cjqr_eal_betas(fit$fit$beta), list(1:2, 1:2), opts,
    resamples = indices, smooth_blocks = blocks)
  # OLS coefficient draws remain valid; an HC3 failure disables only the
  # new smooth inference, never silently discarding difficult draws.
  expect_true(out$available)
  expect_false(out$smooth$available)
  expect_identical(out$bootstrap$successful, 4L)
  expect_identical(out$smooth$bootstrap$successful, 0L)
  expect_identical(out$smooth$bootstrap$failed, 4L)
  expect_true(all(grepl("Unstable leverage", out$smooth$bootstrap$status$error)))
  for (j in 1:2) expect_true(all(is.na(out$smooth$tables[[j]])))
  expect_error(CJQR:::.cjqr_eal_smooth_studentized_radial(c(0, 0), c(1, 1),
    matrix(1, 2, 2)), "Singular or ill-conditioned")
})
