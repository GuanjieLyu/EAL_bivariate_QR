# Independent algebraic checks for anchor-aligned marginal intercept inference.
# Fixtures do not optimize or refit the EAL likelihood.
.eal_intercept_fixture <- function(distinct = FALSE, anchor = .5,
                                   anchors = c(.25, .5, .75)) {
  fit <- .eal_coef_fixture(distinct)
  fit$anchor <- fit$fit$p <- anchor
  fit$anchors <- anchors
  fit$selection$index <- match(anchor, anchors)
  fit$selection$audit <- data.frame(anchor = anchors, strict = TRUE)
  fit
}

.eal_intercept_opts <- function(B = 199L, level = .95) {
  CJQR:::.cjqr_eal_ci_options(.5, level, B, 27L, 1L, 256, TRUE)
}

test_that("intercept draws equal direct OLS plus in-bag residual quantiles", {
  for (distinct in c(FALSE, TRUE)) {
    fit <- .eal_intercept_fixture(distinct, anchor = .25,
      anchors = c(.75, .25, .5))
    original <- serialize(fit, NULL)
    out <- cjqr_eal_coef_ci(fit, B = 199L, seed = 37L, keep_draws = TRUE)
    designs <- if (distinct) fit$X else list(fit$X, fit$X)
    expect_identical(dim(out$draws$intercepts), c(3L, 2L, 199L))
    expect_identical(out$intercept$candidates, c(.75, .25, .5))
    expect_identical(out$intercept$index, 2L)
    expect_true(out$available)
    for (b in c(1L, 73L, 199L)) for (j in 1:2) {
      ii <- out$draws$indices[, b]
      Xb <- designs[[j]][ii, , drop = FALSE]
      b_ols <- qr.coef(qr(Xb), fit$Y[ii, j])
      residual <- fit$Y[ii, j] - drop(Xb %*% b_ols)
      expected <- unname(b_ols[1L]) + stats::quantile(residual,
        fit$anchors, names = FALSE, type = 8L)
      expect_equal(unname(out$draws$intercepts[, j, b]), expected,
        tolerance = 1e-12)
      ids <- seq_len(nrow(out$tables[[j]]))
      expect_equal(out$draws$coefficients[[j]][, b], b_ols[ids],
        tolerance = 1e-12)
    }
    for (j in 1:2) {
      b_ols <- qr.coef(qr(designs[[j]]), fit$Y[, j])
      residual <- fit$Y[, j] - drop(designs[[j]] %*% b_ols)
      expected <- unname(b_ols[1L]) + stats::quantile(residual,
        fit$anchors, names = FALSE, type = 8L)
      expect_equal(unname(out$intercept$reference_point_all_anchors[, j]),
        expected, tolerance = 1e-12)
      expect_equal(unname(out$reference[[j]][1L, 1L]), expected[2L],
        tolerance = 1e-12)
    }
    expect_identical(serialize(fit, NULL), original)
    expect_identical(out$bootstrap$joint_refits, 0L)
    expect_true(out$interpretation$includes_intercept_inference)
    expect_true(out$interpretation$intercept_anchor_selection_protected)
    expect_false(out$interpretation$conditional_selective_inference)
    expect_false(out$interpretation$includes_dependence_inference)
  }
})

test_that("adaptive intercept intervals use the complete-grid Bonferroni correction", {
  fit <- .eal_intercept_fixture()
  adaptive <- cjqr_eal_coef_ci(fit, B = 199L, seed = 52L, keep_draws = TRUE)
  fit$anchors <- .5
  fit$selection$index <- 1L
  fit$selection$audit <- data.frame(anchor = .5, strict = TRUE)
  fixed <- cjqr_eal_coef_ci(fit, B = 199L, seed = 52L, keep_draws = TRUE)
  expect_identical(adaptive$draws$indices, fixed$draws$indices)
  expect_identical(adaptive$draws$coefficients, fixed$draws$coefficients)
  expect_equal(adaptive$bootstrap$intercept_p_value_floor, 6 / 200)
  expect_equal(fixed$bootstrap$intercept_p_value_floor, 2 / 200)
  for (j in 1:2) {
    selected <- adaptive$draws$intercepts[2L, j, ]
    expect_identical(unname(selected), unname(fixed$draws$intercepts[1L, j, ]))
    ends <- stats::quantile(selected, c(.05 / 6, 1 - .05 / 6),
      names = FALSE, type = 8L)
    estimate <- adaptive$tables[[j]][1L, 1L]
    expect_equal(unname(adaptive$reference[[j]][1L, 2:3]), ends)
    expect_equal(unname(adaptive$tables[[j]][1L, 2:3]),
      c(min(ends[1L], estimate), max(ends[2L], estimate)))
    expect_equal(unname(adaptive$tables[[j]][1L, 4L]),
      min(1, 3 * fixed$tables[[j]][1L, 4L]))
    expect_lte(adaptive$tables[[j]][1L, 2L], fixed$tables[[j]][1L, 2L])
    expect_gte(adaptive$tables[[j]][1L, 3L], fixed$tables[[j]][1L, 3L])
    expect_identical(adaptive$tables[[j]][-1L, , drop = FALSE],
      fixed$tables[[j]][-1L, , drop = FALSE])
  }
})

test_that("selected intercept p-values invert the corrected hull confidence intervals", {
  fit <- .eal_intercept_fixture(anchor = .75)
  # Move one margin nearer zero to exercise a nontrivial rather than floor p-value.
  fit$Y[, 1L] <- fit$Y[, 1L] - .48
  fit$fit$beta[1L, 1L] <- .02
  fit$fit$beta[1L, 2L] <- -.02
  out <- cjqr_eal_coef_ci(fit, B = 499L, seed = 21L, keep_draws = TRUE)
  alphas <- seq(0, 1, length.out = 20001L)
  for (j in 1:2) {
    d <- out$draws$intercepts[3L, j, ]
    estimate <- out$tables[[j]][1L, 1L]
    positive <- estimate > 0
    endpoint <- stats::quantile(d,
      if (positive) alphas / 6 else 1 - alphas / 6,
      names = FALSE, type = 8L)
    rejected <- if (positive) endpoint > 0 else endpoint < 0
    raw <- if (any(rejected)) alphas[which(rejected)[1L]] else 1
    oracle <- min(1, max(raw, 6 / 500))
    expect_lte(abs(unname(out$tables[[j]][1L, 4L]) - oracle), 5.1e-5)
    for (alpha in c(.05, .1, .2, .4, .6, .8)) {
      ends <- stats::quantile(d, c(alpha / 6, 1 - alpha / 6),
        names = FALSE, type = 8L)
      hull <- c(min(ends[1L], estimate), max(ends[2L], estimate))
      excludes <- hull[1L] > 0 || hull[2L] < 0
      expect_identical(unname(out$tables[[j]][1L, 4L] < alpha), excludes)
    }
  }
})

test_that("failed unselected anchor fits remain in the inference family", {
  fit <- .eal_intercept_fixture()
  fit$selection$audit$strict <- c(FALSE, TRUE, FALSE)
  fit$candidates <- lapply(seq_along(fit$anchors), function(k)
    list(anchor = fit$anchors[k], fit = list(strict_ok = k == 2L)))
  out <- cjqr_eal_coef_ci(fit, B = 199L, seed = 63L)
  expect_identical(out$intercept$K, 3L)
  expect_identical(out$intercept$candidates, fit$anchors)
  expect_equal(out$bootstrap$intercept_p_value_floor, .03)
  expect_true(out$available)
})

test_that("missing or conflicting selection metadata cannot shrink the anchor family", {
  fit <- .eal_intercept_fixture()
  bad <- fit
  bad$anchors <- NULL
  expect_error(cjqr_eal_coef_ci(bad), "candidate anchors|anchor grid")
  bad <- fit
  bad$selection$audit <- NULL
  expect_error(cjqr_eal_coef_ci(bad), "audit|grid")
  bad <- fit
  bad$selection$audit <- data.frame(anchor = .5, strict = TRUE)
  expect_error(cjqr_eal_coef_ci(bad), "audit|grid")
  bad <- fit
  bad$anchors <- c(.25, .5, .5)
  expect_error(cjqr_eal_coef_ci(bad), "distinct|anchor")
  bad <- fit
  bad$anchor <- .25
  expect_error(cjqr_eal_coef_ci(bad), "disagrees|anchor")
  bad <- fit
  bad$fit$p <- .1
  expect_error(cjqr_eal_coef_ci(bad), "Selected anchor|anchor")
  bad <- fit
  bad$selection$index <- 1L
  expect_error(cjqr_eal_coef_ci(bad), "index|selected|Selected")
  bad <- fit
  bad$selection$index <- NULL
  expect_error(cjqr_eal_coef_ci(bad), "index|selected|Selected")
  expect_warning(cjqr_eal_coef_ci(fit, B = 100L), "anchor-adjusted.*resolution")
})

test_that("anchor-aligned intercept estimates and intervals are translation equivariant", {
  shift <- c(7, -11)
  for (distinct in c(FALSE, TRUE)) {
    fit <- .eal_intercept_fixture(distinct, anchor = .25)
    before <- cjqr_eal_coef_ci(fit, B = 199L, seed = 29L, keep_draws = TRUE)
    fit$Y <- sweep(fit$Y, 2L, shift, "+")
    if (distinct) for (j in 1:2) fit$fit$beta[[j]][1L] <-
      fit$fit$beta[[j]][1L] + shift[j] else
      fit$fit$beta[1L, ] <- fit$fit$beta[1L, ] + shift
    after <- cjqr_eal_coef_ci(fit, B = 199L, seed = 29L, keep_draws = TRUE)
    expect_identical(before$draws$indices, after$draws$indices)
    for (j in 1:2) {
      expect_equal(after$draws$intercepts[, j, ],
        before$draws$intercepts[, j, ] + shift[j], tolerance = 1e-10)
      expect_equal(after$tables[[j]][1L, 1:3],
        before$tables[[j]][1L, 1:3] + shift[j], tolerance = 1e-10)
      expect_equal(after$reference[[j]][1L, 1:3],
        before$reference[[j]][1L, 1:3] + shift[j], tolerance = 1e-10)
      expect_equal(after$tables[[j]][-1L, , drop = FALSE],
        before$tables[[j]][-1L, , drop = FALSE], tolerance = 1e-10)
    }
  }
})

test_that("one rank-deficient draw suppresses every intercept bound and test", {
  fit <- .eal_intercept_fixture(distinct = TRUE)
  n <- nrow(fit$Y)
  opts <- .eal_intercept_opts(B = 4L)
  idx <- matrix(rep(seq_len(n), opts$B), ncol = opts$B)
  idx[, 2L] <- 1L
  expect_warning(out <- CJQR:::.cjqr_eal_coef_compute(fit$X, fit$Y,
    fit$fit$beta, list(1:2, 1:3), opts, resamples = idx,
    anchor = .5, anchors = c(.25, .5, .75)),
    "No failed draws were discarded or replaced", fixed = TRUE)
  expect_false(out$available)
  expect_identical(out$bootstrap$successful, 3L)
  expect_identical(out$bootstrap$failed, 1L)
  expect_identical(out$bootstrap$replacement_draws, 0L)
  expect_identical(out$bootstrap$status$ok, c(TRUE, FALSE, TRUE, TRUE))
  expect_true(all(is.na(out$draws$intercepts[, , 2L])))
  expect_true(all(is.finite(out$draws$intercepts[, , -2L])))
  for (j in 1:2) {
    expect_true(all(is.na(out$tables[[j]][, -1L])))
    expect_true(all(is.na(out$reference[[j]][, -1L])))
    expect_true(all(is.finite(out$tables[[j]][, 1L])))
    expect_true(all(is.finite(out$reference[[j]][, 1L])))
  }
})
