test_that("auxiliary inference is an exact alias for the established procedure", {
  object <- .eal_coef_fixture(distinct = TRUE)
  frozen <- serialize(object, NULL)
  set.seed(341L)
  rng <- .Random.seed
  current <- summary(object, inference = "auxiliary", B = 120L, seed = 17L)
  legacy <- summary(object, inference = "reference", B = 120L, seed = 17L)
  expect_true(is.finite(current$coefficient_inference$bootstrap$elapsed_seconds))
  expect_true(is.finite(legacy$coefficient_inference$bootstrap$elapsed_seconds))
  current$coefficient_inference$bootstrap$elapsed_seconds <- NULL
  legacy$coefficient_inference$bootstrap$elapsed_seconds <- NULL
  expect_identical(current, legacy)
  expect_identical(serialize(object, NULL), frozen)
  expect_identical(.Random.seed, rng)
  expect_match(current$inference, "Auxiliary-bootstrap", fixed = TRUE)
  text <- paste(capture.output(print(current)), collapse = "\n")
  expect_match(text, "auxiliary-bootstrap", fixed = TRUE)
  expect_false(grepl("reference-assisted", text, ignore.case = TRUE))
  expect_identical(current$coefficient_inference$bootstrap$joint_refits, 0L)
})

test_that("default summaries do not silently enable auxiliary inference", {
  object <- .eal_coef_fixture()
  result <- summary(object)
  expect_null(result$coefficient_inference)
  expect_match(result$inference, "inference = 'auxiliary'", fixed = TRUE)
  expect_error(summary(object, inference = "invalid"), "arg")
})
