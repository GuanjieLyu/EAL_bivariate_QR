# Bounded-memory full-covariance Scott KDE. The computational change of
# coordinates evaluates the kernels; it never changes the displayed residuals.
.cjqr_residual_diagnostic_kde <- function(z, grid_size, probabilities) {
  covariance <- stats::cov(z)
  if (any(!is.finite(covariance)) || rcond(covariance) < 1e-10)
    stop("Normal-score residuals are singular or numerically near-collinear; a two-dimensional KDE cannot be computed reliably.", call. = FALSE)
  bandwidth <- covariance * nrow(z)^(-1 / 3)
  factor <- tryCatch(chol(bandwidth), error = function(e) NULL)
  if (is.null(factor) || any(!is.finite(factor)))
    stop("Normal-score residuals require a positive-definite KDE bandwidth.", call. = FALSE)
  inverse_factor <- solve(factor)
  padding <- 4.5 * max(sqrt(diag(bandwidth)))
  limit <- max(abs(z)) + padding
  if (!is.finite(limit) || limit <= 0)
    stop("Normal-score residuals have an unsupported numerical range.", call. = FALSE)
  axis <- seq(-limit, limit, length.out = grid_size)
  grid <- as.matrix(expand.grid(x = axis, y = axis))
  transformed_z <- z %*% inverse_factor
  transformed_grid <- grid %*% inverse_factor
  squared_z <- rowSums(transformed_z^2)
  if (any(!is.finite(c(transformed_z, transformed_grid, squared_z))))
    stop("Normal-score residuals have an unsupported numerical range for KDE evaluation.", call. = FALSE)
  values <- numeric(nrow(grid))
  # At most 128 x 2048 distances are materialised, independent of sample size.
  for (start in seq.int(1L, nrow(grid), by = 128L)) {
    gi <- seq.int(start, min(start + 127L, nrow(grid)))
    query <- transformed_grid[gi, , drop = FALSE]
    sums <- numeric(length(gi))
    squared_query <- rowSums(query^2)
    for (first in seq.int(1L, nrow(z), by = 2048L)) {
      zi <- seq.int(first, min(first + 2047L, nrow(z)))
      distances <- outer(squared_query, squared_z[zi], "+") -
        2 * tcrossprod(query, transformed_z[zi, , drop = FALSE])
      sums <- sums + rowSums(exp(-pmax(distances, 0) / 2))
    }
    values[gi] <- sums / (nrow(z) * 2 * pi * prod(diag(factor)))
  }
  spacing <- axis[2L] - axis[1L]
  cell_area <- spacing^2
  integrated_mass <- sum(values) * cell_area
  if (any(!is.finite(values)) || !is.finite(integrated_mass) ||
      abs(integrated_mass - 1) > .01)
    stop("The KDE grid does not integrate sufficiently close to one; increase `grid_size` (maximum 301) or inspect the residual spread and collinearity.", call. = FALSE)
  sorted <- sort(values, decreasing = TRUE)
  cumulative_mass <- cumsum(sorted) * cell_area
  if (max(probabilities) >= utils::tail(cumulative_mass, 1L))
    stop("The requested `contour_probs` exceed the probability mass covered by the KDE grid; request less extreme contour probabilities.", call. = FALSE)
  indices <- vapply(probabilities, function(p) which(cumulative_mass >= p)[1L], integer(1L))
  thresholds <- sorted[indices]
  if (any(!is.finite(thresholds)) || any(thresholds <= 0) || anyDuplicated(thresholds))
    stop("The KDE grid cannot distinguish the requested contour probabilities; increase `grid_size` or use fewer, more separated `contour_probs`.", call. = FALSE)
  enclosed_mass <- vapply(thresholds, function(v) sum(values[values >= v]) * cell_area, numeric(1L))
  list(x = axis, y = axis, density = matrix(values, grid_size, grid_size),
       bandwidth = bandwidth, covariance = covariance, grid_size = grid_size,
       integrated_mass = integrated_mass, mass_error = integrated_mass - 1,
       cell_area = cell_area, range = c(-limit, limit),
       maximum_kernel_cell_mass = max(values) * cell_area,
       grid_chunk_size = 128L, observation_chunk_size = 2048L,
       contours = data.frame(probability = probabilities, threshold = thresholds,
                             enclosed_grid_mass = enclosed_mass))
}

# Plotting is intentionally restricted to visual styling. Axis limits, residual
# values, probability contours and the two-histogram/one-contour layout are fixed.
plot.cjqr_residual_diagnostics <- function(x, breaks = 20L,
    contour_probs = seq(.1, .9, .1), grid_size = 121L, labels = NULL,
    points = TRUE, ...) {
  fail <- function(message) stop(message, call. = FALSE)
  integer_scalar <- function(value, lower, upper, name) {
    if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
        value != floor(value) || value < lower || value > upper)
      fail(sprintf("`%s` must be one integer between %d and %d.", name, lower, upper))
    as.integer(value)
  }
  breaks <- integer_scalar(breaks, 2L, 200L, "breaks")
  grid_size <- integer_scalar(grid_size, 41L, 301L, "grid_size")
  if (!is.numeric(contour_probs) || !length(contour_probs) || length(contour_probs) > 25L ||
      any(!is.finite(contour_probs)) || any(contour_probs <= 0 | contour_probs >= 1) ||
      any(diff(contour_probs) <= 0))
    fail("`contour_probs` must contain one to 25 strictly increasing, finite probabilities inside (0, 1).")
  if (!is.logical(points) || length(points) != 1L || is.na(points))
    fail("`points` must be TRUE or FALSE.")
  if (!inherits(x, "cjqr_residual_diagnostics") || !is.list(x))
    fail("`x` must be a `cjqr_residual_diagnostics` object.")
  u <- x$uniform
  z <- x$normal
  is_pair <- function(a) is.matrix(a) && is.numeric(a) && ncol(a) == 2L
  if (!is_pair(u) || !is_pair(z) || !identical(dim(u), dim(z)))
    fail("The diagnostic object must contain matching numeric two-column `uniform` and `normal` matrices.")
  n <- nrow(z)
  if (!is.numeric(x$n) || length(x$n) != 1L || !is.finite(x$n) || x$n != n)
    fail("The diagnostic object's `n` must equal the number of paired residual rows.")
  if (n < 3L) fail("At least three paired residual rows are needed for a two-dimensional KDE.")
  finite_counts <- list(uniform = colSums(is.finite(u)), normal = colSums(is.finite(z)),
                        complete_pairs = sum(rowSums(is.finite(u) & is.finite(z)) == 2L))
  if (any(!is.finite(u)) || any(!is.finite(z)))
    fail("Residual plots require finite values in every row; nonfinite rows are not silently dropped. Inspect the diagnostic object.")
  if (any(u < 0 | u > 1)) fail("Uniform residuals must lie in [0, 1].")
  if (is.null(labels)) labels <- x$labels
  if (!is.character(labels) || length(labels) != 2L || anyNA(labels) ||
      any(!nzchar(trimws(labels))))
    fail("`labels` must contain two nonempty character labels.")
  style <- list(col = "#007D87", point_col = "#55555533", reference_col = "#666666",
                cex = 1, cex.axis = 1, cex.lab = 1.05, cex.main = 1.05, lwd = 1.3)
  dots <- list(...)
  if (length(dots)) {
    dot_names <- names(dots)
    if (is.null(dot_names) || anyNA(dot_names) || any(!nzchar(dot_names)) ||
        anyDuplicated(dot_names) || any(!dot_names %in% names(style)))
      fail(paste0("Unsupported or unnamed plotting argument in `...`; allowed style arguments are: ",
                  paste(names(style), collapse = ", "), "."))
    style[dot_names] <- dots
  }
  for (name in c("col", "point_col", "reference_col")) {
    value <- style[[name]]
    valid <- (is.character(value) || is.numeric(value)) && length(value) == 1L && !is.na(value)
    if (valid) valid <- !inherits(try(grDevices::col2rgb(value, alpha = TRUE), silent = TRUE), "try-error")
    if (!valid) fail(sprintf("`%s` must specify one valid colour.", name))
  }
  for (name in c("cex", "cex.axis", "cex.lab", "cex.main", "lwd")) {
    value <- style[[name]]
    if (!is.numeric(value) || length(value) != 1L || !is.finite(value) || value <= 0 || value > 10)
      fail(sprintf("`%s` must be one positive finite number no greater than 10.", name))
  }
  histograms <- lapply(seq_len(2L), function(j)
    graphics::hist(u[, j], breaks = seq(0, 1, length.out = breaks + 1L),
                   plot = FALSE, right = TRUE, include.lowest = TRUE))
  histogram_totals <- vapply(histograms, function(h) sum(h$counts), integer(1L))
  if (any(histogram_totals != n)) fail("Histogram construction did not retain every paired residual.")
  kde <- .cjqr_residual_diagnostic_kde(z, grid_size, contour_probs)
  hist_limit <- max(1, unlist(lapply(histograms, `[[`, "density"))) * 1.06
  histogram_ylim <- c(0, max(pretty(c(0, hist_limit))))
  out <- list(n = n, labels = labels, uniform = u, normal = z,
              finite_counts = finite_counts, histograms = histograms,
              histogram_totals = histogram_totals, histogram_ylim = histogram_ylim,
              kde = kde, contours = kde$contours, normal_limits = kde$range,
              points_drawn = if (points) n else 0L,
              no_refits = TRUE, no_rank_transformation = TRUE)
  old <- graphics::par(no.readonly = TRUE)
  on.exit({
    graphics::par(old)
    # Restoring mfrow/mfcol resets text sizing and the current panel. Reset
    # margins in line units after the text-size correction, then the panel.
    graphics::par(cex = old$cex, mex = old$mex, mar = old$mar, oma = old$oma)
    graphics::par(mfg = old$mfg)
  }, add = TRUE)
  graphics::par(mfrow = c(1L, 3L), mar = c(4.1, 4.2, 2.7, 1.0), oma = c(0, 0, 0, 0),
                mgp = c(2.5, .8, 0), las = 1, cex = style$cex,
                cex.axis = style$cex.axis, cex.lab = style$cex.lab, cex.main = style$cex.main)
  for (j in seq_len(2L)) {
    graphics::plot(histograms[[j]], freq = FALSE, xlim = c(0, 1), ylim = histogram_ylim,
                   xaxs = "i", yaxs = "i", bty = "l",
                   col = grDevices::adjustcolor(style$col, alpha.f = .55), border = "white",
                   xlab = "Uniform residual", ylab = if (j == 1L) "Density" else "", main = labels[j])
    graphics::abline(h = 1, col = style$reference_col, lty = 2, lwd = style$lwd)
  }
  graphics::par(pty = "s")
  graphics::plot(NA_real_, NA_real_, xlim = kde$range, ylim = kde$range,
                 asp = 1, xaxs = "i", yaxs = "i", bty = "l",
                 xlab = labels[1L], ylab = labels[2L], main = "Normal-score residuals")
  if (points) graphics::points(z[, 1L], z[, 2L], pch = 16, cex = .45, col = style$point_col)
  graphics::contour(kde$x, kde$y, kde$density, levels = sort(kde$contours$threshold),
                    add = TRUE, drawlabels = FALSE, col = style$col, lwd = style$lwd)
  invisible(out)
}
