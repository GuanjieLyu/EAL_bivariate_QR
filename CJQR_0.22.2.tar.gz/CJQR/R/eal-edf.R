# Conditional OPG complexity of the fitted joint EAL model. This is not a
# sampling covariance, a test reference df, or an initializer-based EDF.

.cjqr_eal_joint_score <- function(object, engine = NULL) {
  .cjqr_eal_require_fit(object)
  X <- .cjqr_eal_designs(object$X)
  beta <- .cjqr_eal_betas(object$fit$beta)
  f <- object$fit
  if (is.null(engine)) engine <- .cjqr_eal_engine(object$copula)
  n <- nrow(X[[1L]])
  d <- vapply(X, ncol, integer(1L))
  if (!is.matrix(object$Y) || !identical(dim(object$Y), c(n, 2L)) ||
      any(!is.finite(object$Y)) || any(!is.finite(unlist(X))) ||
      any(!is.finite(unlist(beta))) || any(lengths(beta) != d) ||
      length(f$sigma) != 2L || any(!is.finite(f$sigma)) || any(f$sigma <= 0) ||
      !is.matrix(f$shape) || !identical(dim(f$shape), c(5L, 2L)) ||
      any(!is.finite(f$shape)))
    stop("The joint EAL score requires finite compatible model components.", call. = FALSE)
  z <- sweep(object$Y - .cjqr_eal_location(object$X, f$beta), 2L, f$sigma, "/")
  tt <- lapply(1:2, function(j)
    engine$density$eal_terms(z[, j], f$p, f$shape[, j], 3L, derivatives = TRUE))
  ref <- engine$ref_density
  cp <- switch(object$copula,
    gaussian = ref$eal_gaussian_terms(tt[[1L]], tt[[2L]], f$theta, TRUE),
    clayton = ref$eal_clayton_terms(tt[[1L]]$logF, tt[[2L]]$logF, f$theta),
    ref$eal_additional_copula_terms(tt[[1L]], tt[[2L]], f$theta,
      object$copula, f$df, TRUE))
  clayton <- identical(object$copula, "clayton")
  copula_e <- if (clayton)
    cbind(cp$dlu * tt[[1L]]$dlogF_de, cp$dlv * tt[[2L]]$dlogF_de) else cp$de
  combined <- cbind(tt[[1L]]$hz, tt[[2L]]$hz) + copula_e
  sb <- lapply(1:2, function(j) X[[j]] * (-combined[, j] / f$sigma[j]))
  ss <- -1 - combined * z
  sh <- lapply(1:2, function(j) tt[[j]]$dlogg_dshape + if (clayton)
    (if (j == 1L) cp$dlu else cp$dlv) * tt[[j]]$dlogF_dshape else cp$dshape[[j]])
  score <- cbind(sb[[1L]], sb[[2L]], ss, sh[[1L]], sh[[2L]],
    if (clayton) cp$dlogtheta else cp$ddelta)
  colnames(score) <- c(paste0("beta1:", colnames(X[[1L]]) %||% seq_len(d[1L])),
    paste0("beta2:", colnames(X[[2L]]) %||% seq_len(d[2L])),
    "log_sigma1", "log_sigma2", paste0("shape1:", 1:5),
    paste0("shape2:", 1:5), "theta_link")
  if (any(!is.finite(score))) stop("Nonfinite joint EAL score.", call. = FALSE)
  list(score = score, residual = z, terms = tt,
    beta_indices = list(seq_len(d[1L]), d[1L] + seq_len(d[2L])),
    nuisance_indices = sum(d) + seq_len(13L))
}

.cjqr_eal_opg_trace <- function(score, penalty, blocks,
                                condition_tolerance = 1e-10) {
  # Coordinate-diagonal scaling is used solely for the linear solve; it is a
  # congruence transformation, and changes neither EDF nor the penalty.
  bad <- function(reason, diagnostics = list())
    list(available = FALSE, reason = reason, edf = rep(NA_real_, length(blocks)),
      diagnostics = diagnostics)
  if (!is.matrix(score) || !is.numeric(score) || any(!is.finite(score)) ||
      !nrow(score) || !ncol(score) || !is.matrix(penalty) ||
      !identical(dim(penalty), rep(ncol(score), 2L)) || any(!is.finite(penalty)))
    return(bad("incompatible_or_nonfinite_information"))
  q <- ncol(score)
  if (any(vapply(blocks, function(b) !length(b) || anyNA(b) ||
      any(b != as.integer(b)) || any(b < 1L | b > q) || anyDuplicated(b) > 0L,
      logical(1L)))) return(bad("invalid_coefficient_blocks"))
  if (max(abs(penalty - t(penalty))) > 1e-10 * max(1, max(abs(penalty))))
    return(bad("nonsymmetric_penalty"))
  penalty <- (penalty + t(penalty)) / 2
  J <- crossprod(score)
  if (any(!is.finite(J))) return(bad("nonfinite_information"))
  diagonal <- diag(J) + diag(penalty)
  if (any(!is.finite(diagonal)) || any(diagonal <= 0))
    return(bad("unidentified_parameter_direction"))
  scale <- sqrt(diagonal)
  Jc <- J / outer(scale, scale)
  Pc <- penalty / outer(scale, scale)
  evJ <- eigen(Jc, symmetric = TRUE, only.values = TRUE)$values
  evP <- eigen(Pc, symmetric = TRUE, only.values = TRUE)$values
  tol <- 1e-10
  if (min(evJ) < -tol * max(1, max(evJ)) ||
      min(evP) < -tol * max(1, max(evP))) return(bad("information_or_penalty_not_PSD"))
  A <- Jc + Pc
  evA <- eigen(A, symmetric = TRUE, only.values = TRUE)$values
  ratio <- min(evA) / max(evA)
  diagnostics <- list(information_rank = sum(evJ > tol * max(evJ)),
    parameter_dimension = q, scaled_eigenvalue_ratio = ratio,
    condition_tolerance = condition_tolerance,
    penalty_rank = sum(evP > tol * max(1, max(evP))))
  if (!is.finite(ratio) || ratio <= condition_tolerance)
    return(bad("singular_or_ill_conditioned_penalized_information", diagnostics))
  R <- chol(A)
  F <- backsolve(R, forwardsolve(t(R), Jc))
  diagonal_F <- diag(F)
  edf <- vapply(blocks, function(b) sum(diagonal_F[b]), numeric(1L))
  if (any(!is.finite(edf)) || any(edf < -1e-7 | edf > lengths(blocks) + 1e-7))
    return(bad("inadmissible_block_trace", diagnostics))
  diagnostics$total_edf <- sum(diagonal_F)
  diagnostics$diagonal_edf <- diagonal_F
  diagnostics$nuisance_included <- TRUE
  list(available = TRUE, reason = "conditional_joint_OPG", edf = edf,
    diagnostics = diagnostics)
}

.cjqr_eal_smooth_edf <- function(object, include_total = FALSE) {
  .cjqr_eal_require_fit(object)
  blocks <- lapply(1:2, function(j) .cjqr_eal_smooth_blocks(object, j))
  empty <- lapply(blocks, function(b) stats::setNames(rep(NA_real_, length(b)),
    vapply(b, `[[`, character(1L), "label")))
  names(empty) <- object$responses
  metadata <- list(method = "conditional joint OPG trace",
    fixed = c("selected anchor", "EAL degree", "smoothing parameters", "copula df"),
    is_sampling_covariance = FALSE, is_test_reference_df = FALSE,
    numerical_regularization = FALSE)
  bad <- function(reason, diagnostics = list()) list(edf = empty, available = FALSE,
    reason = reason, diagnostics = c(diagnostics, metadata))
  if (!sum(lengths(blocks)) && !include_total) return(list(edf = empty, available = TRUE,
    reason = "no_smooth_components", diagnostics = metadata))
  f <- object$fit
  # Older serialized or presentation-only objects can omit density details.
  # A summary must remain printable: do not attempt abs(), log() or a link
  # transformation until every component required for the score is valid.
  if (!is.matrix(f$shape) || !is.numeric(f$shape) ||
      !identical(dim(f$shape), c(5L, 2L)) || any(!is.finite(f$shape)) ||
      !is.numeric(f$sigma) || length(f$sigma) != 2L ||
      any(!is.finite(f$sigma)) || any(f$sigma <= 0) ||
      !is.numeric(f$theta) || length(f$theta) != 1L || !is.finite(f$theta) ||
      !is.numeric(f$p) || length(f$p) != 1L || !is.finite(f$p) ||
      f$p <= 0 || f$p >= 1)
    return(bad("incomplete_or_invalid_density_parameters"))
  valid_theta <- tryCatch({
    .cjqr_validate_copula_theta(f$theta, object$copula)
    TRUE
  }, error = function(e) FALSE)
  if (!valid_theta) return(bad("incomplete_or_invalid_density_parameters"))
  cert <- f$improved_certificate
  boundary <- c(cert$dependence_boundary, cert$scale_boundary, cert$shape_boundary,
    f$dependence_boundary)
  if (any(boundary, na.rm = TRUE) || length(cert$boundary))
    return(bad("numerical_search_boundary"))
  # Independently check current stored parameters against the engine bounds.
  # This also protects older serialized objects with incomplete certificates.
  ctl <- object$control %||% list()
  sb <- ctl$shape_bound %||% 8
  dep_bound <- switch(object$copula,
    gaussian =, student_t = ctl$rho_bounds %||% c(-.995, .995),
    clayton = ctl$theta_bounds %||% c(.005, 30),
    frank = ctl$frank_bounds %||% c(-30, 30),
    gumbel = ctl$gumbel_bounds %||% c(1 + exp(-17), 30))
  delta <- .cjqr_delta_from_theta(f$theta, object$copula)
  delta_bound <- .cjqr_delta_from_theta(dep_bound, object$copula)
  if (any(abs(f$shape) >= sb - 1e-5) ||
      any(log(f$sigma) <= log(1e-5) + 1e-5 | log(f$sigma) >= log(1e3) - 1e-5) ||
      delta <= min(delta_bound) + 1e-5 || delta >= max(delta_bound) - 1e-5)
    return(bad("numerical_search_boundary"))
  sc <- tryCatch(.cjqr_eal_joint_score(object), error = function(e) e)
  if (inherits(sc, "error")) return(bad("joint_score_unavailable",
    list(message = conditionMessage(sc))))
  knot_tol <- f$knot_tolerance %||% 1e-7
  if (!is.numeric(knot_tol) || length(knot_tol) != 1L ||
      !is.finite(knot_tol) || knot_tol <= 0) knot_tol <- 1e-7
  cusp <- vapply(1:2, function(j) sum(abs(sc$residual[, j]) <= knot_tol &
    abs(sc$terms[[j]]$hz_left0 - sc$terms[[j]]$hz_right0) > 1e-7), integer(1L))
  if (any(cusp)) return(bad("nondifferentiable_fitted_residual",
    list(cusp_counts = cusp, cusp_tolerance = knot_tol)))
  d <- vapply(.cjqr_eal_designs(object$X), ncol, integer(1L))
  q <- ncol(sc$score)
  P <- matrix(0, q, q)
  if (!is.list(object$P) || length(object$P) != 2L)
    return(bad("fitted_penalties_unavailable"))
  for (j in 1:2) {
    pj <- object$P[[j]]
    if (!is.matrix(pj) || !identical(dim(pj), rep(unname(d[j]), 2L)))
      return(bad("fitted_penalties_incompatible"))
    P[sc$beta_indices[[j]], sc$beta_indices[[j]]] <- pj
  }
  global_blocks <- unlist(lapply(1:2, function(j) lapply(blocks[[j]], function(b)
    sc$beta_indices[[j]][b$ids])), recursive = FALSE)
  ans <- .cjqr_eal_opg_trace(sc$score, P, global_blocks)
  if (!ans$available) return(bad(ans$reason, ans$diagnostics))
  offset <- 0L
  for (j in 1:2) {
    ids <- offset + seq_along(empty[[j]])
    empty[[j]][] <- ans$edf[ids]
    offset <- offset + length(empty[[j]])
  }
  list(edf = empty, available = TRUE, reason = ans$reason,
    diagnostics = c(ans$diagnostics, list(cusp_counts = cusp,
      nuisance_dimension = length(sc$nuisance_indices)), metadata))
}
