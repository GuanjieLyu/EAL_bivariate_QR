`%||%` <- function(x, y) if (is.null(x)) y else x

.is_intercept_only_formula <- function(formula) {
  if (!inherits(formula, "formula") || length(formula) != 2L) return(FALSE)
  tt <- tryCatch(stats::terms(formula), error = function(e) NULL)
  !is.null(tt) &&
    identical(attr(tt, "term.labels"), character()) &&
    identical(as.integer(attr(tt, "intercept")), 1L)
}

.cjqr_formula_call_name <- function(x) {
  if (!is.call(x) || !length(x)) return("")
  head <- x[[1L]]
  if (is.symbol(head)) return(as.character(head))
  if (is.call(head) && length(head) == 3L &&
      as.character(head[[1L]]) %in% c("::", ":::")) {
    return(as.character(head[[3L]]))
  }
  ""
}

.cjqr_formula_contains_call <- function(x, targets) {
  if (!is.call(x)) return(FALSE)
  if (.cjqr_formula_call_name(x) %in% targets) return(TRUE)
  any(vapply(as.list(x)[-1L], .cjqr_formula_contains_call, logical(1L),
             targets = targets))
}
