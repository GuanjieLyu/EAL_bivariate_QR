# Internal installed-package loader. Cache only a serialized pristine factory,
# never a live engine: each caller receives fresh private environments, including
# optimizer caches and the multistart baseline-envelope registry.
.cjqr_eal_engine_cache <- new.env(parent = emptyenv())

.cjqr_eal_engine_sources <- function(directory) {
  files <- sort(list.files(directory, pattern = "[.]R$", full.names = TRUE))
  hashes <- tools::md5sum(files)
  names(hashes) <- basename(files)
  if (!length(hashes) || anyNA(hashes))
    stop("The installed CJQR EAL engine sources cannot be verified.", call. = FALSE)
  hashes
}

.cjqr_eal_engine <- function(copula = "gaussian", directory = NULL) {
  copula <- .cjqr_normalize_copula(copula)
  installed <- is.null(directory)
  if (is.null(directory)) directory <- system.file("eal-engine", package = "CJQR")
  if (!is.character(directory) || length(directory) != 1L ||
      is.na(directory) || !nzchar(directory) || !dir.exists(directory))
    stop("The installed CJQR EAL engine directory is unavailable.", call. = FALSE)
  directory <- normalizePath(directory, winslash = "/", mustWork = TRUE)
  # Explicit source directories are development/validation inputs: never cache
  # them. Installed templates are bounded to one current entry per family.
  if (installed) {
    signature <- list(directory = directory,
      package_version = as.character(getNamespaceVersion("CJQR")),
      R_version = paste(R.version$major, R.version$minor, sep = "."),
      source_md5 = .cjqr_eal_engine_sources(directory))
    previous <- .cjqr_eal_engine_cache[[copula]]
    if (!is.null(previous) && identical(previous$signature, signature))
      return(unserialize(previous$template))
  }
  loader <- new.env(parent = asNamespace("stats"))
  sys.source(file.path(directory, "load_engine.R"), envir = loader)
  engine <- loader$load_cjqr_eal_engine(directory, copula = copula)
  if (!installed) return(engine)
  # Detect a source replacement during construction rather than publishing a
  # template associated with a stale signature. Every hit rechecks source bytes.
  current <- .cjqr_eal_engine_sources(directory)
  if (!identical(signature$source_md5, current) ||
      !identical(unname(current[names(engine$manifest$source_md5)]),
        unname(engine$manifest$source_md5)))
    stop("CJQR EAL engine sources changed during loading; retry with a stable installation.", call. = FALSE)
  template <- serialize(engine, NULL, version = 3L)
  .cjqr_eal_engine_cache[[copula]] <- list(signature = signature, template = template)
  unserialize(template)
}
