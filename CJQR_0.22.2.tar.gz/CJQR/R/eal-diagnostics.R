# Extract diagnostics without refitting, prediction, simulation or RNG changes.
# Failed strict fits remain errors; inspecting them does not make them usable.
cjqr_fit_diagnostics <- function(object) {
  if (!inherits(object, "cjqr_eal") && !inherits(object, "cjqr_eal_convergence_error"))
    stop("`object` must be a cjqr_eal fit or a captured cjqr_eal_convergence_error.", call. = FALSE)
  candidates <- object$candidates
  if (!is.list(candidates) || !length(candidates) || !is.list(object$selection))
    stop("The object does not contain a complete EAL anchor audit.", call. = FALSE)
  scalar <- function(value) if (is.numeric(value) && length(value) == 1L) as.numeric(value) else NA_real_
  text_values <- function(value) {
    value <- as.character(unlist(value, use.names = FALSE))
    paste(unique(value[!is.na(value) & nzchar(value)]), collapse = "; ")
  }
  anchors <- do.call(rbind, lapply(candidates, function(candidate) {
    f <- candidate$fit
    data.frame(anchor = scalar(candidate$anchor), initialized = isTRUE(candidate$start$ok),
      certified = isTRUE(f$strict_ok), objective = scalar(f$objective),
      known_minimum = scalar(f$best_candidate_objective), kkt = scalar(f$stationarity),
      seconds = scalar(candidate$seconds),
      issue = text_values(c(f$error, f$tail_multistart$extension_error,
        if (!isTRUE(f$strict_ok)) f$message,
        f$improved_certificate$reason_codes)),
      stringsAsFactors = FALSE)
  }))
  rows <- list()
  for (candidate in candidates) {
    starts <- candidate$start$qgam
    for (j in seq_along(starts)) {
      s <- starts[[j]]
      errors <- lapply(s$attempts, `[[`, "error")
      rows[[length(rows) + 1L]] <- data.frame(anchor = scalar(candidate$anchor),
        margin = j, ok = isTRUE(s$ok), strategy = text_values(s$strategy),
        retries = scalar(s$retries), warning = text_values(s$warnings),
        error = text_values(errors), stringsAsFactors = FALSE)
    }
  }
  initializers <- if (length(rows)) do.call(rbind, rows) else
    data.frame(anchor = numeric(), margin = integer(), ok = logical(),
      strategy = character(), retries = numeric(), warning = character(), error = character())
  accepted <- inherits(object, "cjqr_eal") && isTRUE(object$selection$strict_ok) &&
    isTRUE(object$fit$strict_ok)
  f <- if (accepted) object$fit else list()
  out <- list(accepted = accepted, status = if (accepted) "certified" else "not_certified",
    copula = object$copula %||% NA_character_, df = object$df,
    n = if (accepted) nrow(.cjqr_eal_designs(object$X)[[1L]]) else scalar(object$n),
    selected_anchor = if (accepted) scalar(object$anchor) else NA_real_,
    unresolved_anchor_gap = scalar(object$selection$unresolved_gap),
    anchors = anchors, initializers = initializers,
    boundary = list(dependence = f$improved_certificate$dependence_boundary %||% NA,
      scale = f$improved_certificate$scale_boundary %||% NA,
      shape = f$improved_certificate$shape_boundary %||% NA),
    certificate = f$improved_certificate, runtime = object$runtime,
    seed = object$seed, elapsed_seconds = scalar(object$elapsed_seconds),
    note = "Numerical checks are not a global-optimum or statistical-validity guarantee; failed fits remain unusable.")
  class(out) <- "cjqr_fit_diagnostics"
  out
}

print.cjqr_fit_diagnostics <- function(x, digits = 4L, ...) {
  if (length(list(...))) stop("Unsupported diagnostic printing argument(s).", call. = FALSE)
  digits <- .cjqr_eal_ci_integer(digits, "digits", 1L)
  if (digits > 22L) stop("`digits` must not exceed 22.", call. = FALSE)
  cat("CJQR EAL fitting diagnostics\n")
  cat("Status:", x$status, " | Copula:", x$copula, " | Observations:", x$n, "\n")
  if (!is.null(x$df)) cat("Fixed Student-t copula df:", x$df, "\n")
  if (x$accepted) cat("Selected anchor:", x$selected_anchor, "\n")
  cat("Anchor audit:\n")
  print(x$anchors, row.names = FALSE, digits = digits)
  problems <- x$initializers[!x$initializers$ok |
    (is.finite(x$initializers$retries) & x$initializers$retries > 0) |
    nzchar(x$initializers$warning) |
    nzchar(x$initializers$error), , drop = FALSE]
  if (nrow(problems)) {
    cat("Initializer warnings/retries/failures (full history is in $initializers):\n")
    print(problems, row.names = FALSE, digits = digits)
  }
  if (any(unlist(x$boundary), na.rm = TRUE))
    cat("Numerical search boundary reached:",
      paste(names(x$boundary)[vapply(x$boundary, isTRUE, logical(1))], collapse = ", "), "\n")
  if (!x$accepted)
    cat("Do not use this object for estimates or CIs. Inspect failed initializers and unresolved candidates before changing numerical settings.\n")
  cat(x$note, "\n")
  invisible(x)
}
