# Self-contained tutorial data with independent synthetic paired observations.
cjqr_example_data <- function(n = 200L, seed = 1L) {
  n <- .cjqr_eal_ci_integer(n, "n", 30L)
  if (n > 1000000L)
    stop("The example-data helper is limited to at most 1000000 rows.", call. = FALSE)
  seed <- .cjqr_eal_seed(seed)
  .cjqr_eal_with_seed(seed, {
    x <- stats::runif(n, -1, 1)
    z <- stats::rbinom(n, 1L, .5)
    rho <- sin(pi * .5 / 2)
    g1 <- stats::rnorm(n)
    g2 <- rho * g1 + sqrt(1 - rho^2) * stats::rnorm(n)
    # Use the smaller normal tail so extreme positive scores cannot round the
    # uniform probability to 1 before applying the Student-t quantile.
    normal_to_t5 <- function(g) {
      ans <- numeric(length(g))
      lo <- g <= 0
      ans[lo] <- stats::qt(stats::pnorm(g[lo]), df = 5)
      ans[!lo] <- stats::qt(stats::pnorm(g[!lo], lower.tail = FALSE),
                            df = 5, lower.tail = FALSE)
      ans
    }
    y1 <- .3 + .6 * z + 1.1 * sin(pi * x) + .8 * sqrt(3 / 5) * normal_to_t5(g1)
    y2 <- -.2 - .5 * z + cos(pi * x) + .9 * sqrt(3 / 5) * normal_to_t5(g2)
    data.frame(y1 = y1, y2 = y2, x = x, z = z)
  })
}

.cjqr_eal_ci_frame_array <- function(a, dims, name, finite = TRUE) {
  if (!is.numeric(a) || !identical(dim(a), dims))
    stop(name, " must be a numeric array with dimensions matching fit.", call. = FALSE)
  if (finite && any(!is.finite(a)))
    stop(name, " must contain finite values when the intervals are available.", call. = FALSE)
  invisible(a)
}

# Margin-specific probability grids may differ in length: validate and flatten
# their matrices directly, without padding the unrequested quantiles.
.cjqr_eal_ci_frame_margins <- function(a, dims, responses, probs, labels,
                                       name, finite = TRUE) {
  if (!is.list(a) || is.data.frame(a) || !is.null(dim(a)) || length(a) != 2L)
    stop(name, " must contain exactly two marginal matrices.", call. = FALSE)
  if (!is.null(names(a)) && !identical(names(a), responses))
    stop(name, " response labels must match fit in the same order.", call. = FALSE)
  for (j in 1:2) {
    current <- a[[j]]
    if (!is.matrix(current) || !is.numeric(current) ||
        !identical(dim(current), dims[[j]]))
      stop(name, " marginal matrix dimensions must match fit and probs.", call. = FALSE)
    if (finite && any(!is.finite(current)))
      stop(name, " must contain finite values when the intervals are available.", call. = FALSE)
    rn <- rownames(current)
    if (!is.null(rn) && !identical(rn, labels))
      stop(name, " row labels must match the paired prediction rows.", call. = FALSE)
    cn <- colnames(current)
    if (!is.null(cn)) {
      cp <- suppressWarnings(as.numeric(cn))
      if (anyNA(cp) || !identical(cp, probs[[j]]))
        stop(name, " probability labels must match probs in the same order.", call. = FALSE)
    }
  }
  invisible(a)
}

.cjqr_eal_ci_frame_list <- function(x, row.names, optional, include_reference) {
  if (is.data.frame(x$fit) || !is.null(dim(x$fit)) || length(x$fit) != 2L ||
      !all(vapply(x$fit, function(a) is.matrix(a) && is.numeric(a), logical(1L))))
    stop("fit must contain exactly two numeric marginal prediction matrices.", call. = FALSE)
  response <- names(x$fit)
  if (is.null(response)) response <- names(x$probs)
  if (is.null(response)) response <- paste0("margin", 1:2)
  if (!is.character(response) || length(response) != 2L || anyNA(response) ||
      any(!nzchar(response)) || anyDuplicated(response))
    stop("Response labels must be distinct, nonmissing and nonempty.", call. = FALSE)
  spec <- .cjqr_eal_probability_spec(x$probs, response)
  if (spec$shared)
    stop("List-valued fit requires two marginal probability vectors in probs.", call. = FALSE)
  probs <- spec$probs
  np <- lengths(probs)
  m <- nrow(x$fit[[1L]])
  dims <- lapply(1:2, function(j) c(m, np[[j]]))
  labels <- rownames(x$fit[[1L]])
  if (!identical(labels, rownames(x$fit[[2L]])))
    stop("Marginal fit matrices must have identical paired row labels.", call. = FALSE)
  .cjqr_eal_ci_frame_margins(x$fit, dims, response, probs, labels, "fit")
  if (!is.logical(x$available) || length(x$available) != 1L || is.na(x$available))
    stop("The CI object must have a single logical available flag.", call. = FALSE)
  if (!is.numeric(x$level) || length(x$level) != 1L || !is.finite(x$level) ||
      x$level <= 0 || x$level >= 1)
    stop("The CI object must have a confidence level strictly between 0 and 1.", call. = FALSE)
  for (nm in c("lower", "upper")) {
    .cjqr_eal_ci_frame_margins(x[[nm]], dims, response, probs, labels, nm,
                               finite = x$available)
    if (!x$available && !all(vapply(x[[nm]], function(a) all(is.na(a)), logical(1L))))
      stop("Unavailable intervals must have all-NA bounds; partial successful bounds are not reported.", call. = FALSE)
  }
  if (x$available && any(vapply(1:2, function(j)
      any(x$lower[[j]] > x$fit[[j]] | x$upper[[j]] < x$fit[[j]]), logical(1L))))
    stop("The bounds do not contain the unchanged joint estimates.", call. = FALSE)
  if (include_reference) {
    if (!is.list(x$reference)) stop("The CI object has no reference results.", call. = FALSE)
    .cjqr_eal_ci_frame_margins(x$reference$fit, dims, response, probs, labels,
                               "reference$fit")
    for (nm in c("lower", "upper")) {
      .cjqr_eal_ci_frame_margins(x$reference[[nm]], dims, response, probs, labels,
                                 paste0("reference$", nm), finite = x$available)
      if (!x$available && !all(vapply(x$reference[[nm]], function(a) all(is.na(a)), logical(1L))))
        stop("Unavailable auxiliary intervals must have all-NA bounds.", call. = FALSE)
    }
    if (x$available && any(vapply(1:2, function(j)
        any(x$reference$lower[[j]] > x$reference$upper[[j]] |
            x$lower[[j]] > x$reference$lower[[j]] |
            x$upper[[j]] < x$reference$upper[[j]]), logical(1L))))
      stop("Auxiliary bounds are invalid or are not contained in the reported joint intervals.", call. = FALSE)
  }
  # Preserve the shared-grid table order: observation, response, probability.
  i <- rep(seq_len(m), each = sum(np))
  j <- rep(rep(1:2, times = np), times = m)
  k <- rep(unlist(lapply(np, seq_len), use.names = FALSE), times = m)
  extract <- function(a) {
    out <- numeric(length(i))
    for (margin in 1:2) {
      at <- which(j == margin)
      out[at] <- a[[margin]][cbind(i[at], k[at])]
    }
    out
  }
  ans <- data.frame(row_index = i, response = response[j],
    prob = rep(unlist(probs, use.names = FALSE), times = m),
    estimate = extract(x$fit), lower = extract(x$lower), upper = extract(x$upper),
    available = rep(x$available, length(i)), row.names = row.names,
    check.names = !optional, stringsAsFactors = FALSE)
  if (!is.null(labels)) ans$row_label <- labels[i]
  if (include_reference) {
    ans$reference_estimate <- extract(x$reference$fit)
    ans$reference_lower <- extract(x$reference$lower)
    ans$reference_upper <- extract(x$reference$upper)
  }
  attr(ans, "cjqr_interval") <- list(method = x$method, level = x$level,
    available = x$available, error = x$error,
    bootstrap = x$bootstrap[c("requested", "attempted", "successful", "failed")],
    pointwise = TRUE, native_joint_standard_errors = FALSE,
    assumptions = x$assumptions)
  ans
}

as.data.frame.cjqr_eal_ci <- function(x, row.names = NULL, optional = FALSE,
                                      include_reference = FALSE, ...) {
  dots <- list(...)
  if (length(dots)) stop("Unsupported arguments to as.data.frame.cjqr_eal_ci().", call. = FALSE)
  if (!inherits(x, "cjqr_eal_ci")) stop("x must be a cjqr_eal_ci object.", call. = FALSE)
  if (!is.logical(optional) || length(optional) != 1L || is.na(optional))
    stop("optional must be TRUE or FALSE.", call. = FALSE)
  if (!is.logical(include_reference) || length(include_reference) != 1L || is.na(include_reference))
    stop("include_reference must be TRUE or FALSE.", call. = FALSE)
  if (is.list(x$fit))
    return(.cjqr_eal_ci_frame_list(x, row.names, optional, include_reference))
  dims <- dim(x$fit)
  if (!is.numeric(x$fit) || length(dims) != 3L || dims[2L] != 2L || dims[3L] < 1L ||
      any(!is.finite(x$fit)))
    stop("fit must be a finite prediction-row-by-2-by-probability numeric array.", call. = FALSE)
  probs <- .cjqr_eal_probs(x$probs)
  if (length(probs) != dims[3L]) stop("probs does not match the probability dimension of fit.", call. = FALSE)
  if (!is.logical(x$available) || length(x$available) != 1L || is.na(x$available))
    stop("The CI object must have a single logical available flag.", call. = FALSE)
  if (!is.numeric(x$level) || length(x$level) != 1L || !is.finite(x$level) ||
      x$level <= 0 || x$level >= 1)
    stop("The CI object must have a confidence level strictly between 0 and 1.", call. = FALSE)
  for (nm in c("lower", "upper")) {
    .cjqr_eal_ci_frame_array(x[[nm]], dims, nm, finite = x$available)
    if (!x$available && !all(is.na(x[[nm]])))
      stop("Unavailable intervals must have all-NA bounds; partial successful bounds are not reported.", call. = FALSE)
  }
  if (x$available && any(x$lower > x$fit | x$upper < x$fit))
    stop("The bounds do not contain the unchanged joint estimates.", call. = FALSE)
  response <- dimnames(x$fit)[[2L]]
  if (is.null(response)) response <- paste0("margin", 1:2)
  if (anyNA(response) || any(!nzchar(response)) || anyDuplicated(response))
    stop("Response labels must be distinct, nonmissing and nonempty.", call. = FALSE)
  m <- dims[1L]
  np <- dims[3L]
  # Order rows for a readable report: observation, response, probability.
  i <- rep(seq_len(m), each = 2L * np)
  j <- rep(rep(1:2, each = np), times = m)
  k <- rep(seq_len(np), times = 2L * m)
  at <- cbind(i, j, k)
  ans <- data.frame(row_index = i, response = response[j], prob = probs[k],
    estimate = x$fit[at], lower = x$lower[at], upper = x$upper[at],
    available = rep(x$available, length(i)), row.names = row.names,
    check.names = !optional, stringsAsFactors = FALSE)
  labels <- dimnames(x$fit)[[1L]]
  if (!is.null(labels)) ans$row_label <- labels[i]
  if (include_reference) {
    if (!is.list(x$reference)) stop("The CI object has no reference results.", call. = FALSE)
    .cjqr_eal_ci_frame_array(x$reference$fit, dims, "reference$fit")
    for (nm in c("lower", "upper")) {
      .cjqr_eal_ci_frame_array(x$reference[[nm]], dims, paste0("reference$", nm),
                               finite = x$available)
      if (!x$available && !all(is.na(x$reference[[nm]])))
        stop("Unavailable auxiliary intervals must have all-NA bounds.", call. = FALSE)
    }
    if (x$available && any(x$reference$lower > x$reference$upper |
        x$lower > x$reference$lower | x$upper < x$reference$upper))
      stop("Auxiliary bounds are invalid or are not contained in the reported joint intervals.", call. = FALSE)
    ans$reference_estimate <- x$reference$fit[at]
    ans$reference_lower <- x$reference$lower[at]
    ans$reference_upper <- x$reference$upper[at]
  }
  attr(ans, "cjqr_interval") <- list(method = x$method, level = x$level,
    available = x$available, error = x$error,
    bootstrap = x$bootstrap[c("requested", "attempted", "successful", "failed")],
    pointwise = TRUE, native_joint_standard_errors = FALSE,
    assumptions = x$assumptions)
  ans
}
