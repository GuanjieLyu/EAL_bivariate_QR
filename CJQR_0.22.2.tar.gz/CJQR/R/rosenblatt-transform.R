# Stable ordered Rosenblatt transforms for the fitted EAL joint distribution.
# Both marginal log tails are needed: an ordinary CDF can round to zero or
# one while its normal-score residual remains entirely representable.
.cjqr_rosenblatt_log_softplus <- function(x) {
  out <- x
  low <- x < -36
  high <- x > 36
  mid <- !low & !high
  out[high] <- log(x[high])
  out[mid] <- log(log1p(exp(x[mid])))
  out
}

.cjqr_rosenblatt_softplus <- function(x) pmax(x, 0) + log1p(exp(-abs(x)))

# log{1-exp(-exp(x))}, including exp(x) below the floating-point range.
.cjqr_rosenblatt_log_failure <- function(x) {
  out <- x
  active <- x >= -36
  out[active] <- log(-expm1(-exp(x[active])))
  out
}

# log{exp(exp(x))-1}; its argument is represented on the logarithmic scale.
.cjqr_rosenblatt_log_expm1_exp <- function(x) {
  out <- x
  active <- x >= -36
  q <- exp(x[active])
  out[active] <- q + log(-expm1(-q))
  out
}

# log(-log(u)) from both marginal tails. The upper-tail branch also handles
# log(u) == -0 when 1-u is smaller than the double-precision number range.
.cjqr_rosenblatt_log_neglog <- function(lf, ls) {
  out <- log(-lf)
  upper <- lf > -log(2)
  tiny <- upper & ls < -36
  regular <- upper & !tiny
  out[tiny] <- ls[tiny]
  out[regular] <- log(-log1p(-exp(ls[regular])))
  out
}

.cjqr_rosenblatt_quantile <- function(lf, ls, df = NULL) {
  lower <- lf <= -log(2)
  out <- lf
  if (is.null(df)) {
    out[lower] <- stats::qnorm(lf[lower], log.p = TRUE)
    out[!lower] <- stats::qnorm(ls[!lower], lower.tail = FALSE, log.p = TRUE)
  } else {
    out[lower] <- stats::qt(lf[lower], df = df, log.p = TRUE)
    out[!lower] <- stats::qt(ls[!lower], df = df, lower.tail = FALSE, log.p = TRUE)
  }
  if (any(!is.finite(out)))
    stop("Rosenblatt transform exceeds the representable conditional quantile range; no tail clipping was applied.", call. = FALSE)
  out
}

.cjqr_rosenblatt_h_logs <- function(lu, su, lv, sv, theta, family, df) {
  # u is the conditioning margin and v the conditional response margin.
  independent <- switch(family, gaussian = theta == 0, clayton = theta == 0,
    frank = theta == 0, gumbel = theta == 1, student_t = rep(FALSE, length(theta)))
  lf <- lv; ls <- sv
  active <- which(!independent)
  if (!length(active)) return(list(logF = lf, logS = ls))
  a <- lu[active]; b <- su[active]; c <- lv[active]; d <- sv[active]
  th <- theta[active]
  if (family %in% c("gaussian", "student_t")) {
    nu <- if (family == "student_t") df else NULL
    x <- .cjqr_rosenblatt_quantile(a, b, nu)
    y <- .cjqr_rosenblatt_quantile(c, d, nu)
    one_minus_square <- (1-th)*(1+th)
    if (family == "gaussian") {
      conditional <- (y-th*x)/sqrt(one_minus_square)
      ff <- stats::pnorm(conditional, log.p = TRUE)
      ss <- stats::pnorm(conditional, lower.tail = FALSE, log.p = TRUE)
    } else {
      # Scale by the conditioning magnitude before squaring: t quantiles may
      # exceed sqrt(double.xmax) even though the conditional t score is finite.
      scale <- pmax(sqrt(df), abs(x))
      denominator <- sqrt((sqrt(df)/scale)^2 + (x/scale)^2) *
        sqrt(one_minus_square/(df+1))
      conditional <- (y/scale-th*(x/scale))/denominator
      ff <- stats::pt(conditional, df = df+1, log.p = TRUE)
      ss <- stats::pt(conditional, df = df+1, lower.tail = FALSE, log.p = TRUE)
    }
  } else if (family == "clayton") {
    # h(v|u) = (1 + u^theta*(v^(-theta)-1))^(-(1+theta)/theta).
    # This difference form avoids cancellation when u and v are both tiny.
    log_q <- log(th) + .cjqr_rosenblatt_log_neglog(c, d)
    log_A <- th*(a-c) + .cjqr_rosenblatt_log_failure(log_q)
    log_hazard <- log1p(th)-log(th) + .cjqr_rosenblatt_log_softplus(log_A)
    ff <- -exp(log_hazard)
    ss <- .cjqr_rosenblatt_log_failure(log_hazard)
  } else if (family == "gumbel") {
    # With x=-log(u), y=-log(v), t=(x^theta+y^theta)^(1/theta),
    # -log h = (t-x) + (theta-1)*log(t/x), evaluated without t-x cancellation.
    log_x <- .cjqr_rosenblatt_log_neglog(a, b)
    log_y <- .cjqr_rosenblatt_log_neglog(c, d)
    log_ratio <- th*(log_y-log_x)
    log_log_t_over_x <- .cjqr_rosenblatt_log_softplus(log_ratio)-log(th)
    first <- log_x + .cjqr_rosenblatt_log_expm1_exp(log_log_t_over_x)
    second <- log(th-1) + log_log_t_over_x
    log_hazard <- .cjqr_logspace_add(first, second)
    ff <- -exp(log_hazard)
    ss <- .cjqr_rosenblatt_log_failure(log_hazard)
  } else {
    # Positive Frank conditional odds:
    # exp{theta(v-u)} * (1-exp(-theta*v))/(1-exp(-theta*(1-v))).
    # Negative Frank is the target-reflection 1-h_positive(1-v|u).
    negative <- th < 0
    temp <- c[negative]; c[negative] <- d[negative]; d[negative] <- temp
    magnitude <- abs(th)
    v_minus_u <- exp(c)-exp(a)
    both_upper <- a > -log(2) & c > -log(2)
    v_minus_u[both_upper] <- exp(b[both_upper])-exp(d[both_upper])
    odds <- magnitude*v_minus_u +
      .cjqr_rosenblatt_log_failure(log(magnitude)+c) -
      .cjqr_rosenblatt_log_failure(log(magnitude)+d)
    ff <- -.cjqr_rosenblatt_softplus(-odds)
    ss <- -.cjqr_rosenblatt_softplus(odds)
    temp <- ff[negative]; ff[negative] <- ss[negative]; ss[negative] <- temp
  }
  if (any(!is.finite(c(ff, ss))) || any(ff > 0 | ss > 0))
    stop("Rosenblatt transform exceeds the representable conditional log-tail range; no tail clipping was applied.", call. = FALSE)
  lf[active] <- ff; ls[active] <- ss
  list(logF = lf, logS = ls)
}

.cjqr_rosenblatt_transform <- function(logF, logS, theta, family,
                                      df = NULL, order = c(1L, 2L)) {
  valid <- function(x) is.matrix(x) && is.numeric(x) && !is.complex(x) && ncol(x) == 2L &&
    nrow(x) >= 1L && all(is.finite(x)) && all(x <= 0)
  if (!valid(logF) || !valid(logS) || !identical(dim(logF), dim(logS)))
    stop("Rosenblatt inputs must be matching finite n-by-two nonpositive log-tail matrices.", call. = FALSE)
  if (any(abs(exp(logF)+exp(logS)-1) > 1e-10))
    stop("Rosenblatt marginal log-CDF and log-survival inputs are not complementary.", call. = FALSE)
  if (!is.numeric(order) || is.complex(order) || !is.null(dim(order)) ||
      length(order) != 2L || anyNA(order) ||
      !setequal(order, c(1,2)))
    stop("`order` must be a permutation of c(1, 2).", call. = FALSE)
  order <- as.integer(order)
  family <- .cjqr_normalize_copula(family)
  if (!is.null(df) && (is.complex(df) || !is.null(dim(df))))
    stop("Rosenblatt `df` must be one real scalar, or NULL for non-Student copulas.", call. = FALSE)
  df <- .cjqr_validate_copula_df(family, df)
  n <- nrow(logF)
  if (!is.numeric(theta) || is.complex(theta) || !is.null(dim(theta)) ||
      !length(theta) %in% c(1L,n) || any(!is.finite(theta)))
    stop("Rosenblatt theta must be finite, with length one or one per observation.", call. = FALSE)
  .cjqr_validate_copula_theta(theta, family)
  theta <- rep(theta, length.out = n)
  lf <- logF[,order,drop=FALSE]; ls <- logS[,order,drop=FALSE]
  h <- .cjqr_rosenblatt_h_logs(lf[,1L], ls[,1L], lf[,2L], ls[,2L], theta, family, df)
  lf[,2L] <- h$logF; ls[,2L] <- h$logS
  normal <- .cjqr_rosenblatt_quantile(lf, ls)
  if (any(abs(exp(lf)+exp(ls)-1) > 1e-10))
    stop("Rosenblatt conditional log-tail consistency check failed.", call. = FALSE)
  list(uniform = exp(lf), normal = normal, logF = lf, logS = ls)
}
