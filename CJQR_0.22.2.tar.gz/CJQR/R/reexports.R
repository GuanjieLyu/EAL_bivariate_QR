#' Re-export selected mgcv smooth constructors
#'
#' These functions are re-exported so structured additive formulas can use
#' `s()`, `te()`, `ti()`, and `t2()` after attaching CJQR.
#' @name mgcv-smooths
#' @aliases s te ti t2
#' @export s te ti t2
NULL
