# Coefficient-level extension of the auxiliary-bootstrap interval construction.
# No joint-model covariance is computed, and no EAL likelihood is refitted.

.cjqr_eal_coef_quantiles <- function(draws) {
  # Inversion evaluates the same sample at many probabilities. Sorting once
  # avoids repeated partial sorts while retaining type-8 interpolation. The
  # older-R fallback retains its version-specific endpoint rounding exactly.
  if (getRversion() < "4.5.0" || !length(draws) || anyNA(draws)) return(function(probs)
    stats::quantile(draws, probs = probs, type = 8L, names = FALSE))
  values <- unname(sort(draws))
  n <- length(values)
  fuzz <- 4 * .Machine$double.eps
  function(probs) {
    position <- 1 / 3 + probs * (n + 1 - 1 / 3 - 1 / 3)
    left <- floor(position * (1 + fuzz))
    weight <- position - left
    weight[abs(weight) < fuzz] <- 0
    lower <- values[pmax(1, pmin(n, left))]
    upper <- values[pmax(1, pmin(n, left + 1))]
    result <- lower
    result[weight == 1] <- upper[weight == 1]
    interpolate <- weight > 0 & weight < 1 & lower != upper
    result[interpolate] <- ((1 - weight) * lower + weight * upper)[interpolate]
    result
  }
}

.cjqr_eal_coef_tail_p <- function(draws, joint, null = 0, quantiles = NULL) {
  if (joint == null) return(1)
  if (is.null(quantiles)) quantiles <- .cjqr_eal_coef_quantiles(draws)
  positive <- joint > null
  outside <- function(alpha) {
    endpoint <- quantiles(if (positive) alpha / 2 else 1 - alpha / 2)
    if (positive) endpoint > null else endpoint < null
  }
  if (!outside(1)) return(1)
  lo <- 0; hi <- 1
  for (i in seq_len(48L)) {
    mid <- (lo + hi) / 2
    if (outside(mid)) hi <- mid else lo <- mid
  }
  # A conservative numerical-resolution floor, NOT an exact Monte Carlo test
  # or a finite-sample validity correction for the percentile bootstrap.
  min(1, max(hi, 2 / (length(draws) + 1)))
}

.cjqr_eal_coef_reference <- function(X, Y, indices, keep_qr = FALSE) {
  if (is.matrix(X)) {
    xb <- X[indices, , drop = FALSE]
    Q <- qr(xb)
    if (Q$rank != ncol(X)) stop("rank_deficient_subject_resample", call. = FALSE)
    beta <- qr.coef(Q, Y[indices, , drop = FALSE])
    out <- list(beta[, 1L], beta[, 2L])
    if (keep_qr) cache <- list(designs = list(xb), decompositions = list(Q))
  } else {
    cache <- if (keep_qr) list(designs = vector("list", 2L),
      decompositions = vector("list", 2L)) else NULL
    if (keep_qr) names(cache$designs) <- names(cache$decompositions) <- names(X)
    out <- vector("list", 2L)
    for (j in seq_len(2L)) {
      xb <- X[[j]][indices, , drop = FALSE]
      Q <- qr(xb)
      if (Q$rank != ncol(X[[j]]))
        stop("rank_deficient_subject_resample_margin_", j, call. = FALSE)
      if (keep_qr) {
        cache$designs[[j]] <- xb
        cache$decompositions[[j]] <- Q
      }
      out[[j]] <- qr.coef(Q, Y[indices, j])
    }
  }
  if (any(!is.finite(unlist(out)))) stop("Nonfinite auxiliary coefficients.", call. = FALSE)
  if (keep_qr) return(list(beta = out, qr_cache = cache))
  out
}

.cjqr_eal_coef_anchor_spec <- function(anchor, anchors) {
  if (is.null(anchor) && is.null(anchors)) return(NULL)
  anchors <- .cjqr_eal_probs(anchors)
  if (length(anchors) > 100L || !is.numeric(anchor) || length(anchor) != 1L ||
      !is.finite(anchor) || sum(abs(anchors - anchor) < 1e-12) != 1L)
    stop("Selected anchor must match one of at most 100 candidate anchors.", call. = FALSE)
  list(selected = anchor, candidates = anchors,
    index = which(abs(anchors - anchor) < 1e-12), K = length(anchors))
}

.cjqr_eal_coef_object_anchors <- function(object) {
  if (is.null(object$anchors))
    stop("Complete candidate anchors are unavailable; intercept inference requires the original anchor grid.",
         call. = FALSE)
  spec <- .cjqr_eal_coef_anchor_spec(object$fit$p, object$anchors)
  if (!is.null(object$anchor) && (!is.numeric(object$anchor) ||
      length(object$anchor) != 1L || !is.finite(object$anchor) ||
      abs(object$anchor - spec$selected) >= 1e-12))
    stop("Stored selected anchor disagrees with fit$p.", call. = FALSE)
  audit <- object$selection$audit$anchor
  if (is.null(audit) || !is.numeric(audit) || length(audit) != spec$K ||
      any(!is.finite(audit)) || anyDuplicated(audit) ||
      any(abs(sort(audit) - sort(spec$candidates)) >= 1e-12))
    stop("Anchor audit must include the complete candidate grid, including failed candidates.", call. = FALSE)
  selected_index <- object$selection$index
  if (is.null(selected_index) || !is.numeric(selected_index) ||
      length(selected_index) != 1L || !is.finite(selected_index) ||
      selected_index != floor(selected_index) || selected_index < 1L ||
      selected_index > spec$K || abs(audit[selected_index] - spec$selected) >= 1e-12)
    stop("Anchor selection index disagrees with the selected anchor.", call. = FALSE)
  spec
}

.cjqr_eal_coef_compute <- function(X, Y, joint, ids, opts, resamples = NULL,
                                    anchor = NULL, anchors = NULL, smooth_blocks = NULL,
                                    joint_tau = NULL) {
  began <- proc.time()[[3L]]
  anchor_spec <- .cjqr_eal_coef_anchor_spec(anchor, anchors)
  if (!is.null(anchor_spec)) opts$probs <- anchor_spec$candidates
  designs <- .cjqr_eal_designs(X)
  Xeval <- if (is.matrix(X)) X[1L, , drop = FALSE] else
    lapply(X, function(z) z[1L, , drop = FALSE])
  dims <- .cjqr_eal_ci_validate_design(X, Y, Xeval, NULL, opts, check_joint = FALSE)
  if (!is.null(smooth_blocks) && dims$estimated_bytes +
      16 * opts$B * sum(vapply(designs, ncol, integer(1L))) +
      8 * sum(vapply(designs, ncol, integer(1L))^2) +
      16 * dims$n * sum(vapply(designs, ncol, integer(1L))) > opts$max_memory_mb * 1024^2)
    stop("Estimated smooth auxiliary workspace exceeds max_memory_mb.", call. = FALSE)
  if (!is.list(joint) || length(joint) != 2L || !is.list(ids) || length(ids) != 2L)
    stop("joint and ids must contain two marginal vectors.", call. = FALSE)
  intercepts <- integer(2L)
  for (j in seq_len(2L)) {
    if (!is.numeric(joint[[j]]) || length(joint[[j]]) != ncol(designs[[j]]) ||
        any(!is.finite(joint[[j]]))) stop("Invalid joint coefficient vector.", call. = FALSE)
    if (!is.numeric(ids[[j]]) || any(!is.finite(ids[[j]])) ||
        any(ids[[j]] != floor(ids[[j]])) || anyDuplicated(ids[[j]]) ||
        any(ids[[j]] < 1L | ids[[j]] > ncol(designs[[j]])))
      stop("Invalid parametric coefficient indices.", call. = FALSE)
    intercepts[j] <- which(vapply(seq_len(ncol(designs[[j]])), function(k)
      max(abs(designs[[j]][, k] - 1)) < 1e-12, logical(1L)))
  }
  # Reuse each draw's QR only within that draw. No bootstrap designs or QR
  # decompositions are retained in the returned object or across draws.
  keep_qr <- !is.null(smooth_blocks)
  point_qr <- keep_qr || !is.null(anchor_spec)
  point <- .cjqr_eal_coef_reference(X, Y, seq_len(dims$n), keep_qr = point_qr)
  reference <- if (point_qr) point$beta else point
  if (!is.null(joint_tau) && (!is.numeric(joint_tau) || length(joint_tau) != 1L ||
      !is.finite(joint_tau) || abs(joint_tau) > 1))
    stop("Invalid fitted Kendall tau.", call. = FALSE)
  tau_reference <- if (!is.null(joint_tau)) tryCatch(
    .cjqr_eal_tau_reference(X, Y, seq_len(dims$n), reference, original = TRUE),
    error = identity) else NULL
  anchor_reference <- function(indices, qr_cache = NULL) {
    ref <- .cjqr_eal_ci_refit(X, Y, indices, anchor_spec$candidates,
      keep_qr = keep_qr, qr_cache = qr_cache)
    if (!isTRUE(ref$ok)) stop(ref$error, call. = FALSE)
    beta <- .cjqr_eal_betas(ref$beta)
    intercept <- sweep(ref$residual_quantiles, 2L,
      vapply(seq_len(2L), function(j) beta[[j]][intercepts[j]], numeric(1L)), "+")
    list(beta = beta, intercept = intercept, qr_cache = ref$qr_cache)
  }
  anchor_point <- if (!is.null(anchor_spec))
    anchor_reference(seq_len(dims$n), qr_cache = point$qr_cache) else NULL
  if (!is.null(anchor_point)) anchor_point$qr_cache <- NULL
  indices <- if (is.null(resamples)) .cjqr_eal_ci_indices(dims$n, opts$B, opts$seed) else resamples
  if (!is.matrix(indices) || !is.numeric(indices) ||
      !identical(dim(indices), c(dims$n, opts$B)) || any(!is.finite(indices)) ||
      any(indices != floor(indices)) || any(indices < 1 | indices > dims$n))
    stop("Invalid paired bootstrap row indices.", call. = FALSE)
  draws <- lapply(seq_len(2L), function(j)
    matrix(NA_real_, nrow = length(ids[[j]]), ncol = opts$B,
      dimnames = list(colnames(designs[[j]])[ids[[j]]], NULL)))
  anchor_draws <- if (!is.null(anchor_spec)) array(NA_real_, c(anchor_spec$K, 2L, opts$B),
    dimnames = list(as.character(anchor_spec$candidates), NULL, NULL)) else NULL
  full_draws <- if (!is.null(smooth_blocks)) lapply(designs, function(Xj)
    matrix(NA_real_, ncol(Xj), opts$B, dimnames = list(colnames(Xj), NULL))) else NULL
  status <- data.frame(draw = seq_len(opts$B), ok = FALSE, error = "",
                       stringsAsFactors = FALSE)
  smooth_status <- status
  tau_status <- status
  tau_draws <- if (!is.null(joint_tau)) rep(NA_real_, opts$B) else NULL
  covariances <- if (!is.null(smooth_blocks)) tryCatch(
    .cjqr_eal_smooth_hc3(X, Y, seq_len(dims$n), reference,
      qr_cache = point$qr_cache), error = identity) else NULL
  point <- NULL
  radials <- if (!is.null(smooth_blocks)) lapply(smooth_blocks, function(blocks)
    lapply(blocks, function(block) rep(NA_real_, opts$B))) else NULL
  for (b in seq_len(opts$B)) {
    ref <- tryCatch(if (is.null(anchor_spec)) {
      if (keep_qr) .cjqr_eal_coef_reference(X, Y, indices[, b], keep_qr = TRUE) else
        list(beta = .cjqr_eal_coef_reference(X, Y, indices[, b]))
    } else
      anchor_reference(indices[, b]), error = identity)
    if (inherits(ref, "error")) status$error[b] <- conditionMessage(ref) else {
      status$ok[b] <- TRUE
      for (j in seq_len(2L)) draws[[j]][, b] <- ref$beta[[j]][ids[[j]]]
      if (!is.null(full_draws)) for (j in seq_len(2L)) full_draws[[j]][, b] <- ref$beta[[j]]
      if (!is.null(anchor_spec)) anchor_draws[, , b] <- ref$intercept
      if (!is.null(joint_tau)) {
        tau_b <- if (inherits(tau_reference, "error")) tau_reference else tryCatch(
          .cjqr_eal_tau_reference(X, Y, indices[, b], ref$beta), error = identity)
        if (inherits(tau_b, "error")) tau_status$error[b] <- conditionMessage(tau_b) else {
          tau_status$ok[b] <- TRUE
          tau_draws[b] <- tau_b$tau
        }
      }
      if (!is.null(smooth_blocks)) {
        radial_b <- if (inherits(covariances, "error")) covariances else tryCatch({
          covariance_b <- .cjqr_eal_smooth_hc3(X, Y, indices[, b], ref$beta,
            qr_cache = ref$qr_cache)
          lapply(seq_len(2L), function(j) lapply(smooth_blocks[[j]], function(block) {
            ii <- block$ids
            .cjqr_eal_smooth_studentized_radial(reference[[j]][ii], ref$beta[[j]][ii],
              covariance_b[[j]][ii, ii, drop = FALSE])
          }))
        }, error = identity)
        if (inherits(radial_b, "error")) smooth_status$error[b] <- conditionMessage(radial_b) else {
          smooth_status$ok[b] <- TRUE
          for (j in seq_len(2L)) for (k in seq_along(smooth_blocks[[j]]))
            radials[[j]][[k]][b] <- radial_b[[j]][[k]]
        }
      }
    }
  }
  available <- all(status$ok)
  tails <- c((1 - opts$level) / 2, (1 + opts$level) / 2)
  level_name <- format(100 * opts$level, trim = TRUE)
  tables <- references <- vector("list", 2L)
  for (j in seq_len(2L)) {
    tables[[j]] <- matrix(NA_real_, length(ids[[j]]), 4L,
      dimnames = list(colnames(designs[[j]])[ids[[j]]],
        c("Estimate", paste0("Lower ", level_name, "%"),
          paste0("Upper ", level_name, "%"), "p-value")))
    tables[[j]][, 1L] <- joint[[j]][ids[[j]]]
    references[[j]] <- tables[[j]]
    references[[j]][, 1L] <- reference[[j]][ids[[j]]]
    is_intercept <- ids[[j]] == intercepts[j]
    if (!is.null(anchor_spec)) references[[j]][is_intercept, 1L] <-
      anchor_point$intercept[anchor_spec$index, j]
    eligible <- if (is.null(anchor_spec)) which(!is_intercept) else seq_along(ids[[j]])
    if (available) for (k in eligible) {
      correction <- if (is_intercept[k]) anchor_spec$K else 1L
      current_draws <- if (is_intercept[k]) anchor_draws[anchor_spec$index, j, ] else draws[[j]][k, ]
      quantiles <- .cjqr_eal_coef_quantiles(current_draws)
      probabilities <- if (is_intercept[k]) c((1 - opts$level) / (2 * correction),
        1 - (1 - opts$level) / (2 * correction)) else tails
      ends <- as.numeric(quantiles(probabilities))
      estimate <- tables[[j]][k, 1L]
      tables[[j]][k, 2:3] <- c(min(ends[1L], estimate), max(ends[2L], estimate))
      tables[[j]][k, 4L] <- min(1, correction *
        .cjqr_eal_coef_tail_p(current_draws, estimate, quantiles = quantiles))
      references[[j]][k, 2:3] <- ends
      references[[j]][k, 4L] <- min(1, correction * min(
        .cjqr_eal_coef_tail_p(current_draws, 1, quantiles = quantiles),
        .cjqr_eal_coef_tail_p(current_draws, -1, quantiles = quantiles)))
    }
  }
  error <- if (available) NULL else paste(
    "At least one auxiliary bootstrap draw failed; all coefficient intervals and tests are unavailable.",
    "No failed draws were discarded or replaced.")
  if (!available) warning(error, call. = FALSE)
  result <- list(tables = tables, reference = references, level = opts$level,
    validation_status = "experimental: finite-sample coefficient calibration is not established",
    null = 0, available = available, error = error,
    method = "auxiliary-bootstrap coefficient percentile hull with interval-inversion tests",
    bootstrap = list(requested = opts$B, attempted = opts$B,
      successful = sum(status$ok), failed = sum(!status$ok), status = status,
      seed = opts$seed, joint_refits = 0L, paired_subject_rows = TRUE,
      fixed_observed_basis = TRUE, endpoint_quantile_type = 8L,
      all_draws_required = TRUE, replacement_draws = 0L,
      p_value_floor = 2 / (opts$B + 1),
      intercept_p_value_floor = if (is.null(anchor_spec)) NA_real_ else
        min(1, 2 * anchor_spec$K / (opts$B + 1)),
      elapsed_seconds = unname(proc.time()[[3L]] - began)),
    interpretation = list(is_joint_sampling_SE = FALSE, is_Wald_test = FALSE,
      simultaneous = FALSE, multiplicity_adjusted = FALSE,
      includes_intercept_inference = !is.null(anchor_spec), includes_dependence_inference = FALSE,
      intercept_anchor_selection_protected = !is.null(anchor_spec),
      conditional_selective_inference = FALSE),
    intercept = if (is.null(anchor_spec)) NULL else c(anchor_spec, list(
      adjustment = "Bonferroni over the complete candidate grid within each margin",
      reference = "OLS intercept plus in-bag residual quantile at the selected anchor",
      fixed_original_basis = TRUE,
      reference_point_all_anchors = anchor_point$intercept)),
    assumptions = c("Independent subject pairs and finite-variance errors independent of covariates.",
      "Common-error additive location structure: mean and quantiles share non-intercept effects.",
      "Each original fixed basis is full rank, has controlled leverage and adequately represents the location function.",
      "Coverage is inherited from the auxiliary estimator; percentile bootstrap validity is asymptotic, not guaranteed in finite samples.",
      "The candidate anchor grid must be fixed before seeing outcomes; residual density must be positive, finite and continuous near all candidate quantiles.",
      "Intercepts use within-margin Bonferroni anchor-selection protection, not conditional selective inference or adjustment across margins/terms.",
      "No native joint SEs, dependence tests or simultaneous inference across model terms are supplied."))
  if (opts$keep_draws) result$draws <- list(indices = indices, coefficients = draws,
    intercepts = anchor_draws)
  if (!is.null(smooth_blocks)) {
    smooth_status$error[!status$ok] <- status$error[!status$ok]
    result$smooth <- .cjqr_eal_smooth_compute(smooth_blocks, joint, reference,
      full_draws, smooth_status, opts,
      covariances = if (inherits(covariances, "error")) NULL else covariances, radials = radials)
    if (opts$keep_draws) result$draws$full_coefficients <- full_draws
  }
  if (!is.null(joint_tau)) {
    tau_status$error[!status$ok] <- status$error[!status$ok]
    result$tau_ci <- .cjqr_eal_tau_interval(joint_tau, tau_reference, tau_draws,
      tau_status, opts)
    result$interpretation$includes_dependence_inference <- TRUE
  }
  class(result) <- "cjqr_eal_coef_ci"
  result
}

cjqr_eal_coef_ci <- function(object, level = 0.95, B = 500L, seed = 1L,
                             max_memory_mb = 256, keep_draws = FALSE) {
  .cjqr_eal_coefficient_inference(object, level, B, seed, max_memory_mb, keep_draws)
}

.cjqr_eal_coefficient_inference <- function(object, level = 0.95, B = 500L, seed = 1L,
                             max_memory_mb = 256, keep_draws = FALSE, include_smooth = FALSE,
                             include_parametric = TRUE, include_tau = FALSE) {
  .cjqr_eal_require_fit(object)
  anchor_spec <- if (include_parametric) .cjqr_eal_coef_object_anchors(object) else NULL
  opts <- .cjqr_eal_ci_options(.5, level, B, seed, 1L, max_memory_mb, keep_draws)
  if (!is.null(object$weights) && (!is.numeric(object$weights) ||
      any(!is.finite(object$weights)) || any(object$weights != 1)))
    stop("Weighted observations are not supported by this auxiliary bootstrap.", call. = FALSE)
  if (opts$B < 100L) warning("B < 100 is only for code checks, not inferential validation.", call. = FALSE)
  if (include_parametric && 1 - level < min(1, 2 * anchor_spec$K / (opts$B + 1)))
    warning("Requested confidence level exceeds the anchor-adjusted bootstrap p-value resolution; increase B.", call. = FALSE)
  designs <- .cjqr_eal_designs(object$X)
  ids <- if (!include_parametric) rep(list(integer()), 2L) else lapply(seq_len(2L), function(j) {
    smooth_ids <- unlist(lapply(.cjqr_eal_smooth_blocks(object, j), `[[`, "ids"), use.names = FALSE)
    setdiff(seq_len(ncol(designs[[j]])), smooth_ids)
  })
  result <- .cjqr_eal_coef_compute(object$X, object$Y,
    .cjqr_eal_betas(object$fit$beta), ids, opts,
    anchor = anchor_spec$selected, anchors = anchor_spec$candidates,
    smooth_blocks = if (include_smooth) lapply(seq_len(2L), function(j)
      .cjqr_eal_smooth_blocks(object, j)) else NULL,
    joint_tau = if (include_tau) .cjqr_kendall_tau(object$fit$theta, object$copula,
      df = object$df) else NULL)
  names(result$tables) <- names(result$reference) <- object$responses
  result
}

print.cjqr_eal_coef_ci <- function(x, digits = 4L,
                                  signif.stars = getOption("show.signif.stars", TRUE), ...) {
  digits <- .cjqr_eal_ci_integer(digits, "digits", 1L)
  if (digits > 22L) stop("digits must not exceed 22.", call. = FALSE)
  if (!is.logical(signif.stars) || length(signif.stars) != 1L || is.na(signif.stars))
    stop("signif.stars must be TRUE or FALSE.", call. = FALSE)
  cat("EXPERIMENTAL: coefficient calibration is not established.\n")
  cat("Auxiliary-bootstrap marginal parametric effects\n")
  for (j in seq_along(x$tables)) {
    cat("\nEquation", j, "\n")
    .cjqr_eal_print_parametric(x$tables[[j]], digits, signif.stars)
  }
  cat("\nAuxiliary-bootstrap percentile-interval inversion for H0: coefficient = 0; no joint-model SEs.\n")
  cat("Bootstrap draws:", x$bootstrap$successful, "of", x$bootstrap$attempted,
      "; joint refits: 0; conservative p-value floor:",
      format(x$bootstrap$p_value_floor, digits = digits), "\n")
  if (!is.null(x$intercept)) cat("Intercepts: selected anchor ", x$intercept$selected,
    "; Bonferroni protection over ", x$intercept$K,
    " candidate anchors per margin; p-value floor: ",
    format(x$bootstrap$intercept_p_value_floor, digits = digits), ".\n", sep = "")
  cat("Validity requires the common-error auxiliary location model. Dependence inference is excluded.\n")
  invisible(x)
}
