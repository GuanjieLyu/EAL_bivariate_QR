# Read-only interpretation of stored numerical checks. No optimizer return
# code alone is a certificate, and no claim of global optimality is made.
.cjqr_eal_summary_convergence <- function(object) {
  scalar <- function(x) if (is.numeric(x) && length(x) == 1L && is.finite(x))
    as.numeric(x) else NA_real_
  flag <- function(x) if (is.logical(x) && length(x) == 1L && !is.na(x)) x else NA
  numeric_record <- function(x) {
    if (is.null(x) || (is.numeric(x) && length(x) == 1L && is.na(x))) return(NA)
    is.numeric(x) && length(x) == 1L && is.finite(x)
  }
  both <- function(...) {
    x <- c(...)
    if (any(!x, na.rm = TRUE)) FALSE else if (anyNA(x)) NA else TRUE
  }
  nonnegative_below <- function(value, tolerance) {
    value <- scalar(value); tolerance <- scalar(tolerance)
    if (is.na(value) || is.na(tolerance) || tolerance < 0) return(NA)
    value >= 0 && value <= tolerance
  }
  matches <- function(x, y, tolerance) {
    x <- scalar(x); y <- scalar(y); tolerance <- scalar(tolerance)
    if (anyNA(c(x, y, tolerance)) || tolerance < 0) return(NA)
    abs(x - y) <= tolerance
  }
  f <- if (is.list(object$fit)) object$fit else list()
  selection <- if (is.list(object$selection)) object$selection else list()
  cert <- if (is.list(f$improved_certificate)) f$improved_certificate else list()
  ctl <- if (is.list(f$improved_control)) f$improved_control else list()
  stationarity <- scalar(cert$kkt)
  if (is.na(stationarity)) stationarity <- scalar(f$stationarity)
  tolerance <- scalar(ctl$strict_gradient_tolerance)
  if (is.na(tolerance)) tolerance <- scalar(f$strict_gradient_tolerance)
  replay_tol <- scalar(ctl$objective_replay_tolerance)
  gap_tol <- scalar(ctl$lower_candidate_gap_tolerance)
  direction_tol <- scalar(ctl$directional_improvement_tolerance)
  objective <- scalar(f$objective)
  replay_absolute <- replay_tol * (1 + abs(objective))
  # Require positive recorded tolerances rather than guessing settings for a
  # legacy object. A contradictory explicit failure takes priority over gaps.
  tolerances <- if (anyNA(c(tolerance, replay_tol, gap_tol, direction_tol))) NA else
    all(c(tolerance, replay_tol, gap_tol, direction_tol) > 0) && tolerance <= 1e-6
  checks <- c(
    fitted_object = inherits(object, "cjqr_eal"),
    fit_certified = flag(f$strict_ok),
    anchor_selection_certified = flag(selection$strict_ok),
    local_certificate = flag(cert$strict_local_ok),
    finite_objective = numeric_record(f$objective),
    finite_certificate_objective = numeric_record(cert$objective),
    finite_certificate_stationarity = numeric_record(cert$kkt),
    finite_fit_stationarity = numeric_record(f$stationarity),
    recorded_tolerances = tolerances,
    stationarity = nonnegative_below(stationarity, tolerance),
    stationarity_records_agree = matches(cert$kkt, f$stationarity,
      if (is.finite(tolerance)) min(1e-10, tolerance * 1e-3) else NA_real_),
    objective_replay = nonnegative_below(cert$objective_replay_gap, replay_absolute),
    objective_records_agree = matches(cert$objective, objective, replay_absolute),
    directional_search = both(flag(cert$directional_check),
      nonnegative_below(cert$max_directional_improvement, direction_tol),
      if (is.na(scalar(cert$probe_count))) NA else
        scalar(cert$probe_count) > 0 && scalar(cert$probe_count) == floor(scalar(cert$probe_count))),
    within_anchor_candidate_gap = both(flag(cert$observed_candidate_gap_ok),
      nonnegative_below(cert$observed_candidate_gap, gap_tol),
      nonnegative_below(f$lower_unconverged_objective_gap, gap_tol)),
    across_anchor_candidate_gap = nonnegative_below(selection$unresolved_gap, gap_tol))
  audit <- selection$audit
  required <- c("anchor", "initialized", "strict", "objective", "known_minimum")
  audit_missing <- is.null(audit) || !is.data.frame(audit) ||
    !all(required %in% names(audit)) || !nrow(audit)
  audit_checks <- c(anchor_initializers = NA, selected_anchor_record = NA,
    selected_objective_record = NA, recomputed_anchor_gap = NA)
  if (!audit_missing) {
    initializers <- vapply(seq_len(nrow(audit)), function(k) flag(audit$initialized[k]), logical(1L))
    audit_checks["anchor_initializers"] <- do.call(both, as.list(initializers))
    index <- scalar(selection$index)
    index_valid <- !is.na(index) && index == floor(index) && index >= 1 && index <= nrow(audit)
    if (!index_valid) {
      missing_index <- is.null(selection$index) || (is.numeric(selection$index) &&
        length(selection$index) == 1L && is.na(selection$index))
      audit_checks[c("selected_anchor_record", "selected_objective_record")] <-
        if (missing_index) NA else FALSE
    } else {
      index <- as.integer(index)
      audit_checks["selected_anchor_record"] <- both(flag(audit$strict[index]),
        matches(audit$anchor[index], f$p, 1e-12),
        matches(audit$anchor[index], object$anchor, 1e-12))
      audit_checks["selected_objective_record"] <- matches(
        audit$objective[index], objective, replay_absolute)
      # An unsuccessful alternative anchor is permissible. All finite known
      # objectives nevertheless contribute to the unresolved-candidate check.
      if (is.numeric(audit$objective) && is.numeric(audit$known_minimum)) {
        seen <- c(audit$objective, audit$known_minimum)
        seen <- seen[is.finite(seen)]
        selected_objective <- scalar(audit$objective[index])
        if (length(seen) && !is.na(selected_objective)) {
          gap <- max(0, selected_objective - min(seen))
          audit_checks["recomputed_anchor_gap"] <- both(
            nonnegative_below(gap, gap_tol), matches(gap, selection$unresolved_gap, gap_tol))
        }
      }
    }
  }
  checks <- c(checks, audit_checks)
  reason_codes <- as.character(unlist(cert$reason_codes, use.names = FALSE))
  reason_codes <- unique(reason_codes[!is.na(reason_codes) & nzchar(reason_codes)])
  if (length(reason_codes)) checks <- c(checks, certificate_reason_codes_clear = FALSE)
  boundary <- list(dependence = flag(cert$dependence_boundary),
    scale = flag(cert$scale_boundary), shape = flag(cert$shape_boundary))
  failed <- names(checks)[!is.na(checks) & !checks]
  missing <- names(checks)[is.na(checks)]
  check_status <- if (length(failed)) "failed" else if (length(missing)) "incomplete" else "passed"
  status <- unname(c(passed = "converged", failed = "not converged",
    incomplete = "not assessed")[check_status])
  boundary_reached <- any(unlist(boundary), na.rm = TRUE) || length(cert$boundary) > 0L
  message <- switch(check_status,
    passed = if (boundary_reached) "Passed stored numerical checks; a search boundary was reached." else
      "Passed stored numerical checks.",
    failed = "Stored numerical checks failed or are inconsistent.",
    incomplete = "Detailed numerical certification is incomplete or unavailable.")
  list(status = status, message = message, stationarity = stationarity,
    tolerance = tolerance, checks = checks,
    reasons = c(if (length(failed)) paste0("Failed: ", failed),
      if (length(missing)) paste0("Unavailable: ", missing), reason_codes),
    boundary = boundary, source = "stored fitted-object certificates and anchor audit",
    recomputed_model_fit = FALSE, proves_global_optimum = FALSE,
    establishes_statistical_validity = FALSE)
}
