# Descriptive diagnostics on retained analysis pairs or explicitly supplied
# evaluation pairs. No optimization, simulation, bootstrap or RNG use.
.cjqr_residual_outcomes <- function(y, location, responses) {
  if (!is.matrix(y) || !is.numeric(y) || is.complex(y) ||
      !identical(dim(y), dim(location)) || any(!is.finite(y)))
    stop("`y` must be a finite numeric matrix with one row per evaluated pair and two columns in fitted response order.", call. = FALSE)
  if (!is.null(colnames(y)) && !identical(colnames(y), responses))
    stop("Named `y` columns must match the fitted response names in order.", call. = FALSE)
  invisible(y)
}

.cjqr_residual_tail_inputs <- function(object, newdata, y) {
  if (!is.null(newdata) && (!is.data.frame(newdata) || !nrow(newdata)))
    stop("`newdata` must be a nonempty data frame.", call. = FALSE)
  if (inherits(object, "cjqr_eal")) {
    .cjqr_eal_require_fit(object)
    X <- .cjqr_eal_newX(object, newdata)
    location <- .cjqr_eal_location(X, object$fit$beta)
    responses <- object$responses
    if (is.null(y)) {
      if (is.null(newdata)) y <- object$Y
      else if (all(responses %in% names(newdata))) y <- as.matrix(newdata[responses])
      else stop("Supply both observed responses in `newdata` or a paired `y` matrix.", call. = FALSE)
    }
    .cjqr_residual_outcomes(y, location, responses)
    f <- object$fit
    if (!is.numeric(f$sigma) || length(f$sigma) != 2L ||
        any(!is.finite(f$sigma)) || any(f$sigma <= 0) ||
        !is.matrix(f$shape) || !identical(dim(f$shape), c(5L, 2L)) ||
        !is.numeric(f$shape) || any(!is.finite(f$shape)))
      stop("Residual diagnostics require valid fitted EAL scales and shape parameters.", call. = FALSE)
    engine <- .cjqr_eal_engine(object$copula)$density
    tails <- lapply(1:2, function(j) engine$eal_terms(
      (y[, j] - location[, j]) / f$sigma[j], p = f$p,
      shape = f$shape[, j], K = 3L, derivatives = FALSE))
    logF <- do.call(cbind, lapply(tails, `[[`, "logF"))
    logS <- do.call(cbind, lapply(tails, `[[`, "logS"))
    theta <- f$theta; family <- object$copula; df <- object$df
    row_index <- if (is.null(newdata)) object$kept_rows else seq_len(nrow(newdata))
    omitted_rows <- if (is.null(newdata)) object$omitted_rows else integer()
    weights <- rep(1, nrow(y))
    convergence <- "certified"
  } else stop("`object` must be a fitted cjqr_eal model.", call. = FALSE)
  if (any(!is.finite(location))) stop("Fitted locations are nonfinite.", call. = FALSE)
  if (is.null(row_index)) row_index <- seq_len(nrow(y))
  row_names <- if (!is.null(newdata)) rownames(newdata) else
    rownames(y) %||% rownames(object$data) %||% as.character(row_index)
  dimnames(logF) <- dimnames(logS) <- list(row_names, responses)
  list(logF = logF, logS = logS, theta = theta, family = family, df = df,
    responses = responses, row_index = row_index, row_names = row_names,
    omitted_rows = omitted_rows %||% integer(), weights = weights,
    convergence = convergence)
}

cjqr_residual_diagnostics <- function(object, newdata = NULL, y = NULL,
                                      order = c(1L, 2L)) {
  if (!is.numeric(order) || is.complex(order) || !is.null(dim(order)) ||
      length(order) != 2L || anyNA(order) ||
      !setequal(order, 1:2))
    stop("`order` must be c(1, 2) or c(2, 1).", call. = FALSE)
  order <- as.integer(order)
  a <- .cjqr_residual_tail_inputs(object, newdata, y)
  r <- .cjqr_rosenblatt_transform(a$logF, a$logS, a$theta, a$family,
                                 df = a$df, order = order)
  labels <- c(a$responses[order[1L]],
              paste(a$responses[order[2L]], "|", a$responses[order[1L]]))
  dimnames(r$uniform) <- dimnames(r$normal) <-
    dimnames(r$logF) <- dimnames(r$logS) <- list(a$row_names, labels)
  marginal_pit <- exp(a$logF)
  marginal_normal <- a$logF
  left <- a$logF <= -log(2)
  marginal_normal[left] <- stats::qnorm(a$logF[left], log.p = TRUE)
  marginal_normal[!left] <- stats::qnorm(a$logS[!left], lower.tail = FALSE, log.p = TRUE)
  n <- nrow(r$uniform)
  safe_cor <- function(z) {
    if (nrow(z) < 3L || any(!is.finite(z)) || any(apply(z, 2L, stats::sd) == 0)) NA_real_
    else unname(stats::cor(z[, 1L], z[, 2L]))
  }
  cdf_distance <- function(u) {
    u <- sort(u); i <- seq_along(u)
    max(i / length(u) - u, u - (i - 1) / length(u))
  }
  summary <- data.frame(component = labels, n = n,
    mean_uniform = colMeans(r$uniform),
    uniform_cdf_distance = apply(r$uniform, 2L, cdf_distance),
    mean_normal = colMeans(r$normal),
    sd_normal = apply(r$normal, 2L, stats::sd), row.names = NULL)
  if (any(!is.finite(r$normal)))
    warning("Some normal scores exceed numerical representability; no rows were dropped. Inspect diagnostics before plotting.", call. = FALSE)
  out <- list(uniform = r$uniform, normal = r$normal,
    logF = r$logF, logS = r$logS,
    marginal_pit = marginal_pit, marginal_normal = marginal_normal,
    labels = labels, responses = a$responses, order = order, n = n,
    copula = .cjqr_normalize_copula(a$family), df = a$df,
    theta = a$theta, row_names = a$row_names, row_index = a$row_index,
    omitted_rows = a$omitted_rows, summary = summary,
    correlation = safe_cor(r$normal), squared_correlation = safe_cor(r$normal^2),
    finite_normal_pairs = sum(rowSums(is.finite(r$normal)) == 2L),
    evaluation = if (is.null(newdata)) "analysis rows" else "new data",
    convergence = a$convergence, weighted = FALSE,
    unequal_fit_weights = !is.null(a$weights) && length(unique(a$weights)) > 1L,
    joint_refits = 0L,
    note = paste("Descriptive fitted-model diagnostics, not a calibrated goodness-of-fit test.",
      "Uniformity alone does not establish independence. No survey adjustment is applied."))
  class(out) <- "cjqr_residual_diagnostics"
  out
}

print.cjqr_residual_diagnostics <- function(x, digits = 4L, ...) {
  if (length(list(...))) stop("Unsupported diagnostic printing arguments.", call. = FALSE)
  if (!is.numeric(digits) || is.complex(digits) || !is.null(dim(digits)) ||
      length(digits) != 1L || !is.finite(digits) ||
      digits < 1 || digits > 15 || digits != as.integer(digits))
    stop("`digits` must be an integer from 1 to 15.", call. = FALSE)
  cat("CJQR Rosenblatt residual diagnostics\n")
  cat("Copula:", x$copula, if (!is.null(x$df)) paste0(" (df = ", x$df, ")") else "", "\n")
  cat("Order:", x$labels[1L], "then", x$labels[2L], "\n")
  cat("Pairs:", x$n, "(", x$evaluation, "); joint refits: 0\n", sep = " ")
  print(x$summary, digits = digits, row.names = FALSE)
  cat("Normal-score correlation:", format(x$correlation, digits = digits), "\n")
  cat("Squared-score correlation:", format(x$squared_correlation, digits = digits), "\n")
  cat(x$note, "\n")
  if (isTRUE(x$unequal_fit_weights)) cat("The fit has unequal weights; these diagnostics describe the unweighted retained pairs.\n")
  invisible(x)
}
