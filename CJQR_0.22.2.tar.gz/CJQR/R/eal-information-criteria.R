# Conditional OPG/Fisher approximations, not unconditional AIC or a Laplace
# marginal-likelihood derivation of BIC. All fitted density nuisance directions
# are included. No joint refit or numerical Hessian is required.

.cjqr_eal_ic_warning <- function() paste0(
  "Conditional OPG AIC-type and EDF BIC-type approximations: selected anchor, ",
  "degree, smoothing parameters and copula df are treated as fixed. ",
  "No selection-uncertainty correction or standard BIC evidence interpretation; ",
  "not comparable with native qgam AIC/BIC.")

.cjqr_eal_ic_warn_flag <- function(warn) {
  if (!is.logical(warn) || length(warn) != 1L || is.na(warn))
    stop("`warn` must be TRUE or FALSE.", call. = FALSE)
}

cjqr_eal_ic <- function(object, warn = TRUE) {
  .cjqr_eal_ic_warn_flag(warn)
  .cjqr_eal_require_fit(object)
  cv <- .cjqr_eal_summary_convergence(object)
  if (!identical(cv$status, "converged"))
    stop("Information criteria require complete, consistent convergence checks: ",
      paste(cv$reasons, collapse = "; "), call. = FALSE)
  copula <- .cjqr_normalize_copula(object$copula)
  f <- object$fit
  if (!is.numeric(f$degree) || length(f$degree) != 1L ||
      !is.finite(f$degree) || f$degree != object$degree)
    stop("Inconsistent stored EAL degree.", call. = FALSE)
  df <- .cjqr_validate_copula_df(copula, object$df)
  if (!identical(copula, .cjqr_normalize_copula(f$copula)) ||
      !identical(df, .cjqr_validate_copula_df(copula, f$df)))
    stop("Inconsistent stored copula specification or fixed degrees of freedom.", call. = FALSE)
  info <- .cjqr_eal_smooth_edf(object, include_total = TRUE)
  if (!isTRUE(info$available))
    stop("Conditional information criterion unavailable: ", info$reason,
      if (!is.null(info$diagnostics$message)) paste0(" (", info$diagnostics$message, ")"),
      ". No parameter-count or regularized fallback is used.", call. = FALSE)
  total <- info$diagnostics$total_edf
  dimension <- info$diagnostics$parameter_dimension
  if (!is.numeric(total) || length(total) != 1L || !is.finite(total) ||
      total <= 0 || total > dimension + 1e-7)
    stop("Total conditional effective degrees of freedom are unavailable or invalid.", call. = FALSE)
  X <- .cjqr_eal_designs(object$X)
  beta <- .cjqr_eal_betas(f$beta)
  n <- nrow(object$Y)
  if (n <= 1L) stop("At least two independent subject pairs are required.", call. = FALSE)
  # Re-evaluate the normalized, unpenalized density; never use the penalized
  # objective as logLik. This detects stale parameters, responses or penalties.
  ll_i <- .cjqr_eal_engine(copula)$log_density(f, object$X, object$Y)
  if (!is.numeric(ll_i) || length(ll_i) != n || any(!is.finite(ll_i)))
    stop("Finite subject-level joint log densities are required.", call. = FALSE)
  ll <- sum(ll_i)
  penalty <- sum(vapply(1:2, function(j)
    drop(crossprod(beta[[j]], object$P[[j]] %*% beta[[j]])) / 2, numeric(1L)))
  objective <- (-ll + penalty) / n
  replay <- c(logLik = ll, penalty = penalty, objective = objective)
  recorded <- c(logLik = f$loglik, penalty = f$penalty, objective = f$objective)
  if (!is.numeric(recorded) || length(recorded) != 3L || any(!is.finite(recorded)) ||
      any(abs(replay - recorded) > 1e-8 * (1 + abs(replay))))
    stop("Stored log likelihood, penalty or objective fails independent replay.", call. = FALSE)
  ans <- list(method = "conditional-opg", conditional = TRUE,
    label = "Conditional OPG information criteria (approximations)",
    logLik = ll, effective_df = total, parameter_dimension = dimension,
    nobs = n, AIC = -2 * ll + 2 * total, BIC = -2 * ll + log(n) * total,
    copula = copula, copula_df = df, copula_df_estimated = FALSE,
    anchor = object$anchor, degree = object$degree,
    fixed = c("selected anchor", "EAL degree", "smoothing parameters", "copula df"),
    diagnostics = c(info$diagnostics, list(replay_difference = replay - recorded,
      convergence = cv$status, density_nuisance_dimension = 13L)),
    assumptions = c("Independent subject pairs and a correctly specified working joint density",
      "Interior, identified, numerically certified solution away from fitted density cusps",
      "Subject-score OPG approximates expected Fisher information",
      "Selected anchor, degree, smoothing parameters and copula df are conditioned upon"),
    limitations = c("No correction for anchor/smoothing selection or misspecification",
      "EDF BIC is a heuristic, not a validated marginal-likelihood or Bayes-factor approximation",
      "Native qgam criteria and likelihoods on different response scales are not comparable"),
    numerical_checks_passed = TRUE, statistical_validity_established = FALSE,
    joint_refits = 0L, call = match.call())
  class(ans) <- "cjqr_eal_ic"
  if (warn) warning(.cjqr_eal_ic_warning(), call. = FALSE)
  ans
}

print.cjqr_eal_ic <- function(x, digits = max(3L, getOption("digits") - 2L), ...) {
  cat(x$label, "\n")
  cat("Copula:", x$copula, if (!is.null(x$copula_df)) paste0(" (fixed df = ", x$copula_df, ")"), "\n")
  tab <- data.frame(n = x$nobs, logLik = x$logLik, edf = x$effective_df,
    AIC = x$AIC, BIC = x$BIC)
  print(tab, digits = digits, row.names = FALSE)
  cat("Conditioning: anchor, degree, smoothing parameters and copula df fixed.\n")
  cat("AIC: OPG/Fisher approximation; BIC: EDF heuristic.\n")
  cat("No selection-uncertainty correction; not comparable with native qgam criteria.\n")
  invisible(x)
}

.cjqr_eal_ic_compare <- function(objects) {
  if (!all(vapply(objects, inherits, logical(1L), "cjqr_eal")))
    stop("Compare only cjqr_eal models fitted to compatible data and specifications.", call. = FALSE)
  a <- objects[[1L]]
  for (b in objects[-1L]) {
    if (!identical(a$responses, b$responses) || !identical(a$Y, b$Y) ||
        !identical(rownames(a$data), rownames(b$data)) ||
        !identical(a$kept_rows, b$kept_rows))
      stop("Copula comparisons require identical paired responses, row order and subject rows.", call. = FALSE)
    # This API is deliberately scoped to copula comparisons, not unrelated
    # regression-model selection. Effective df may still differ by copula.
    if (!identical(a$degree, b$degree) || !setequal(a$anchors, b$anchors) ||
        !identical(.cjqr_eal_designs(a$X), .cjqr_eal_designs(b$X)) ||
        !identical(a$P, b$P) || !identical(a$data, b$data))
      stop("Copula comparisons require the same marginal data, designs, EAL degree, candidate anchors and fitted penalties.", call. = FALSE)
  }
  invisible(TRUE)
}

.cjqr_eal_ic_values <- function(object, dots, k, criterion, labels, warn) {
  .cjqr_eal_ic_warn_flag(warn)
  if (!is.numeric(k) || length(k) != 1L || !is.finite(k) || k <= 0)
    stop("`k` must be a positive finite scalar.", call. = FALSE)
  objects <- c(list(object), dots)
  .cjqr_eal_ic_compare(objects)
  ans <- lapply(objects, cjqr_eal_ic, warn = FALSE)
  value <- vapply(ans, function(x) if (criterion == "BIC") x$BIC else
    -2 * x$logLik + k * x$effective_df, numeric(1L))
  if (warn) warning(.cjqr_eal_ic_warning(), call. = FALSE)
  if (length(ans) == 1L) return(unname(value))
  tab <- data.frame(df = vapply(ans, `[[`, numeric(1L), "effective_df"), value)
  names(tab)[2L] <- criterion
  rownames(tab) <- make.unique(labels)
  attr(tab, "method") <- "conditional-opg"
  attr(tab, "qualification") <- .cjqr_eal_ic_warning()
  tab
}

AIC.cjqr_eal <- function(object, ..., k = 2, warn = TRUE) {
  expr <- as.list(substitute(list(object, ...)))[-1L]
  labels <- vapply(expr, function(x) paste(deparse(x), collapse = ""), character(1L))
  .cjqr_eal_ic_values(object, list(...), k, "AIC", labels, warn)
}

BIC.cjqr_eal <- function(object, ..., warn = TRUE) {
  expr <- as.list(substitute(list(object, ...)))[-1L]
  labels <- vapply(expr, function(x) paste(deparse(x), collapse = ""), character(1L))
  .cjqr_eal_ic_values(object, list(...), 2, "BIC", labels, warn)
}
