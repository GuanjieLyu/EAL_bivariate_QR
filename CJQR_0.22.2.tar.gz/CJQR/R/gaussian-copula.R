.gaussian_copula_terms <- function(
    z1, z2, delta) {
  rho <- .cjqr_theta_from_delta(
    delta, "gaussian"
  )
  d <- 1 - rho^2
  A <- z1^2 + z2^2
  B <- z1 * z2
  logc <- -0.5 * log(d) - (rho^2 * A - 2 * rho * B) / (2 * d)
  dz1 <- rho * (z2 - rho * z1) / d
  dz2 <- rho * (z1 - rho * z2) / d
  drho <- rho / d + (B * (1 + rho^2) - rho * A) / d^2
  ddelta <- drho * .cjqr_dtheta_ddelta(
    delta, rho, "gaussian"
  )
  list(logc = logc, dz1 = dz1, dz2 = dz2,
       drho = drho, ddelta = ddelta, rho = rho)
}

.pbvn_one <- function(a, b, rho, rel.tol = 1e-7) {
  if (is.na(a) || is.na(b) || is.na(rho)) return(NA_real_)
  if (a == -Inf || b == -Inf) return(0)
  if (a == Inf) return(stats::pnorm(b))
  if (b == Inf) return(stats::pnorm(a))
  if (abs(rho) < 1e-12) return(stats::pnorm(a) * stats::pnorm(b))
  den <- sqrt(1 - rho^2)
  val <- stats::integrate(function(x) stats::dnorm(x) * stats::pnorm((b - rho * x) / den),
                          lower = -Inf, upper = a, rel.tol = rel.tol,
                          subdivisions = 200L, stop.on.error = FALSE)$value
  pmin(1, pmax(0, val))
}

.pbvn <- function(a, b, rho, rel.tol = 1e-7) {
  n <- max(length(a), length(b), length(rho))
  a <- rep(a, length.out = n); b <- rep(b, length.out = n); rho <- rep(rho, length.out = n)
  vapply(seq_len(n), function(i) .pbvn_one(a[i], b[i], rho[i], rel.tol), numeric(1L))
}

.gaussian_copula_cdf <- function(u1, u2, rho) {
  n <- max(length(u1), length(u2), length(rho))
  u1 <- rep(u1, length.out = n); u2 <- rep(u2, length.out = n); rho <- rep(rho, length.out = n)
  ans <- numeric(n)
  zero <- u1 <= 0 | u2 <= 0
  one1 <- u1 >= 1 & !zero; one2 <- u2 >= 1 & !zero
  ans[one1] <- u2[one1]
  ans[one2] <- u1[one2]
  both1 <- u1 >= 1 & u2 >= 1
  ans[both1] <- 1
  mid <- !(zero | one1 | one2)
  if (any(mid)) ans[mid] <- .pbvn(stats::qnorm(u1[mid]), stats::qnorm(u2[mid]), rho[mid])
  pmin(1, pmax(0, ans))
}
