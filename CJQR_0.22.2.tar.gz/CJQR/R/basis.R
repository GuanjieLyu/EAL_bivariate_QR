# Fixed marginal mgcv penalty construction for the EAL estimator.
.cjqr_resolve_sp_multiplier <- function(sp_multiplier, blueprint, margin) {
  labels <- blueprint$free_labels
  number_free <- length(labels)
  if (is.null(sp_multiplier)) {
    return(stats::setNames(rep(1, number_free), labels))
  }
  if (!is.numeric(sp_multiplier) || length(sp_multiplier) != number_free ||
      any(!is.finite(sp_multiplier)) || any(sp_multiplier < 0)) {
    stop(
      "The supplied `sp_multiplier$", margin, "` must contain exactly ",
      number_free, " finite nonnegative value",
      if (number_free == 1L) "" else "s",
      ", one for each free mgcv smoothing-parameter group.",
      call. = FALSE
    )
  }
  nms <- names(sp_multiplier)
  if (!is.null(nms)) {
    if (anyNA(nms) || any(!nzchar(nms)) || anyDuplicated(nms) ||
        !setequal(nms, labels)) {
      stop(
        "A named `sp_multiplier$", margin,
        "` must use each canonical free smoothing-parameter label exactly once: ",
        if (length(labels)) paste(labels, collapse = ", ") else "<none>",
        ".", call. = FALSE
      )
    }
    sp_multiplier <- sp_multiplier[labels]
  }
  stats::setNames(as.numeric(sp_multiplier), labels)
}

.cjqr_matrix_rank <- function(x) {
  x <- as.matrix(x)
  if (!length(x) || !any(x != 0)) return(0L)
  as.integer(qr(x, tol = sqrt(.Machine$double.eps))$rank)
}

.cjqr_sum_penalty_components <- function(components, sp, p = NULL) {
  if (!length(components)) {
    if (is.null(p)) p <- 0L
    return(matrix(0, p, p))
  }
  if (!is.numeric(sp) || length(sp) != length(components) ||
      any(!is.finite(sp)) || any(sp < 0)) {
    stop("Internal smoothing-parameter/component mapping is invalid.",
         call. = FALSE)
  }
  out <- matrix(0, nrow(components[[1L]]), ncol(components[[1L]]))
  for (j in seq_along(components)) out <- out + sp[[j]] * components[[j]]
  0.5 * (out + t(out))
}

.cjqr_penalty_blueprint <- function(fit) {
  fitted_coefficients <- tryCatch(stats::coef(fit), error = function(e) NULL)
  p <- length(fitted_coefficients)
  if (!p && is.matrix(fit$X)) p <- ncol(fit$X)
  if (!p || !is.finite(p)) {
    stop("The mgcv coefficient dimension is unavailable.", call. = FALSE)
  }
  empty_mapping <- function() data.frame(
    component = character(), smooth_index = integer(), smooth = character(),
    penalty_index = integer(), full_sp_index = integer(),
    free_sp_index = integer(), sp_group_index = integer(),
    coefficient_first = integer(),
    coefficient_last = integer(), rank = integer(), fixed = logical(),
    formula_fixed = logical(), stringsAsFactors = FALSE
  )
  if (!length(fit$smooth)) {
    return(list(raw = list(), mapping = empty_mapping(),
                free_labels = character(), formula_full_sp = numeric(), p = p))
  }

  raw <- list()
  rows <- list()
  free_keys <- character()
  free_labels <- character()
  group_keys <- character()
  formula_full_sp <- numeric()
  next_full_sp <- 1L
  component_id <- 0L

  for (smooth_index in seq_along(fit$smooth)) {
    sm <- fit$smooth[[smooth_index]]
    coefficient_index <- seq.int(sm$first.para, sm$last.para)
    number_penalties <- length(sm$S)
    if (!number_penalties) next
    full_indices <- if (!is.null(sm$first.sp) && !is.null(sm$last.sp)) {
      seq.int(sm$first.sp, sm$last.sp)
    } else {
      seq.int(next_full_sp, length.out = number_penalties)
    }
    next_full_sp <- max(full_indices) + 1L
    smooth_sp <- as.numeric(sm$sp %||% rep(-1, number_penalties))
    if (length(smooth_sp) != number_penalties) {
      smooth_sp <- rep(-1, number_penalties)
    }
    smooth_rank <- as.integer(sm$rank %||% rep(NA_integer_, number_penalties))
    if (length(smooth_rank) != number_penalties) {
      smooth_rank <- rep(NA_integer_, number_penalties)
    }

    for (penalty_index in seq_len(number_penalties)) {
      component_id <- component_id + 1L
      local <- as.matrix(sm$S[[penalty_index]])
      if (!identical(dim(local), c(length(coefficient_index),
                                    length(coefficient_index))) ||
          any(!is.finite(local))) {
        stop("mgcv returned an invalid smooth penalty component.",
             call. = FALSE)
      }
      full <- matrix(0, p, p)
      full[coefficient_index, coefficient_index] <- local
      full <- 0.5 * (full + t(full))
      label <- as.character(sm$label %||% paste0("smooth", smooth_index))
      component_name <- paste0(label, ".", penalty_index)
      raw[[component_id]] <- full

      formula_fixed <- is.finite(smooth_sp[[penalty_index]]) &&
        smooth_sp[[penalty_index]] >= 0
      shared_id <- sm$id
      key <- if (!is.null(shared_id) && length(shared_id) &&
                 !is.na(shared_id[[1L]]) && nzchar(as.character(shared_id[[1L]]))) {
        paste0("id:", as.character(shared_id[[1L]]),
               ":penalty:", penalty_index)
      } else {
        paste0("smooth:", smooth_index, ":penalty:", penalty_index)
      }
      group_index <- match(key, group_keys, nomatch = 0L)
      if (!group_index) {
        group_keys <- c(group_keys, key)
        group_index <- length(group_keys)
      }
      free_index <- NA_integer_
      if (formula_fixed) {
        formula_full_sp[[component_id]] <- smooth_sp[[penalty_index]]
      } else {
        free_index <- match(key, free_keys, nomatch = 0L)
        if (!free_index) {
          free_keys <- c(free_keys, key)
          free_labels <- c(free_labels, component_name)
          free_index <- length(free_keys)
        }
        formula_full_sp[[component_id]] <- NA_real_
      }
      component_rank <- smooth_rank[[penalty_index]]
      if (!is.finite(component_rank) || component_rank < 0) {
        component_rank <- .cjqr_matrix_rank(local)
      }
      rows[[component_id]] <- data.frame(
        component = component_name,
        smooth_index = as.integer(smooth_index),
        smooth = label,
        penalty_index = as.integer(penalty_index),
        full_sp_index = as.integer(full_indices[[penalty_index]]),
        free_sp_index = as.integer(free_index),
        sp_group_index = as.integer(group_index),
        coefficient_first = as.integer(sm$first.para),
        coefficient_last = as.integer(sm$last.para),
        rank = as.integer(component_rank),
        fixed = formula_fixed,
        formula_fixed = formula_fixed,
        stringsAsFactors = FALSE
      )
    }
  }

  if (!length(raw)) {
    return(list(raw = list(), mapping = empty_mapping(),
                free_labels = character(), formula_full_sp = numeric(), p = p))
  }
  component_names <- make.unique(vapply(rows, `[[`, character(1L),
                                         "component"))
  names(raw) <- component_names
  mapping <- do.call(rbind, rows)
  rownames(mapping) <- NULL
  mapping$component <- component_names
  list(raw = raw, mapping = mapping,
       free_labels = make.unique(free_labels),
       formula_full_sp = formula_full_sp, p = p)
}

.cjqr_penalty_metadata <- function(fit, requested_sp = NULL,
                                     requested_sp_multiplier = NULL,
                                     margin = "margin1",
                                     multiplier = 1,
                                     source = "initializer",
                                     blueprint = NULL) {
  multiplier <- as.numeric(multiplier)
  if (length(multiplier) != 1L || !is.finite(multiplier) || multiplier < 0) {
    stop("A margin penalty multiplier must be finite and nonnegative.",
         call. = FALSE)
  }
  if (is.null(blueprint)) blueprint <- .cjqr_penalty_blueprint(fit)
  mapping <- blueprint$mapping
  number_free <- length(blueprint$free_labels)
  sp_multiplier_free <- .cjqr_resolve_sp_multiplier(
    requested_sp_multiplier, blueprint, margin
  )

  if (!is.null(requested_sp)) {
    if (!is.numeric(requested_sp) || length(requested_sp) != number_free ||
        any(!is.finite(requested_sp)) || any(requested_sp < 0)) {
      stop(
        "The supplied margin `sp` must contain exactly ", number_free,
        " finite nonnegative value", if (number_free == 1L) "" else "s",
        ", one for each free mgcv smoothing parameter.",
        call. = FALSE
      )
    }
    sp_initial_free <- as.numeric(requested_sp)
    source <- "user-fixed"
  } else if (number_free) {
    fitted_free <- as.numeric(fit$sp %||% numeric())
    if (length(fitted_free) != number_free || any(!is.finite(fitted_free)) ||
        any(fitted_free < 0)) {
      stop(
        "The initializer smoothing parameters could not be matched to the mgcv penalty components.",
        call. = FALSE
      )
    }
    sp_initial_free <- fitted_free
  } else {
    sp_initial_free <- numeric()
  }
  names(sp_initial_free) <- blueprint$free_labels

  if (NROW(mapping)) {
    fitted_full <- as.numeric(fit$full.sp %||% numeric())
    full_indices <- mapping$full_sp_index
    if (length(fitted_full) >= max(full_indices) &&
        all(is.finite(fitted_full[full_indices])) &&
        all(fitted_full[full_indices] >= 0)) {
      sp_initial_full <- fitted_full[full_indices]
    } else {
      sp_initial_full <- blueprint$formula_full_sp
      free_component <- !is.na(mapping$free_sp_index)
      sp_initial_full[free_component] <-
        sp_initial_free[mapping$free_sp_index[free_component]]
    }
    if (length(sp_initial_full) != length(blueprint$raw) ||
        any(!is.finite(sp_initial_full)) || any(sp_initial_full < 0)) {
      stop("The full mgcv smoothing-parameter mapping is invalid.",
           call. = FALSE)
    }
  } else {
    sp_initial_full <- numeric()
    if (!is.null(requested_sp) && length(requested_sp)) {
      stop("A margin without smooth terms cannot receive smoothing parameters.",
           call. = FALSE)
    }
  }
  names(sp_initial_full) <- names(blueprint$raw)

  # Joint fitting holds smoothing parameters fixed. Store selected and effective
  # penalties separately so each supplied multiplier is applied exactly once.
  sp_final_free <- sp_initial_free
  sp_final_full <- sp_initial_full
  sp_multiplier_full <- rep(1, length(sp_final_full))
  if (NROW(mapping)) {
    free_component <- !is.na(mapping$free_sp_index)
    sp_multiplier_full[free_component] <-
      sp_multiplier_free[mapping$free_sp_index[free_component]]
  }
  names(sp_multiplier_full) <- names(sp_final_full)
  component_multiplier_full <- multiplier * sp_multiplier_full
  sp_effective_free <- multiplier * sp_multiplier_free * sp_final_free
  sp_effective_full <- component_multiplier_full * sp_final_full
  mapping$fixed <- mapping$formula_fixed | !is.null(requested_sp)

  penalty_initial <- .cjqr_sum_penalty_components(
    blueprint$raw, sp_initial_full, blueprint$p
  )
  penalty_final <- .cjqr_sum_penalty_components(
    blueprint$raw, sp_final_full, blueprint$p
  )
  penalty_effective <- .cjqr_sum_penalty_components(
    blueprint$raw, sp_effective_full, blueprint$p
  )
  list(
    raw = blueprint$raw,
    normalized = NULL,
    mapping = mapping,
    sp_initial_free = sp_initial_free,
    sp_initial_full = sp_initial_full,
    sp_final_free = sp_final_free,
    sp_final_full = sp_final_full,
    sp_effective_free = sp_effective_free,
    sp_effective_full = sp_effective_full,
    sp_multiplier_free = sp_multiplier_free,
    sp_multiplier_full = sp_multiplier_full,
    component_multiplier_full = component_multiplier_full,
    multiplier = multiplier,
    source = source,
    rank_effective = .cjqr_matrix_rank(penalty_effective),
    penalty_initial = penalty_initial,
    penalty_final = penalty_final,
    penalty_effective = penalty_effective,
    response_scale = NULL,
    normalization_factor = NULL
  )
}
