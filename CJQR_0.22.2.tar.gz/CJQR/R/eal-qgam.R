# Calibrated qgam initialization with a fixed optimizer retry sequence.
.cjqr_eal_qgam_native <- function(formula, data, prob, newdata, seed) {
  start <- proc.time()[3L]
  strategies <- list(
    list(name = "native_newton", optimizer = c("outer", "newton"),
      control = mgcv::gam.control(nthreads = 1L, maxit = 200L)),
    list(name = "cautious_newton", optimizer = c("outer", "newton"),
      control = mgcv::gam.control(nthreads = 1L, maxit = 500L,
        newton = list(maxNstep = 2, maxSstep = 1, maxHalf = 60))),
    list(name = "native_bfgs", optimizer = c("outer", "bfgs"),
      control = mgcv::gam.control(nthreads = 1L, maxit = 1000L)),
    list(name = "native_lbfgs", optimizer = c("outer", "optim"),
      control = mgcv::gam.control(nthreads = 1L, maxit = 1000L, optim = list(factr = 1000))))
  .cjqr_eal_with_seed(seed, {
    attempts <- list(); chosen <- NULL; prediction <- rep(NA_real_, nrow(newdata))
    for (a in seq_along(strategies)) {
      strategy <- strategies[[a]]; warnings <- character(); error <- ""; fit <- NULL
      set.seed(seed)
      invisible(utils::capture.output(invisible(utils::capture.output({
        fit <- tryCatch(withCallingHandlers(qgam::qgam(formula, data = data, qu = prob,
          argGam = list(method = "REML", optimizer = strategy$optimizer, control = strategy$control),
          control = list(progress = "none")), warning = function(w) {
            warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning")
          }), error = function(e) {error <<- conditionMessage(e); NULL})
      }, type = "output")), type = "message"))
      if (!is.null(fit)) fit <- .cjqr_eal_restore_formula_environment(fit, formula)
      no_outer <- !is.null(fit) && !length(fit$sp) && is.null(fit$outer.info) &&
        identical(fit$family$family, "elf") && identical(as.integer(fit$family$n.theta), 0L)
      outer_ok <- no_outer || (!is.null(fit) && if (strategy$name == "native_lbfgs")
        identical(as.integer(fit$outer.info$convergence), 0L) else
        identical(as.character(fit$outer.info$conv), "full convergence"))
      ok <- !is.null(fit) && isTRUE(fit$converged) && outer_ok &&
        all(is.finite(stats::coef(fit))) && all(is.finite(fit$sp))
      if (ok) {
        prediction <- tryCatch(as.numeric(stats::predict(fit, newdata = newdata, type = "response")),
          error = function(e) {error <<- conditionMessage(e); rep(NA_real_, nrow(newdata))})
        ok <- all(is.finite(prediction))
      }
      attempts[[a]] <- list(strategy = strategy$name, ok = ok, warnings = unique(warnings), error = error,
        no_free_outer_parameters = no_outer,
        inner_converged = if (is.null(fit)) FALSE else isTRUE(fit$converged),
        outer = if (is.null(fit)) NULL else fit$outer.info$conv,
        outer_code = if (is.null(fit)) NULL else fit$outer.info$convergence,
        outer_diagnostics = if (is.null(fit)) NULL else fit$outer.info)
      if (ok) {chosen <- fit; break}
    }
    list(ok = !is.null(chosen), prediction = if (is.null(chosen)) rep(NA_real_, nrow(newdata)) else prediction,
      outer = if (is.null(chosen)) NULL else chosen$outer.info$conv,
      outer_code = if (is.null(chosen)) NULL else chosen$outer.info$convergence,
      convergence_basis = if (is.null(chosen)) "failed" else if (no_outer)
        "native_mgcv_converged_no_free_outer_parameters" else
        if (strategies[[length(attempts)]]$name == "native_lbfgs") "native_mgcv_optim_code_0_factr1000"
        else "native_mgcv_full_convergence",
      strategy = if (is.null(chosen)) NA_character_ else strategies[[length(attempts)]]$name,
      attempts = attempts, retries = length(attempts) - 1L,
      warnings = unique(unlist(lapply(attempts, function(x) x$warnings))),
      seconds = unname(proc.time()[3L] - start), fit = chosen)
  })
}
