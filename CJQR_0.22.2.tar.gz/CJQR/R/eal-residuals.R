# Marginal diagnostic residuals only: these neither decorrelate the outcomes
# nor supply a sampling distribution after fitting or selecting the model.
residuals.cjqr_eal <- function(object,
    type = c("response", "standardized", "pit", "quantile"), ...) {
  if (length(list(...))) stop("Unsupported EAL residual arguments.", call. = FALSE)
  type <- match.arg(type)
  .cjqr_eal_require_fit(object)
  location <- .cjqr_eal_location(object$X, object$fit$beta)
  Y <- object$Y
  if (!is.matrix(Y) || !is.numeric(Y) || !identical(dim(Y), dim(location)) ||
      ncol(Y) != 2L || any(!is.finite(Y)) || any(!is.finite(location)))
    stop("Residuals require finite paired outcomes and compatible fitted locations.", call. = FALSE)
  out <- Y - location
  dimnames(out) <- list(rownames(Y) %||% rownames(location), object$responses)
  if (type == "response") return(out)
  f <- object$fit
  if (!is.numeric(f$sigma) || length(f$sigma) != 2L ||
      any(!is.finite(f$sigma)) || any(f$sigma <= 0))
    stop("Residuals require two positive finite fitted scales.", call. = FALSE)
  out <- sweep(out, 2L, f$sigma, "/")
  if (any(!is.finite(out))) stop("Nonfinite standardized EAL residuals.", call. = FALSE)
  if (type == "standardized") return(out)
  if (!is.matrix(f$shape) || !is.numeric(f$shape) ||
      !identical(dim(f$shape), c(5L, 2L)) || any(!is.finite(f$shape)))
    stop("PIT and quantile residuals require valid fitted EAL shape parameters.", call. = FALSE)
  density <- .cjqr_eal_engine(object$copula)$density
  for (j in seq_len(2L)) {
    terms <- density$eal_terms(out[, j], p = f$p, shape = f$shape[, j],
      K = 3L, derivatives = FALSE)
    lf <- terms$logF; ls <- terms$logS
    if (length(lf) != nrow(out) || length(ls) != nrow(out) ||
        anyNA(lf) || anyNA(ls) || any(lf > 0 | ls > 0))
      stop("Invalid fitted marginal tail probabilities.", call. = FALSE)
    if (type == "pit") out[, j] <- exp(lf) else {
      # Work in the smaller log tail, rather than clip a rounded PIT away from
      # 0 or 1. Genuine representational limits remain visible, not censored.
      left <- lf <= -log(2)
      out[left, j] <- stats::qnorm(lf[left], log.p = TRUE)
      out[!left, j] <- stats::qnorm(ls[!left], lower.tail = FALSE, log.p = TRUE)
    }
  }
  out
}
