# Private copula mathematics and independent numerical reference kernels.
# Current GJRM-style links only; EAL likelihood optimization lives in inst/eal-engine.
.cjqr_normalize_copula <- function(family) {
  if (!is.character(family) || length(family) != 1L || is.na(family) ||
      !nzchar(family)) {
    stop("`family` must name one copula family.", call. = FALSE)
  }
  key <- tolower(gsub("[[:space:].-]+", "_", family))
  aliases <- c(
    gaussian = "gaussian", normal = "gaussian", gauss = "gaussian",
    clayton = "clayton", frank = "frank", gumbel = "gumbel",
    student_t = "student_t", student = "student_t",
    studentt = "student_t", t = "student_t", tcopula = "student_t",
    t_copula = "student_t"
  )
  ans <- unname(aliases[key])
  if (!length(ans) || is.na(ans)) {
    stop(
      "Unsupported copula family. Choose Gaussian, Clayton, Frank, Gumbel, or Student-t.",
      call. = FALSE
    )
  }
  ans
}

.cjqr_validate_copula_df <- function(family, df = NULL) {
  family <- .cjqr_normalize_copula(family)
  if (family == "student_t") {
    if (is.null(df) || !is.numeric(df) || length(df) != 1L ||
        !is.finite(df) || df <= 0) {
      stop("Student-t copulas require one finite `df > 0`.", call. = FALSE)
    }
    return(as.numeric(df))
  }
  if (!is.null(df)) {
    stop("`df` is only defined for the Student-t copula.", call. = FALSE)
  }
  NULL
}

.cjqr_dependence_eta_limits <- function(family) {
  switch(.cjqr_normalize_copula(family),
    gaussian =, student_t = c(-8.75, 8.75),
    clayton =, gumbel = c(-17, 20), frank = c(-Inf, Inf))
}

.cjqr_clip_dependence_eta <- function(delta, family) {
  limits <- .cjqr_dependence_eta_limits(family)
  pmin(limits[[2L]], pmax(limits[[1L]], as.numeric(delta)))
}

.cjqr_theta_from_delta <- function(delta, family) {
  family <- .cjqr_normalize_copula(family)
  if (any(!is.finite(delta))) stop("Copula link values must be finite.", call. = FALSE)
  eta <- .cjqr_clip_dependence_eta(delta, family)
  ans <- switch(family, gaussian =, student_t = tanh(eta),
    clayton = exp(eta), frank = eta, gumbel = 1 + exp(eta))
  if (any(!is.finite(ans))) stop("The transformed copula parameter is outside floating-point range.", call. = FALSE)
  ans
}

.cjqr_dtheta_ddelta <- function(delta, theta, family) {
  family <- .cjqr_normalize_copula(family)
  eta <- .cjqr_clip_dependence_eta(delta, family)
  derivative <- switch(family, gaussian =, student_t = 1 - tanh(eta)^2,
    clayton = theta, frank = rep(1, length(theta)), gumbel = theta - 1)
  limits <- .cjqr_dependence_eta_limits(family)
  derivative[delta < limits[[1L]] | delta > limits[[2L]]] <- 0
  derivative
}

.cjqr_validate_copula_theta <- function(theta, family) {
  family <- .cjqr_normalize_copula(family)
  theta <- as.numeric(theta)
  if (!length(theta) || any(!is.finite(theta))) {
    stop("Copula parameters must be finite.", call. = FALSE)
  }
  valid <- switch(
    family,
    gaussian = abs(theta) < 1,
    student_t = abs(theta) < 1,
    clayton = theta >= 0,
    frank = rep(TRUE, length(theta)),
    gumbel = theta >= 1
  )
  if (any(!valid)) {
    domain <- switch(
      family,
      gaussian = "(-1, 1)", student_t = "(-1, 1)",
      clayton = "[0, Inf)", frank = "the real line",
      gumbel = "[1, Inf)"
    )
    stop("The ", family, " copula parameter must lie in ", domain, ".",
         call. = FALSE)
  }
  invisible(theta)
}

.cjqr_delta_from_theta <- function(theta, family) {
  family <- .cjqr_normalize_copula(family)
  .cjqr_validate_copula_theta(theta, family)
  theta <- as.numeric(theta)
  switch(family, gaussian =, student_t = atanh(theta),
    clayton = log(theta), frank = theta, gumbel = log(theta - 1))
}

.cjqr_recycle_copula <- function(...) {
  x <- lapply(list(...), as.numeric)
  n <- max(vapply(x, length, integer(1L)))
  lapply(x, rep, length.out = n)
}

.cjqr_logspace_add <- function(a, b) {
  m <- pmax(a, b)
  out <- m + log1p(exp(pmin(a, b) - m))
  out[is.infinite(m) & m < 0] <- -Inf
  out
}

.cjqr_z_probability_terms <- function(z) {
  logu <- stats::pnorm(z, log.p = TRUE)
  logs <- stats::pnorm(z, lower.tail = FALSE, log.p = TRUE)
  u <- ifelse(z <= 0, exp(logu), -expm1(logs))
  list(
    u = pmin(1, pmax(0, u)),
    logu = logu,
    logs = logs,
    logphi = stats::dnorm(z, log = TRUE)
  )
}

.cjqr_clayton_logS <- function(a, b) {
  small <- pmax(a, b) < 350
  out <- numeric(length(a))
  if (any(small)) {
    out[small] <- log1p(expm1(a[small]) + expm1(b[small]))
  }
  if (any(!small)) {
    aa <- a[!small]
    bb <- b[!small]
    m <- pmax(aa, bb)
    inside <- exp(aa - m) + exp(bb - m) - exp(-m)
    out[!small] <- m + log(inside)
  }
  out
}

.cjqr_clayton_terms <- function(z1, z2, theta) {
  p1 <- .cjqr_z_probability_terms(z1)
  p2 <- .cjqr_z_probability_terms(z2)
  n <- length(theta)
  logc <- dz1 <- dz2 <- dtheta <- numeric(n)
  near <- theta < 1e-6

  # The first-order expansion supplies the nonzero score at independence,
  # allowing an optimizer to move away from the delta=0 boundary.
  if (any(near)) {
    lu <- p1$logu[near]
    lv <- p2$logu[near]
    th <- theta[near]
    score0 <- (1 + lu) * (1 + lv)
    logc[near] <- th * score0
    dz1[near] <- th * (1 + lv) *
      exp(pmin(700, p1$logphi[near] - lu))
    dz2[near] <- th * (1 + lu) *
      exp(pmin(700, p2$logphi[near] - lv))
    dtheta[near] <- score0
  }

  if (any(!near)) {
    i <- !near
    th <- theta[i]
    lu <- p1$logu[i]
    lv <- p2$logu[i]
    a <- -th * lu
    b <- -th * lv
    logS <- .cjqr_clayton_logS(a, b)
    ar <- exp(a - logS)
    br <- exp(b - logS)
    logc[i] <- log1p(th) - (1 + th) * (lu + lv) -
      (2 + 1 / th) * logS
    bu <- -(1 + th) + (2 * th + 1) * ar
    bv <- -(1 + th) + (2 * th + 1) * br
    dz1[i] <- bu * exp(pmin(700, p1$logphi[i] - lu))
    dz2[i] <- bv * exp(pmin(700, p2$logphi[i] - lv))
    dlogS <- (-lu) * ar + (-lv) * br
    dtheta[i] <- 1 / (1 + th) - (lu + lv) + logS / th^2 -
      (2 + 1 / th) * dlogS
  }
  list(logc = logc, dz1 = dz1, dz2 = dz2, dtheta = dtheta)
}

.cjqr_frank_positive_core <- function(u, v, theta) {
  n <- length(theta)
  logc <- du <- dv <- dtheta <- numeric(n)
  near <- theta < 1e-5
  if (any(near)) {
    th <- theta[near]
    uu <- u[near]
    vv <- v[near]
    score0 <- 0.5 * (1 - 2 * uu) * (1 - 2 * vv)
    logc[near] <- th * score0
    du[near] <- -th * (1 - 2 * vv)
    dv[near] <- -th * (1 - 2 * uu)
    dtheta[near] <- score0
  }
  if (any(!near)) {
    i <- !near
    th <- theta[i]
    uu <- u[i]
    vv <- v[i]
    et <- exp(-th)
    eu <- exp(-th * uu)
    ev <- exp(-th * vv)
    A <- -expm1(-th)
    Au <- -expm1(-th * uu)
    Av <- -expm1(-th * vv)
    # D = A - Au*Av.  This equivalent sum avoids subtracting two values
    # rounded to one for strong positive dependence.
    D <- eu * Av + ev * (-expm1(-th * (1 - vv)))
    logc[i] <- log(th) + log(A) - th * (uu + vv) - 2 * log(D)
    du[i] <- -th + 2 * th * eu * Av / D
    dv[i] <- -th + 2 * th * ev * Au / D
    Dprime <- et - uu * eu * Av - vv * ev * Au
    dtheta[i] <- 1 / th + et / A - (uu + vv) - 2 * Dprime / D
  }
  list(logc = logc, du = du, dv = dv, dtheta = dtheta)
}

.cjqr_frank_terms <- function(z1, z2, theta) {
  p1 <- .cjqr_z_probability_terms(z1)
  p2 <- .cjqr_z_probability_terms(z2)
  ans <- list(
    logc = numeric(length(theta)), dz1 = numeric(length(theta)),
    dz2 = numeric(length(theta)), dtheta = numeric(length(theta))
  )
  positive <- theta >= 0
  if (any(positive)) {
    a <- .cjqr_frank_positive_core(
      p1$u[positive], p2$u[positive], theta[positive]
    )
    ans$logc[positive] <- a$logc
    ans$dz1[positive] <- a$du * exp(p1$logphi[positive])
    ans$dz2[positive] <- a$dv * exp(p2$logphi[positive])
    ans$dtheta[positive] <- a$dtheta
  }
  if (any(!positive)) {
    i <- !positive
    # C_{-a}(u,v) = u - C_a(u,1-v), hence
    # c_{-a}(u,v) = c_a(u,1-v).
    a <- .cjqr_frank_positive_core(
      p1$u[i], 1 - p2$u[i], -theta[i]
    )
    ans$logc[i] <- a$logc
    ans$dz1[i] <- a$du * exp(p1$logphi[i])
    ans$dz2[i] <- -a$dv * exp(p2$logphi[i])
    ans$dtheta[i] <- -a$dtheta
  }
  ans
}

.cjqr_gumbel_log_core <- function(logu, logv, theta, scores = FALSE) {
  # u and v are strictly inside (0,1) in likelihood evaluation.  The floor
  # only protects log(0) after a probability rounds to one in a machine tail.
  x <- pmax(-logu, .Machine$double.xmin)
  y <- pmax(-logv, .Machine$double.xmin)
  lx <- log(x)
  ly <- log(y)
  logA <- .cjqr_logspace_add(theta * lx, theta * ly)
  t <- exp(logA / theta)
  wx <- exp(theta * lx - logA)
  wy <- exp(theta * ly - logA)
  q <- (theta - 1) / t
  logc <- -t - logu - logv + (theta - 1) * (lx + ly) +
    (2 / theta - 2) * logA + log1p(q)
  exact_independence <- theta == 1
  logc[exact_independence] <- 0
  if (!scores) return(logc)
  common <- t + 2 * (theta - 1) + q / (1 + q)
  dx <- 1 + (theta - 1) / x - common * wx / x
  dy <- 1 + (theta - 1) / y - common * wy / y
  dx[exact_independence] <- 0
  dy[exact_independence] <- 0
  list(logc = logc, dx = dx, dy = dy)
}

.cjqr_gumbel_terms <- function(z1, z2, theta) {
  p1 <- .cjqr_z_probability_terms(z1)
  p2 <- .cjqr_z_probability_terms(z2)
  core <- .cjqr_gumbel_log_core(p1$logu, p2$logu, theta, scores = TRUE)
  dz1 <- -core$dx * exp(pmin(700, p1$logphi - p1$logu))
  dz2 <- -core$dy * exp(pmin(700, p2$logphi - p2$logu))

  x <- pmax(-p1$logu, .Machine$double.xmin)
  y <- pmax(-p2$logu, .Machine$double.xmin)
  lx <- log(x)
  ly <- log(y)
  logA <- .cjqr_logspace_add(theta * lx, theta * ly)
  wx <- exp(theta * lx - logA)
  wy <- exp(theta * ly - logA)
  mean_log <- wx * lx + wy * ly
  t <- exp(logA / theta)
  dlogt <- mean_log / theta - logA / theta^2
  dtheta <- -t * dlogt + lx + ly - 2 * logA / theta^2 +
    (2 / theta - 2) * mean_log +
    (1 - (theta - 1) * dlogt) / (t + theta - 1)
  list(logc = core$logc, dz1 = dz1, dz2 = dz2, dtheta = dtheta)
}

.cjqr_student_quantile_from_z <- function(z, df) {
  lower <- z <= 0
  ans <- numeric(length(z))
  if (any(lower)) {
    ans[lower] <- stats::qt(stats::pnorm(z[lower], log.p = TRUE),
                            df = df, log.p = TRUE)
  }
  if (any(!lower)) {
    ans[!lower] <- stats::qt(
      stats::pnorm(z[!lower], lower.tail = FALSE, log.p = TRUE),
      df = df, lower.tail = FALSE, log.p = TRUE
    )
  }
  ans
}

.cjqr_student_terms <- function(z1, z2, rho, df) {
  q1 <- .cjqr_student_quantile_from_z(z1, df)
  q2 <- .cjqr_student_quantile_from_z(z2, df)
  d <- 1 - rho^2
  N <- q1^2 - 2 * rho * q1 * q2 + q2^2
  Q <- N / d
  log_joint <- lgamma((df + 2) / 2) - lgamma(df / 2) -
    log(df * pi) - 0.5 * log(d) - (df + 2) / 2 * log1p(Q / df)
  logc <- log_joint - stats::dt(q1, df = df, log = TRUE) -
    stats::dt(q2, df = df, log = TRUE)

  dq1 <- -(df + 2) * (q1 - rho * q2) / (d * (df + Q)) +
    (df + 1) * q1 / (df + q1^2)
  dq2 <- -(df + 2) * (q2 - rho * q1) / (d * (df + Q)) +
    (df + 1) * q2 / (df + q2^2)
  ratio1 <- exp(pmin(700, stats::dnorm(z1, log = TRUE) -
                            stats::dt(q1, df = df, log = TRUE)))
  ratio2 <- exp(pmin(700, stats::dnorm(z2, log = TRUE) -
                            stats::dt(q2, df = df, log = TRUE)))
  dz1 <- dq1 * ratio1
  dz2 <- dq2 * ratio2

  dQ <- 2 * (rho * N - q1 * q2 * d) / d^2
  drho <- rho / d - (df + 2) * dQ / (2 * (df + Q))
  list(logc = logc, dz1 = dz1, dz2 = dz2, dtheta = drho,
       q1 = q1, q2 = q2)
}

.cjqr_copula_terms <- function(
    z1, z2, delta, family, df = NULL) {
  family <- .cjqr_normalize_copula(family)
  df <- .cjqr_validate_copula_df(family, df)
  values <- .cjqr_recycle_copula(z1, z2, delta)
  z1 <- values[[1L]]
  z2 <- values[[2L]]
  delta <- values[[3L]]
  if (any(!is.finite(c(z1, z2, delta)))) {
    n <- length(delta)
    return(list(
      logc = rep(NA_real_, n), dz1 = rep(NA_real_, n),
      dz2 = rep(NA_real_, n), dtheta = rep(NA_real_, n),
      ddelta = rep(NA_real_, n), theta = rep(NA_real_, n),
      rho = rep(NA_real_, n), family = family, df = df
    ))
  }
  theta <- .cjqr_theta_from_delta(
    delta, family
  )
  .cjqr_validate_copula_theta(theta, family)
  core <- switch(
    family,
    gaussian = {
      ans <- .gaussian_copula_terms(
        z1, z2, delta
      )
      list(logc = ans$logc, dz1 = ans$dz1, dz2 = ans$dz2,
           dtheta = ans$drho, ddelta = ans$ddelta)
    },
    clayton = .cjqr_clayton_terms(z1, z2, theta),
    frank = .cjqr_frank_terms(z1, z2, theta),
    gumbel = .cjqr_gumbel_terms(z1, z2, theta),
    student_t = .cjqr_student_terms(z1, z2, theta, df)
  )
  dlink <- .cjqr_dtheta_ddelta(
    delta, theta, family
  )
  rho <- if (family %in% c("gaussian", "student_t")) theta else
    rep(NA_real_, length(theta))
  list(
    logc = core$logc, dz1 = core$dz1, dz2 = core$dz2,
    dtheta = core$dtheta,
    ddelta = if (identical(family, "gaussian")) {
      core$ddelta
    } else {
      core$dtheta * dlink
    },
    theta = theta, rho = rho, family = family, df = df
  )
}

.cjqr_copula_log_density <- function(u1, u2, theta, family, df = NULL) {
  family <- .cjqr_normalize_copula(family)
  df <- .cjqr_validate_copula_df(family, df)
  values <- .cjqr_recycle_copula(u1, u2, theta)
  u1 <- values[[1L]]
  u2 <- values[[2L]]
  theta <- values[[3L]]
  if (any(!is.finite(c(u1, u2, theta))) ||
      any(u1 <= 0 | u1 >= 1 | u2 <= 0 | u2 >= 1)) {
    stop("Copula density probabilities must lie strictly inside (0, 1).",
         call. = FALSE)
  }
  .cjqr_validate_copula_theta(theta, family)
  z1 <- stats::qnorm(u1)
  z2 <- stats::qnorm(u2)
  switch(
    family,
    gaussian = {
      d <- 1 - theta^2
      -0.5 * log(d) -
        (theta^2 * (z1^2 + z2^2) - 2 * theta * z1 * z2) / (2 * d)
    },
    clayton = .cjqr_clayton_terms(z1, z2, theta)$logc,
    frank = .cjqr_frank_terms(z1, z2, theta)$logc,
    gumbel = .cjqr_gumbel_terms(z1, z2, theta)$logc,
    student_t = .cjqr_student_terms(z1, z2, theta, df)$logc
  )
}

.cjqr_frank_positive_cdf <- function(u, v, theta) {
  near <- abs(theta) < 1e-6
  out <- u * v
  if (any(!near)) {
    i <- !near
    th <- theta[i]
    uu <- u[i]
    vv <- v[i]
    both_high <- uu > 0.5 & vv > 0.5
    first_high <- uu > 0.5 & !both_high
    second_high <- vv > 0.5 & !both_high
    low <- !both_high & !first_high & !second_high
    value <- numeric(length(th))
    if (any(low)) {
      tl <- th[low]
      ul <- uu[low]
      vl <- vv[low]
      ratio <- expm1(-tl * ul) * expm1(-tl * vl) / expm1(-tl)
      stable_direct <- is.finite(ratio) & ratio > -1 + 1e-8
      low_value <- numeric(length(tl))
      if (any(stable_direct)) {
        low_value[stable_direct] <-
          -log1p(ratio[stable_direct]) / tl[stable_direct]
      }
      if (any(!stable_direct)) {
        j <- !stable_direct
        tj <- tl[j]
        uj <- ul[j]
        vj <- vl[j]
        log_a <- log(-expm1(-tj))
        log_d <- .cjqr_logspace_add(
          -tj * uj + log(-expm1(-tj * vj)),
          -tj * vj + log(-expm1(-tj * (1 - vj)))
        )
        low_value[j] <- (log_a - log_d) / tj
      }
      value[low] <- low_value
    }
    if (any(both_high)) {
      value[both_high] <- uu[both_high] + vv[both_high] - 1 +
        .cjqr_frank_positive_cdf(
          1 - uu[both_high], 1 - vv[both_high], th[both_high]
        )
    }
    if (any(first_high)) {
      value[first_high] <- vv[first_high] -
        .cjqr_frank_positive_cdf(
          1 - uu[first_high], vv[first_high], -th[first_high]
        )
    }
    if (any(second_high)) {
      value[second_high] <- uu[second_high] -
        .cjqr_frank_positive_cdf(
          uu[second_high], 1 - vv[second_high], -th[second_high]
        )
    }
    out[i] <- value
  }
  pmin(1, pmax(0, out))
}

.cjqr_student_cdf_one <- function(u, v, rho, df, rel.tol = 1e-8) {
  if (u <= 0 || v <= 0) return(0)
  if (u >= 1) return(v)
  if (v >= 1) return(u)
  if (u > 0.5 && v > 0.5) {
    return(pmin(1, pmax(0, u + v - 1 +
      .cjqr_student_cdf_one(1 - u, 1 - v, rho, df, rel.tol))))
  }
  if (u > 0.5) {
    return(pmin(1, pmax(0, v -
      .cjqr_student_cdf_one(1 - u, v, -rho, df, rel.tol))))
  }
  if (v > 0.5) {
    return(pmin(1, pmax(0, u -
      .cjqr_student_cdf_one(u, 1 - v, -rho, df, rel.tol))))
  }
  if (v < u) {
    return(.cjqr_student_cdf_one(v, u, rho, df, rel.tol))
  }
  q2 <- stats::qt(v, df = df)
  den <- 1 - rho^2
  tail_limit <- stats::pt(
    rho * sqrt((df + 1) / den), df = df + 1
  )
  integrand <- function(t) {
    out <- rep(tail_limit, length(t))
    positive <- is.finite(t) & t > 0
    if (!any(positive)) return(out)
    logp <- log(u) + log(t[positive])
    x <- stats::qt(logp, df = df, log.p = TRUE)
    finite_x <- is.finite(x)
    value <- rep(tail_limit, length(x))
    if (any(finite_x)) {
      xx <- x[finite_x]
      scale <- pmax(sqrt(df), abs(xx))
      norm <- scale * sqrt(df / scale^2 + (xx / scale)^2)
      arg <- sqrt((df + 1) / den) * (q2 / norm - rho * xx / norm)
      value[finite_x] <- stats::pt(arg, df = df + 1)
    }
    out[positive] <- value
    out
  }
  value <- tryCatch(
    u * stats::integrate(
      integrand, lower = 0, upper = 1, rel.tol = rel.tol,
      subdivisions = 600L, stop.on.error = FALSE
    )$value,
    error = function(e) NA_real_
  )
  pmin(1, pmax(0, value))
}

.cjqr_copula_cdf <- function(u1, u2, theta, family, df = NULL) {
  family <- .cjqr_normalize_copula(family)
  df <- .cjqr_validate_copula_df(family, df)
  values <- .cjqr_recycle_copula(u1, u2, theta)
  u1 <- values[[1L]]
  u2 <- values[[2L]]
  theta <- values[[3L]]
  if (any(u1 < 0 | u1 > 1 | u2 < 0 | u2 > 1, na.rm = TRUE)) {
    stop("Copula CDF probabilities must lie in [0, 1].", call. = FALSE)
  }
  if (any(is.infinite(theta))) {
    stop("Copula parameters must be finite.", call. = FALSE)
  }
  finite_theta <- theta[is.finite(theta)]
  if (length(finite_theta)) {
    .cjqr_validate_copula_theta(finite_theta, family)
  }
  ans <- rep(NA_real_, length(theta))
  valid <- !is.na(u1) & !is.na(u2) & !is.na(theta)
  zero <- valid & (u1 <= 0 | u2 <= 0)
  ans[zero] <- 0
  edge1 <- valid & !zero & u1 >= 1
  edge2 <- valid & !zero & u2 >= 1
  ans[edge1] <- u2[edge1]
  ans[edge2] <- u1[edge2]
  ans[valid & u1 >= 1 & u2 >= 1] <- 1
  mid <- valid & u1 > 0 & u1 < 1 & u2 > 0 & u2 < 1
  if (!any(mid)) return(ans)

  uu <- u1[mid]
  vv <- u2[mid]
  th <- theta[mid]
  ans[mid] <- switch(
    family,
    gaussian = .gaussian_copula_cdf(uu, vv, th),
    clayton = {
      independent <- th < 1e-7
      value <- uu * vv
      if (any(!independent)) {
        j <- !independent
        logS <- .cjqr_clayton_logS(-th[j] * log(uu[j]),
                                     -th[j] * log(vv[j]))
        value[j] <- exp(-logS / th[j])
      }
      value
    },
    frank = .cjqr_frank_positive_cdf(uu, vv, th),
    gumbel = {
      x <- -log(uu)
      y <- -log(vv)
      logA <- .cjqr_logspace_add(th * log(x), th * log(y))
      exp(-exp(logA / th))
    },
    student_t = vapply(
      seq_along(uu),
      function(i) .cjqr_student_cdf_one(uu[i], vv[i], th[i], df),
      numeric(1L)
    )
  )
  pmin(1, pmax(0, ans))
}

.cjqr_frank_positive_hfunc <- function(u, v, theta) {
  near <- theta < 1e-6
  h21 <- v
  h12 <- u
  if (any(!near)) {
    i <- !near
    th <- theta[i]
    uu <- u[i]
    vv <- v[i]
    eu <- exp(-th * uu)
    ev <- exp(-th * vv)
    Au <- -expm1(-th * uu)
    Av <- -expm1(-th * vv)
    D <- eu * Av + ev * (-expm1(-th * (1 - vv)))
    h21[i] <- eu * Av / D
    h12[i] <- ev * Au / D
  }
  list(h21 = h21, h12 = h12)
}

.cjqr_copula_hfunc <- function(u1, u2, theta, family, df = NULL) {
  family <- .cjqr_normalize_copula(family)
  df <- .cjqr_validate_copula_df(family, df)
  values <- .cjqr_recycle_copula(u1, u2, theta)
  u1 <- values[[1L]]
  u2 <- values[[2L]]
  theta <- values[[3L]]
  if (any(!is.finite(c(u1, u2, theta))) ||
      any(u1 < 0 | u1 > 1 | u2 < 0 | u2 > 1)) {
    stop("Copula h-function probabilities must be finite and lie in [0, 1].",
         call. = FALSE)
  }
  .cjqr_validate_copula_theta(theta, family)
  # Conditional limits at exactly zero or one are interpreted by continuity.
  eps <- 1e-12
  uu <- pmin(1 - eps, pmax(eps, u1))
  vv <- pmin(1 - eps, pmax(eps, u2))
  ans <- switch(
    family,
    gaussian = {
      z1 <- stats::qnorm(uu)
      z2 <- stats::qnorm(vv)
      den <- sqrt(1 - theta^2)
      list(
        h21 = stats::pnorm((z2 - theta * z1) / den),
        h12 = stats::pnorm((z1 - theta * z2) / den)
      )
    },
    student_t = {
      q1 <- stats::qt(uu, df = df)
      q2 <- stats::qt(vv, df = df)
      den <- 1 - theta^2
      list(
        h21 = stats::pt(
          (q2 - theta * q1) *
            sqrt((df + 1) / ((df + q1^2) * den)),
          df = df + 1
        ),
        h12 = stats::pt(
          (q1 - theta * q2) *
            sqrt((df + 1) / ((df + q2^2) * den)),
          df = df + 1
        )
      )
    },
    clayton = {
      independent <- theta < 1e-7
      h21 <- vv
      h12 <- uu
      if (any(!independent)) {
        i <- !independent
        logS <- .cjqr_clayton_logS(-theta[i] * log(uu[i]),
                                     -theta[i] * log(vv[i]))
        logC <- -logS / theta[i]
        h21[i] <- exp((theta[i] + 1) * (logC - log(uu[i])))
        h12[i] <- exp((theta[i] + 1) * (logC - log(vv[i])))
      }
      list(h21 = h21, h12 = h12)
    },
    frank = {
      positive <- theta >= 0
      h21 <- h12 <- numeric(length(theta))
      if (any(positive)) {
        tmp <- .cjqr_frank_positive_hfunc(
          uu[positive], vv[positive], theta[positive]
        )
        h21[positive] <- tmp$h21
        h12[positive] <- tmp$h12
      }
      if (any(!positive)) {
        i <- !positive
        tmp <- .cjqr_frank_positive_hfunc(
          uu[i], 1 - vv[i], -theta[i]
        )
        h21[i] <- 1 - tmp$h21
        h12[i] <- tmp$h12
      }
      list(h21 = h21, h12 = h12)
    },
    gumbel = {
      x <- -log(uu)
      y <- -log(vv)
      logA <- .cjqr_logspace_add(theta * log(x), theta * log(y))
      t <- exp(logA / theta)
      C <- exp(-t)
      wx <- exp(theta * log(x) - logA)
      wy <- exp(theta * log(y) - logA)
      list(
        h21 = C * t * wx / (x * uu),
        h12 = C * t * wy / (y * vv)
      )
    }
  )
  ans$h21 <- pmin(1, pmax(0, ans$h21))
  ans$h12 <- pmin(1, pmax(0, ans$h12))
  ans$h21[u2 <= 0] <- 0
  ans$h21[u2 >= 1] <- 1
  ans$h12[u1 <= 0] <- 0
  ans$h12[u1 >= 1] <- 1
  ans
}

.cjqr_frank_positive_simulate <- function(n, theta) {
  theta <- as.numeric(theta)
  if (!length(theta) %in% c(1L, n) || any(!is.finite(theta)) ||
      any(theta < 0)) {
    stop("Positive Frank simulation requires one parameter or one nonnegative parameter per row.",
         call. = FALSE)
  }
  theta <- rep(theta, length.out = n)
  u <- stats::runif(n)
  w <- stats::runif(n)
  v <- w
  active <- theta >= 1e-7
  if (any(active)) {
    th <- theta[active]
    uu <- u[active]
    ww <- w[active]
    # Stable logarithm of exp(-theta*v) after conditional inversion.
    log_num <- .cjqr_logspace_add(log1p(-ww) - th * uu,
                                    log(ww) - th)
    log_den <- log(ww + (1 - ww) * exp(-th * uu))
    v[active] <- - (log_num - log_den) / th
  }
  cbind(u, pmin(1, pmax(0, v)))
}

.cjqr_simulate_copula_uv <- function(n, theta, family, df = NULL) {
  family <- .cjqr_normalize_copula(family)
  df <- .cjqr_validate_copula_df(family, df)
  if (!is.numeric(n) || length(n) != 1L || !is.finite(n) ||
      n < 1 || n != floor(n) || n > .Machine$integer.max) {
    stop("`n` must be one positive integer.", call. = FALSE)
  }
  n <- as.integer(n)
  if (!is.numeric(theta) || !length(theta) ||
      !length(theta) %in% c(1L, n) || any(!is.finite(theta))) {
    stop("Simulation requires one finite copula parameter or one finite parameter per row.",
         call. = FALSE)
  }
  theta <- as.numeric(theta)
  theta <- rep(theta, length.out = n)
  .cjqr_validate_copula_theta(theta, family)
  ans <- switch(
    family,
    gaussian = {
      z1 <- stats::rnorm(n)
      z2 <- theta * z1 + sqrt(1 - theta^2) * stats::rnorm(n)
      cbind(stats::pnorm(z1), stats::pnorm(z2))
    },
    student_t = {
      z1 <- stats::rnorm(n)
      z2 <- theta * z1 + sqrt(1 - theta^2) * stats::rnorm(n)
      common_scale <- sqrt(stats::rchisq(n, df = df) / df)
      cbind(stats::pt(z1 / common_scale, df = df),
            stats::pt(z2 / common_scale, df = df))
    },
    clayton = {
      u <- stats::runif(n)
      w <- stats::runif(n)
      v <- w
      active <- theta >= 1e-7
      if (any(active)) {
        th <- theta[active]
        uu <- u[active]
        ww <- w[active]
        log_u_power <- -th * log(uu)
        b <- -(th / (th + 1)) * log(ww)
        log_expm1_b <- numeric(length(th))
        large <- b > 50
        log_expm1_b[large] <- b[large] + log1p(-exp(-b[large]))
        log_expm1_b[!large] <- log(expm1(b[!large]))
        log_v_power <- .cjqr_logspace_add(
          0, log_u_power + log_expm1_b
        )
        v[active] <- exp(-log_v_power / th)
      }
      cbind(u, v)
    },
    frank = {
      uv <- .cjqr_frank_positive_simulate(n, abs(theta))
      negative <- theta < 0
      if (any(negative)) uv[negative, 2L] <- 1 - uv[negative, 2L]
      uv
    },
    gumbel = {
      independence <- theta == 1
      draw_gumbel <- function(th) {
        m <- length(th)
        alpha <- 1 / th
        angle <- stats::runif(m, 0, pi)
        exponential <- stats::rexp(m)
        log_frailty <- log(sin(alpha * angle)) -
          log(sin(angle)) / alpha +
          ((1 - alpha) / alpha) *
          (log(sin((1 - alpha) * angle)) - log(exponential))
        e1 <- stats::rexp(m)
        e2 <- stats::rexp(m)
        log_nl1 <- alpha * (log(e1) - log_frailty)
        log_nl2 <- alpha * (log(e2) - log_frailty)
        cbind(exp(-exp(log_nl1)), exp(-exp(log_nl2)))
      }
      if (all(independence)) {
        cbind(stats::runif(n), stats::runif(n))
      } else if (!any(independence)) {
        draw_gumbel(theta)
      } else {
        out <- cbind(stats::runif(n), stats::runif(n))
        active <- !independence
        out[active, ] <- draw_gumbel(theta[active])
        out
      }
    }
  )
  ans[] <- pmin(1 - .Machine$double.eps,
                pmax(.Machine$double.xmin, as.numeric(ans)))
  colnames(ans) <- c("u1", "u2")
  ans
}

.cjqr_copula_simulate <- function(n, theta, family, df = NULL) {
  .cjqr_simulate_copula_uv(n, theta, family, df)
}

.cjqr_frank_kendall_tau_core <- function(theta) {
  vapply(theta, function(x) {
    if (x == 0) return(0)
    sign_x <- sign(x)
    a <- abs(x)
    if (a < 1e-4) {
      return(x / 9 - x^3 / 900 + x^5 / 52920)
    }
    integrand <- function(t) {
      out <- numeric(length(t))
      small <- abs(t) < sqrt(.Machine$double.eps)
      regular <- !small & t <= 700
      out[small] <- 1
      out[regular] <- t[regular] / expm1(t[regular])
      out
    }
    integral <- stats::integrate(
      integrand, 0, a, rel.tol = 1e-9,
      subdivisions = 300L, stop.on.error = FALSE
    )$value
    sign_x * (1 - 4 / a + 4 * integral / a^2)
  }, numeric(1L))
}

.cjqr_kendall_tau <- function(theta, family, df = NULL) {
  family <- .cjqr_normalize_copula(family)
  # Student-t Kendall tau is df-invariant.  Validate df when a caller supplies
  # it, while keeping the transformation usable from summary paths that
  # only carry theta.
  if (!is.null(df)) {
    if (family != "student_t") {
      stop("`df` is only defined for the Student-t copula.", call. = FALSE)
    }
    .cjqr_validate_copula_df(family, df)
  }
  .cjqr_validate_copula_theta(theta, family)
  theta <- as.numeric(theta)
  switch(
    family,
    gaussian =,
    student_t = 2 / pi * asin(theta),
    clayton = theta / (theta + 2),
    frank = .cjqr_frank_kendall_tau_core(theta),
    gumbel = 1 - 1 / theta
  )
}

.cjqr_copula_theta_from_tau <- function(tau, family) {
  family <- .cjqr_normalize_copula(family)
  tau <- as.numeric(tau)
  if (!length(tau) || any(!is.finite(tau))) {
    stop("Kendall's tau values must be finite.", call. = FALSE)
  }
  positive_only <- family %in% c("clayton", "gumbel")
  if (any(tau <= -1 | tau >= 1) || (positive_only && any(tau < 0))) {
    domain <- if (positive_only) "[0, 1)" else "(-1, 1)"
    stop("Kendall's tau must lie in ", domain, " for the ", family,
         " copula.", call. = FALSE)
  }
  switch(
    family,
    gaussian =,
    student_t = sin(pi * tau / 2),
    clayton = 2 * tau / (1 - tau),
    gumbel = 1 / (1 - tau),
    frank = vapply(tau, function(target) {
      if (target == 0) return(0)
      target_abs <- abs(target)
      upper <- 1
      while (.cjqr_frank_kendall_tau_core(upper) < target_abs &&
             upper < 1e8) {
        upper <- 2 * upper
      }
      root <- stats::uniroot(
        function(x) .cjqr_frank_kendall_tau_core(x) - target_abs,
        lower = 0, upper = upper, tol = 1e-10
      )$root
      sign(target) * root
    }, numeric(1L))
  )
}
